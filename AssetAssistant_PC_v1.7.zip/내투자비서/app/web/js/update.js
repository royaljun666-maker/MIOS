/* ==========================================================================
   update.js — 자동 업데이트 알림 · 사용 잠금(킬 스위치)
   앱을 켤 때 클라우드의 '관리 파일'(update.json)을 서버가 확인해서:
     · 새 버전 있으면  → "업데이트 있어요 · 받기" 안내
     · 사용 허용을 끄거나 파일을 지우면 → 사용 중지 화면으로 막음
   ========================================================================== */
'use strict';

let _upd = null;
function openApk(url) {
  if (!IS_APP && _upd && _upd.pc) url = _upd.pc;
  if (!url) { toast('내려받을 주소가 없어요. 관리 파일의 apk 주소를 확인해 주세요.', 3500); return; }
  try { if (IS_APP) location.href = url; else window.open(url, '_blank', 'noopener'); } catch (e) { location.href = url; }
}

/* 사용 중지 전체 화면 */
function appBlock(o) {
  let el = document.getElementById('appBlock');
  if (!el) { el = document.createElement('div'); el.id = 'appBlock'; el.className = 'appblock'; document.body.appendChild(el); }
  el.innerHTML =
    '<div class="ab-box"><div class="ab-ico">' + icon(o.icon || 'lock') + '</div>' +
    '<h2>' + esc(o.title) + '</h2><p>' + esc(o.msg).replace(/\n/g, '<br>') + '</p>' +
    '<div class="ab-acts">' +
      (o.apk ? '<button class="btn btn-primary btn-lg" id="abGet">' + icon('download') + '새 버전 받기</button>' : '') +
      '<button class="btn btn-gray" id="abRetry">' + icon('refresh', 'ic-sm') + '다시 확인</button>' +
    '</div></div>';
  hydrateIcons(el);
  document.documentElement.style.overflow = 'hidden';
  const g = el.querySelector('#abGet'); if (g) g.onclick = () => openApk(o.apk);
  el.querySelector('#abRetry').onclick = () => { el.querySelector('#abRetry').classList.add('loading'); checkUpdate(true); };
}
function clearBlock() { const el = document.getElementById('appBlock'); if (el) el.remove(); document.documentElement.style.overflow = ''; }

/* 위쪽 업데이트 안내 띠 */
function updateBanner(o) {
  if (document.getElementById('updBanner')) return;
  const b = document.createElement('div'); b.id = 'updBanner'; b.className = 'upd-banner';
  b.innerHTML = '<span class="ic" data-icon="download"></span><div class="ub-txt"><b>새 버전이 나왔어요' + (o.latest_name ? ' (v' + esc(o.latest_name) + ')' : '') + '</b>' +
    (o.notice ? '<span>' + esc(o.notice) + '</span>' : '<span>받기를 눌러 업데이트하세요. 지금 정보는 그대로 유지돼요.</span>') + '</div>' +
    '<button class="btn btn-primary btn-sm" id="ubGet">받기</button><button class="ub-x" id="ubX" aria-label="닫기">✕</button>';
  document.body.appendChild(b); hydrateIcons(b);
  document.body.classList.add('has-banner');
  b.querySelector('#ubGet').onclick = () => openApk(o.apk);
  b.querySelector('#ubX').onclick = () => { b.remove(); document.body.classList.remove('has-banner'); };
}

async function checkUpdate(manual) {
  let d;
  try { d = await api('/api/update', { timeout: 12000 }); }
  catch (e) {
    // 확인 실패 시 잠금 화면은 그대로 둠(눌러서 풀리면 안 됨) — 버튼만 원래대로
    if (manual) { const r = document.getElementById('abRetry'); if (r) r.classList.remove('loading'); toast('확인하지 못했어요. 잠시 후 다시 시도해 주세요'); }
    return;
  }
  _upd = d;
  if (!d || !d.configured) return;                 // 관리 파일 주소가 아직 설정 안 됨 → 평소대로
  const grace = d.grace_days || 7;

  // ① 사용 중지(관리 파일에서 껐거나 파일을 지움)
  if (d.status === 'deleted') {
    appBlock({ title: '앱 사용이 중지되었어요', icon: 'lock',
      msg: '지금은 이 앱을 쓸 수 없어요.\n만든 사람에게 문의해 주세요.' });
    return;
  }
  if (d.status === 'ok' && d.enabled === false) {
    appBlock({ title: '앱 사용이 잠시 중지되었어요', icon: 'lock',
      msg: d.notice || '점검 중이에요. 잠시 뒤 다시 켜 주세요.', apk: d.apk && d.latest > d.current ? d.apk : '' });
    return;
  }
  // ② 인터넷으로 오래 확인 못 함 → 유예 지나면 막기 (비행기모드 등 짧은 끊김은 통과)
  if (d.status === 'offline') {
    const days = d.days_since_ok;
    if (days != null && days > grace) {
      appBlock({ title: '인터넷 연결이 필요해요', icon: 'wifi',
        msg: '업데이트 확인을 ' + Math.floor(days) + '일 동안 못 했어요.\n인터넷에 연결한 뒤 다시 확인을 눌러 주세요.' });
    } else { clearBlock(); }
    return;
  }
  // ③ 정상 — 새 버전?
  clearBlock();
  otaNotice(d);
  if (d.status === 'ok' && d.latest > d.current) {
    if (d.require) {
      appBlock({ title: '업데이트가 필요해요', icon: 'download',
        msg: (d.notice || '새 버전으로 바꿔야 계속 쓸 수 있어요.') + '\n\n받기를 눌러 설치하면 지금 정보는 그대로 유지돼요.', apk: d.apk });
    } else { updateBanner(d); }
  } else if (manual) {
    toast('최신 버전을 쓰고 있어요');
  }
}

/* 자동 업데이트(폰): 새 기능을 받아 뒀거나 방금 적용됐을 때 알려 주기 */
function otaNotice(d) {
  const o = d && d.ota; if (!o) return;
  let seen = {}; try { seen = JSON.parse(localStorage.getItem('ota_seen') || '{}'); } catch (e) {}
  const name = c => 'v' + Math.floor(c / 100) + '.' + (c % 100);
  if (o.applied && seen.applied !== o.applied) {
    seen.applied = o.applied;
    setTimeout(() => toast('✨ ' + name(o.applied) + '(으)로 자동 업데이트됐어요', 4000), 1200);
  } else if (o.ready && seen.ready !== o.ready) {
    seen.ready = o.ready;
    toast('새 기능(' + name(o.ready) + ')을 받아 뒀어요. 앱을 완전히 닫았다 다시 켜면 적용돼요', 5000);
  }
  try { localStorage.setItem('ota_seen', JSON.stringify(seen)); } catch (e) {}
}
