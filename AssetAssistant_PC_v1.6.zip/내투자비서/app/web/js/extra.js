/* ==========================================================================
   extra.js — 관심종목(즐겨찾기) · AI 종목 발굴(추천)
   ========================================================================== */
'use strict';

/* 관심종목에 담긴 코드로 시세를 받아 가격·등락을 채움 */
let _watchBusy = false;
async function refreshWatchPrices(force) {
  const list = watchlist().filter(w => w.ticker);
  if (!list.length || _watchBusy) return;
  if (!force && list.every(w => w.cur && Date.now() - (w.at || 0) < 120000)) return;
  _watchBusy = true;
  try {
    const items = [...new Set(list.map(w => w.ticker + ':' + (w.market || 'kr')))].join(',');
    const data = await api('/prices?items=' + encodeURIComponent(items), { timeout: 60000 });
    list.forEach(w => {
      const d = data[w.ticker + ':' + (w.market || 'kr')];
      if (d && d.price > 0) {
        w.cur = d.price; w.at = Date.now();
        if (d.name && String(d.name).trim()) w.name = String(d.name).trim();
        if (d.change_pct != null && isFinite(d.change_pct)) w.chg = d.change_pct;
        storeFund(w, d);
      }
    });
    save({ noSync: true });
  } catch (e) { /* 서버 꺼짐 등 */ } finally { _watchBusy = false; }
}

function watchColor(w) { const n = dispName(w); return /^[A-Za-z]/.test(n) || w.market === 'us' ? 'var(--c2)' : 'var(--c1)'; }

PAGES.watch = function (params, isRe) {
  const el = pageEl('watch');
  const list = watchlist();
  const st = TRADE_STYLES[tradeStyle()];
  const styleChips = '<div class="chips" style="margin-bottom:4px">' + Object.values(TRADE_STYLES).map(s =>
    '<button class="chip ' + (s.key === tradeStyle() ? 'on' : '') + '" data-act="set-style" data-v="' + s.key + '">' + s.emoji + ' ' + s.label + '</button>').join('') + '</div>';

  const cards = list.length ? list.map(w => {
    const chg = (w.chg != null && w.chgAt !== undefined) || w.chg != null ? w.chg : null;
    const per = (w.per != null && w.per !== '') ? 'PER ' + num(w.per).toFixed(1) : '';
    return '<div class="wl-card" data-act="watch-insight" data-t="' + esc(w.ticker) + '">' +
      '<div class="logo" style="background:' + watchColor(w) + '">' + esc(logoTxt(w)) + '</div>' +
      '<div class="mid"><b>' + esc(dispName(w)) + '</b><span>' + esc(w.ticker || '') + (w.market === 'us' ? ' · 미국' : ' · 국내') + (per ? ' · ' + per : '') + '</span></div>' +
      '<div class="end">' + (w.cur ? '<b>' + priceTxt(w.cur, w.ccy) + '</b>' : '<b class="muted">–</b>') +
        (chg != null ? '<span class="' + cls(chg) + '">' + pct(chg) + '</span>' : '<span class="muted">시세 갱신</span>') + '</div>' +
      '<button class="wl-x" data-act="watch-del" data-t="' + esc(w.ticker) + '" title="관심 삭제">' + icon('x', 'ic-sm') + '</button></div>';
  }).join('') : '';

  const aiOn = AI_STATUS && AI_STATUS.on;
  el.innerHTML =
    '<div class="page-head"><div><h1>관심 · 발굴</h1><div class="desc">안 가진 종목도 담아 두고 지켜보고, AI에게 새 종목을 추천받아요</div></div>' +
      '<div class="actions"><button class="btn btn-primary" data-act="watch-add">' + icon('plus') + '관심종목 추가</button></div></div>' +

    '<div class="card" style="margin-bottom:16px"><div class="card-head"><h3>' + icon('radar', 'ic-sm') + 'AI 종목 발굴</h3>' +
      '<span class="badge ' + (aiOn ? 'green' : 'orange') + '">' + (aiOn ? 'AI 연결됨' : 'AI 연결 전') + '</span></div>' +
      '<p class="note" style="margin:0 0 12px">내 종목·관심종목과 요즘 시장 흐름을 보고, 지금 관심 가질 만한 <b>새 종목 후보</b>를 추천해요. ' +
        '<b>참고용</b>이에요 — 사는 건 직접 판단하세요.</p>' +
      '<div style="font-size:.84rem;color:var(--text-3);font-weight:650;margin-bottom:6px">내 투자 성향 (추천·분석에 반영돼요)</div>' + styleChips +
      '<button class="btn btn-soft btn-block" style="margin-top:12px" data-act="discover">' + icon('sparkles') + (aiOn ? 'AI에게 종목 추천받기' : '먼저 AI를 연결해 주세요') + '</button>' +
      '<div id="discoverBox"></div></div>' +

    '<div class="card"><div class="card-head"><h3>' + icon('star', 'ic-sm') + '관심종목 <span class="muted" style="font-weight:600">' + list.length + '</span></h3>' +
      (list.length ? '<button class="btn btn-outline btn-sm" data-act="watch-refresh" data-refresh-btn>' + icon('refresh', 'ic-sm') + '시세 갱신</button>' : '') + '</div>' +
      (list.length ? '<div class="wl-list">' + cards + '</div>' +
        '<p class="note" style="margin:12px 2px 0">카드를 누르면 AI 분석(오를 확률·의견·참고 가격)이 나와요.</p>' +
        '<div class="wl-acts"><button class="btn btn-soft" data-act="brief-watch">' + icon('clipboard') + '관심종목 AI 뉴스 브리핑</button>' +
        '<button class="btn btn-gray" data-act="watch-news">' + icon('news') + '관심종목 최신 뉴스</button></div>' +
        '<div id="watchNews"></div>'
      : '<div class="empty"><div class="ill">' + icon('star') + '</div><b>관심종목이 없어요</b><p>사고 싶은데 아직 안 산 종목, 지켜보는 종목을 담아 두세요. 위 <b>관심종목 추가</b>로 이름 검색해서 넣으면 돼요.</p>' +
        '<button class="btn btn-primary btn-lg" data-act="watch-add">' + icon('plus') + '관심종목 추가</button></div>') + '</div>';
  hydrateIcons(el); bindTips(el);
  if (!isRe && list.length) refreshWatchPrices(false).then(() => { if (route.page === 'watch') PAGES.watch({}, true); });
};

/* 관심종목 추가 — 이름으로 검색 */
function openAddWatch() {
  const m = openModal({ title: '관심종목 추가', size: 'wide',
    body: '<div class="input-wrap"><span class="prefix-ic">' + icon('search') + '</span><input class="input lg" id="wq" placeholder="종목 이름이나 코드 (예: 삼성전자, 엔비디아)" autocomplete="off"></div>' +
      '<div class="chips" style="margin-top:12px" id="wqp">' + ['삼성전자', 'SK하이닉스', '엔비디아', '테슬라', '애플', 'TIGER 미국S&P500'].map(q => '<button class="chip" data-q="' + esc(q) + '">' + esc(q) + '</button>').join('') + '</div>' +
      '<div class="sr" id="wsr"><div class="sr-empty">한글로 검색해도 돼요. 미국 주식도 “엔비디아”처럼 찾을 수 있어요.</div></div>' });
  const q = m.body.querySelector('#wq'), sr = m.body.querySelector('#wsr');
  let seq = 0;
  const run = debounce(async () => {
    const my = ++seq, v = q.value.trim();
    if (!v) { sr.innerHTML = '<div class="sr-empty">종목 이름을 입력하세요.</div>'; return; }
    sr.innerHTML = '<div class="sr-empty">찾는 중…</div>';
    try {
      const r = await api('/api/search?q=' + encodeURIComponent(v), { timeout: 12000 });
      if (my !== seq) return;
      if (!r || !r.length) { sr.innerHTML = '<div class="sr-empty">결과가 없어요. 이름을 바꿔 보세요.</div>'; return; }
      sr.innerHTML = r.map(x => {
        const has = inWatch(x.ticker, x.ccy);
        return '<button data-add="' + esc(JSON.stringify(x)) + '" ' + (has ? 'disabled' : '') + '><div class="logo" style="background:' + (x.market === 'us' ? 'var(--c2)' : 'var(--c1)') + '">' + esc(x.market === 'us' ? x.ticker.slice(0, 2) : x.name.slice(0, 1)) + '</div>' +
          '<div class="mid"><b>' + esc(x.name) + '</b><span>' + esc(x.ticker) + ' · ' + esc(x.exchange || '') + '</span></div>' +
          (has ? '<span class="badge gray">담김</span>' : '<span class="badge blue">＋ 담기</span>') + '</button>';
      }).join('');
    } catch (e) { if (my === seq) sr.innerHTML = '<div class="sr-empty">' + SERVER_DOWN + '</div>'; }
  }, 260);
  q.addEventListener('input', run);
  m.body.querySelector('#wqp').addEventListener('click', e => { const b = e.target.closest('[data-q]'); if (b) { q.value = b.dataset.q; run(); q.focus(); } });
  sr.addEventListener('click', e => {
    const b = e.target.closest('[data-add]'); if (!b) return;
    const x = JSON.parse(b.dataset.add);
    addToWatch(x);
    b.disabled = true; b.querySelector('.badge').outerHTML = '<span class="badge green">' + icon('check', 'ic-sm') + '담김</span>'; hydrateIcons(b);
    toast('“' + x.name + '”을(를) 관심종목에 담았어요');
  });
  setTimeout(() => q.focus(), 250);
}
function addToWatch(x) {
  if (inWatch(x.ticker, x.ccy)) return;
  watchlist().push({ ticker: x.ticker, name: x.name, market: x.market, ccy: x.ccy || (x.market === 'us' ? 'USD' : 'KRW'), exch: x.exchange || '', at: 0 });
  save();
  if (route.page === 'watch') { refreshWatchPrices(true).then(() => { if (route.page === 'watch') PAGES.watch({}, true); }); PAGES.watch({}, true); }
}
function delWatch(ticker) {
  const p = P(); p.watch = watchlist().filter(w => (w.ticker || '').toUpperCase() !== String(ticker).toUpperCase());
  save(); PAGES.watch({}, true);
}

/* 관심종목 AI 분석 — openInsight 와 같은 화면, 계좌 없이 */
function watchInsight(ticker) {
  const w = watchlist().find(x => (x.ticker || '').toUpperCase() === String(ticker).toUpperCase()); if (!w) return;
  if (!(AI_STATUS && AI_STATUS.on)) { needAI(() => watchInsight(ticker)); return; }
  const m = openAiModal('AI 분석 — ' + esc(dispName(w)), 'AI가 최근 뉴스와 숫자를 보고 <b>오를 확률과 의견</b>을 정리했어요. 확률은 추정이라 틀릴 수 있어요.', '최근 뉴스와 실적을 모으고 있어요…');
  const q = { ticker: w.ticker || '', market: w.market || 'kr', name: w.name || '', price: w.cur || '', per: w.per || '', pbr: w.pbr || '',
    forward_per: w.fper || '', asof: w.asof || '', peg: w.peg || '', roe: w.roe || '', op_income: w.opIncome || '', op_margin: w.opMargin || '',
    market_cap: w.marketCap || '', eps: w.eps || '', mcap_ccy: w.mcapCcy || '', style: tradeStyle() };
  const qs = Object.keys(q).map(k => k + '=' + encodeURIComponent(q[k])).join('&');
  api('/insight?' + qs, { timeout: 150000 })
    .then(d => aiFill(m, d, x => renderAiText(x.text), d && d.headline_count != null ? '뉴스 ' + d.headline_count + '건' : ''))
    .catch(() => aiFill(m, { status: 'fail', text: SERVER_DOWN }));
}

/* AI 종목 발굴 */
function openDiscover() {
  if (!(AI_STATUS && AI_STATUS.on)) { needAI(openDiscover); return; }
  const box = document.getElementById('discoverBox');
  if (box) box.innerHTML = '<div class="ai-loading" style="padding:30px 10px"><div class="orb"></div><div>요즘 시장을 살펴 새 종목을 찾는 중이에요…<br><span style="font-size:.8rem">20~40초 걸려요</span></div></div>';
  const have = [];
  allHoldings().forEach(x => { const n = dispName(x.h); if (n) have.push(n + (x.h.ticker ? '(' + x.h.ticker + ')' : '')); });
  watchlist().forEach(w => { const n = dispName(w); if (n) have.push(n + (w.ticker ? '(' + w.ticker + ')' : '')); });
  api('/discover', { method: 'POST', body: { have: have.join(', '), style: tradeStyle() }, timeout: 180000 })
    .then(d => {
      if (!box) return;
      if (d && d.status === 'no_key') { box.innerHTML = '<div class="callout warn" style="margin-top:12px">' + icon('key', 'ic-sm') + 'AI를 먼저 연결해 주세요.</div>'; return; }
      if (!d || (d.status !== 'ok' && d.status !== 'ok_text') || (!d.items && !d.text)) {
        box.innerHTML = '<div class="callout warn" style="margin-top:12px">' + icon('alert', 'ic-sm') + '추천을 받지 못했어요. 잠시 후 다시 해 주세요.</div>'; return;
      }
      if (!d.items) { box.innerHTML = '<div class="ai-sec" style="margin-top:12px"><div class="ln plain">' + mdInline(d.text) + '</div></div>'; return; }
      box.innerHTML = renderDiscover(d);
      hydrateIcons(box); bindTips(box);
    })
    .catch(() => { if (box) box.innerHTML = '<div class="callout warn" style="margin-top:12px">' + icon('alert', 'ic-sm') + SERVER_DOWN + '</div>'; });
}
function renderDiscover(d) {
  const st = TRADE_STYLES[tradeStyle()];
  let html = '<div class="disc-meta">' + icon('sparkles', 'ic-sm') + esc(d.provider || '') + (d.model ? ' · ' + esc(d.model) : '') + ' · ' + st.emoji + st.label + ' 기준</div>';
  html += d.items.map(it => {
    const up = Math.max(10, Math.min(90, parseInt(it.up, 10) || 55));
    const mk = (it.market === 'us' || /^[A-Za-z]/.test(it.ticker || '')) ? 'us' : 'kr';
    const has = inWatch(it.ticker, mk === 'us' ? 'USD' : 'KRW');
    const payload = esc(JSON.stringify({ ticker: it.ticker, name: it.name, market: mk, ccy: mk === 'us' ? 'USD' : 'KRW' }));
    return '<div class="disc-card">' +
      '<div class="disc-top"><div class="logo" style="background:' + (mk === 'us' ? 'var(--c2)' : 'var(--c1)') + '">' + esc((mk === 'us' ? (it.ticker || it.name).slice(0, 2) : (it.name || '').slice(0, 1))) + '</div>' +
        '<div style="flex:1;min-width:0"><b>' + esc(it.name || '') + '</b><span class="disc-tk">' + esc(it.ticker || '') + (it.theme ? ' · <span class="disc-theme">#' + esc(it.theme) + '</span>' : '') + '</span></div>' +
        '<div class="disc-up ' + (up >= 50 ? 'up' : 'down') + '">' + (up >= 50 ? '▲' : '▼') + ' ' + up + '%</div></div>' +
      (it.why ? '<div class="disc-why">' + mdInline(it.why) + '</div>' : '') +
      '<div class="disc-acts">' +
        '<button class="btn btn-soft btn-sm" data-act="disc-insight" data-p="' + payload + '">' + icon('sparkles', 'ic-sm') + 'AI 분석</button>' +
        '<button class="btn btn-outline btn-sm" data-act="disc-watch" data-p="' + payload + '" ' + (has ? 'disabled' : '') + '>' + icon(has ? 'check' : 'star', 'ic-sm') + (has ? '관심 담김' : '관심 담기') + '</button></div></div>';
  }).join('');
  html += '<p class="note" style="margin:12px 2px 0">AI가 뉴스를 보고 고른 <b>참고 후보</b>예요. 추천이 곧 수익을 뜻하지 않아요 — 꼭 직접 확인하고 판단하세요.</p>';
  return html;
}
/* 발굴 결과의 종목을 임시로 관심에 담아 AI 분석 */
function discInsight(p) {
  const x = JSON.parse(p);
  if (!inWatch(x.ticker, x.ccy)) { watchlist().push(Object.assign({ at: 0, _tmp: true }, x)); }
  watchInsight(x.ticker);
  // 임시로 담은 건 분석만 하고 목록엔 남기지 않음 (사용자가 '관심 담기'를 눌러야 저장)
  const p2 = P(); p2.watch = watchlist().filter(w => !w._tmp);
}

/* ==========================================================================
   배경음 — 코드로 만드는 아주 잔잔한 패드(음악 파일 없음). 기본 꺼짐.
   브라우저 규칙상 사용자가 화면을 한 번 누른 뒤에만 소리가 납니다.
   ========================================================================== */
const Ambient = (function () {
  let ctx = null, master = null, timer = null, on = false;
  const NOTES = [196.00, 246.94, 293.66, 392.00, 440.00];  // 잔잔한 5음 (G, B, D, G, A)
  function ensure() {
    if (ctx) return true;
    try {
      const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return false;
      ctx = new AC();
      master = ctx.createGain(); master.gain.value = 0.05; master.connect(ctx.destination);  // 아주 작게
      return true;
    } catch (e) { return false; }
  }
  function voice() {
    if (!ctx || ctx.state !== 'running') return;
    const now = ctx.currentTime;
    const f = NOTES[Math.floor(Math.random() * NOTES.length)] * (Math.random() < 0.3 ? 2 : 1);
    const osc = ctx.createOscillator(), g = ctx.createGain();
    osc.type = 'sine'; osc.frequency.value = f;
    const dur = 4 + Math.random() * 4;
    g.gain.setValueAtTime(0, now);
    g.gain.linearRampToValueAtTime(0.5, now + dur * 0.4);
    g.gain.linearRampToValueAtTime(0, now + dur);
    osc.connect(g); g.connect(master);
    osc.start(now); osc.stop(now + dur + 0.1);
  }
  function loop() { if (on) { voice(); timer = setTimeout(loop, 2600 + Math.random() * 2600); } }
  return {
    start() {
      if (on || !ensure()) return;
      if (ctx.state === 'suspended') ctx.resume();
      on = true; loop();
    },
    stop() { on = false; clearTimeout(timer); if (master && ctx) { try { master.gain.setTargetAtTime(0, ctx.currentTime, 0.3); } catch (e) {} setTimeout(() => { if (!on && master) master.gain.value = 0.05; }, 600); } },
    get on() { return on; },
  };
})();
window.Ambient = Ambient;
// 사용자가 처음 화면을 누르면, 켜 둔 경우 배경음 시작
document.addEventListener('pointerdown', function _once() {
  if (UI.sound && window.Ambient) Ambient.start();
  document.removeEventListener('pointerdown', _once);
}, { once: true });

/* 관심종목 최신 뉴스 — 종목마다 최근 뉴스 몇 개씩 */
async function loadWatchNews() {
  const box = document.getElementById('watchNews'); if (!box) return;
  const list = watchlist().filter(w => w.ticker || w.name).slice(0, 12);
  box.innerHTML = '<div class="wn-loading">' + icon('news') + ' 관심종목 ' + list.length + '개의 뉴스를 모으는 중…</div>';
  hydrateIcons(box);
  const res = await Promise.all(list.map(w => api('/news?ticker=' + encodeURIComponent(w.ticker || '') + '&market=' + (w.market || 'kr') + '&name=' + encodeURIComponent(w.name || ''), { timeout: 25000 })
    .then(arr => ({ w, arr: Array.isArray(arr) ? arr.slice(0, 4) : [] })).catch(() => ({ w, arr: [] }))));
  if (!document.getElementById('watchNews')) return;
  box.innerHTML = res.map(({ w, arr }) =>
    '<div class="wn-group"><div class="wn-h"><b>' + esc(dispName(w)) + '</b>' + (w.chg != null ? '<span class="' + cls(w.chg) + '">' + pct(w.chg) + '</span>' : '') +
      '<button class="btn btn-soft btn-sm" data-act="watch-insight" data-t="' + esc(w.ticker) + '">' + icon('sparkles', 'ic-sm') + 'AI 영향 분석</button>' +
      (w.ticker ? '<button class="btn btn-gray btn-sm" data-act="ai-chart" data-t="' + esc(w.ticker) + '" data-m="' + (w.market || 'kr') + '" data-n="' + esc(dispName(w)) + '">' + icon('activity', 'ic-sm') + '차트</button>' : '') + '</div>' +
    (arr.length ? '<div class="headlines">' + newsListHtml(arr) + '</div>' : '<p class="note" style="margin:6px 2px">최근 7일 뉴스가 없어요.</p>') + '</div>').join('') +
    '<p class="note" style="margin-top:10px">뉴스가 주가에 어떤 영향을 줄지는 <b>AI 영향 분석</b>이나 <b>관심종목 AI 뉴스 브리핑</b>에서 볼 수 있어요.</p>';
  hydrateIcons(box);
}
