/* ==========================================================================
   main.js — 화면 이동 · 버튼 동작 · 시세 갱신 · 시작
   ========================================================================== */
'use strict';

/* ---------------- 화면 이동 (브라우저 뒤로가기 지원) ---------------- */
// 하단 '더보기'에 들어가는 화면
const MORE_PAGES = [['calc', '계산기', 'target', '🧮 수익률 · 불타기/물타기 · 프랍 리스크'], ['market', '시장', 'globe', '지수·환율·공포탐욕·경제 뉴스'], ['history', '자산 기록', 'history', '날짜별 총자산 그래프'],
  ['games', '게임', 'rocket', '🚀 크래시 · 🎱 로또 추첨'], ['settings', '설정', 'settings', 'AI 연결·성향·화면·데이터']];
const GAME_PAGES = [['game', '크래시', 'rocket', '🚀 로켓이 터지기 전에 내리기 · 출석 보너스'], ['lotto', '로또', 'star', '🎱 내가 돌리는 6/45 추첨기']];
function openGames() {
  const m = openModal({ title: '🎮 게임', body: '<div class="more-grid">' + GAME_PAGES.map(([pg, t, ic, d]) =>
    '<button class="more-tile' + (route.page === pg || (pg === 'games' && /^(game|lotto)$/.test(route.page)) ? ' on' : '') + '" data-pg="' + pg + '"><span class="mt-ico mt-' + pg + '">' + icon(ic) + '</span><b>' + t + '</b><span>' + d + '</span></button>').join('') + '</div>' +
    '<p class="note" style="margin:12px 2px 0">게임 포인트는 재미용이에요. 현금으로 바꿀 수 없어요.</p>' });
  m.body.addEventListener('click', e => { const b = e.target.closest('[data-pg]'); if (b) { m.close(); go(b.dataset.pg); } });
}
function openMore() {
  const m = openModal({ title: '더보기', body: '<div class="more-grid">' + MORE_PAGES.map(([pg, t, ic, d]) =>
    '<button class="more-tile' + (route.page === pg ? ' on' : '') + '" data-pg="' + pg + '"><span class="mt-ico mt-' + pg + '">' + icon(ic) + '</span><b>' + t + '</b><span>' + d + '</span></button>').join('') + '</div>' +
    promoSlot('more') +
    ((REMOTE.charity ? '<button class="sp-cta" data-act="support">💚 초록우산 기부하기 <span>하루 천 원, 아이들에게</span></button>' : '<button class="sp-cta" data-act="support">☕ 개발자 후원하기 <span>커피 한 잔 값으로 응원</span></button>')) });
  m.body.addEventListener('click', e => { const b = e.target.closest('[data-pg]'); if (!b) return; m.close(); if (b.dataset.pg === 'games') openGames(); else if (b.dataset.pg === 'calc') openCalc(); else go(b.dataset.pg); });
}
let _backStack = [], _fromBack = false;            // 폰 뒤로가기용 '지나온 화면' 목록
function go(page, params, noPush) {
  if (!PAGES[page]) page = 'home';
  if (!_fromBack && route && route.page && route.page !== page) { _backStack.push(route.page); if (_backStack.length > 30) _backStack.shift(); }
  if (page === 'home') _backStack = [];
  route = { page, params: params || {} };
  document.querySelectorAll('.page').forEach(p => p.classList.toggle('on', p.id === 'page-' + page));
  document.querySelectorAll('#nav [data-nav], #tabbar [data-nav]').forEach(n => n.classList.toggle('on', n.dataset.nav === page));
  const mt = document.querySelector('#tabbar .tab-more'); if (mt) mt.classList.toggle('on', MORE_PAGES.concat(GAME_PAGES).some(x => x[0] === page));
  document.body.dataset.page = page;                // 화면마다 고유색(제목 막대 등)
  closeMenu(); hideTip();
  if (!noPush && location.hash !== '#' + page) history.pushState({ page }, '', '#' + page);
  window.scrollTo(0, 0);
  PAGES[page](route.params);
  fxPageEnter(page);                                // 카드 순차 등장 · 숫자 굴러가기
  refreshChrome();
  if (_refreshing) setRefreshing(true);
  const p = route.params || {};
  if (page === 'accounts' && p._openH && window.innerWidth <= 1240) { const a = findAcc(curAccId), h = a && a.holdings.find(x => x.id === selH); if (h) openHoldingModal(a, h); }
}
window.addEventListener('popstate', () => { const p = location.hash.slice(1) || 'home'; closeAllModals(); if (p !== route.page) go(p, {}, true); });

/* ---------------- 버튼 동작 ---------------- */
const ACT = {
  'person-menu': el => personMenu(el),
  'toggle-theme': () => { const cur = document.documentElement.getAttribute('data-theme'); UI.theme = cur === 'dark' ? 'light' : 'dark'; saveUI(); applyView(); },
  quit: () => quitApp(),
  'refresh-all': () => refreshPrices(),
  'refresh-acc': () => refreshPrices(),
  'save-snap': () => { saveSnapshot(false); rerender(); },
  'acc-new': () => openAccountForm(null),
  'open-acc': el => go('accounts', { acc: el.dataset.a }),
  'sel-acc': el => { curAccId = el.dataset.a; selH = null; rerender(); },
  'acc-menu': el => accountMenu(el, el.dataset.a),
  'edit-cash': el => { const a = findAcc(el.dataset.a); if (a) inlineEdit(el, nf(num(a.cash), 0), v => { a.cash = String(Math.max(0, v)); save(); rerender(); toast('현금을 바꿨어요'); }, '원'); },
  'h-new': el => { el.classList.remove('pulse'); openAddHolding(el.dataset.a); },
  'sel-h': el => selectHolding(el.dataset.a, el.dataset.h),
  'open-h': el => { curAccId = el.dataset.a; selH = el.dataset.h; go('accounts', { acc: el.dataset.a, h: el.dataset.h, _openH: true }); },
  'h-sort': el => { UI.hSort = el.dataset.v; saveUI(); rerender(); },
  'h-edit': el => openEditHolding(el.dataset.a, el.dataset.h),
  'h-buy': el => openBuy(el.dataset.a, el.dataset.h),
  'h-sell': el => openSell(el.dataset.a, el.dataset.h),
  'edit-target': el => openTarget(el.dataset.a, el.dataset.h),
  'toggle-check': el => { _checkOpen = !_checkOpen; el.classList.toggle('open', _checkOpen); const b = document.getElementById('checkBody'); if (b) b.classList.toggle('hide', !_checkOpen); },
  'set-policy': el => { S.settings.policy = el.dataset.v; save(); rerender(); toast(POLICY[el.dataset.v].label + ' 기준으로 바꿨어요'); },
  'd-range': el => {
    detailRange = el.dataset.v;
    const box = el.closest('.detail') || el.closest('.modal-body');
    el.parentElement.querySelectorAll('button').forEach(b => b.classList.toggle('on', b === el));
    const a = findAcc(curAccId), hid = (box && box.closest('.modal') && box.closest('.modal').dataset.detail) || selH;
    const h = a && a.holdings.find(x => x.id === hid);
    if (h && box) loadDetailChart(box, h);
  },
  'ai-insight': el => openInsight(el.dataset.a, el.dataset.h),
  'ai-review': el => openAccReview(el.dataset.a),
  'ai-brief-all': () => needAI(openBriefAll),
  'ai-brief-acc': el => needAI(() => openBriefAcc(el.dataset.a)),
  'brief-watch': () => needAI(openBriefWatch),
  'more': () => openMore(),
  'support': () => { closeAllModals(); openSupport(); },
  'ai-chat': el => openChat(el.dataset.q),
  'pick-sectors': () => openSectorPicker(route.page === 'watch' ? () => { const db = document.getElementById('discoverBox'); if (db) db.innerHTML = ''; PAGES.watch({}, true); } : null),
  'promo-open': el => promoOpen(el.dataset.id),
  'promo-x': el => promoHide(el.dataset.id),
  'perf-more': () => { const box = document.getElementById('perfList'); if (!box) return;
    const rows = allHoldings().map(x => ({ a: x.a, h: x.h, v: hv(x.h) })).filter(x => x.v.cost > 0).sort((p, q) => q.v.ret - p.v.ret);
    box.innerHTML = rows.map(x => holdRowHtml(x.a, x.h, x.v)).join(''); hydrateIcons(box); },
  'ai-chart': el => { closeAllModals(); openChartAI(el.dataset.t, el.dataset.m, el.dataset.n); },
  'watch-news': () => loadWatchNews(),
  'ai-topdown': () => needAI(openTopdown),
  'ai-review-pick': () => needAI(() => pickAccount(openAccReview)),
  'ai-insight-pick': () => needAI(() => pickHolding((a, h) => openInsight(a, h))),
  'ai-chart-pick': () => needAI(() => pickHolding((a, h) => { const x = findAcc(a).holdings.find(y => y.id === h); openChartAI(x.ticker, mkt(x), dispName(x)); })),
  'ai-setup': () => openProfileHub('survey'),              // 🧑 나의 투자 프로필 (설문·DNA·캐릭터 한 곳에서)
  'ai-setup-run': () => openAiSetup(true),
  'profile-hub': (el) => openProfileHub(el.dataset.tab || 'survey'),
  'dna': () => openDna(),
  checkin: () => doCheckin(),
  'my-view': (el) => openMyView(JSON.parse(el.dataset.p)),
  council: (el) => openCouncil(el && el.dataset.t ? JSON.parse(el.dataset.t) : null),
  'council-again': (el) => openCouncil(JSON.parse(el.dataset.t || 'null') || null),
  'council-seen': (el) => { const v = cnLoad(CW_KEY); v.forEach(x => { if (x.id === el.dataset.id) x.seen = 1; }); cnSave(CW_KEY, v, 40); const c = document.getElementById('cnHome'); if (c) c.outerHTML = councilHomeCard(); },
  'sample-on': () => sampleOn(),
  'sample-off': () => sampleOff(),
  'hide-amt': () => { UI.hideAmt = !UI.hideAmt; saveUI(); applyView(); toast(UI.hideAmt ? '🙈 금액을 숨겼어요' : '👁 금액을 다시 보여요'); },
  'ai-disc-open': () => openDiscModal(),
  'ai-sb-open': () => openSbPicker(),
  'home-brief': () => openHomeBrief(),
  'ai-track-open': () => openTrackModal(),
  paper: (el) => openPaperTrade(JSON.parse(el.dataset.p)),
  'disc-paper': (el) => { const x = JSON.parse(el.dataset.p); if (!inWatch(x.ticker, x.ccy)) { watchlist().push(Object.assign({ at: Date.now() }, x)); save(); } openPaperTrade(x); },
  'sbrief': (el) => openSessionBrief(el.dataset.k),
  'set-style': el => { UI.tradeStyle = el.dataset.v; saveUI(); const db = document.getElementById('discoverBox'); if (db) db.innerHTML = ''; if (route.page === 'watch') PAGES.watch({}, true); else rerender(); toast(TRADE_STYLES[el.dataset.v].label + ' 기준으로 바꿨어요'); },
  'watch-add': () => openAddWatch(),
  'watch-del': el => delWatch(el.dataset.t),
  'watch-insight': el => watchInsight(el.dataset.t),
  'watch-open': el => openWatchSheet(el.dataset.t),
  'real-buy': el => openRealBuy(JSON.parse(el.dataset.p)),
  'paper-refresh': (el) => paperRefreshNow(el),
  'paper-sell-all': () => paperSellAll(),
  'paper-hist-more': (el) => { const box = el.closest('.pp-hist'); if (box) box.innerHTML = paperHistHtml(100); },
  'watch-rank': () => openWatchRank(),
  'ai-wizard': () => openAiWizard(),
  persona: () => openPersona(),
  'prop-coach': () => openPropCoach(),
  calc: (el) => (el && el.dataset.p ? openCalcFor(JSON.parse(el.dataset.p)) : openCalc()),
  'move-why': (el) => openMoveWhy(JSON.parse(el.dataset.p)),
  'mk-digest': () => openNewsDigest(((MK.news[mkNewsLang] || [])).map(n => newsT(n)), mkNewsLang === 'us' ? '해외 경제 뉴스' : '경제 뉴스'),
  'fl-digest': () => openNewsDigest(((FL.data && FL.data.items) || []).slice(0, 40).map(x => newsT(x)), '속보'),
  'watch-refresh': () => refreshWatchPrices(true).then(() => { if (route.page === 'watch') PAGES.watch({}, true); }),
  'discover': () => openDiscover(),
  'disc-insight': el => discInsight(el.dataset.p),
  'disc-watch': el => { const x = JSON.parse(el.dataset.p); addToWatch(x); el.disabled = true; el.innerHTML = icon('check', 'ic-sm') + '관심 담김'; hydrateIcons(el); toast('관심종목에 담았어요'); },
  'chat-clear': async () => { if (await confirmBox({ title: '대화 지우기', msg: 'AI와 나눈 대화를 모두 지울까요?', ok: '지우기', danger: true })) { saveChat([]); rerender(); } },
  'home-alloc': el => { UI.homeAlloc = el.dataset.v; saveUI(); rerender(); },
  'mk-refresh': () => { MK.sentAt = 0; MK.fail = 0; MK.sentFail = false; MK.news = {}; setRefreshing(true); Promise.all([loadMarket(true), api('/api/sentiment').then(d => { MK.sent = d; MK.sentAt = Date.now(); }).catch(() => {})]).finally(() => { setRefreshing(false); if (route.page === 'market') { PAGES.market({}, true); loadMkNews(mkNewsLang); } toast('시장 정보를 새로 불러왔어요'); }); },
  'mk-news': el => { mkNewsLang = el.dataset.v; PAGES.market({}, true); loadMkNews(mkNewsLang); },
  'hist-range': el => { UI.histRange = el.dataset.v; saveUI(); rerender(); },
  'hist-apply': () => { const f = document.getElementById('hFrom').value, t = document.getElementById('hTo').value; if (!f || !t) { toast('시작일과 끝일을 모두 골라 주세요'); return; } histFrom = f <= t ? f : t; histTo = f <= t ? t : f; rerender(); },
  'snap-toggle': el => el.closest('.snap').classList.toggle('open'),
  'snap-del': async el => {
    const d = el.dataset.date;
    if (await confirmBox({ title: '기록 삭제', msg: dateLabel(d) + ' 기록을 지울까요?', ok: '삭제', danger: true })) { P().history = P().history.filter(x => x.date !== d); save(); rerender(); toast('기록을 지웠어요'); }
  },
};
function needAI(fn) {
  if (AI_STATUS && AI_STATUS.on) { fn(); return; }
  openAiWizard(fn);                                 // 🧓 아주 쉬운 AI 켜기 도우미 (v4.15)
}

document.addEventListener('click', e => {
  const nav = e.target.closest('[data-nav]');
  if (nav && !e.target.closest('[data-act]')) { e.preventDefault(); closeAllModals(); go(nav.dataset.nav, { sec: nav.dataset.sec }); return; }
  const el = e.target.closest('[data-act]');
  if (!el || el.disabled) return;
  const fn = ACT[el.dataset.act];
  if (fn) { e.preventDefault(); e.stopPropagation(); closeMenu(); fn(el, e); }
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { if (_menu) closeMenu(); else { const m = topModal(); if (m) m.close(); } }
});

/* 종목 선택: 넓은 화면은 오른쪽 패널, 좁은 화면은 팝업 */
function selectHolding(accId, hId) {
  const a = findAcc(accId), h = a && a.holdings.find(x => x.id === hId); if (!h) return;
  curAccId = accId; selH = hId;
  const card = document.getElementById('detailCard');
  if (card && window.innerWidth > 1240) {
    document.querySelectorAll('.tbl tr.hrow').forEach(r => r.classList.toggle('sel', r.dataset.h === hId));
    card.innerHTML = detailHtml(a, h); card.scrollTop = 0;
    wireDetail(card, a, h);
  } else openHoldingModal(a, h);
}

/* ---------------- 시세 갱신 ---------------- */
let _refreshing = false;
function setRefreshing(on) {
  document.querySelectorAll('[data-refresh-btn], .mtop [data-act="refresh-all"]').forEach(b => { b.classList.toggle('loading', on); if (b.tagName === 'BUTTON') b.disabled = on; });
}
function snapshotAll() {
  const keep = S.curPerson;
  S.people.forEach(p => { if (p.accounts.length) { S.curPerson = p.id; saveSnapshot(true); } });
  S.curPerson = keep;
}
async function refreshPrices(opts) {
  opts = opts || {};
  if (_refreshing) return;
  _refreshing = true; setRefreshing(true);
  if (!opts.silent) toast('최신 시세를 가져오는 중… (종목이 많으면 30초쯤 걸려요)', 2600);
  let ok = 0, fail = 0, fxOk = false;
  try {
    try { const f = await api('/fx', { timeout: 12000 }); if (f && f.rate > 0) { S.settings.fxRate = String(f.rate); S.settings.fxPrev = f.prev > 0 ? String(f.prev) : ''; S.settings.fxAt = todayKey(); fxOk = true; } } catch (e) {}
    const seen = {}, order = [], all = [];
    S.people.forEach(p => p.accounts.forEach(a => a.holdings.forEach(h => { all.push(h); if (h.ticker) { const k = h.ticker + ':' + mkt(h); if (!seen[k]) { seen[k] = 1; order.push(k); } } })));
    if (order.length) {
      const data = await api('/prices?items=' + encodeURIComponent(order.join(',')), { timeout: 180000 });
      const done = {};
      all.forEach(h => {
        if (!h.ticker) return;
        const k = h.ticker + ':' + mkt(h), d = data[k];
        if (d && d.price > 0) {
          h.cur = String(d.price);
          const nm = d.name && String(d.name).trim();
          // 이름이 달라졌으면 예전에 다른 종목 정보가 섞였을 수 있으니 지표를 비우고 새로 채움
          if (nm && h.name && h.name !== nm) clearFund(h);
          if (nm) h.name = nm;
          storeFund(h, d);
          if (!done[k]) { ok++; done[k] = 1; }
        } else if (!done[k]) { fail++; done[k] = 1; }
      });
    }
    if (!order.length && !fxOk) throw new Error('down');
    if (ok > 0 || (!order.length && fxOk)) {           // 하나도 못 받았으면 '방금 갱신'으로 치지 않음 (자동 재시도 유지)
      UI.lastRefresh = Date.now(); saveUI();
      if (S.settings.autoSnap) snapshotAll();
    }
    save();
    if (!ok && fail) toast('시세를 받지 못했어요 (' + fail + '종목) · 인터넷 연결을 확인하고 다시 눌러 주세요', 3600);
    else if (!opts.silent || fail) toast('시세 갱신 완료 · ' + ok + '종목' + (fail ? ' · 실패 ' + fail + '종목' : '') + (fxOk ? ' · 환율 ' + nf(fx(), 1) + '원' : ''), 3200);
  } catch (e) {
    toast(SERVER_DOWN, 4000);
  } finally {
    _refreshing = false; setRefreshing(false);
    // 시세가 보이는 화면만 다시 그림 · 입력 중인 글(AI 키, 질문)은 지우지 않게
    const pgEl = document.getElementById('page-' + route.page), ae = document.activeElement;
    const typing = pgEl && ae && pgEl.contains(ae) && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName);
    if (['home', 'accounts', 'history', 'watch'].includes(route.page) && !typing) rerender(); else refreshChrome();
  }
}

/* ---------------- 종료 ---------------- */
async function quitApp() {
  if (!(await confirmBox({ title: '앱 종료', msg: '앱을 끌까요?<br>다음에는 바탕화면의 <b>“' + BRAND.name + '”</b> 아이콘으로 다시 켜면 돼요.', ok: '종료' }))) return;
  save({ noSync: true });
  try { await pushServer(); } catch (e) {}
  const bye = () => {
    document.body.innerHTML = '<div style="min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:30px;gap:10px;font-family:var(--font);background:var(--bg);color:var(--text)">' +
      '<div style="font-size:56px">👋</div><div style="font-size:1.5rem;font-weight:800">앱을 종료했어요</div><div style="color:var(--text-2);line-height:1.7">이제 이 창(탭)을 닫으셔도 돼요.<br>다음에는 바탕화면의 <b>“' + BRAND.name + '”</b>를 두 번 누르세요.</div></div>';
    try { window.close(); } catch (e) {}
  };
  api('/shutdown', { timeout: 3000 }).then(bye).catch(bye);
}

/* ---------------- 화려한 첫 화면 (세션당 한 번) ----------------
   색 블록 16개가 사방에서 날아와 4×4로 조립 → 하나의 아이콘으로 합쳐짐 →
   상승 차트가 그려지고 빛이 번지며 불꽃 → 앱 이름이 한 글자씩. 누르면 건너뛰기. */
function showIntro() {
  // v4.7: 앱을 켜면 무조건 재생 — 업데이트 직후·애니메이션 줄이기·세션 기록과 상관없이.
  // 다른 앱에 갔다가 3분 넘게 지나 돌아와도 다시 재생. 끄고 싶으면 설정 → 화면 → 시작 애니메이션.
  if (UI.introOff) return;
  if (document.querySelector('.intro')) return;
  const N = 4, tiles = [];
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
    const i = r * N + c, ang = Math.random() * Math.PI * 2, dist = 360 + Math.random() * 320;
    const t = (r + c) / (2 * N - 2);                                   // 왼쪽 위 → 오른쪽 아래 색 변화
    const col = 'hsl(' + Math.round(222 - t * 30 + (Math.random() * 8 - 4)) + ',' + Math.round(88 - t * 6) + '%,' + Math.round(58 + (Math.random() * 8 - 4)) + '%)';
    tiles.push('<i class="ib-tile" style="--c:' + c + ';--r:' + r + ';--bg:' + col +
      ';--fx:' + Math.round(Math.cos(ang) * dist) + 'px;--fy:' + Math.round(Math.sin(ang) * dist) + 'px;--fr:' + Math.round(Math.random() * 540 - 270) + 'deg' +
      ';--d:' + Math.round(350 + (Math.abs(r - 1.5) + Math.abs(c - 1.5)) * 170 + Math.random() * 200) + 'ms;--w:' + ((r + c) * 60) + 'ms"></i>');
  }
  const sparks = Array.from({ length: 12 }, (_, i) => '<i class="ib-spark" style="--a:' + (i * 30) + 'deg;--l:' + (70 + Math.random() * 60) + 'px"></i>').join('');
  const name = BRAND.name.split('').map((ch, i) => '<span style="--i:' + i + '">' + (ch === ' ' ? '&nbsp;' : ch) + '</span>').join('');
  const el = document.createElement('div');
  el.className = 'intro ib';
  el.innerHTML =
    '<div class="ib-bg"><i class="ib-glow"></i><i class="ib-grid"></i>' +
      Array.from({ length: 40 }, () => '<i class="ib-star" style="left:' + (Math.random() * 100).toFixed(1) + '%;top:' + (Math.random() * 100).toFixed(1) + '%;--t:' + (Math.random() * 3).toFixed(2) + 's;--s:' + (1 + Math.random() * 2).toFixed(1) + 'px"></i>').join('') + '</div>' +
    '<div class="ib-core">' +
      '<div class="ib-stage">' + tiles.join('') +
        '<div class="ib-logo"><svg viewBox="0 0 96 96"><path class="ib-line" pathLength="1" d="M20 64 L40 42 L54 54 L76 28" fill="none" stroke="#fff" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>' +
          '<circle class="ib-dot" cx="76" cy="28" r="6" fill="#fff"/></svg></div>' +
        '<i class="ib-ring"></i><i class="ib-ring r2"></i>' + sparks +
      '</div>' +
      '<div class="ib-name">' + name + '</div>' +
      '<div class="ib-sub">똑똑한 투자 판단, 3초 만에</div>' +
      '<div class="ib-load"><i></i></div><div class="ib-load-t">시작하는 중…</div>' +
    '</div>';
  document.body.appendChild(el);
  const SPEED = 2;                                   // 시작 애니메이션 빠르기 (2 = 두 배 빠르게, 약 3초)
  try { requestAnimationFrame(() => el.getAnimations({ subtree: true }).forEach(a => { a.playbackRate = SPEED; })); } catch (e) {}
  let done = false;
  const finish = () => { if (done) return; done = true; el.classList.add('out'); setTimeout(() => el.remove(), 650); };
  el.addEventListener('click', finish);
  window._introFinish = finish;
  setTimeout(() => { if (window._introHold) el._late = true; else finish(); }, Math.round(6300 / SPEED));   // 업데이트 받는 중이면 끝날 때까지 기다림
}

/* ---------------- 폰 뒤로가기 (자바가 appBack() 을 부름) ----------------
   열린 메뉴·창 닫기 → 지나온 화면으로 → 홈에서는 '종료하시겠습니까?' */
let _exitAsking = false;
function appBack() {
  const intro = document.querySelector('.intro'); if (intro) { intro.click(); return; }
  if (_modals.length && document.getElementById('consentLock')) { topModal().close(); return; }   // 동의 화면에서 약관 보기 창
  if (document.getElementById('appBlock') || document.getElementById('licLock') || document.getElementById('consentLock')) { askExit(); return; }
  if (typeof _menu !== 'undefined' && _menu) { closeMenu(); return; }
  if (_modals.length) { topModal().close(); return; }
  if (route.page !== 'home') {
    let prev = _backStack.pop();
    while (prev && (prev === route.page || !PAGES[prev])) prev = _backStack.pop();
    _fromBack = true; go(prev || 'home'); _fromBack = false;
    return;
  }
  askExit();
}
function askExit() {
  if (_exitAsking) return;
  _exitAsking = true;
  confirmBox({ title: '앱을 종료할까요?', msg: '언제든 다시 켜면 지금 상태 그대로 이어서 볼 수 있어요.', ok: '종료', cancel: '계속 쓰기' }).then(yes => {
    _exitAsking = false;
    if (yes) { try { if (UI.soundMode && window.Upbeat) { Upbeat.stop(); Ambient.stop(); } } catch (e) {} try { window.AndroidBridge && AndroidBridge.exitApp(); } catch (e) {} }
  });
}
window.appBack = appBack;

// 🎬 다른 앱에 3분 넘게 있다가 돌아오면 (폰이 앱을 끄지 않고 기억해 둔 경우) 시작 애니메이션 다시
let _hiddenAt = 0;
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { _hiddenAt = Date.now(); return; }
  if (_hiddenAt && Date.now() - _hiddenAt > 3 * 60 * 1000) { _hiddenAt = 0; try { showIntro(); } catch (e) {} }
});

/* ---------------- 시작 ---------------- */
(async function init() {
  showIntro();
  introUpdate();
  setTimeout(showConsent, 300);                     // ⚖️ 약관·위험 고지·개인정보 동의 (처음 또는 약관이 바뀌면)                                    // 시작 애니메이션 동안 새 버전 받아서 적용
  hydrateIcons(document);
  if (IS_APP) document.documentElement.classList.add('in-app');   // 폰 앱: 종료 버튼 등 PC 전용 요소 숨김
  applyView();
  if (window.matchMedia) matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if (UI.theme === 'auto') applyView(); });
  const start = location.hash.slice(1);
  history.replaceState({ page: start || 'home' }, '', '#' + (PAGES[start] ? start : 'home'));
  go(PAGES[start] ? start : 'home', {}, true);
  await loadAIStatus();
  if (route.page === 'home' || route.page === 'ai') rerender();
  const r = await pullServer();
  if (r === 'pulled') { rerender(); toast('이 기기에 자동 백업된 자산 정보를 불러왔어요', 3000); }
  const anyAcc = S.people.some(p => p.accounts.length);
  if (!UI.onboarded) {
    if (anyAcc) { UI.onboarded = true; saveUI(); } else openOnboarding();
  }
  const anyTicker = S.people.some(p => p.accounts.some(a => a.holdings.some(h => h.ticker)));
  if (anyTicker && S.settings.autoRefresh && Date.now() - (UI.lastRefresh || 0) > 30 * 60 * 1000) refreshPrices({ silent: true });
  // 넓은 화면(오른쪽 상세 패널) ↔ 좁은 화면 경계를 넘을 때만 다시 그림 (입력 중인 칸이 사라지지 않게)
  let wasWide = window.innerWidth > 1240;
  askAiSetupWhenFree();                             // 설치·업데이트 후 처음: 성향·말투 묻기
  try { grantDailyBonus(); } catch (e) {}           // 🚀 게임 출석 보너스(하루 1회)
  try { usageTick(); setTimeout(maybeNudge, 9000); } catch (e) {}   // 쓴 날 세기 · 가끔 후원 안내
  checkUpdate(false).finally(licenseCheck);          // 켤 때마다 자동 업데이트·사용 잠금 확인 → 이용권(쿠폰) 확인
  otaWatch();                                       // 폰: 새 묶음 받으면 바로 적용
  setInterval(() => checkUpdate(false).finally(licenseCheck), 30 * 60 * 1000);  // 오래 켜 둔 경우 30분마다 재확인
  window.addEventListener('resize', debounce(() => {
    const wide = window.innerWidth > 1240;
    if (wide !== wasWide) { wasWide = wide; if (route.page === 'accounts') rerender(); }
  }, 250));
  setInterval(loadAIStatus, 120000);
  setTimeout(() => councilTick(true), 9000);
  setTimeout(() => maybeAiWizard(), 7000);          // 🧓 처음 설치·AI 꺼짐 → 쉬운 AI 켜기 도우미 한 번         // 🏛 위원회 신호 감시 · 시장 이상 신호
  setInterval(() => { if (!document.hidden) councilTick(); }, 10 * 60 * 1000);
})();
