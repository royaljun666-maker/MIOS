"""
AI 엔진 (ai_engine.py)
======================

여러 AI 회사(LLM)를 한 가지 방식으로 부르는 심부름꾼입니다.
  - 키(API Key)는 앱 화면 ⚙️ 설정 → 'AI 연결'에서 넣습니다.
  - 넣은 키는 이 PC의  userdata/settings.json  에만 저장됩니다. (브라우저·인터넷 어디에도 안 올라감)
  - 예전 방식(환경변수 GEMINI_API_KEY 등)도 그대로 동작합니다.

지원 회사
  gemini      구글 Gemini            — 무료(추천)
  groq        Groq                   — 무료 · 매우 빠름
  openrouter  OpenRouter             — ':free' 모델 무료
  github      GitHub Models          — GPT-4.1 등 무료(깃허브 계정)
  mistral     Mistral                — 무료(Experiment 요금제)
  cerebras    Cerebras               — 무료 · 매우 빠름
  ollama      Ollama (내 PC)         — 완전 무료 · 인터넷 불필요
  openai      OpenAI (ChatGPT)       — 유료(선불 충전)
  anthropic   Anthropic (Claude)     — 유료(선불 충전)
"""

import re
import json
import os
import random
import threading
import time

import requests
from flask import Blueprint, jsonify, request

HERE = os.path.dirname(os.path.abspath(__file__))
# 폰 앱에서는 앱 전용 저장 공간을 ASSET_DATA_DIR 로 넘겨받음
DATA_DIR = os.environ.get("ASSET_DATA_DIR") or os.path.join(HERE, "userdata")
SETTINGS_PATH = os.path.join(DATA_DIR, "settings.json")
AI_TIMEOUT = 60

# ---------------------------------------------------------------------------
# 제공사 목록 — 화면(설정)에 그대로 보여줍니다.
#   kind: gemini / anthropic / openai(=OpenAI 호환 API)
#   models: [모델ID, 짧은 설명]  ← 기본 추천 목록. 화면의 '목록 불러오기'로 최신 목록을 받을 수 있음
# ---------------------------------------------------------------------------
PROVIDERS = {
    "gemini": {
        "name": "Google Gemini", "kind": "gemini", "tier": "free",
        "badge": "무료 · 추천",
        "desc": "구글 계정만 있으면 무료. 한국어 실력이 좋고 가장 무난합니다.",
        "base": "https://generativelanguage.googleapis.com/v1beta",
        "key_url": "https://aistudio.google.com/app/apikey",
        "key_hint": "AIza… 또는 AQ.…로 시작",
        "steps": ["아래 '키 발급 페이지 열기'를 누릅니다.",
                  "구글 계정으로 로그인합니다.",
                  "'API 키 만들기(Create API key)'를 누릅니다.",
                  "만들어진 키(AIza… 또는 AQ.…로 시작)를 복사해서 아래 칸에 붙여넣습니다."],
        "models": [["gemini-3.1-flash-lite", "추천 · 무료 · 빠르고 많이 씀"],
                   ["gemini-2.5-flash", "똑똑하고 빠름"],
                   ["gemini-2.5-flash-lite", "무료 한도 넉넉"],
                   ["gemini-3-flash", "최신 · 균형"],
                   ["gemini-2.5-pro", "가장 깊은 분석 · 무료 한도 적음"]],
    },
    "groq": {
        "name": "Groq", "kind": "openai", "tier": "free",
        "badge": "무료 · 초고속",
        "desc": "카드 등록 없이 무료. 답이 매우 빠릅니다(Llama·GPT-OSS 등 공개 모델).",
        "base": "https://api.groq.com/openai/v1",
        "key_url": "https://console.groq.com/keys",
        "key_hint": "gsk_로 시작",
        "steps": ["'키 발급 페이지 열기'를 누릅니다.",
                  "구글 계정 등으로 가입/로그인합니다.",
                  "'Create API Key'를 누르고 이름은 아무거나 적습니다.",
                  "나온 키(gsk_…)를 복사해 붙여넣습니다. (창을 닫으면 다시 못 보니 바로 복사!)"],
        "models": [["openai/gpt-oss-120b", "추천 · OpenAI 공개모델"],
                   ["llama-3.3-70b-versatile", "메타 Llama 70B"],
                   ["qwen/qwen3-32b", "알리바바 Qwen3"],
                   ["llama-3.1-8b-instant", "가장 빠름 · 가벼움"]],
    },
    "openrouter": {
        "name": "OpenRouter", "kind": "openai", "tier": "free",
        "badge": "무료 모델 다수",
        "desc": "이름 끝이 ':free'인 모델은 무료. DeepSeek·Llama·Qwen 등 여러 회사 모델을 한 키로.",
        "base": "https://openrouter.ai/api/v1",
        "key_url": "https://openrouter.ai/settings/keys",
        "key_hint": "sk-or-로 시작",
        "steps": ["'키 발급 페이지 열기'를 누릅니다.",
                  "구글 계정 등으로 로그인합니다.",
                  "'Create Key'를 눌러 키(sk-or-…)를 만들고 복사합니다.",
                  "아래에 붙여넣고 '목록 불러오기'로 무료(:free) 모델을 고릅니다."],
        "models": [],  # 무료 모델은 자주 바뀌므로 '목록 불러오기'로 받는다(키 없이도 가능)
    },
    "github": {
        "name": "GitHub Models", "kind": "openai", "tier": "free",
        "badge": "GPT 무료",
        "desc": "깃허브 계정으로 GPT-4.1 등 OpenAI 모델을 무료로(하루 횟수 제한).",
        "base": "https://models.github.ai/inference",
        "key_url": "https://github.com/settings/personal-access-tokens/new",
        "key_hint": "github_pat_ 또는 ghp_로 시작",
        "steps": ["깃허브(github.com)에 가입/로그인합니다.",
                  "'키 발급 페이지 열기' → 이름 아무거나, 기간 선택.",
                  "아래쪽 권한(Permissions)에서 'Models'를 Read-only로 켭니다.",
                  "'Generate token'으로 만든 토큰을 복사해 붙여넣습니다."],
        "models": [["openai/gpt-4.1-mini", "추천 · GPT-4.1 mini"],
                   ["openai/gpt-4.1", "GPT-4.1 · 하루 횟수 적음"],
                   ["openai/gpt-4o-mini", "GPT-4o mini"],
                   ["deepseek/DeepSeek-V3-0324", "DeepSeek V3"]],
    },
    "mistral": {
        "name": "Mistral", "kind": "openai", "tier": "free",
        "badge": "무료",
        "desc": "프랑스 Mistral. 무료 'Experiment' 요금제로 사용(전화번호 인증 필요).",
        "base": "https://api.mistral.ai/v1",
        "key_url": "https://console.mistral.ai/api-keys",
        "key_hint": "32자리 문자",
        "steps": ["'키 발급 페이지 열기'로 가입/로그인합니다.",
                  "요금제는 무료 'Experiment'를 고릅니다(전화번호 인증).",
                  "'Create new key'로 키를 만들어 복사합니다.",
                  "아래 칸에 붙여넣습니다."],
        "models": [["mistral-small-latest", "추천 · 빠름"],
                   ["mistral-medium-latest", "균형"],
                   ["mistral-large-latest", "가장 똑똑함"]],
    },
    "cerebras": {
        "name": "Cerebras", "kind": "openai", "tier": "free",
        "badge": "무료 · 초고속",
        "desc": "카드 없이 무료. 응답 속도가 매우 빠릅니다.",
        "base": "https://api.cerebras.ai/v1",
        "key_url": "https://cloud.cerebras.ai/platform",
        "key_hint": "csk-로 시작",
        "steps": ["'키 발급 페이지 열기'로 가입/로그인합니다.",
                  "왼쪽 'API Keys' 메뉴로 갑니다.",
                  "키(csk-…)를 만들어 복사합니다.",
                  "아래 칸에 붙여넣습니다."],
        "models": [["gpt-oss-120b", "추천 · OpenAI 공개모델"],
                   ["llama-3.3-70b", "메타 Llama 70B"],
                   ["qwen-3-32b", "Qwen3 32B"]],
    },
    "ollama": {
        "name": "Ollama (내 PC)", "kind": "openai", "tier": "local",
        "badge": "완전 무료 · 오프라인",
        "desc": "AI를 내 컴퓨터에서 직접 돌립니다. 키·인터넷 불필요. 대신 PC 사양(메모리 16GB+)이 필요합니다.",
        "base": "http://localhost:11434",
        "key_url": "https://ollama.com/download",
        "key_hint": "키 필요 없음",
        "no_key": True,
        "steps": ["'설치 페이지 열기'에서 Ollama를 내려받아 설치합니다.",
                  "명령창(cmd)에서  ollama pull qwen3:8b  를 한 번 실행합니다.",
                  "아래 '목록 불러오기'로 설치된 모델을 고릅니다."],
        "models": [["qwen3:8b", "추천 · 한국어 무난"],
                   ["gemma3:12b", "구글 Gemma3"],
                   ["llama3.1:8b", "메타 Llama"]],
    },
    "openai": {
        "name": "OpenAI (ChatGPT)", "kind": "openai", "tier": "paid",
        "badge": "유료",
        "desc": "ChatGPT를 만든 회사. API는 무료가 없고 선불 충전($5~)이 필요합니다. ChatGPT Plus 구독과는 별개입니다.",
        "base": "https://api.openai.com/v1",
        "key_url": "https://platform.openai.com/api-keys",
        "key_hint": "sk-로 시작",
        "steps": ["'키 발급 페이지 열기'로 로그인합니다.",
                  "Billing에서 선불 금액을 충전합니다(무료 없음).",
                  "'Create new secret key'로 키(sk-…)를 만들어 복사합니다.",
                  "아래 칸에 붙여넣습니다."],
        "models": [["gpt-5-mini", "추천 · 가성비"],
                   ["gpt-5-nano", "가장 저렴"],
                   ["gpt-4.1-mini", "GPT-4.1 mini"]],
    },
    "anthropic": {
        "name": "Anthropic (Claude)", "kind": "anthropic", "tier": "paid",
        "badge": "유료",
        "desc": "Claude를 만든 회사. API는 선불 충전($5~)이 필요합니다. Claude 구독(Pro)과는 별개입니다.",
        "base": "https://api.anthropic.com/v1",
        "key_url": "https://console.anthropic.com/settings/keys",
        "key_hint": "sk-ant-로 시작",
        "steps": ["'키 발급 페이지 열기'로 로그인합니다.",
                  "Billing에서 선불 크레딧을 충전합니다.",
                  "'Create Key'로 키(sk-ant-…)를 만들어 복사합니다.",
                  "아래 칸에 붙여넣습니다."],
        "models": [["claude-haiku-4-5-20251001", "추천 · 빠르고 저렴"],
                   ["claude-sonnet-5-5", "균형 · 똑똑함"],
                   ["claude-opus-5-5", "가장 똑똑함 · 비쌈"]],
    },
}
ORDER = ["gemini", "groq", "openrouter", "github", "mistral", "cerebras", "ollama", "openai", "anthropic"]

# 구글 서버 혼잡(503) 때 자동으로 바꿔 시도할 Gemini 모델
# 기본 모델이 그 키에서 안 될 때(모델 이름 없음·과부하) 순서대로 대신 시도
GEM_FALLBACK = ["gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-3-flash"]


# ---------------------------------------------------------------------------
# 설정 파일 (userdata/settings.json)
# ---------------------------------------------------------------------------
_LOCK = threading.Lock()


def load_settings():
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            s = json.load(f)
            if isinstance(s, dict):
                return s
    except Exception:
        pass
    return {}


def save_settings(s):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = SETTINGS_PATH + ".tmp"
    with _LOCK:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False, indent=2)
        os.replace(tmp, SETTINGS_PATH)


def mask(key):
    key = (key or "").strip()
    if not key:
        return ""
    if len(key) <= 10:
        return key[:2] + "…"
    return key[:4] + "…" + key[-4:]


def _configured(pid, cfg):
    if not cfg:
        return False
    if PROVIDERS.get(pid, {}).get("no_key"):
        return bool(cfg.get("model"))
    return bool((cfg.get("key") or "").strip())


def default_model(pid):
    ms = PROVIDERS.get(pid, {}).get("models") or []
    return ms[0][0] if ms else ""


# ---------------------------------------------------------------------------
# 에러 → 쉬운 한국어
# ---------------------------------------------------------------------------
class AIError(Exception):
    def __init__(self, code, msg, detail=""):
        super().__init__(msg)
        self.code = code
        self.msg = msg
        self.detail = detail


def _extract_msg(body_text):
    """AI 회사가 보낸 오류 본문(JSON)에서 사람이 읽을 문장만 꺼냄."""
    try:
        j = json.loads(body_text)
        e = j.get("error", j) if isinstance(j, dict) else j
        if isinstance(e, dict):
            return str(e.get("message") or e.get("msg") or e)[:200]
        if isinstance(e, list) and e and isinstance(e[0], dict):
            return str((e[0].get("error") or {}).get("message") or e[0])[:200]
        return str(e)[:200]
    except Exception:
        return (body_text or "")[:200]


def _friendly(status, body_text, pid):
    t = _extract_msg(body_text)
    low = (body_text or "")[:600].lower()
    if "access_token_type_unsupported" in low or "expected oauth 2 access token" in low:
        return AIError("auth", "구글이 이 키(AQ.로 시작하는 새 형식)를 아직 받아 주지 않았어요. 구글 쪽에서 일부 계정에 생기는 문제예요. "
                               "① 키 발급 페이지에서 키를 새로 만들어 다시 붙여넣거나 ② 잠시 뒤 다시 해 보거나 ③ 다른 무료 AI(Groq 등)를 추가해 주세요. "
                               "(구글 오류: ACCESS_TOKEN_TYPE_UNSUPPORTED)", t)
    if status in (401, 403) or "api key not valid" in low or "invalid api key" in low or "unauthorized" in low:
        return AIError("auth", "키가 올바르지 않아요. 키를 다시 복사해서 붙여넣어 주세요.", t)
    if status == 402 or "insufficient" in low or "credit" in low or "billing" in low:
        return AIError("billing", "충전된 금액(크레딧)이 없어요. 이 회사는 유료라 선불 충전이 필요합니다.", t)
    if status == 429 or "quota" in low or "rate limit" in low or "resource_exhausted" in low:
        return AIError("quota", "오늘(또는 1분) 무료 사용 한도를 다 썼어요. 잠시 후 다시 하거나 다른 AI를 추가해 두세요.", t)
    if status == 404 or "not found" in low or "does not exist" in low or "model_not_found" in low:
        return AIError("model", "이 모델 이름을 찾을 수 없어요. '목록 불러오기'로 모델을 다시 골라 주세요.", t)
    if status in (500, 502, 503, 504) or "overloaded" in low or "unavailable" in low:
        return AIError("busy", "AI 회사 서버가 지금 붐벼요. 잠시 후 다시 시도해 주세요.", t)
    return AIError("other", f"AI 호출 실패 (HTTP {status})", t)


def _post(url, headers, body, pid):
    """일시 장애(5xx)는 재시도, 429는 한 번만 짧게 재시도."""
    last_err = None
    for i in range(3):
        try:
            r = requests.post(url, headers=headers, json=body, timeout=AI_TIMEOUT)
        except requests.exceptions.ConnectionError:
            if pid == "ollama":
                raise AIError("network", "Ollama가 켜져 있지 않아요. Ollama 프로그램을 실행해 주세요.")
            last_err = AIError("network", "인터넷 연결을 확인해 주세요.")
            time.sleep(1.5 * (i + 1))
            continue
        except requests.exceptions.Timeout:
            last_err = AIError("busy", "AI 응답이 너무 늦어요(시간 초과). 잠시 후 다시 시도해 주세요.")
            continue
        if r.status_code < 400:
            return r
        err = _friendly(r.status_code, r.text, pid)
        if err.code == "busy" and i < 2:
            time.sleep((2 ** i) + random.uniform(0, 1))
            last_err = err
            continue
        if err.code == "quota" and i == 0 and "per minute" in r.text.lower():
            time.sleep(2.5)
            last_err = err
            continue
        raise err
    raise last_err or AIError("other", "AI 호출 실패")


# ---------------------------------------------------------------------------
# 호출
# ---------------------------------------------------------------------------
def call(pid, key, model, prompt=None, max_out=1200, base_url=None,
         system=None, messages=None, temperature=0.7):
    """한 번 호출. messages=[{"role":"user"|"assistant","content":"..."}] 를 주면 대화형."""
    p = PROVIDERS.get(pid)
    if not p:
        raise AIError("other", f"알 수 없는 AI 회사: {pid}")
    msgs = list(messages or [])
    if prompt:
        msgs.append({"role": "user", "content": prompt})
    if not msgs:
        raise AIError("other", "보낼 내용이 없어요.")
    kind = p["kind"]

    if kind == "gemini":
        url = f"{p['base']}/models/{model}:generateContent"
        headers = {"x-goog-api-key": key, "content-type": "application/json"}
        gen = {"temperature": temperature, "maxOutputTokens": max_out}
        # 2.5 flash 계열은 '생각'에 토큰을 써서 본문이 잘림 → 끔. (pro 는 끌 수 없음)
        if model.startswith("gemini-2.5-flash"):
            gen["thinkingConfig"] = {"thinkingBudget": 0}
        body = {"contents": [{"role": "model" if m["role"] == "assistant" else "user",
                              "parts": [{"text": m["content"]}]} for m in msgs],
                "generationConfig": gen}
        if system:
            body["systemInstruction"] = {"parts": [{"text": system}]}
        r = _post(url, headers, body, pid)
        j = r.json()
        cands = j.get("candidates") or []
        parts = (cands[0].get("content", {}).get("parts") if cands else []) or []
        text = "".join(x.get("text", "") for x in parts if not x.get("thought")).strip()
        if not text and cands and cands[0].get("finishReason") == "SAFETY":
            raise AIError("other", "AI가 안전 정책으로 답을 거절했어요. 질문을 바꿔 보세요.")
        return text

    if kind == "anthropic":
        url = f"{p['base']}/messages"
        headers = {"x-api-key": key, "anthropic-version": "2023-06-01",
                   "content-type": "application/json"}
        body = {"model": model, "max_tokens": max_out, "messages": msgs}
        if system:
            body["system"] = system
        r = _post(url, headers, body, pid)
        blocks = r.json().get("content", []) or []
        return "".join(b.get("text", "") for b in blocks if b.get("type") == "text").strip()

    # OpenAI 호환(OpenAI·Groq·OpenRouter·GitHub·Mistral·Cerebras·Ollama)
    base = (base_url or p["base"]).rstrip("/")
    if pid == "ollama" and not base.endswith("/v1"):
        base += "/v1"
    url = f"{base}/chat/completions"
    headers = {"content-type": "application/json"}
    if key:
        headers["authorization"] = f"Bearer {key}"
    if pid == "openrouter":
        headers["HTTP-Referer"] = "http://localhost"
        headers["X-Title"] = "My Asset App"
    full = ([{"role": "system", "content": system}] if system else []) + msgs
    body = {"model": model, "messages": full}
    if pid == "openai":
        # 최신 OpenAI 모델은 max_tokens 대신 max_completion_tokens, temperature 고정
        body["max_completion_tokens"] = max_out * (4 if model.startswith(("gpt-5", "o")) else 1)
        if not model.startswith(("gpt-5", "o")):
            body["temperature"] = temperature
    else:
        body["max_tokens"] = max_out
        body["temperature"] = temperature
    r = _post(url, headers, body, pid)
    j = r.json()
    ch = (j.get("choices") or [{}])[0]
    text = ((ch.get("message") or {}).get("content") or "").strip()
    # 일부 추론 모델은 <think>…</think> 를 본문에 섞어 보냄 → 제거
    if "<think>" in text and "</think>" in text:
        text = text.split("</think>", 1)[1].strip()
    return text


def list_models(pid, key="", base_url=None):
    """그 회사에서 지금 쓸 수 있는 모델 목록 [[id, 설명], ...]."""
    p = PROVIDERS[pid]
    kind = p["kind"]
    out = []
    if kind == "gemini":
        r = requests.get(f"{p['base']}/models?pageSize=200", headers={"x-goog-api-key": key}, timeout=15)
        if r.status_code >= 400:
            raise _friendly(r.status_code, r.text, pid)
        skip = ("embedding", "tts", "image", "vision", "live", "audio", "aqa", "learnlm", "thinking", "-exp")
        prev = []
        for m in r.json().get("models", []) or []:
            nm = (m.get("name") or "").replace("models/", "")
            if "generateContent" not in (m.get("supportedGenerationMethods") or []) or not nm.startswith("gemini"):
                continue
            if any(x in nm for x in skip):
                continue
            row = [nm, m.get("displayName") or ""]
            (prev if ("preview" in nm or "-pre" in nm) else out).append(row)
        # 정식 모델 먼저(최신순), 그다음 preview. 깔끔한 이름만 보이게.
        out.sort(key=lambda x: x[0], reverse=True)
        prev.sort(key=lambda x: x[0], reverse=True)
        res = out + prev
        return res if res else [[nm, dn] for nm, dn in ((m.get("name", "").replace("models/", ""), m.get("displayName", ""))
                                                        for m in r.json().get("models", []) or []) if nm.startswith("gemini")]
    if kind == "anthropic":
        r = requests.get(f"{p['base']}/models?limit=100",
                         headers={"x-api-key": key, "anthropic-version": "2023-06-01"}, timeout=15)
        if r.status_code >= 400:
            raise _friendly(r.status_code, r.text, pid)
        return [[m["id"], m.get("display_name", "")] for m in r.json().get("data", [])]
    if pid == "ollama":
        base = (base_url or p["base"]).rstrip("/")
        if base.endswith("/v1"):
            base = base[:-3]
        try:
            r = requests.get(f"{base}/api/tags", timeout=5)
        except requests.exceptions.ConnectionError:
            raise AIError("network", "Ollama가 켜져 있지 않아요. Ollama 프로그램을 실행해 주세요.")
        return [[m["name"], f"{round((m.get('size') or 0) / 1e9, 1)}GB"] for m in r.json().get("models", [])]
    if pid == "openrouter":
        r = requests.get(f"{p['base']}/models", timeout=15)
        r.raise_for_status()
        known = ("deepseek/", "meta-llama/", "google/", "qwen/", "mistralai/", "openai/", "moonshotai/", "z-ai/", "nvidia/")
        for m in r.json().get("data", []):
            if not m["id"].endswith(":free"):   # 가격 0이어도 ':free'가 아닌 미리보기 모델은 제외
                continue
            ctx = m.get("context_length") or 0
            out.append([m["id"], (m.get("name") or "") + (f" · {ctx // 1000}K" if ctx else "")])
        out.sort(key=lambda x: (0 if x[0].startswith(known) else 1, x[0]))
        return out
    if pid == "github":
        r = requests.get("https://models.github.ai/catalog/models",
                         headers={"authorization": f"Bearer {key}"} if key else {}, timeout=15)
        if r.status_code >= 400:
            raise _friendly(r.status_code, r.text, pid)
        for m in r.json():
            mods = m.get("supported_output_modalities") or ["text"]
            if "text" in mods and "embedding" not in (m.get("id") or ""):
                out.append([m["id"], m.get("name") or ""])
        return out
    r = requests.get(f"{p['base']}/models", headers={"authorization": f"Bearer {key}"}, timeout=15)
    if r.status_code >= 400:
        raise _friendly(r.status_code, r.text, pid)
    skip = ("embed", "whisper", "tts", "dall-e", "image", "audio", "moderation", "realtime",
            "transcribe", "guard", "search", "davinci", "babbage", "ocr")
    for m in r.json().get("data", []):
        mid = m.get("id") or ""
        if mid and not any(s in mid.lower() for s in skip):
            out.append([mid, ""])
    out.sort(key=lambda x: x[0])
    return out


# ---------------------------------------------------------------------------
# 후보 순서: 기본 AI → (자동 대체 켜짐) 다른 등록 AI들 → 예전 환경변수 키
# ---------------------------------------------------------------------------
def candidates():
    s = load_settings()
    provs = s.get("providers") or {}
    prim = s.get("primary")
    out, seen = [], set()

    def add(pid, key, model, base=None):
        k = (pid, key, model)
        if model and k not in seen:
            seen.add(k)
            out.append((pid, key, model, base))

    def add_cfg(pid):
        cfg = provs.get(pid) or {}
        if pid not in PROVIDERS or not _configured(pid, cfg):
            return
        model = cfg.get("model") or default_model(pid)
        add(pid, (cfg.get("key") or "").strip(), model, cfg.get("base_url"))
        if pid == "gemini":
            for m in GEM_FALLBACK:
                add(pid, cfg["key"].strip(), m)

    if prim:
        add_cfg(prim)
    if s.get("auto_fallback", True) or not prim:
        for pid in ORDER:
            if pid != prim:
                add_cfg(pid)

    # 예전 방식: 환경변수
    def env_keys(*names):
        ks = []
        for n in names:
            for part in (os.environ.get(n) or "").split(","):
                part = part.strip()
                if part and part not in ks:
                    ks.append(part)
        return ks
    env_model = os.environ.get("AI_MODEL")
    for k in env_keys("GEMINI_API_KEY", "GEMINI_API_KEY2", "GEMINI_API_KEY3", "GOOGLE_API_KEY"):
        for m in ([env_model] if env_model and env_model.startswith("gemini") else []) + GEM_FALLBACK:
            add("gemini", k, m)
    for k in env_keys("ANTHROPIC_API_KEY", "ANTHROPIC_API_KEY2"):
        add("anthropic", k, os.environ.get("AI_MODEL_ANTHROPIC") or default_model("anthropic"))
    for k in env_keys("OPENAI_API_KEY"):
        add("openai", k, os.environ.get("AI_MODEL_OPENAI") or default_model("openai"))
    for k in env_keys("GROQ_API_KEY"):
        add("groq", k, default_model("groq"))
    return out


def has_ai():
    return bool(candidates())


def complete(prompt=None, max_out=1200, system=None, messages=None, temperature=0.7):
    """후보를 차례로 시도. 반환 (text, provider_name, model, error_message)."""
    cands = candidates()
    if not cands:
        return (None, None, None, "NO_KEY")
    last = None
    bad_keys = set()
    for pid, key, model, base in cands:
        # 키가 틀렸거나 충전이 없으면 같은 키의 다른 모델은 건너뜀.
        # (한도 초과는 Gemini처럼 '모델별' 한도인 곳이 있어 다른 모델은 계속 시도)
        if (pid, key) in bad_keys:
            continue
        try:
            text = call(pid, key, model, prompt=prompt, max_out=max_out, base_url=base,
                        system=system, messages=messages, temperature=temperature)
            if text:
                return (text, PROVIDERS[pid]["name"], model, None)
            last = AIError("other", "AI가 빈 답을 보냈어요.")
        except AIError as e:
            last = e
            if e.code in ("auth", "billing"):
                bad_keys.add((pid, key))
        except Exception as e:  # 예상 못 한 오류도 다음 후보로
            last = AIError("other", f"{type(e).__name__}")
    msg = last.msg if isinstance(last, AIError) else str(last)
    for _, k, _, _ in cands:
        if k:
            msg = msg.replace(k, "***")
    return (None, None, None, msg)


def status_summary():
    s = load_settings()
    cands = candidates()
    if not cands:
        return {"on": False, "provider": None, "model": None, "count": 0}
    pid, _, model, _ = cands[0]
    n = len({(c[0], c[1]) for c in cands})
    return {"on": True, "provider": PROVIDERS[pid]["name"], "provider_id": pid,
            "model": model, "count": n, "auto_fallback": s.get("auto_fallback", True)}


# ---------------------------------------------------------------------------
# 화면(설정)용 API
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 관심 섹터 — 화면이 'X-AI-Sectors: semi,battery' 처럼 키만 보냄 (web/js/core.js SECTORS 와 키가 같아야 함)
# ---------------------------------------------------------------------------
SECTOR_INFO = {
    "semi": "반도체 (메모리·파운드리·장비·소재·AI칩 설계)",
    "battery": "2차전지·배터리 (셀·양극재·음극재·전해질·분리막·리튬)",
    "ai": "AI·소프트웨어 (AI 서비스·클라우드·데이터센터 소프트웨어·보안)",
    "platform": "인터넷·플랫폼 (검색·메신저·커머스·핀테크)",
    "bigtech": "미국 빅테크 (대형 기술주)",
    "display": "디스플레이·전자부품 (OLED·기판·카메라모듈·MLCC)",
    "robot": "로봇·자동화 (산업용·협동 로봇·감속기·스마트팩토리)",
    "space": "우주항공 (위성·발사체·항공기 부품)",
    "bio": "바이오·제약 (신약·바이오시밀러·CDMO·비만/항암 치료제)",
    "health": "의료기기·헬스케어 (미용의료·진단·임플란트·디지털 헬스)",
    "auto": "자동차·부품 (완성차·전장·타이어·전기차 부품)",
    "ship": "조선·해운 (LNG선·선박 엔진·기자재·해운사)",
    "defense": "방산 (무기 수출·K방산·탄약·레이더)",
    "nuclear": "원전·전력기기 (원전 설비·SMR·변압기·전선·전력망)",
    "green": "신재생·수소 (태양광·풍력·수소·연료전지)",
    "chem": "정유·화학 (정유·석유화학·특수화학)",
    "steel": "철강·소재 (철강·비철금속·희토류·소재)",
    "build": "건설·인프라 (건설·시멘트·해외 수주·인프라)",
    "bank": "은행·금융지주 (밸류업·배당·주주환원)",
    "broker": "증권·보험 (증권사·손해/생명보험)",
    "beauty": "화장품·뷰티 (K뷰티 수출·ODM·인디 브랜드)",
    "food": "음식료·유통 (K푸드 수출·라면·편의점·백화점)",
    "travel": "여행·항공·레저 (항공·여행사·카지노·호텔)",
    "content": "엔터·K콘텐츠 (K팝 기획사·드라마/영화 제작·웹툰)",
    "game": "게임 (모바일·PC·콘솔 게임사)",
    "telecom": "통신 (이동통신사·통신장비)",
    "crypto": "가상자산 관련 (거래소 지분·비트코인 보유 기업·블록체인)",
    "dividend": "고배당·리츠 (배당주·부동산 리츠)",
    "etf": "ETF·지수 (국내외 대표 지수·테마 ETF)",
}


def req_sectors(extra=None):
    """요청의 관심 섹터 키 목록 (머리글 + 본문). 모르는 키는 버림."""
    raw = []
    try:
        raw += [x.strip() for x in str(request.headers.get("X-AI-Sectors", "")).split(",")]
    except Exception:
        pass
    if isinstance(extra, list):
        raw += [str(x).strip() for x in extra]
    out = []
    for k in raw:
        if k in SECTOR_INFO and k not in out:
            out.append(k)
    return out[:15]


# 투자자 설문 — 화면이 'X-AI-Profile: age=40;job=office;goal=retire;...' 로 보냄 (web/js/core.js PROFILE_Q 와 키가 같아야 함)
PROFILE_TEXT = {
    "age": ("나이", {"20": "20대 이하", "30": "30대", "40": "40대", "50": "50대", "60": "60대 이상"}),
    "job": ("직업", {"office": "회사원", "biz": "자영업·사업", "pro": "전문직", "public": "공무원·교사", "free": "프리랜서",
                     "student": "학생", "home": "주부", "retired": "은퇴", "etc": "기타"}),
    "goal": ("운용 목적", {"grow": "목돈을 크게 불리기", "retire": "노후·은퇴 준비", "house": "내 집 마련", "income": "꾸준한 배당·용돈",
                         "edu": "자녀 교육·결혼 자금", "keep": "물가 이기며 지키기", "short": "짧게 빠른 수익"}),
    "exp": ("투자 경험", {"0": "처음", "1": "1년 미만", "3": "1~3년", "5": "3~10년", "10": "10년 넘게"}),
    "risk": ("-20% 손실 때 반응(위험 감내)", {"low": "무서워서 팔 것 같음 — 위험 회피형", "mid": "지켜보며 기다림 — 중립형", "high": "오히려 더 삼 — 공격형"}),
    "share": ("전체 자산 중 투자 비중", {"s": "10% 미만(여윳돈)", "m": "10~30%", "l": "30~50%", "xl": "50% 넘게"}),
    # v4.16 — 더 다양한 질문
    "src": ("투자금의 성격", {"pay": "매달 월급에서 조금씩", "lump": "모아 둔 목돈", "sev": "퇴직금·보상금 — 잃으면 복구가 어려움, 지키는 쪽을 먼저",
                        "loan": "빌린 돈·신용 — 위험을 가장 먼저, 레버리지 위험을 분명히", "gift": "상속·증여"}),
    "info": ("정보를 주로 얻는 곳", {"news": "뉴스·신문", "yt": "유튜브·방송", "chart": "차트·HTS 직접", "ppl": "주변 사람·단톡방 — 소문과 사실을 구분해 주기",
                            "rep": "증권사 리포트·공시", "none": "거의 안 봄 — 기초 정보도 함께"}),
    "dec": ("결정하는 방식", {"num": "숫자·근거를 따져서 — 수치·출처를 넉넉히", "gut": "느낌·직감으로 — 근거를 짧고 분명하게 짚어 주기",
                          "follow": "남들 따라서 — 스스로 판단할 기준을 세워 주기", "slow": "오래 고민하는 편 — 핵심을 먼저 정리해 주기"}),
    "time": ("장중에 볼 수 있는 시간", {"no": "거의 못 봄 — 장중 대응이 필요한 이야기는 피하기", "some": "하루 한두 번", "live": "장중 계속 볼 수 있음"}),
    "target": ("1년 목표 수익", {"bank": "은행 이자보다 조금 더", "10": "10% 정도", "20": "20% 이상", "x2": "두 배 이상 — 그만큼의 위험을 분명히"}),
    "asset": ("주로 투자하는 것", {"kr": "국내 주식", "us": "미국 주식", "etf": "ETF 위주", "mix": "주식+코인", "re": "부동산이 더 큼 — 주식은 보조"}),
    "learn": ("배우고 싶은 정도", {"just": "결론만 간단히", "why": "이유까지", "deep": "공부하듯 깊게 — 개념·배경도 설명"}),
    "fam": ("가족 상황", {"solo": "혼자", "couple": "부부", "kids": "어린 자녀 — 교육비·안정성 고려", "grown": "자녀 독립", "parent": "부모님 부양"}),
    "worry": ("투자하며 가장 걱정되는 것", {"loss": "원금 손실", "miss": "기회를 놓치는 것", "time": "볼 시간이 없는 것", "know": "모르고 하는 것", "tax": "세금·제도"}),
    # v4.17 — 💰 자본 자세히
    "emerg": ("비상금(생활비)", {"0": "없음 — 투자금이 곧 생활비가 될 수 있으니 유동성·안전을 최우선", "3": "1~3개월치", "6": "3~6개월치", "12": "6개월치 넘게"}),
    "living": ("생활비 형편", {"tight": "빠듯함 — 손실이 생활에 바로 영향", "ok": "보통", "easy": "여유 있음"}),
    "income": ("수입", {"fixed": "매달 고정", "var": "들쭉날쭉 — 현금 여유를 더 두는 쪽", "none": "수입 없음·은퇴 — 원금 보전과 현금흐름이 우선"}),
    "debt": ("투자에 쓴 빚", {"no": "없음", "low": "있음(이자 5% 미만)", "mid": "있음(이자 5~10%) — 기대 수익이 이자를 넘기 어려움을 분명히", "high": "있음(이자 10% 넘게) — 빚부터 갚는 것이 가장 확실한 수익임을 분명히"}),
    "debt_due": ("빚 만기", {"1": "1년 안 — 그 전에 현금화해야 하니 변동성 큰 자산은 위험", "3": "1~3년", "99": "3년 넘게·만기 없음"}),
    "pension": ("연금", {"yes": "생활비는 연금으로 충당됨", "part": "조금 부족 — 투자금에서 생활비를 빼 써야 할 수 있음", "no": "거의 없음 — 투자금이 노후 자금 그 자체, 손실 복구가 어려움"}),
    "kids_cost": ("몇 년 안 큰 지출", {"soon": "1~2년 안 — 그 돈은 변동성 자산에 두지 않는 쪽", "later": "3~5년 뒤", "no": "당장은 없음"}),
    # v4.17 — 🧠 성격·습관
    "on_loss": ("-10% 때 실제 행동", {"sell": "바로 팜 — 내릴 때마다 팔기를 반복하면 손실이 쌓이기 쉬우니 사기 전에 기준을 정하도록", "avg": "더 사서 평균 낮춤 — 물타기 위험(집중 커짐)을 짚어 주기",
                                  "hold": "그냥 둠", "never": "겪어 본 적 없음 — 첫 손실 때 어떻게 될지 미리 생각하게"}),
    "on_gain": ("+20% 때 실제 행동", {"sell": "바로 팜 — 이익은 짧게 손실은 길게 가는 습관 주의", "more": "더 삼 — 추격 매수 위험", "hold": "그냥 둠", "part": "절반만 팜"}),
    "regret": ("더 아픈 것", {"miss": "오를 종목을 안 산 것 — FOMO(놓칠까 두려움)로 급하게 사는 경향 주의", "lose": "산 종목이 떨어진 것 — 손실 회피 성향, 안전 자산 비중을 더"}),
    "speed": ("결정 속도", {"now": "바로 그 자리에서 — 충동 매매 위험, '하루 자고 결정' 습관 제안", "day": "하루 뒤", "days": "며칠 알아보고", "weeks": "몇 주 지켜보고"}),
    "depend": ("남 의견에 흔들림", {"much": "많이 — 유튜브·지인 말에 사기 쉬우니 스스로 확인할 기준을 주기", "some": "조금", "no": "거의 안"}),
    "sleep": ("손실 중 잠", {"bad": "못 잠 — 지금 변동성이 이 사람에게 너무 크다는 신호, 비중·종목 위험을 낮추는 쪽", "so": "뒤척임", "fine": "잘 잠"}),
    "night": ("밤에 미국 시세", {"often": "자주 봄 — 수면·건강 비용도 투자 비용", "some": "가끔", "no": "안 봄"}),
}
PROFILE_NUM = {"cap_total": "투자에 쓸 수 있는 총자금", "cap_month": "매달 새로 넣을 수 있는 돈"}


def _man(v):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return None
    if v < 0:
        return None
    return ("%.1f" % (v / 10000)).rstrip("0").rstrip(".") + "억 원" if v >= 10000 else ("%d만 원" % round(v) if v >= 1 else "0원")


def req_profile_text():
    """요청의 투자자 설문을 AI 지시문 한 덩어리로. 없으면 빈 문자열."""
    try:
        raw = str(request.headers.get("X-AI-Profile", ""))
    except Exception:
        return ""
    lines, got = [], {}
    for part in raw.split(";"):
        k, _, v = part.partition("=")
        k, v = k.strip(), v.strip()
        if k in PROFILE_TEXT and v in PROFILE_TEXT[k][1]:
            lines.append(f"- {PROFILE_TEXT[k][0]}: {PROFILE_TEXT[k][1][v]}")
            got[k] = v
        elif k in PROFILE_NUM and _man(v) is not None:
            lines.append(f"- {PROFILE_NUM[k]}: 약 {_man(v)}")
            got[k] = float(v)
    if not lines:
        return ""
    # 🛡 안전 점검 — 가장 안전한 대안을 먼저 주기 위한 신호 (앱이 설문에서 계산)
    flags = []
    if got.get("emerg") == "0":
        flags.append("비상금이 없음")
    if got.get("debt") in ("mid", "high"):
        flags.append("이자 높은 빚으로 투자 중")
    if got.get("debt_due") == "1":
        flags.append("1년 안에 갚을 빚")
    if got.get("pension") == "no" or got.get("income") == "none":
        flags.append("수입·연금이 없어 손실 복구가 어려움")
    if got.get("kids_cost") == "soon":
        flags.append("1~2년 안 큰 지출 예정")
    if got.get("sleep") == "bad":
        flags.append("손실 중 잠을 못 잠(변동성 과다)")
    if got.get("living") == "tight":
        flags.append("생활비 빠듯")
    if got.get("cap_month") is not None and got.get("cap_total") and got["cap_month"] > 0 and got["cap_total"] < got["cap_month"] * 3:
        flags.append("총자금이 작아 적립식이 더 맞음")
    safety = ""
    if flags:
        safety = ("\n[🛡 안전 신호 — 이 사람에게는 '가장 안전한 대안'을 먼저 보여 주세요: " + " · ".join(flags) + "]"
                  "\n- 위 신호가 있으면 답의 앞부분에 그 사람 상황에서 안전한 쪽(현금 비중·분할·변동성 낮은 자산·빚 상환·비상금 확보)을 먼저 말하고, 공격적인 이야기는 뒤에 작게.")
    return ("[이 투자자에 대해 — 답의 방향·위험 수준·예시를 여기에 맞추세요. 사용자를 잘 알수록 더 안전한 대안을 줄 수 있습니다]\n" + "\n".join(lines) + safety +
            "\n- 예: 노후 준비·위험 회피형이면 변동성 큰 종목은 비중을 작게 권하고 위험을 먼저, 처음 하는 사람이면 기초부터,"
            " 투자 비중이 크면 분산·현금 비중을 강조, 젊고 공격형이면 성장주 기회도 함께. 단, 사용자에게 설문 내용을 그대로 읊지는 마세요.")


# 🎭 AI 캐릭터 (v4.16) — 사람마다 다른 말투·비유·순서·분위기. 사실·근거·결론은 바꾸지 않고 '말하는 방식'만.
PERSONA_TONE = {"polite": "정중한 존댓말", "friend": "친근한 반말 (친구처럼)", "senior": "경험 많은 선배처럼 (존댓말이지만 편하게)",
                "warm": "손주가 어르신께 말하듯 다정하고 쉬운 존댓말", "anchor": "뉴스 앵커처럼 또박또박 중립적으로", "pro": "전문가처럼 건조하고 간결하게",
                "coach": "운동 코치처럼 힘 있게 북돋우며", "calm": "차분한 상담사처럼 안심시키며"}
PERSONA_META = {"none": "비유를 거의 쓰지 않음", "cook": "요리·음식", "farm": "농사·텃밭", "sport": "스포츠·경기", "baduk": "바둑·장기", "drive": "운전·길",
                "weather": "날씨·계절", "fish": "낚시·바다", "kids": "육아·아이 키우기", "shop": "장사·가게 운영", "army": "군대·작전", "hike": "등산",
                "game": "게임·RPG", "music": "음악·악기", "health": "건강·운동·식단", "build": "집 짓기·건축", "travel": "여행", "drama": "드라마·영화"}
PERSONA_ORDER = {"first": "결론부터 한 줄로 말하고 근거를 붙임", "why": "근거를 차례로 쌓은 뒤 마지막에 결론", "ask": "먼저 짧게 되묻거나 상황을 짚고 나서 설명",
                 "story": "이야기하듯 흐름을 따라 설명"}
_VOICE_A = ["첫 문장은 늘 '지금 상황을 한 줄로 하면'으로 시작", "첫 문장은 늘 질문 형태로 시작", "첫 문장에 오늘 날짜·시각의 분위기를 한마디 얹음",
            "핵심 숫자 하나를 먼저 던지고 시작", "'좋은 소식부터 / 나쁜 소식부터' 식으로 둘로 나눠 시작", "상대의 상황(설문)을 한마디 짚고 시작",
            "속담이나 격언 한 줄로 시작", "'결론: ○○' 처럼 굵은 한 줄로 시작", "가장 중요한 위험 하나를 먼저 말하고 시작", "최근 뉴스 제목 하나를 인용하며 시작",
            "비유 한 문장으로 그림을 그리며 시작", "'3가지만 보면 돼요' 식으로 개수를 먼저 말하고 시작"]
_VOICE_B = ["문단 끝마다 한 줄 요약을 괄호로 붙임", "숫자는 항상 '쉽게 말하면 ~'으로 한 번 더 풀어 줌", "중요한 말은 ★ 표시로 강조", "근거마다 '출처:'를 짧게 붙임",
            "단락마다 소제목을 이모지 하나로 시작", "'반대로 보면' 단락을 꼭 하나 넣음", "'제가 틀릴 수 있는 지점'을 한 줄 밝힘", "표를 즐겨 씀(2~3열)",
            "번호 목록을 즐겨 씀", "짧은 문장을 즐겨 씀(한 문장 20자 안팎)", "'예를 들면'으로 구체적 예를 꼭 하나 듦", "마지막에 '한 줄 기억' 문장을 남김"]
_VOICE_C = ["마무리는 다음에 볼 신호 하나로", "마무리는 격려 한마디로", "마무리는 질문 하나로(사용자가 생각해 보도록)", "마무리는 오늘 할 수 있는 작은 확인 한 가지로",
            "마무리는 비유를 마무리하며", "마무리는 체크리스트 3개로", "마무리는 '만약 ~라면' 두 갈래로", "마무리는 담담한 한 문장으로"]


PERSONA_SAMPLE = {   # 말투별 예시 문장 — 모델이 흉내 내기 쉽게 (내용은 예시일 뿐)
    "polite": "삼성전자는 오를 근거가 3개, 내릴 근거가 2개로 오를 근거 쪽이 조금 더 많습니다. 다만 환율 부담은 먼저 보셔야 합니다.",
    "friend": "삼성전자, 오를 근거 3개에 내릴 근거 2개야. 오를 쪽이 살짝 많아. 근데 환율은 좀 신경 쓰이네.",
    "senior": "삼성전자 보면요, 오를 근거 3개·내릴 근거 2개예요. 오를 쪽이 조금 앞서는데, 저라면 환율부터 챙겨 봐요.",
    "warm": "삼성전자는요, 오를 이유가 세 가지, 내릴 이유가 두 가지예요. 오를 쪽이 조금 더 많아요. 어려운 말 없이 천천히 설명드릴게요.",
    "anchor": "삼성전자, 상승 근거 3건 대 하락 근거 2건. 상승 쪽이 우세합니다. 변수는 환율입니다.",
    "pro": "삼성전자: 상승 근거 3, 하락 근거 2. 상승 우위. 리스크 요인은 환율.",
    "coach": "삼성전자! 오를 근거 3개, 내릴 근거 2개. 오를 쪽이 앞서 있어요. 환율만 체크하고 가요, 집중!",
    "calm": "삼성전자는 오를 근거가 3개, 내릴 근거가 2개예요. 서두를 건 없어요. 환율은 천천히 같이 보면 돼요.",
}


def req_persona_brief():
    """프롬프트 본문 맨 위에 붙이는 한 줄 — 모델이 가장 잘 보는 자리."""
    p = req_persona()
    if not p:
        return ""
    try:
        if int(p.get("str", 6)) == 0:
            return ""
    except (TypeError, ValueError):
        pass
    bits = []
    if p.get("name"):
        bits.append("이름 " + p["name"][:20])
    if p.get("tone") in PERSONA_TONE:
        bits.append("말투: " + PERSONA_TONE[p["tone"]])
    if p.get("meta") in PERSONA_META and p["meta"] != "none":
        bits.append("비유: " + PERSONA_META[p["meta"]])
    if p.get("order") in PERSONA_ORDER:
        bits.append(PERSONA_ORDER[p["order"]])
    if p.get("catch", "").strip():
        bits.append("말버릇 '" + p["catch"].strip()[:30] + "'")
    return "🎭 [이 답은 반드시 이 캐릭터로] " + " · ".join(bits) if bits else ""


def _pseed(seed, n, salt):
    import hashlib
    h = hashlib.sha256(f"{seed}:{salt}".encode()).hexdigest()
    return int(h[:8], 16) % n


def req_persona():
    """X-AI-Persona 헤더 → dict (없으면 {})."""
    try:
        raw = str(request.headers.get("X-AI-Persona", ""))
    except Exception:
        return {}
    out = {}
    for part in raw.split(";"):
        k, _, v = part.partition("=")
        k, v = k.strip(), v.strip()
        if k:
            try:
                from urllib.parse import unquote
                out[k] = unquote(v)[:200]
            except Exception:
                out[k] = v[:200]
    return out


def req_temperature(base=0.6):
    """캐릭터의 '다양성' 슬라이더(0~10)로 온도 조절: 0=늘 비슷(0.3) … 10=매번 다르게(1.0). 없으면 기본."""
    p = req_persona()
    try:
        v = int(p.get("var", ""))
        return round(0.3 + max(0, min(10, v)) * 0.07, 2)
    except (TypeError, ValueError):
        return base


def req_persona_text():
    p = req_persona()
    if not p:
        return ""
    def sl(k, default=5):
        try:
            return max(0, min(10, int(p.get(k, default))))
        except (TypeError, ValueError):
            return default
    strength = sl("str", 6)
    if strength == 0:
        return ""
    lines = []
    name = p.get("name", "").strip()[:20]
    if name:
        lines.append(f"- 당신의 이름은 '{name}'입니다. 자연스러울 때 스스로를 이 이름으로 부르세요.")
    if p.get("tone") in PERSONA_TONE:
        lines.append(f"- 말투: {PERSONA_TONE[p['tone']]}")
    if p.get("meta") in PERSONA_META and p.get("meta") != "none":
        lines.append(f"- 비유를 들 때는 주로 '{PERSONA_META[p['meta']]}' 세계의 비유를 씀 (어려운 개념마다 하나씩)")
    elif p.get("meta") == "none":
        lines.append("- 비유는 거의 쓰지 않고 바로 설명")
    if p.get("order") in PERSONA_ORDER:
        lines.append(f"- 설명 순서: {PERSONA_ORDER[p['order']]}")
    h = sl("humor"); lines.append("- 유머: " + ("전혀 없이 진지하게" if h <= 1 else "가끔 가볍게 한 번" if h <= 5 else "자주, 가볍게 웃기게" if h <= 8 else "농담을 즐겨 섞되 숫자·근거는 정확히"))
    o = sl("opt"); lines.append("- 분위기: " + ("신중·보수적 — 위험을 먼저, 기대는 절제해서" if o <= 2 else "약간 신중" if o <= 4 else "중립" if o <= 6 else "약간 긍정적" if o <= 8 else "희망적·밝게 — 단, 위험도 빠뜨리지 않기"))
    b = sl("blunt"); lines.append("- 표현: " + ("아주 부드럽게 돌려서" if b <= 2 else "부드럽게" if b <= 4 else "보통" if b <= 6 else "직설적으로" if b <= 8 else "아주 직설적으로, 돌려 말하지 않기"))
    e = sl("emoji"); lines.append("- 이모지: " + ("쓰지 않음" if e <= 1 else "소제목에만 조금" if e <= 5 else "자주 써서 생동감 있게"))
    if p.get("catch", "").strip():
        lines.append(f"- 즐겨 쓰는 말버릇(가끔 자연스럽게): \"{p['catch'].strip()[:40]}\"")
    if p.get("bio", "").strip():
        lines.append(f"- 사용자가 직접 적은 자기소개(답에 녹이되 그대로 읊지는 말 것): \"{p['bio'].strip()[:200]}\"")
    if p.get("tone") in PERSONA_SAMPLE:
        lines.append(f"- 이런 말투예요(예시 문장, 내용은 참고만): \"{PERSONA_SAMPLE[p['tone']]}\"")
    seed = p.get("seed", "")
    if seed:                                                   # 같은 답을 골라도 사람마다 다른 '지문'
        lines.append("- 이 사용자만의 습관: " + _VOICE_A[_pseed(seed, len(_VOICE_A), 'a')] + " · " + _VOICE_B[_pseed(seed, len(_VOICE_B), 'b')] + " · " + _VOICE_C[_pseed(seed, len(_VOICE_C), 'c')])
    depth = "이 설정을 약하게, 가끔만 드러내세요" if strength <= 3 else "이 설정을 자연스럽게 반영하세요" if strength <= 7 else "이 설정을 뚜렷하게, 매 답마다 드러내세요"
    return ("[🎭 당신의 캐릭터 — 말하는 방식만 바꾸고, 사실·숫자·근거·결론은 절대 바꾸지 마세요. 사람마다 답이 달라야 하는 건 '어떻게 말하느냐'이지 '무엇이 사실이냐'가 아닙니다]\n"
            + "\n".join(lines) + f"\n- 강도: {depth}. 정해진 '## 제목' 형식은 그대로 지키고, 제목 아래 문장들에서 개성을 내세요.")


# 🧬 투자 DNA (v2.21) — 화면 슬라이더 값(0~10, 5=보통)과 고르기 값을 AI 지시로
DNA_PICK = {
    "gen": ("성별", {"m": "남성", "f": "여성"}),
    "per": ("성격", {"care": "신중함 — 확실할 때만 움직이고 손실을 크게 싫어함", "bal": "균형형", "bold": "과감함 — 기회에 크게 베팅하는 편",
                    "imp": "즉흥적 — 감정적 매매 위험이 있으니 규칙·분할을 꼭 상기시켜 줄 것"}),
    "port": ("포트폴리오 구분", {"one": "한 계좌로 모두 운용", "cs": "핵심(안전)+위성(공격) 나눠 운용 — 제안할 때 핵심/위성 중 어디에 맞는지 구분",
                           "pen": "연금·ISA 중심 — 장기·세제 혜택·안정성 우선", "trd": "매매 전용 계좌 — 단기 매매 관점"}),
    "cap": ("투자금 규모", {"s": "500만 원 이하", "m": "500만~3천만 원", "l": "3천만~1억 원", "xl": "1억 원 이상"}),
    "mon": ("매달 추가로 넣는 돈", {"0": "없음", "s": "50만 원 이하", "m": "50만~200만 원", "l": "200만 원 이상 — 적립식·분할매수 제안이 유효"}),
    "loss": ("버틸 수 있는 손실", {"5": "-5%", "10": "-10%", "20": "-20%", "30": "-30%", "50": "-50%까지"}),
}
DNA_SLIDE = {   # 키: (제목, 0쪽 뜻, 10쪽 뜻) — 0쪽이 비어 있으면 '중요도'
    "pat": ("인내심", "결과를 빨리 보고 싶어함", "몇 년도 기다릴 수 있음"),
    "frq": ("매매 빈도", "거의 사고팔지 않음", "자주 사고팖"),
    "vol": ("출렁임 견디기", "가격이 흔들리면 불안해함", "크게 흔들려도 견딤"),
    "cht": ("차트(기술적 분석) 중시", "", ""), "fun": ("실적·재무 중시", "", ""), "nws": ("뉴스·재료 중시", "", ""),
    "flw": ("수급(외국인·기관) 중시", "", ""), "mac": ("정치·매크로 중시", "", ""), "rate": ("미국 금리·연준 중시", "", ""),
    "fx": ("환율 중시", "", ""),
    "size": ("선호 종목 크기", "소형주 선호", "대형주 선호"), "ctry": ("선호 시장", "국내(국장) 선호", "미국(미장) 선호"),
    "etf": ("개별주 vs ETF", "개별 종목 선호", "ETF 선호"), "gv": ("가치 vs 성장", "싼 가치주 선호", "빠른 성장주 선호"),
    "div": ("배당 중시", "", ""), "thm": ("테마·유행 따라가기", "", ""),
    "con": ("분산 vs 집중", "넓게 분산", "몇 종목에 집중"), "lev": ("레버리지·고위험 상품 허용", "", ""),
    "warn": ("위험 경고 강도", "경고는 짧게만 원함", "위험을 꼼꼼하게 많이 알려 주길 원함"),
}


def _dna_word(v, lo, hi):
    if lo:
        side = hi if v > 5 else lo
        return side + (" (강하게)" if abs(v - 5) >= 4 else " (약간)" if abs(v - 5) <= 1 else "")
    return ["전혀 안 봄", "거의 안 봄", "조금 봄", "조금 봄", "덜 중요", "", "약간 중요", "중요", "꽤 중요", "아주 중요", "가장 중요"][v]


def req_dna_text():
    """요청의 '투자 DNA'를 AI 지시문으로. 보통(5)·안 고른 항목은 빼서 짧게."""
    try:
        raw = str(request.headers.get("X-AI-DNA", ""))[:600]
    except Exception:
        return ""
    lines, heavy = [], []
    for part in raw.split(";"):
        k, _, v = part.partition("=")
        k, v = k.strip(), v.strip()
        if k in DNA_PICK and v in DNA_PICK[k][1]:
            lines.append(f"- {DNA_PICK[k][0]}: {DNA_PICK[k][1][v]}")
        elif k in DNA_SLIDE and v.isdigit() and 0 <= int(v) <= 10 and int(v) != 5:
            t, lo, hi = DNA_SLIDE[k]
            lines.append(f"- {t}: {_dna_word(int(v), lo, hi)} ({v}/10)")
            if not lo and int(v) >= 8:
                heavy.append(t.replace(" 중시", ""))
    if not lines:
        return ""
    return ("[이 사용자의 투자 DNA — 본인이 직접 조절한 값. 분석의 관점·비중·소개할 예시·위험 설명을 여기에 맞추세요]\n" + "\n".join(lines) +
            ("\n- 특히 중요하게 보는 것: " + ", ".join(heavy) + " → 이 관점의 근거를 먼저, 더 자세히." if heavy else "") +
            "\n- 중요도가 낮은 관점은 짧게. 선호(소형/대형, 국장/미장, 개별주/ETF, 가치/성장)에 맞는 대안을 우선 제시하되, 맞지 않는 게 더 낫다면 솔직히 말하세요."
            "\n- 버틸 수 있는 손실·출렁임 견디기를 넘는 위험이 있으면 반드시 경고하고 비중을 줄이라고 하세요. 사용자에게 이 목록을 그대로 읊지는 마세요.")


def sector_names(keys):
    return [SECTOR_INFO[k].split(" (")[0] for k in keys]


def sector_lines(keys):
    return "\n".join("- " + SECTOR_INFO[k] for k in keys)


bp = Blueprint("ai", __name__)


def _local_request():
    """설정 변경은 이 앱 화면(같은 주소)에서 온 요청만 허용 — 다른 웹사이트가 몰래 못 바꾸게."""
    origin = request.headers.get("Origin")
    if not origin or origin == "null":
        return True
    host = request.host_url.rstrip("/")
    return origin.rstrip("/") == host


ENV_NAMES = {"gemini": ("GEMINI_API_KEY", "GEMINI_API_KEY2", "GEMINI_API_KEY3", "GOOGLE_API_KEY"),
             "anthropic": ("ANTHROPIC_API_KEY", "ANTHROPIC_API_KEY2"),
             "openai": ("OPENAI_API_KEY",), "groq": ("GROQ_API_KEY",)}


@bp.get("/api/ai/providers")
def api_providers():
    s = load_settings()
    provs = s.get("providers") or {}
    out = []
    for pid in ORDER:
        p = PROVIDERS[pid]
        cfg = provs.get(pid) or {}
        env = next((n for n in ENV_NAMES.get(pid, ()) if (os.environ.get(n) or "").strip()), None)
        out.append({
            "env": env,
            "id": pid, "name": p["name"], "tier": p["tier"], "badge": p["badge"], "desc": p["desc"],
            "key_url": p["key_url"], "key_hint": p["key_hint"], "steps": p["steps"],
            "no_key": bool(p.get("no_key")), "models": p["models"],
            "default_base": p["base"] if pid == "ollama" else None,
            "configured": _configured(pid, cfg), "key_masked": mask(cfg.get("key")),
            "model": cfg.get("model") or default_model(pid), "base_url": cfg.get("base_url") or "",
        })
    return jsonify({"providers": out, "primary": s.get("primary"),
                    "auto_fallback": s.get("auto_fallback", True), "status": status_summary()})


@bp.post("/api/ai/settings")
def api_save_settings():
    if not _local_request():
        return jsonify({"ok": False, "error": "허용되지 않은 요청"}), 403
    d = request.get_json(force=True, silent=True) or {}
    s = load_settings()
    provs = s.setdefault("providers", {})
    pid = d.get("provider")
    if pid:
        if pid not in PROVIDERS:
            return jsonify({"ok": False, "error": "알 수 없는 AI"}), 400
        cfg = provs.setdefault(pid, {})
        if d.get("remove"):
            provs.pop(pid, None)
            if s.get("primary") == pid:
                s["primary"] = next((x for x in ORDER if _configured(x, provs.get(x))), None)
        else:
            if isinstance(d.get("key"), str) and d["key"].strip():
                cfg["key"] = d["key"].strip()
            if isinstance(d.get("model"), str) and d["model"].strip():
                cfg["model"] = d["model"].strip()
            if isinstance(d.get("base_url"), str):
                cfg["base_url"] = d["base_url"].strip()
            if d.get("make_primary") or not s.get("primary"):
                if _configured(pid, cfg):
                    s["primary"] = pid
    if "primary" in d and (d["primary"] in PROVIDERS or d["primary"] is None):
        s["primary"] = d["primary"]
    if "auto_fallback" in d:
        s["auto_fallback"] = bool(d["auto_fallback"])
    save_settings(s)
    return jsonify({"ok": True, "status": status_summary()})


@bp.post("/api/ai/test")
def api_test():
    if not _local_request():
        return jsonify({"ok": False, "error": "허용되지 않은 요청"}), 403
    d = request.get_json(force=True, silent=True) or {}
    pid = d.get("provider")
    if pid not in PROVIDERS:
        return jsonify({"ok": False, "error": "알 수 없는 AI"}), 400
    cfg = (load_settings().get("providers") or {}).get(pid) or {}
    key = (d.get("key") or "").strip() or (cfg.get("key") or "")
    model = (d.get("model") or "").strip() or cfg.get("model") or default_model(pid)
    base = (d.get("base_url") or "").strip() or cfg.get("base_url") or None
    if not key and not PROVIDERS[pid].get("no_key"):
        return jsonify({"ok": False, "error": "키를 먼저 붙여넣어 주세요."})
    t0 = time.time()
    try:
        text = call(pid, key, model, prompt="안녕하세요. 한 문장으로 짧게 인사해 주세요.",
                    max_out=80, base_url=base)
        return jsonify({"ok": True, "reply": (text or "")[:200], "model": model,
                        "ms": int((time.time() - t0) * 1000)})
    except AIError as e:
        return jsonify({"ok": False, "error": e.msg, "code": e.code, "detail": e.detail[:200]})
    except Exception as e:
        return jsonify({"ok": False, "error": f"연결 실패: {type(e).__name__}"})


# ── 🧓 아주 쉬운 AI 켜기 (v4.15) — 키가 들어 있는 아무 글이나 받아서 키만 골라내고, 확인 후 바로 저장 ──
# 구글 키: 예전 'AIza'+35글자 / 2026년부터 새 형식 'AQ.'+영문·숫자·_·-·. (AI Studio 가 AQ. 키만 주는 계정이 있음)
_GKEY = re.compile(r"AIza[0-9A-Za-z_\-]{35}|AQ\.[0-9A-Za-z_\-.]{20,300}")


def find_gemini_key(text):
    m = _GKEY.search(str(text or ""))
    return m.group(0).rstrip(".") if m else ""


def _android_clip_text():
    """폰(Chaquopy): 안드로이드 클립보드 글자. 실패하면 빈 문자열."""
    try:
        from java import jclass
        from com.chaquo.python import Python as _Py
        ctx = _Py.getPlatform().getApplication()
        cm = ctx.getSystemService(jclass("android.content.Context").CLIPBOARD_SERVICE)
        clip = cm.getPrimaryClip()
        if clip is None or clip.getItemCount() < 1:
            return ""
        t = clip.getItemAt(0).coerceToText(ctx)
        return str(t) if t is not None else ""
    except Exception:
        return ""


@bp.get("/api/ai/clip-key")
def api_clip_key():
    """복사해 둔 글에 구글 AI 키가 있으면 그 키만 돌려줌 (다른 클립보드 내용은 절대 돌려주지 않음)."""
    if not _local_request():
        return jsonify({"ok": False}), 403
    k = find_gemini_key(_android_clip_text())
    return jsonify({"ok": bool(k), "key": k, "masked": mask(k) if k else ""})


@bp.post("/api/ai/quick-setup")
def api_quick_setup():
    """키(또는 키가 들어 있는 카톡 메시지 통째로)를 받아 → 키만 골라 → 실제로 인사 보내 확인 → 구글 Gemini 기본으로 저장."""
    if not _local_request():
        return jsonify({"ok": False, "error": "허용되지 않은 요청"}), 403
    d = request.get_json(force=True, silent=True) or {}
    key = find_gemini_key(d.get("text"))
    if not key:
        return jsonify({"ok": False, "error": "구글 AI 키를 찾지 못했어요. 'AIza' 또는 'AQ.'로 시작하는 키를 통째로 복사해 주세요."})
    last = None
    for model in [default_model("gemini")] + [m for m in GEM_FALLBACK if m != default_model("gemini")]:
        try:
            text = call("gemini", key, model, prompt="안녕하세요. 한 문장으로 짧게 인사해 주세요.", max_out=80)
            s = load_settings()
            cfg = s.setdefault("providers", {}).setdefault("gemini", {})
            cfg["key"], cfg["model"] = key, model
            s["primary"] = "gemini"
            save_settings(s)
            return jsonify({"ok": True, "reply": (text or "")[:200], "model": model, "masked": mask(key), "status": status_summary()})
        except AIError as e:
            last = e
            if e.code in ("auth", "billing"):
                break
        except Exception as e:
            last = AIError("other", f"연결 실패: {type(e).__name__}")
    msg = last.msg if isinstance(last, AIError) else "연결하지 못했어요"
    return jsonify({"ok": False, "error": msg, "code": getattr(last, "code", ""), "detail": (getattr(last, "detail", "") or "")[:200]})


@bp.post("/api/ai/models")
def api_models():
    if not _local_request():
        return jsonify({"ok": False, "error": "허용되지 않은 요청"}), 403
    d = request.get_json(force=True, silent=True) or {}
    pid = d.get("provider")
    if pid not in PROVIDERS:
        return jsonify({"ok": False, "error": "알 수 없는 AI"}), 400
    cfg = (load_settings().get("providers") or {}).get(pid) or {}
    key = (d.get("key") or "").strip() or (cfg.get("key") or "")
    base = (d.get("base_url") or "").strip() or cfg.get("base_url") or None
    if not key and not PROVIDERS[pid].get("no_key") and pid != "openrouter":
        return jsonify({"ok": False, "error": "키를 먼저 붙여넣어 주세요."})
    try:
        return jsonify({"ok": True, "models": list_models(pid, key, base)})
    except AIError as e:
        return jsonify({"ok": False, "error": e.msg})
    except Exception as e:
        return jsonify({"ok": False, "error": f"목록을 못 가져왔어요: {type(e).__name__}"})


MARKET_CTX_FN = None   # price_server 가 넣어 줌: 지금 시장 지표·헤드라인 (20분 캐시)
QUOTE_FN = None        # price_server 가 넣어 줌: 질문에 나온 종목의 실제 시세·지표

CHAT_DEPTH = {   # 설명 수준 — 줄 수를 정하지 않고 '어떻게' 설명할지만
    "brief": "간략 — 핵심만 짧고 분명하게. 군더더기 없이.",
    "easy": "쉽게(주식 초보) — 전문용어는 쉬운 우리말로 풀고(괄호로 뜻), 생활 비유를 섞어 친절하게. 초보가 다음에 뭘 하면 되는지까지.",
    "serious": "진중 — 근거와 반대 근거, 낙관/기본/비관 시나리오, 위험 요인까지 꼼꼼하고 균형 있게.",
    "expert": "전문가 — 밸류에이션·실적 추정·수급·기술적 지표·업종 비교·촉매를 전문 용어로 깊이 있게. 숫자를 많이.",
    "teacher": "선생님 — '무엇 → 왜 → 예를 들면' 순서로 차근차근 가르치듯. 끝에 '📚 오늘의 투자 공부:' 한 단락.",
}


@bp.post("/api/ai/chat")
def api_chat():
    """자유 대화 (Gemini 처럼 무엇이든). 내 설정(설명 수준·성향·관심 섹터)과 포트폴리오·시장 상황을 함께 줌."""
    d = request.get_json(force=True, silent=True) or {}
    msgs = [m for m in (d.get("messages") or [])
            if isinstance(m, dict) and m.get("role") in ("user", "assistant") and m.get("content")][-16:]
    if not msgs or msgs[-1]["role"] != "user":
        return jsonify({"status": "fail", "text": "질문이 비어 있어요."})
    ctx = str(d.get("context") or "")[:6000]
    styles = {"long": ("장기투자", "앞으로 1년"), "swing": ("스윙매매", "앞으로 1~3개월"),
              "day": ("단타", "앞으로 1주일"), "scalp": ("스캘핑", "오늘~내일")}
    s_label, s_hz = styles.get(str(d.get("style") or request.headers.get("X-AI-Style", "")), styles["long"])
    depth = CHAT_DEPTH.get(request.headers.get("X-AI-Depth", ""), CHAT_DEPTH["easy"])
    secs = req_sectors()
    mkt = ""
    try:
        if MARKET_CTX_FN:
            mkt = MARKET_CTX_FN() or ""
    except Exception:
        mkt = ""
    quotes = ""
    try:
        if QUOTE_FN:
            quotes = QUOTE_FN(str(msgs[-1].get("content") or "")[:500], d.get("known") or []) or ""
    except Exception:
        quotes = ""
    system = (
        "[표현 규칙 — 법적 이유로 반드시 지킬 것] 당신은 투자 정보를 정리해 주는 비서이지 자문가가 아닙니다. "
        "사라·팔라·들고 있으라 같은 행동 지시, 매수·매도 같은 매매 의견, 종목 추천, 진입·손절·목표가 제시를 하지 말고, "
        "오를 수 있는 이유와 내릴 수 있는 이유를 근거와 함께 나란히 보여 주세요. 결정은 사용자가 합니다.\n"
        "당신은 한국 개인투자자 곁의 친근하고 유능한 AI 비서입니다. 한국어로 답하세요.\n"
        + ((req_persona_text() + "\n\n") if req_persona_text() else "") +
        "구글 Gemini 같은 범용 AI처럼, 사용자가 자연스럽게 묻는 무엇이든 — 투자 개념, 시장·경제, 특정 종목, 내 계좌, "
        "세금·제도, 투자와 상관없는 일상 질문까지 — 질문의 의도에 맞춰 충실하고 자유롭게 답하세요. 정해진 틀에 억지로 맞추지 마세요.\n\n"
        "[이 사용자 맞춤 설정 — 모든 답에 반영]\n"
        f"- 설명 수준: {depth}\n"
        f"- 투자 성향: {s_label} (기본 판단 기간 {s_hz})\n"
        + (f"- 관심 섹터: {', '.join(sector_names(secs))}\n" if secs else "- 관심 섹터: (정하지 않음 — 골고루)\n") +
        (req_profile_text() + "\n" if req_profile_text() else "") +
        (req_dna_text() + "\n" if req_dna_text() else "") +
        "\n[답하는 방식]\n"
        + ("- 🎭 위 캐릭터의 말투·비유·순서를 모든 문장에 적용하세요. 같은 질문이라도 이 사용자에게는 이 사용자만의 답이어야 합니다.\n" if req_persona_text() else "") +
        "- 질문에 곧바로 답하며 시작하세요. 필요하면 소제목(##), 목록, 표(마크다운)를 써서 읽기 쉽게.\n"
        "- 길이는 질문 크기에 맞게: 간단한 질문은 짧게, 깊은 질문은 충분히 길고 자세하게. 답을 중간에 끊지 말고 끝까지 완성하세요.\n"
        "- 특정 종목을 사도/팔아도 될지, 오를지·내릴지를 물어도 사라·팔라·기다리라고 답하지 마세요(법적 이유 — 이 앱은 투자 자문을 하지 않아요). "
        "맨 첫 줄을 굵게 '**정리: 오를 근거 N개 · 내릴 근거 M개 — ○○ 쪽 근거가 더 많아요**'처럼 근거의 양과 세기로 시작하고, "
        "이어서 '📈 오를 수 있는 이유'와 '📉 내릴 수 있는 이유'를 근거(숫자·뉴스·출처)와 함께 나란히 보여 주세요. 결정은 사용자가 한다는 걸 존중하세요.\n"
        f"  그다음 '{s_hz} 상승 가능성 추정 73% / 하락 가능성 추정 27% (보장 아님)'처럼 확률을 1% 단위로 주세요. 느낌으로 고르지 말고 기본 50에서 "
        "추세·실적·주가 수준·뉴스·시장 분위기·수급·위험을 항목별로 더하고 빼서 계산하고, 그 계산식(예: 50 +8 추세 +6 실적 -4 가격 부담 … = 67)을 한 줄로 보여 주세요. "
        "10~90 범위, 50과 55·60·65처럼 5로 끝나는 수는 쓰지 말고, 근거가 쏠리면 80대·20대처럼 과감하게.\n"
        "  가격은 이동평균선·최근 저점·고점·하루 평균 변동폭 같은 '지표 가격'만 말하고, 그 가격에서 무엇을 하라고 하지 마세요.\n"
        "- 어떤 종목이 좋냐고 물으면 '추천'하지 말고, 관심 섹터와 투자 성향에 맞는 '조건'(예: 이익 증가·부채·밸류에이션)을 설명하고 "
        "그 조건에 해당하는 예시 종목을 사실 위주로 소개하세요. 각 예시의 위험도 함께. 앱의 '조건 검색기'로 직접 찾아볼 수 있다고 알려 주세요.\n"
        "- 아래 [내 포트폴리오]는 앱이 계산한 사실입니다. 질문과 관련 있을 때 적극 활용하고, 숫자는 바꾸거나 지어내지 마세요. 관련 없으면 굳이 꺼내지 않아도 됩니다.\n"
        "- ⚠ 가격·수익률·지표 숫자는 아래 [방금 앱이 확인한 실제 시세·지표], [내 포트폴리오], [지금 시장 상황]에 있는 것만 쓰세요. "
        "거기에 없는 종목의 현재가·지표 숫자를 기억으로 지어내지 마세요(학습 데이터의 가격은 오래돼 틀려요). "
        "시세가 없으면 '앱에서 시세를 확인하지 못했어요'라고 말하고, 숫자를 쓸 땐 기준 시각을 함께 밝히세요.\n"
        "- 지표 가격은 반드시 위 확인된 현재가·이동평균·52주 고저 같은 실제 숫자에서 가져와 출처를 보여 주세요.\n"
        "- 종목·투자 관련 답의 마지막 줄: '참고 정보이며 투자 권유가 아닙니다. 판단과 책임은 본인에게 있습니다.'\n\n"
        "[내 포트폴리오]\n" + (ctx or "(정보 없음)") + ("\n\n" + quotes if quotes else "") + ("\n\n" + mkt if mkt else ""))
    text, prov, mdl, err = complete(messages=msgs, system=system, max_out=8192, temperature=req_temperature(0.8))
    if err == "NO_KEY":
        return jsonify({"status": "no_key", "text": "AI가 아직 연결되지 않았어요. 설정 → AI 연결에서 무료 키를 넣어 주세요."})
    if not text:
        return jsonify({"status": "fail", "text": err or "답을 받지 못했어요."})
    return jsonify({"status": "ok", "provider": prov, "model": mdl, "text": text})
