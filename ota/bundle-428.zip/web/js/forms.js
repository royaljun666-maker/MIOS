/* ==========================================================================
   forms.js — 계좌 · 종목(검색 추가/수정) · 더 사기 · 팔기 · 가족 · 첫 실행 안내
   ========================================================================== */
'use strict';

const BROKERS = ['키움증권', '삼성증권', '미래에셋증권', '한국투자증권', '토스증권', 'NH투자증권', 'KB증권', '신한투자증권', '연금저축', 'ISA'];

/* ---------------- 계좌 ---------------- */
function openAccountForm(id, after) {
  const a = id ? findAcc(id) : null;
  const m = openModal({
    title: a ? '계좌 이름 바꾸기' : '계좌 만들기',
    body: '<div class="field"><label>계좌 이름</label><input class="input lg" id="fAccName" placeholder="예: 키움증권" value="' + esc(a ? a.name : '') + '" maxlength="30" autocomplete="off"><div class="err-msg">이름을 적어 주세요</div></div>' +
      (a ? '' : '<div class="label" style="font-size:.84rem;color:var(--text-3);font-weight:600;margin:-4px 0 10px">자주 쓰는 이름</div><div class="chips">' + BROKERS.map(b => '<button class="chip" data-pick="' + esc(b) + '">' + esc(b) + '</button>').join('') + '</div>'),
    foot: '<button class="btn btn-gray" data-x>취소</button><button class="btn btn-primary" data-ok>' + (a ? '저장' : '만들기') + '</button>',
  });
  const inp = m.body.querySelector('#fAccName');
  setTimeout(() => inp.focus(), 250);
  m.body.querySelectorAll('[data-pick]').forEach(b => b.onclick = () => { inp.value = b.dataset.pick; inp.focus(); });
  const ok = () => {
    const nm = inp.value.trim();
    if (!nm) { inp.closest('.field').classList.add('err'); return; }
    let target = a;
    if (a) a.name = nm;
    else {
      const used = new Set(accounts().map(x => x.ci));
      target = { id: uid('a'), name: nm, cash: '0', holdings: [], ci: nextFree(used) };
      accounts().push(target);
    }
    save(); m.close();
    if (after) after(target);
    else { curAccId = target.id; go('accounts', { acc: target.id }); }
    toast(a ? '이름을 바꿨어요' : '“' + nm + '” 계좌를 만들었어요');
  };
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') ok(); });
  m.foot.querySelector('[data-x]').onclick = () => m.close();
  m.foot.querySelector('[data-ok]').onclick = ok;
}

function accountMenu(anchor, id) {
  const a = findAcc(id); if (!a) return;
  openMenu(anchor, [
    { label: '계좌 이름 바꾸기', icon: 'pencil', act: () => openAccountForm(id) },
    { label: '현금 금액 수정', icon: 'coins', act: () => editCashModal(id) },
    '-',
    { label: '계좌 삭제', icon: 'trash', danger: true, act: async () => {
      if (await confirmBox({ title: '계좌 삭제', msg: '“' + esc(a.name) + '” 계좌와 그 안의 종목 ' + a.holdings.length + '개를 모두 지울까요?<br>지운 뒤에는 되돌릴 수 없어요.', ok: '삭제', danger: true })) {
        P().accounts = accounts().filter(x => x.id !== id); curAccId = null; save({ force: true }); rerender(); toast('계좌를 삭제했어요');
      }
    } },
  ]);
}

function editCashModal(id) {
  const a = findAcc(id); if (!a) return;
  const m = openModal({
    title: '현금 수정 — ' + esc(a.name),
    body: '<div class="field"><label>이 계좌에 있는 현금(예수금)</label><div class="input-wrap"><input class="input lg tnum" id="fCash" inputmode="decimal" value="' + esc(nf(num(a.cash), 0)) + '"><span class="suffix">원</span></div>' +
      '<div class="help">증권사 앱의 <b>예수금</b>(주식을 사지 않고 남아 있는 돈)을 적어 주세요. 달러 예수금은 원화로 바꿔서 더해 주세요.</div></div>',
    foot: '<button class="btn btn-gray" data-x>취소</button><button class="btn btn-primary" data-ok>저장</button>',
  });
  const inp = m.body.querySelector('#fCash'); setTimeout(() => { inp.focus(); inp.select(); }, 250);
  moneyInput(inp);
  const ok = () => { a.cash = String(Math.max(0, num(inp.value))); save(); m.close(); rerender(); toast('현금을 ' + won(num(a.cash)) + '으로 바꿨어요'); };
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') ok(); });
  m.foot.querySelector('[data-x]').onclick = () => m.close();
  m.foot.querySelector('[data-ok]').onclick = ok;
}

/* 숫자 칸에 쉼표 자동 */
function moneyInput(inp, decimals) {
  inp.addEventListener('input', () => {
    const raw = inp.value.replace(/[^\d.]/g, '');
    if (raw === '') { inp.value = ''; return; }
    const parts = raw.split('.');
    const intp = parts[0].replace(/^0+(?=\d)/, '');
    const out = Number(intp || 0).toLocaleString('ko-KR') + (parts.length > 1 && decimals !== 0 ? '.' + parts.slice(1).join('').slice(0, decimals || 4) : '');
    const atEnd = inp.selectionStart === inp.value.length;
    inp.value = out;
    if (atEnd) inp.setSelectionRange(out.length, out.length);
  });
}

/* ---------------- 시세 → 종목에 저장 ---------------- */
function clearFund(h) {
  ['per', 'fper', 'pbr', 'peg', 'roe', 'opIncome', 'opMargin', 'marketCap', 'eps', 'asof', 'pegGrowth', 'pegNative', 'pegBasis',
    'epsF', 'ltg', 'epsRev', 'trendClass', 'opTrend', 'roeTrend', 'valWarn', 'valSrcs', 'mcapCcy', 'naverUrl', 'chg', 'chgAt']
    .forEach(k => { delete h[k]; });
}
function storeFund(h, d) {
  if (!h || !d) return;
  const map = { per: 'per', forward_per: 'fper', pbr: 'pbr', peg: 'peg', roe: 'roe', op_income: 'opIncome', op_margin: 'opMargin', market_cap: 'marketCap', eps: 'eps',
    peg_growth: 'pegGrowth', peg_native: 'pegNative', peg_basis: 'pegBasis', eps_f: 'epsF', ltg: 'ltg', eps_rev: 'epsRev', trend_class: 'trendClass' };
  for (const k in map) if (d[k] != null) h[map[k]] = String(d[k]);
  if (d.asof) h.asof = String(d.asof);
  if (Array.isArray(d.op_trend)) h.opTrend = d.op_trend;
  if (Array.isArray(d.roe_trend)) h.roeTrend = d.roe_trend;
  if (Array.isArray(d.val_warn)) h.valWarn = d.val_warn.slice(0, 6);
  if (Array.isArray(d.val_srcs)) h.valSrcs = d.val_srcs;
  if (d.mcap_ccy) h.mcapCcy = String(d.mcap_ccy);
  if (d.naver_url) h.naverUrl = d.naver_url;
  if (d.change_pct != null && isFinite(d.change_pct)) { h.chg = d.change_pct; h.chgAt = todayKey(); h.chgDate = d.chg_date || null; }
  if (d.range_pct != null) { h.rng = d.range_pct; h.hiP = d.hi_pct; h.loP = d.lo_pct; h.rngAt = todayKey(); } else { h.rng = null; }
  h.sess = d.session || '';                         // 'NXT 프리마켓' / 'NXT 애프터마켓' (정규장 밖)
}

/* ---------------- 종목 추가 (이름 검색) ---------------- */
const QUICK = ['삼성전자', 'SK하이닉스', '애플', '테슬라', '엔비디아', '마이크로소프트', 'KODEX 200', 'TIGER 미국S&P500', 'SCHD'];

function openAddHolding(accId) {
  if (!accounts().length) { toast('먼저 계좌(증권사)를 하나 만들어 주세요'); openAccountForm(null); return; }
  const a = findAcc(accId) || findAcc(curAccId) || accounts()[0];
  if (a.holdings.length >= MAXH) { toast('한 계좌에 최대 ' + MAXH + '종목까지 넣을 수 있어요'); return; }
  const m = openModal({ title: '종목 추가 — ' + esc(a.name), size: 'wide' });
  stepSearch(m, a);
}

/* 💼 관심종목에서 '실제로 샀어요' → 그 종목으로 바로 수량·평균가 입력 (v4.10 · 실제 주문은 증권사 앱에서) */
function openRealBuy(pick) {
  if (!accounts().length) { toast('먼저 계좌(증권사)를 하나 만들어 주세요'); openAccountForm(null); return; }
  const a = findAcc(curAccId) || accounts()[0];
  if (a.holdings.length >= MAXH) { toast('한 계좌에 최대 ' + MAXH + '종목까지 넣을 수 있어요'); return; }
  const m = openModal({ title: '종목 추가 — ' + esc(a.name), size: 'wide' });
  if (accounts().length > 1) { stepSearch(m, a); toast('넣을 계좌를 고른 뒤 ⭐ ' + pick.name + '을(를) 누르세요'); return; }
  stepDetails(m, a, pick);
}
function addPicks() {
  const seen = new Set(), out = [];
  const push = (p, tag) => { const k = p.ticker + ':' + p.market; if (!p.ticker || seen.has(k)) return; seen.add(k); out.push(Object.assign({ tag }, p)); };
  (UI.recentPicks || []).forEach(p => push(p, '🕘'));
  watchlist().forEach(w => push({ ticker: w.ticker, name: dispName(w), market: w.market || (w.ccy === 'USD' ? 'us' : 'kr'), ccy: w.ccy || (w.market === 'us' ? 'USD' : 'KRW'), exchange: w.exch || '' }, '⭐'));
  return out.slice(0, 10);
}
function stepSearch(m, a, preset) {
  const accs = accounts();
  m.body.oninput = null;
  m.setTitle('종목 추가 — ' + esc(a.name));
  const picks = addPicks();
  m.setBody(
    (accs.length > 1 ? '<div class="ah-acc"><span>어느 계좌에 넣을까요?</span><div class="chips scroll">' + accs.map(x => '<button class="chip' + (x.id === a.id ? ' on' : '') + '" data-acc="' + x.id + '">' + esc(x.name) + '</button>').join('') + '</div></div>' : '') +
    '<div class="input-wrap"><span class="prefix-ic">' + icon('search') + '</span><input class="input lg" id="q" placeholder="종목 이름이나 코드 (예: 삼성전자, 애플, TSLA)" autocomplete="off" value="' + esc(preset || '') + '"></div>' +
    (picks.length ? '<div class="ah-sub">⭐ 관심종목 · 🕘 최근 넣은 종목 — 누르면 바로 수량 입력</div><div class="chips" id="qk">' + picks.map((p, i) => '<button class="chip pick" data-k="' + i + '">' + p.tag + ' ' + esc(p.name) + '</button>').join('') + '</div>' : '') +
    '<div class="ah-sub">많이 찾는 종목</div><div class="chips" id="qp">' + QUICK.map(q => '<button class="chip" data-q="' + esc(q) + '">' + esc(q) + '</button>').join('') + '</div>' +
    '<div class="sr" id="sr"></div>' +
    '<div style="text-align:center;margin-top:10px"><button class="btn btn-ghost btn-sm" data-manual>' + icon('pencil', 'ic-sm') + '찾는 종목이 없어요 · 직접 입력</button></div>');
  m.setFoot('');
  const q = m.body.querySelector('#q'), sr = m.body.querySelector('#sr');
  let results = [], kb = -1, seq = 0;
  const render = () => {
    if (!q.value.trim()) { sr.innerHTML = '<div class="sr-empty">한글 이름으로 검색해도 돼요. 미국 주식도 “애플”, “테슬라”처럼 찾을 수 있어요.</div>'; return; }
    if (!results.length) { sr.innerHTML = '<div class="sr-empty">검색 결과가 없어요. 이름을 조금 바꿔 보거나<br>아래 <b>직접 입력</b>을 눌러 주세요.</div>'; return; }
    sr.innerHTML = results.map((r, i) => '<button data-i="' + i + '" class="' + (i === kb ? 'kb' : '') + '"><div class="logo" style="background:' + (r.market === 'us' ? 'var(--c2)' : 'var(--c1)') + '">' + esc(r.market === 'us' ? r.ticker.slice(0, 2) : r.name.slice(0, 1)) + '</div>' +
      '<div class="mid"><b>' + esc(r.name) + '</b><span>' + esc(r.ticker) + ' · ' + esc(r.exchange || '') + '</span></div><span class="badge ' + (r.market === 'us' ? 'orange' : 'blue') + '">' + (r.market === 'us' ? '미국 · 달러' : '국내 · 원화') + '</span></button>').join('');
  };
  const search = debounce(async () => {
    const my = ++seq, v = q.value.trim();
    if (!v) { results = []; render(); return; }
    sr.innerHTML = '<div class="sr-empty">찾는 중…</div>';
    try { const r = await api('/api/search?q=' + encodeURIComponent(v), { timeout: 12000 }); if (my !== seq) return; results = r || []; kb = results.length ? 0 : -1; render(); }
    catch (e) { if (my === seq) sr.innerHTML = '<div class="sr-empty">' + SERVER_DOWN + '<br>아래 <b>직접 입력</b>으로도 넣을 수 있어요.</div>'; }
  }, 260);
  q.addEventListener('input', search);
  q.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown' && results.length) { kb = Math.min(results.length - 1, kb + 1); render(); e.preventDefault(); }
    else if (e.key === 'ArrowUp' && results.length) { kb = Math.max(0, kb - 1); render(); e.preventDefault(); }
    else if (e.key === 'Enter' && kb >= 0 && results[kb]) stepDetails(m, a, results[kb]);
  });
  sr.addEventListener('click', e => { const b = e.target.closest('button[data-i]'); if (b) stepDetails(m, a, results[+b.dataset.i]); });
  m.body.querySelector('#qp').addEventListener('click', e => { const b = e.target.closest('[data-q]'); if (b) { q.value = b.dataset.q; search(); q.focus(); } });
  m.body.querySelector('[data-manual]').onclick = () => stepDetails(m, a, null);
  const qk = m.body.querySelector('#qk'); if (qk) qk.addEventListener('click', e => { const b = e.target.closest('[data-k]'); if (b) stepDetails(m, a, picks[+b.dataset.k]); });
  m.body.querySelectorAll('[data-acc]').forEach(b => b.onclick = () => { const na = findAcc(b.dataset.acc); if (na) { a = na; curAccId = na.id; m.setTitle('종목 추가 — ' + esc(a.name)); m.body.querySelectorAll('[data-acc]').forEach(x => x.classList.toggle('on', x === b)); } });
  setTimeout(() => q.focus(), 250);
  render(); if (preset) search();
}

function stepDetails(m, a, pick) {
  const manual = !pick;
  let ccy = pick ? pick.ccy : 'KRW', cur = 0, fundData = null, totalMode = false;
  const sfx = () => ccy === 'USD' ? '$' : '원';
  m.setTitle(manual ? '직접 입력' : '얼마나 가지고 계세요?');
  m.setBody(
    (manual ?
      '<div class="callout gray" style="margin-bottom:16px">' + icon('info', 'ic-sm') + '<div>펀드·채권·예금처럼 검색되지 않는 자산도 직접 넣을 수 있어요. <b>현재가를 직접 적으면</b> 수익률이 계산돼요.</div></div>' +
      '<div class="seg block lg" id="fCcy" style="margin-bottom:16px"><button data-v="KRW" class="on">원화 (₩)</button><button data-v="USD">달러 ($)</button></div>' +
      '<div class="row wrap-m"><div class="field"><label>이름 <span class="req">*</span></label><input class="input" id="fName" placeholder="예: 내 연금펀드" maxlength="40"><div class="err-msg">이름을 적어 주세요</div></div>' +
      '<div class="field"><label>종목코드 (있으면)</label><input class="input" id="fTicker" placeholder="005930 / AAPL" maxlength="12"><div class="help">코드가 있으면 시세가 자동 갱신돼요</div></div></div>'
    : '<div class="picked"><div class="logo" style="background:' + (pick.market === 'us' ? 'var(--c2)' : 'var(--c1)') + '">' + esc(pick.market === 'us' ? pick.ticker.slice(0, 2) : pick.name.slice(0, 1)) + '</div>' +
        '<div class="mid"><b>' + esc(pick.name) + '</b><span>' + esc(pick.ticker) + ' · ' + esc(pick.exchange || '') + ' · <span id="curTxt">현재가 확인 중…</span></span></div>' +
        '<button class="btn btn-ghost btn-sm" data-back>' + icon('search', 'ic-sm') + '다시 찾기</button></div>') +
    '<div class="row wrap-m">' +
      '<div class="field"><label>평균 매입가 (1주당) <span class="req">*</span></label><div class="input-wrap"><input class="input lg tnum" id="fAvg" inputmode="decimal" placeholder="0"><span class="suffix" data-sfx>' + sfx() + '</span></div>' +
        '<div class="ah-tools"><button type="button" class="ah-t" data-fillcur hidden>현재가로 채우기</button><button type="button" class="ah-t" data-total>총 매입금액으로 입력</button></div>' +
        '<div class="help" id="fAvgHelp">증권사 앱의 <b>평균단가·매입가</b>를 적어 주세요</div><div class="err-msg">산 가격을 적어 주세요</div></div>' +
      '<div class="field"><label>수량 <span class="req">*</span></label><div class="input-wrap"><input class="input lg tnum" id="fQty" inputmode="decimal" placeholder="0"><span class="suffix">주</span></div>' +
        '<div class="help">소수점 주식도 OK (예: 0.5)</div><div class="err-msg">몇 주인지 적어 주세요</div></div>' +
    '</div>' +
    (manual ? '<div class="field"><label>현재가 (1주당) <span class="req">*</span></label><div class="input-wrap"><input class="input tnum" id="fCur" inputmode="decimal" placeholder="0"><span class="suffix" data-sfx>' + sfx() + '</span></div><div class="err-msg">현재가를 적어 주세요</div></div>' : '') +
    '<div class="preview" id="fPrev"></div>' +
    '<details class="more-opt"><summary>' + icon('chevron-down', 'ic-sm') + '더 자세히 (안 해도 돼요)</summary>' +
      '<div class="row wrap-m"><div class="field"><label>목표 비중</label><div class="input-wrap"><input class="input tnum" id="fTgt" inputmode="decimal" placeholder="예: 20"><span class="suffix">%</span></div><div class="help">계좌에서 이 종목을 몇 %로 가져갈지</div></div>' +
      (manual ? '' : '<div class="field"><label>현재가 직접 입력</label><div class="input-wrap"><input class="input tnum" id="fCur" inputmode="decimal" placeholder="자동"><span class="suffix" data-sfx>' + sfx() + '</span></div><div class="help">비워 두면 자동으로 가져와요</div></div>') + '</div>' +
      '<div class="field"><label>이 종목에 대한 나의 규칙</label><textarea class="input" id="fRule" rows="2" placeholder="예: 20% 오르면 절반 팔기 / PER 30 넘으면 비중 줄이기"></textarea><div class="help">AI 분석 때 이 규칙을 함께 보여줘요</div></div>' +
      '<label class="check"><input type="checkbox" id="fDef"><span><b>방어자산</b>이에요 (채권·배당주·금 등 하락장에 버티는 자산) — 계좌 건강검진에 반영돼요</span></label>' +
    '</details>' +
    '<label class="check" style="margin-top:10px"><input type="checkbox" id="fPay"><span>방금 <b>새로 산 것</b>이에요 → 산 금액만큼 계좌 현금에서 빼기<br><span class="muted" style="font-size:.82rem">원래 가지고 있던 주식을 옮겨 적는 거라면 체크하지 마세요</span></span></label>');
  m.setFoot('<button class="btn btn-gray shrink" data-back2>' + icon('chevron-left', 'ic-sm') + '</button><button class="btn btn-primary" data-ok>추가하기</button>');
  const $ = s => m.body.querySelector(s);
  ['#fAvg', '#fQty', '#fCur', '#fTgt'].forEach(s => { const e = $(s); if (e) moneyInput(e); });
  const getAvg = () => { const v = num($('#fAvg').value), q = num($('#fQty').value); return totalMode ? (q > 0 ? v / q : 0) : v; };
  const prev = () => {
    if (!$('#fAvg')) return;
    const avg = getAvg(), qty = num($('#fQty').value);
    const c = num(($('#fCur') || {}).value) || cur;
    const box = $('#fPrev');
    if (!(avg > 0 && qty > 0)) { box.innerHTML = '<div class="hint">평균 매입가와 수량을 적으면<br>원금·평가금액·수익률을 바로 계산해 드려요.</div>'; return; }
    const cost = avg * qty, val = c * qty, pl = val - cost, ret = cost > 0 ? pl / cost * 100 : 0;
    box.innerHTML = (totalMode ? '<div class="pr"><span class="k">평균 단가 (계산)</span><span class="v">' + priceTxt(avg, ccy) + '</span></div>' : '') +
      '<div class="pr"><span class="k">투자 원금</span><span class="v">' + money(cost, ccy) + '</span></div>' +
      (c > 0 ? '<div class="pr"><span class="k">지금 평가금액</span><span class="v">' + money(val, ccy) + '</span></div>' +
        '<div class="pr total"><span class="k">수익</span><span class="v ' + cls(pl) + '">' + moneyS(pl, ccy) + ' (' + pct(ret) + ')</span></div>' : '') +
      (ccy === 'USD' ? '<div class="pr"><span class="k">원화로 (1$=' + nf(fx(), 1) + '원)</span><span class="v">' + won((c > 0 ? val : cost) * fx()) + '</span></div>' : '');
  };
  m.body.oninput = prev;                         // 화면마다 바꿔 끼움 (다시 찾기·한 종목 더 때 예전 계산이 남지 않게)
  prev();
  const fieldAvg = $('#fAvg').closest('.field');
  $('[data-total]').onclick = () => {          // 증권사 앱에 '매입금액(총액)'만 보일 때
    totalMode = !totalMode;
    fieldAvg.querySelector('label').innerHTML = (totalMode ? '총 매입금액' : '평균 매입가 (1주당)') + ' <span class="req">*</span>';
    $('[data-total]').textContent = totalMode ? '1주당 평균가로 입력' : '총 매입금액으로 입력';
    $('#fAvgHelp').innerHTML = totalMode ? '증권사 앱의 <b>매입금액</b>(산 돈 전체)을 적으면 1주 평균가를 계산해요' : '증권사 앱의 <b>평균단가·매입가</b>를 적어 주세요';
    $('#fAvg').value = ''; $('#fAvg').focus(); prev();
  };
  $('[data-fillcur]').onclick = () => { if (cur > 0) { if (totalMode) $('[data-total]').click(); $('#fAvg').value = nf(cur, ccy === 'USD' ? 2 : 0); prev(); $('#fQty').focus(); } };
  if (manual) {
    $('#fCcy').addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return;
      ccy = b.dataset.v; $('#fCcy').querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b));
      m.body.querySelectorAll('[data-sfx]').forEach(s => s.textContent = sfx()); prev();
    });
    setTimeout(() => $('#fName').focus(), 200);
  } else {
    $('[data-back]').onclick = () => stepSearch(m, a);
    setTimeout(() => $('#fAvg').focus(), 200);
    api('/price?ticker=' + encodeURIComponent(pick.ticker) + '&market=' + pick.market, { timeout: 20000 }).then(d => {
      if (!m.body.isConnected) return;
      if (d && d.price > 0) {
        cur = d.price; fundData = d;
        const fc = $('[data-fillcur]'); if (fc) { fc.hidden = false; fc.textContent = '현재가로 채우기 (' + priceTxt(cur, ccy) + ')'; }
        $('#curTxt').innerHTML = '현재가 <b>' + esc(priceTxt(cur, ccy)) + '</b>' + (d.change_pct != null ? ' <span class="' + cls(d.change_pct) + '">' + pct(d.change_pct) + '</span>' : '');
        prev();
      } else $('#curTxt').textContent = '현재가를 못 가져왔어요 (더 자세히에서 직접 입력 가능)';
    }).catch(() => { if (m.body.isConnected) $('#curTxt').textContent = '현재가를 못 가져왔어요'; });
  }
  m.foot.querySelector('[data-back2]').onclick = () => stepSearch(m, a);
  m.foot.querySelector('[data-ok]').onclick = async () => {
    m.body.querySelectorAll('.field.err').forEach(f => f.classList.remove('err'));
    const avg = getAvg(), qty = num($('#fQty').value);
    const curIn = num(($('#fCur') || {}).value);
    const name = manual ? $('#fName').value.trim() : pick.name;
    const ticker = manual ? $('#fTicker').value.trim().toUpperCase() : pick.ticker;
    let bad = false;
    if (manual && !name) { $('#fName').closest('.field').classList.add('err'); bad = true; }
    if (!(avg > 0)) { $('#fAvg').closest('.field').classList.add('err'); bad = true; }
    if (!(qty > 0)) { $('#fQty').closest('.field').classList.add('err'); bad = true; }
    const price = curIn || cur;
    if (manual && !(price > 0)) { $('#fCur').closest('.field').classList.add('err'); bad = true; }
    if (bad) return;
    const tgt = num($('#fTgt').value);
    const dup = ticker ? a.holdings.find(x => (x.ticker || '').toUpperCase() === ticker && ccyOf(x) === ccy) : null;
    if (dup) {
      const ok = await confirmBox({ title: '이미 있는 종목이에요', msg: '“' + esc(dispName(dup)) + '”을(를) 이미 ' + nf(num(dup.qty)) + '주 가지고 있어요.<br>수량을 <b>합쳐서</b> 평균 매입가를 다시 계산할까요?', ok: '합치기' });
      if (!ok) return;
      const q0 = num(dup.qty), a0 = num(dup.avg), nq = q0 + qty;
      dup.avg = String((a0 * q0 + avg * qty) / nq); dup.qty = String(nq);
      if (price > 0) dup.cur = String(price);
      if (fundData) storeFund(dup, fundData);
      if ($('#fPay').checked) a.cash = String(num(a.cash) - avg * qty * (ccy === 'USD' ? fx() : 1));
      save(); rememberPick(pick); addDone(m, a, dup, '“' + dispName(dup) + '” 수량을 합쳤어요', '새 평균 매입가 ' + priceTxt(num(dup.avg), ccy));
      return;
    }
    const used = new Set(a.holdings.map(x => x.ci));
    const h = { id: uid('h'), name, ticker, ccy, avg: String(avg), qty: String(qty), cur: String(price > 0 ? price : avg),
      target: tgt > 0 ? String(tgt) : '', rule: $('#fRule').value.trim(), defensive: $('#fDef').checked, ci: nextFree(used), exch: pick ? pick.exchange : '' };
    if (fundData) storeFund(h, fundData);
    a.holdings.push(h);
    if ($('#fPay').checked) a.cash = String(num(a.cash) - avg * qty * (ccy === 'USD' ? fx() : 1));
    save(); rememberPick(pick);
    addDone(m, a, h, '“' + name + '” 추가했어요', nf(qty) + '주 · 평균 ' + priceTxt(avg, ccy));
  };
}
function rememberPick(p) {
  if (!p || !p.ticker) return;
  UI.recentPicks = [{ ticker: p.ticker, name: p.name, market: p.market, ccy: p.ccy, exchange: p.exchange || '' }]
    .concat((UI.recentPicks || []).filter(x => !(x.ticker === p.ticker && x.market === p.market))).slice(0, 8);
  saveUI();
}
/* 추가 완료 — 창을 닫지 않고 바로 '한 종목 더' */
function addDone(m, a, h, title, sub) {
  rerender();
  m.setTitle('추가 완료');
  m.setBody('<div class="ah-done"><div class="ah-ok">✓</div><b>' + esc(title) + '</b><span>' + esc(sub) + ' · ' + esc(a.name) + '</span>' +
    '<p>계속 넣을 종목이 있으면 <b>한 종목 더</b>를 눌러 주세요.</p></div>');
  m.setFoot('<button class="btn btn-gray" data-fin>다 했어요</button><button class="btn btn-primary" data-more>' + icon('plus') + '한 종목 더</button>');
  m.foot.querySelector('[data-more]').onclick = () => {
    if (a.holdings.length >= MAXH) { toast('한 계좌에 최대 ' + MAXH + '종목까지 넣을 수 있어요'); return; }
    stepSearch(m, a);
  };
  m.foot.querySelector('[data-fin]').onclick = () => { m.close(); curAccId = a.id; selH = h.id; go('accounts', { acc: a.id, h: h.id }); };
}

/* ---------------- 종목 수정 ---------------- */
function openEditHolding(accId, hId) {
  const a = findAcc(accId), h = a && a.holdings.find(x => x.id === hId); if (!h) return;
  let ccy = ccyOf(h);
  const sfx = () => ccy === 'USD' ? '$' : '원';
  const m = openModal({
    title: '종목 수정', size: 'wide',
    body:
      '<div class="seg block lg" id="fCcy" style="margin-bottom:16px"><button data-v="KRW" class="' + (ccy === 'KRW' ? 'on' : '') + '">원화 (₩)</button><button data-v="USD" class="' + (ccy === 'USD' ? 'on' : '') + '">달러 ($)</button></div>' +
      '<div class="row wrap-m"><div class="field"><label>이름</label><input class="input" id="fName" value="' + esc(h.name || '') + '" maxlength="40"></div>' +
      '<div class="field"><label>종목코드</label><input class="input" id="fTicker" value="' + esc(h.ticker || '') + '" maxlength="12"><div class="help">국내 6자리 (예: 005930, 0023B0) · 미국 영문 (예: AAPL)</div></div></div>' +
      '<div class="row wrap-m"><div class="field"><label>평균 매입가</label><div class="input-wrap"><input class="input tnum" id="fAvg" inputmode="decimal" value="' + esc(nf(num(h.avg), 4)) + '"><span class="suffix" data-sfx>' + sfx() + '</span></div><div class="err-msg">숫자를 적어 주세요</div></div>' +
      '<div class="field"><label>수량</label><div class="input-wrap"><input class="input tnum" id="fQty" inputmode="decimal" value="' + esc(nf(num(h.qty), 6)) + '"><span class="suffix">주</span></div><div class="err-msg">숫자를 적어 주세요</div></div></div>' +
      '<div class="row wrap-m"><div class="field"><label>현재가</label><div class="input-wrap"><input class="input tnum" id="fCur" inputmode="decimal" value="' + esc(nf(num(h.cur), 4)) + '"><span class="suffix" data-sfx>' + sfx() + '</span></div><div class="help">코드가 있으면 시세 갱신 때 자동으로 바뀌어요</div></div>' +
      '<div class="field"><label>목표 비중</label><div class="input-wrap"><input class="input tnum" id="fTgt" inputmode="decimal" value="' + (hasT(h) ? esc(num(h.target)) : '') + '" placeholder="안 정해도 돼요"><span class="suffix">%</span></div></div></div>' +
      '<div class="field"><label>나의 규칙</label><textarea class="input" id="fRule" rows="2" placeholder="예: 20% 오르면 절반 팔기">' + esc(h.rule || '') + '</textarea></div>' +
      '<label class="check"><input type="checkbox" id="fDef" ' + (h.defensive ? 'checked' : '') + '><span><b>방어자산</b>이에요 (채권·배당주·금 등)</span></label>',
    foot: '<button class="btn btn-danger shrink" data-del>' + icon('trash', 'ic-sm') + '삭제</button><button class="btn btn-gray" data-x>취소</button><button class="btn btn-primary" data-ok>저장</button>',
  });
  const $ = s => m.body.querySelector(s);
  ['#fAvg', '#fQty', '#fCur', '#fTgt'].forEach(s => moneyInput($(s)));
  $('#fCcy').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; ccy = b.dataset.v; $('#fCcy').querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); m.body.querySelectorAll('[data-sfx]').forEach(s => s.textContent = sfx()); });
  m.foot.querySelector('[data-x]').onclick = () => m.close();
  m.foot.querySelector('[data-del]').onclick = async () => {
    if (await confirmBox({ title: '종목 삭제', msg: '“' + esc(dispName(h)) + '”을(를) 계좌에서 지울까요?<br><span class="muted">판 거라면 “팔기”를 쓰면 현금에 자동으로 더해져요.</span>', ok: '삭제', danger: true })) {
      a.holdings = a.holdings.filter(x => x.id !== h.id); save(); m.close(); closeDetailModal(h.id); rerender(); toast('삭제했어요');
    }
  };
  m.foot.querySelector('[data-ok]').onclick = () => {
    const avg = num($('#fAvg').value), qty = num($('#fQty').value);
    let bad = false;
    if (!(avg >= 0) || $('#fAvg').value.trim() === '') { $('#fAvg').closest('.field').classList.add('err'); bad = true; }
    if (!(qty > 0)) { $('#fQty').closest('.field').classList.add('err'); bad = true; }
    if (bad) return;
    const tk = $('#fTicker').value.trim().toUpperCase();
    if (tk !== (h.ticker || '').toUpperCase() || ccy !== ccyOf(h)) { h.chg = null; h.chgAt = null; }
    h.name = $('#fName').value.trim(); h.ticker = tk; h.ccy = ccy; h.avg = String(avg); h.qty = String(qty);
    const c = num($('#fCur').value); if (c > 0) h.cur = String(c);
    const t = num($('#fTgt').value); h.target = t > 0 ? String(t) : '';
    h.rule = $('#fRule').value.trim(); h.defensive = $('#fDef').checked;
    save(); m.close(); closeDetailModal(h.id); rerender(); toast('저장했어요');
  };
}
function closeDetailModal(hId) { _modals.slice().forEach(md => { if (md.el.dataset.detail === hId) md.close(); }); }

/* ---------------- 목표 비중 ---------------- */
function openTarget(accId, hId) {
  const a = findAcc(accId), h = a && a.holdings.find(x => x.id === hId); if (!h) return;
  const T = accT(a), v = hv(h), w = T.asset > 0 ? v.valK / T.asset * 100 : 0;
  const m = openModal({
    title: '목표 비중 — ' + esc(dispName(h)),
    body: '<div class="field"><label>이 종목을 계좌의 몇 %로 가져갈까요?</label><div class="input-wrap"><input class="input lg tnum" id="fT" inputmode="decimal" value="' + (hasT(h) ? num(h.target) : '') + '" placeholder="예: 20"><span class="suffix">%</span></div>' +
      '<div class="help">지금은 <b>' + w.toFixed(1) + '%</b> (' + won(v.valK) + ' / 계좌 ' + won(T.asset) + ')</div></div><div class="preview" id="tPrev"></div>',
    foot: (hasT(h) ? '<button class="btn btn-danger shrink" data-clr>목표 지우기</button>' : '') + '<button class="btn btn-gray" data-x>취소</button><button class="btn btn-primary" data-ok>저장</button>',
  });
  const inp = m.body.querySelector('#fT'), pv = m.body.querySelector('#tPrev');
  const upd = () => {
    const t = num(inp.value);
    if (!(t > 0)) { pv.innerHTML = '<div class="hint">목표를 적으면 얼마나 더 사거나 덜어내야 하는지 알려드려요.</div>'; return; }
    const g = v.valK - T.asset * t / 100;
    const sh = v.cur > 0 ? Math.abs(g) / (v.cur * v.m) : 0;
    pv.innerHTML = '<div class="pr"><span class="k">목표 금액</span><span class="v">' + won(T.asset * t / 100) + '</span></div>' +
      '<div class="pr total"><span class="k">' + (Math.abs(g) < 1000 ? '상태' : g < 0 ? '더 사야 할 금액' : '덜어낼 금액') + '</span><span class="v ' + (g < 0 ? 'gap-buy' : 'gap-sell') + '">' + (Math.abs(g) < 1000 ? '목표 도달' : won(Math.abs(g)) + ' (약 ' + nf(sh, 1) + '주)') + '</span></div>';
  };
  inp.addEventListener('input', upd); upd(); setTimeout(() => { inp.focus(); inp.select(); }, 250);
  const ok = () => { const t = num(inp.value); h.target = t > 0 ? String(t) : ''; save(); m.close(); rerender(); };
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') ok(); });
  m.foot.querySelector('[data-x]').onclick = () => m.close();
  m.foot.querySelector('[data-ok]').onclick = ok;
  const c = m.foot.querySelector('[data-clr]'); if (c) c.onclick = () => { h.target = ''; save(); m.close(); rerender(); };
}

/* ---------------- 더 사기 (물타기/불타기) ---------------- */
function openBuy(accId, hId) {
  const a = findAcc(accId), h = a && a.holdings.find(x => x.id === hId); if (!h) return;
  const c = ccyOf(h), sf = c === 'USD' ? '$' : '원';
  const m = openModal({
    title: '더 사기 — ' + esc(dispName(h)),
    body: '<div class="callout gray" style="margin-bottom:16px">' + icon('info', 'ic-sm') + '<div>지금 평단 <b>' + priceTxt(num(h.avg), c) + '</b> · 보유 <b>' + nf(num(h.qty), 4) + '주</b> · 현재가 <b>' + priceTxt(num(h.cur), c) + '</b></div></div>' +
      '<div class="row wrap-m"><div class="field"><label>산 가격 (1주당)</label><div class="input-wrap"><input class="input lg tnum" id="bP" inputmode="decimal" value="' + esc(nf(num(h.cur), 4)) + '"><span class="suffix">' + sf + '</span></div><div class="err-msg">가격을 적어 주세요</div></div>' +
      '<div class="field"><label>산 수량</label><div class="input-wrap"><input class="input lg tnum" id="bQ" inputmode="decimal" placeholder="0"><span class="suffix">주</span></div><div class="err-msg">수량을 적어 주세요</div></div></div>' +
      '<div class="preview" id="bPrev"></div>' +
      '<label class="check"><input type="checkbox" id="bPay" checked><span>산 금액만큼 <b>계좌 현금에서 빼기</b></span></label>',
    foot: '<button class="btn btn-gray" data-x>취소</button><button class="btn btn-up" data-ok>사기 확정</button>',
  });
  const $ = s => m.body.querySelector(s);
  moneyInput($('#bP')); moneyInput($('#bQ'));
  const upd = () => {
    const bp = num($('#bP').value), bq = num($('#bQ').value), avg = num(h.avg), qty = num(h.qty), box = $('#bPrev');
    if (!(bp > 0 && bq > 0)) { box.innerHTML = '<div class="hint">가격과 수량을 적으면 <b>새 평단가</b>를 미리 보여드려요.</div>'; return; }
    const nq = qty + bq, na = (avg * qty + bp * bq) / nq, d = na - avg;
    const kind = bp < avg ? '<span class="kind water">💧 물타기 · 평단이 내려가요</span>' : bp > avg ? '<span class="kind fire">🔥 불타기 · 평단이 올라가요</span>' : '<span class="kind same">평단 그대로</span>';
    box.innerHTML = kind +
      '<div class="pr"><span class="k">이번에 쓰는 돈</span><span class="v">' + money(bp * bq, c) + (c === 'USD' ? ' (' + won(bp * bq * fx()) + ')' : '') + '</span></div>' +
      '<div class="pr"><span class="k">수량</span><span class="v">' + nf(qty, 4) + ' → ' + nf(nq, 4) + '주</span></div>' +
      '<div class="pr total"><span class="k">새 평단가</span><span class="v">' + priceTxt(na, c) + ' <span class="' + cls(d) + '" style="font-size:.86rem">' + (d ? arrow(d) + ' ' + priceTxt(Math.abs(d), c) : '') + '</span></span></div>' +
      ($('#bPay').checked && bp * bq * mult(h) > num(a.cash) ? '<div class="callout warn" style="margin-top:10px">' + icon('alert', 'ic-sm') + '<div>계좌 현금(' + won(num(a.cash)) + ')보다 많아요. 그대로 하면 현금이 마이너스로 표시돼요. 증권사 예수금과 맞는지 확인해 주세요.</div></div>' : '');
  };
  m.body.addEventListener('input', upd); upd(); setTimeout(() => $('#bQ').focus(), 250);
  m.foot.querySelector('[data-x]').onclick = () => m.close();
  m.foot.querySelector('[data-ok]').onclick = () => {
    const bp = num($('#bP').value), bq = num($('#bQ').value);
    $('#bP').closest('.field').classList.toggle('err', !(bp > 0)); $('#bQ').closest('.field').classList.toggle('err', !(bq > 0));
    if (!(bp > 0 && bq > 0)) return;
    const avg = num(h.avg), qty = num(h.qty), nq = qty + bq, na = (avg * qty + bp * bq) / nq;
    const kind = bp < avg ? '물타기' : bp > avg ? '불타기' : '추가 매수';
    h.avg = String(na); h.qty = String(nq);
    const spent = bp * bq * mult(h);
    if ($('#bPay').checked) a.cash = String(num(a.cash) - spent);
    save(); m.close(); closeDetailModal(h.id); rerender();
    toast(kind + ' 완료 · 새 평단 ' + priceTxt(na, c) + ($('#bPay').checked ? ' · 현금 -' + won(spent) : ''), 3200);
  };
}

/* ---------------- 팔기 ---------------- */
function openSell(accId, hId) {
  const a = findAcc(accId), h = a && a.holdings.find(x => x.id === hId); if (!h) return;
  const c = ccyOf(h), sf = c === 'USD' ? '$' : '원', have = num(h.qty);
  const m = openModal({
    title: '팔기 — ' + esc(dispName(h)),
    body: '<div class="callout gray" style="margin-bottom:16px">' + icon('info', 'ic-sm') + '<div>평단 <b>' + priceTxt(num(h.avg), c) + '</b> · 보유 <b>' + nf(have, 4) + '주</b> · 현재가 <b>' + priceTxt(num(h.cur), c) + '</b></div></div>' +
      '<div class="row wrap-m"><div class="field"><label>판 가격 (1주당)</label><div class="input-wrap"><input class="input lg tnum" id="sP" inputmode="decimal" value="' + esc(nf(num(h.cur), 4)) + '"><span class="suffix">' + sf + '</span></div><div class="err-msg">가격을 적어 주세요</div></div>' +
      '<div class="field"><label>판 수량 <button class="badge blue" style="margin-left:auto;cursor:pointer" id="sAll" type="button">전부</button></label><div class="input-wrap"><input class="input lg tnum" id="sQ" inputmode="decimal" placeholder="0"><span class="suffix">주</span></div><div class="err-msg">보유 수량(' + nf(have, 4) + '주) 이하로 적어 주세요</div></div></div>' +
      '<div class="preview" id="sPrev"></div>' +
      '<details class="more-opt"><summary>' + icon('chevron-down', 'ic-sm') + '수수료·세금 (자동 적용 중)</summary><div class="row">' +
        '<div class="field"><label>수수료율</label><div class="input-wrap"><input class="input tnum" id="sFee" inputmode="decimal" value="' + esc(S.settings.feeRate) + '"><span class="suffix">%</span></div></div>' +
        '<div class="field"><label>거래세율</label><div class="input-wrap"><input class="input tnum" id="sTax" inputmode="decimal" value="' + (c === 'USD' ? '0' : esc(S.settings.taxRate)) + '"><span class="suffix">%</span></div></div></div>' +
        '<p class="note" style="margin:0">국내 주식 매도 시 거래세가 붙어요(2026년 0.20%). 수수료는 증권사마다 달라요. 미국 주식 양도세는 1년 합산 신고라 여기선 빼지 않아요.</p></details>',
    foot: '<button class="btn btn-gray" data-x>취소</button><button class="btn btn-down" data-ok>팔기 확정</button>',
  });
  const $ = s => m.body.querySelector(s);
  moneyInput($('#sP')); moneyInput($('#sQ'));
  const calc = () => { const p = num($('#sP').value), q = num($('#sQ').value), fr = num($('#sFee').value), tr = num($('#sTax').value);
    const gross = p * q, fee = gross * fr / 100, tax = gross * tr / 100, net = gross - fee - tax; return { p, q, gross, fee, tax, net, real: net - num(h.avg) * q }; };
  const upd = () => {
    const k = calc(), box = $('#sPrev');
    if (!(k.p > 0 && k.q > 0)) { box.innerHTML = '<div class="hint">가격과 수량을 적으면 세금·수수료를 뺀 <b>실제로 받는 돈</b>을 보여드려요.</div>'; return; }
    if (k.q > have + 1e-9) { box.innerHTML = '<div class="hint" style="color:var(--bad)">가진 수량(' + nf(have, 4) + '주)보다 많아요.</div>'; return; }
    box.innerHTML = '<div class="pr"><span class="k">판 금액</span><span class="v">' + money(k.gross, c) + '</span></div>' +
      '<div class="pr"><span class="k">수수료 · 세금</span><span class="v muted">-' + money(k.fee + k.tax, c) + '</span></div>' +
      '<div class="pr"><span class="k">실현 손익</span><span class="v ' + cls(k.real) + '">' + moneyS(k.real, c) + '</span></div>' +
      '<div class="pr total"><span class="k">계좌 현금으로 들어오는 돈</span><span class="v" style="color:var(--brand-text)">+' + money(k.net, c) + (c === 'USD' ? ' (' + won(k.net * fx()) + ')' : '') + '</span></div>';
  };
  m.body.addEventListener('input', upd); upd();
  $('#sAll').onclick = () => { $('#sQ').value = nf(have, 6); upd(); };
  setTimeout(() => $('#sQ').focus(), 250);
  m.foot.querySelector('[data-x]').onclick = () => m.close();
  m.foot.querySelector('[data-ok]').onclick = () => {
    const k = calc();
    $('#sP').closest('.field').classList.toggle('err', !(k.p > 0));
    const qBad = !(k.q > 0) || k.q > have + 1e-9; $('#sQ').closest('.field').classList.toggle('err', qBad);
    if (!(k.p > 0) || qBad) return;
    S.settings.feeRate = String(num($('#sFee').value));
    if (c === 'KRW') S.settings.taxRate = String(num($('#sTax').value));
    a.cash = String(num(a.cash) + k.net * mult(h));
    const remain = have - k.q, all = remain <= 1e-7;
    if (all) a.holdings = a.holdings.filter(x => x.id !== h.id); else h.qty = String(remain);
    save(); m.close(); closeDetailModal(h.id); rerender();
    toast((all ? '전부 팔았어요' : '팔았어요') + ' · 현금 +' + won(k.net * mult(h)) + ' · 실현손익 ' + moneyS(k.real, c), 3600);
  };
}

/* ---------------- 가족(사람) ---------------- */
function personMenu(anchor) {
  const items = S.people.map(p => ({ label: p.name + ' (' + p.accounts.length + '계좌)', icon: 'user', on: p.id === S.curPerson, act: () => { if (p.id !== S.curPerson) { S.curPerson = p.id; curAccId = null; selH = null; save(); rerender(); toast(p.name + '님 자산으로 바꿨어요'); } } }));
  items.push('-', { label: '가족 추가', icon: 'plus', act: () => openPersonForm(null) }, { label: '이름 바꾸기', icon: 'pencil', act: () => openPersonForm(S.curPerson) });
  openMenu(anchor, items);
}
function openPersonForm(id) {
  const p = id ? S.people.find(x => x.id === id) : null;
  const m = openModal({
    title: p ? '이름 바꾸기' : '가족 추가',
    body: '<div class="field"><label>이름</label><input class="input lg" id="fP" maxlength="20" value="' + esc(p ? p.name : '') + '" placeholder="예: 엄마, 아빠, 나"><div class="err-msg">이름을 적어 주세요</div>' +
      (p ? '' : '<div class="help">가족 한 명 한 명의 계좌를 따로 관리할 수 있어요. 왼쪽 위 이름을 눌러 바꿔 볼 수 있어요.</div>') + '</div>',
    foot: (p && S.people.length > 1 ? '<button class="btn btn-danger shrink" data-del>' + icon('trash', 'ic-sm') + '</button>' : '') + '<button class="btn btn-gray" data-x>취소</button><button class="btn btn-primary" data-ok>' + (p ? '저장' : '추가') + '</button>',
  });
  const inp = m.body.querySelector('#fP'); setTimeout(() => inp.focus(), 250);
  const ok = () => {
    const nm = inp.value.trim(); if (!nm) { inp.closest('.field').classList.add('err'); return; }
    if (p) p.name = nm;
    else { const np = { id: uid('p'), name: nm, accounts: [], history: [] }; S.people.push(np); S.curPerson = np.id; curAccId = null; selH = null; }
    save(); m.close(); rerender(); toast(p ? '이름을 바꿨어요' : nm + '님을 추가했어요');
  };
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') ok(); });
  m.foot.querySelector('[data-x]').onclick = () => m.close();
  m.foot.querySelector('[data-ok]').onclick = ok;
  const d = m.foot.querySelector('[data-del]');
  if (d) d.onclick = async () => {
    if (await confirmBox({ title: '가족 삭제', msg: '“' + esc(p.name) + '”님과 그 계좌·기록을 모두 지울까요?<br>되돌릴 수 없어요.', ok: '삭제', danger: true })) {
      S.people = S.people.filter(x => x.id !== p.id); if (S.curPerson === p.id) S.curPerson = S.people[0].id; curAccId = null; save({ force: true }); m.close(); rerender();
    }
  };
}

/* ---------------- 첫 실행 안내 ---------------- */
function openOnboarding() {
  const m = openModal({ title: '', sticky: true, onClose: () => { UI.onboarded = true; saveUI(); } });
  m.el.querySelector('.modal-head').style.paddingBottom = '0';
  let step = 0, accName = '';
  const dots = n => '<div class="dots">' + [0, 1, 2, 3].map(i => '<i class="' + (i === n ? 'on' : '') + '"></i>').join('') + '</div>';
  const show = () => {
    if (step === 0) {
      m.setBody('<div class="ob"><div class="ob-ill">' + icon('sparkles') + '</div><h3>' + BRAND.name + '에 오신 걸<br>환영해요</h3><p>여러 증권사에 흩어진 내 주식을 한곳에 모아<br>쉽게 보고, 똑똑하게 관리해요.</p>' +
        '<div class="feats">' +
          '<div class="feat"><div class="ico" style="background:var(--brand-soft);color:var(--brand)">' + icon('wallet') + '</div><div><b>모든 계좌를 한눈에</b><span>총자산·수익률·비중을 자동으로 계산해요</span></div></div>' +
          '<div class="feat"><div class="ico" style="background:var(--good-soft);color:var(--good)">' + icon('globe') + '</div><div><b>시장 흐름까지 무료로</b><span>코스피·나스닥·환율·금리·공포지수</span></div></div>' +
          '<div class="feat"><div class="ico" style="background:var(--warn-soft);color:var(--warn)">' + icon('sparkles') + '</div><div><b>무료 AI 비서</b><span>내 종목 뉴스 요약, 궁금한 건 바로 질문</span></div></div>' +
        '</div>' + dots(0) + '</div>');
      m.setFoot('<button class="btn btn-primary" data-n>시작하기</button>');
    } else if (step === 1) {
      const cur = P().name === '나' || P().name === '이순신' ? '' : P().name;
      m.setBody('<div class="ob"><div class="ob-ill">' + icon('user') + '</div><h3>누구의 자산을<br>관리할까요?</h3><p>이름(또는 별명)을 적어 주세요. 가족 자산도 나중에 따로 추가할 수 있어요.</p>' +
        '<div class="field" style="margin-top:22px;text-align:left"><input class="input lg" id="obName" maxlength="20" placeholder="예: 김철수" value="' + esc(cur) + '" style="text-align:center"></div>' + dots(1) + '</div>');
      m.setFoot('<button class="btn btn-gray shrink" data-p>' + icon('chevron-left', 'ic-sm') + '</button><button class="btn btn-primary" data-n>다음</button>');
      setTimeout(() => { const i = m.body.querySelector('#obName'); i.focus(); i.addEventListener('keydown', e => { if (e.key === 'Enter') next(); }); }, 250);
    } else if (step === 2) {
      m.setBody('<div class="ob"><div class="ob-ill">' + icon('card') + '</div><h3>첫 계좌를 만들어요</h3><p>주로 쓰는 <b>증권사 이름</b>으로 만들면 편해요.</p>' +
        '<div class="field" style="margin-top:22px"><input class="input lg" id="obAcc" maxlength="30" placeholder="예: 키움증권" value="' + esc(accName) + '" style="text-align:center"></div>' +
        '<div class="quick-picks">' + BROKERS.slice(0, 8).map(b => '<button class="chip" data-pick="' + esc(b) + '">' + esc(b) + '</button>').join('') + '</div>' + dots(2) + '</div>');
      m.setFoot('<button class="btn btn-gray shrink" data-p>' + icon('chevron-left', 'ic-sm') + '</button><button class="btn btn-primary" data-n>계좌 만들기</button>');
      const i = m.body.querySelector('#obAcc');
      m.body.querySelectorAll('[data-pick]').forEach(b => b.onclick = () => { i.value = b.dataset.pick; m.body.querySelectorAll('[data-pick]').forEach(x => x.classList.toggle('on', x === b)); });
      setTimeout(() => { i.focus(); i.addEventListener('keydown', e => { if (e.key === 'Enter') next(); }); }, 250);
    } else {
      m.setBody('<div class="ob"><div class="ob-ill">' + icon('key') + '</div><h3>AI 비서도 연결할까요?</h3><p>구글 계정만 있으면 <b>무료</b>예요.<br>안내대로 <b>키 하나만 붙여넣으면</b> 끝나요. (약 3분)</p>' +
        '<div class="callout info" style="margin-top:20px;text-align:left">' + icon('info', 'ic-sm') + '<div>나중에 해도 괜찮아요. 왼쪽 메뉴 <b>설정 → AI 연결</b>에서 언제든 할 수 있어요.</div></div>' + dots(3) + '</div>');
      m.setFoot('<button class="btn btn-gray" data-later>나중에 할게요</button><button class="btn btn-primary" data-ai>지금 연결하기</button>');
    }
    const n = m.foot.querySelector('[data-n]'); if (n) n.onclick = next;
    const p = m.foot.querySelector('[data-p]'); if (p) p.onclick = () => { step--; show(); };
    const later = m.foot.querySelector('[data-later]'); if (later) later.onclick = () => finish(false);
    const ai = m.foot.querySelector('[data-ai]'); if (ai) ai.onclick = () => finish(true);
  };
  const next = () => {
    if (step === 1) { const v = m.body.querySelector('#obName').value.trim(); if (v) { P().name = v; save(); rerender(); } }
    if (step === 2) {
      const v = m.body.querySelector('#obAcc').value.trim();
      if (!v) { m.body.querySelector('#obAcc').classList.add('err'); m.body.querySelector('#obAcc').focus(); toast('계좌 이름을 적거나 아래에서 골라 주세요'); return; }
      accName = v;
      if (!accounts().some(a => a.name === v)) { const used = new Set(accounts().map(x => x.ci)); const na = { id: uid('a'), name: v, cash: '0', holdings: [], ci: nextFree(used) }; accounts().push(na); curAccId = na.id; save(); }
      if (AI_STATUS && AI_STATUS.on) { finish(false); return; }   // AI가 이미 연결돼 있으면 마지막 단계 생략
    }
    step++; show();
  };
  const finish = toAi => {
    UI.onboarded = true; saveUI(); m.close();
    if (toAi) go('settings', { sec: 'ai' });
    else { go('accounts', { acc: curAccId }); setTimeout(() => { const b = document.getElementById('btnAddHolding') || document.querySelector('[data-act="h-new"]'); if (b) { b.classList.add('pulse'); toast('“종목 추가”를 눌러 가진 주식을 넣어 보세요', 3500); } }, 400); }
  };
  show();
}
