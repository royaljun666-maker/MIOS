/* ==========================================================================
   flash.js — 📰 속보 (v2.20)
   최근 하루 속보·시장 뉴스를 트위터 카드처럼. 중요 속보는 색으로, 누르면 원래 기사로.
   ========================================================================== */
'use strict';

const FL = { data: null, busy: false, filter: 'all', timer: null, view: 'flash', my: null, myBusy: false };
const FL_LV = { red: ['🔴', '긴급'], orange: ['🟠', '중요'], normal: ['', ''] };
function flMine() {                                        // 내 종목·관심종목 이름 (카드에 '내 종목' 표시)
  const n = new Set();
  allHoldings().forEach(x => { const s = dispName(x.h); if (s && s.length >= 2) n.add(s); });
  watchlist().forEach(w => { const s = dispName(w); if (s && s.length >= 2) n.add(s); });
  return [...n];
}
function flCard(it, mine) {
  const hit = it.stock || mine.find(n => (it.title + ' ' + trOf(it)).includes(n));
  const lv = FL_LV[it.level] || FL_LV.normal, src = it.src || '뉴스';
  const hue = [...src].reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
  return '<a class="fl-card ' + it.level + (hit ? ' mine' : '') + '" href="' + esc(safeUrl(it.url)) + '" target="_blank" rel="noopener">' +
    '<div class="fl-av" style="background:hsl(' + hue + ',55%,48%)">' + esc(src.slice(0, 1)) + '</div>' +
    '<div class="fl-main"><div class="fl-top"><b>' + esc(src) + '</b><span>· ' + (it.ts ? esc(ago(it.ts * 1000)) : '') + '</span>' +
      (lv[1] ? '<i class="fl-tag ' + it.level + '">' + lv[0] + ' ' + lv[1] + '</i>' : '') + (hit ? '<i class="fl-tag mine">' + (it.held === false ? '⭐ ' : '💼 ') + esc(hit) + '</i>' : '') + '</div>' +
      '<div class="fl-title">' + trInline(it) + '</div>' +
      '<div class="fl-foot">' + icon('link', 'ic-sm') + '<span>원문 기사 보기</span>' + (it.via === 'naver' ? '<span class="fl-en">네이버</span>' : it.via === 'rss' ? '<span class="fl-en">' + esc(it.src) + '</span>' : '') + (it.lang === 'en' ? '<span class="fl-en">해외</span>' : '') + '</div>' +
      (it.n > 1 ? '<div class="fl-more" data-flm><b>📚 비슷한 기사 ' + (it.n - 1) + '건 더</b> · ' + esc((it.srcs || []).slice(0, 4).join('·')) + ' <i>펼치기 ›</i></div>' +
        '<div class="fl-mlist">' + (it.more || []).map(m => '<span class="fl-mi" data-u="' + esc(safeUrl(m.url)) + '">· ' + (trOn() && trOf(m) ? esc(trOf(m)) : trOn() && isForeignT(m.title) ? trSpan(m.title) : esc(m.title)) + ' <em>' + esc(m.src || '') + '</em></span>').join('') + '</div>' : '') + '</div></a>';
}
function flLoad(fresh) {
  if (FL.busy) return;
  FL.busy = true;
  api('/api/flash' + (fresh ? '?fresh=1' : ''), { timeout: 30000 })
    .then(d => { if (d && d.ok) FL.data = d; })
    .catch(() => { if (!FL.data) FL.data = { err: 1, items: [] }; })
    .finally(() => { FL.busy = false; if (route.page === 'news') PAGES.news(null, true); });
}
function myNewsItems() {                               // 보유 종목 먼저, 그다음 관심종목
  const seen = new Set(), out = [];
  allHoldings().forEach(x => { const t = x.h.ticker; if (t && !seen.has(t)) { seen.add(t); out.push({ ticker: t, name: dispName(x.h), market: mkt(x.h), held: true }); } });
  watchlist().forEach(w => { const t = w.ticker; if (t && !seen.has(t)) { seen.add(t); out.push({ ticker: t, name: dispName(w), market: w.market, held: false }); } });
  return out.slice(0, 25);
}
function myNewsLoad(fresh) {
  if (FL.myBusy) return;
  const items = myNewsItems(); if (!items.length) { FL.my = { ok: true, items: [], at: Date.now() / 1000, stocks: 0 }; return; }
  FL.myBusy = true;
  api('/api/mynews', { method: 'POST', body: { items, fresh: !!fresh }, timeout: 60000 })
    .then(d => { if (d && d.ok) FL.my = d; }).catch(() => { if (!FL.my) FL.my = { err: 1, items: [] }; })
    .finally(() => { FL.myBusy = false; if (route.page === 'news') PAGES.news(null, true); });
}
PAGES.news = function (params, isRe) {
  if (FL.view === 'mine') return newsMinePage(isRe);
  if (FL.view === 'movers') return moversPage(isRe);
  const el = pageEl('news');
  const d = FL.data, mine = flMine();
  let items = (d && d.items) || [];
  const cnt = { red: items.filter(x => x.level === 'red').length, imp: items.filter(x => x.level !== 'normal').length, mine: items.filter(x => mine.some(n => (x.title + ' ' + trOf(x)).includes(n))).length };
  if (FL.filter === 'imp') items = items.filter(x => x.level !== 'normal');
  if (FL.filter === 'mine') items = items.filter(x => mine.some(n => (x.title + ' ' + trOf(x)).includes(n)));
  const chips = [['all', '전체 ' + ((d && d.items) || []).length], ['imp', '🔴🟠 중요 ' + cnt.imp], ['mine', '⭐ 내 종목 ' + cnt.mine]]
    .map(([k, l]) => '<button class="chip' + (FL.filter === k ? ' on' : '') + '" data-fl="' + k + '">' + l + '</button>').join('');
  el.innerHTML = flViewSeg() + '<div class="page-head"><div><h1>📰 속보</h1><div class="desc">최근 하루 증시·경제 속보 · 누르면 원래 기사로 가요' + (d && d.at ? ' · ' + esc(ago(d.at * 1000)) + ' 확인' : '') + '</div></div>' +
      '<div class="actions"><button class="btn btn-outline" id="flRe">' + icon('refresh', 'ic-sm') + '새로고침</button></div></div>' +
    (items.length >= 3 ? '<button class="btn btn-soft btn-block fl-digest" data-act="fl-digest">🧠 AI로 속보 묶어 읽기 — 지금 무슨 일이, 시장엔 어떤 재료인지</button>' : '') +
    '<div class="chips fl-chips" id="flF">' + chips + '</div>' +
    (cnt.red ? '<div class="fl-alert">🔴 긴급 속보 ' + cnt.red + '건 — 맨 위 빨간 카드부터 확인하세요</div>' : '') +
    '<div class="fl-list">' + (!d ? '<div class="ai-loading" style="padding:40px 10px"><div class="orb"></div><div>속보를 모으는 중이에요…</div></div>'
      : d.err ? '<p class="note">' + SERVER_DOWN + '</p>'
      : items.length ? items.slice(0, FL.limit || 30).map(x => flCard(x, mine)).join('') + (items.length > (FL.limit || 30) ? '<button class="btn btn-soft btn-block" id="flMore">더 보기 (' + (items.length - (FL.limit || 30)) + '건)</button>' : '') : '<p class="note" style="padding:20px 4px">' + (FL.filter === 'mine' ? '내 종목·관심종목 이름이 들어간 속보가 아직 없어요.' : '표시할 속보가 없어요.') + '</p>') + '</div>' +
    '<p class="note" style="margin:12px 2px 0">같은 내용의 기사는 한 장으로 묶었어요. 🔴 긴급(속보·폭락·전쟁 등) · 🟠 중요(단독·급등락·금리·환율 등)는 제목의 단어로 자동 표시돼요. 네이버 증권·연합뉴스·한국경제·매일경제·CNBC·MarketWatch·구글 뉴스에서 모아요.</p>';
  hydrateIcons(el);
  el.querySelector('.fl-list').addEventListener('click', e => {      // 비슷한 기사: 펼치기 / 그 기사로
    const mi = e.target.closest('.fl-mi'), mo = e.target.closest('[data-flm]');
    if (mi) { e.preventDefault(); openExt ? openExt(mi.dataset.u) : window.open(mi.dataset.u, '_blank'); return; }
    if (mo) { e.preventDefault(); mo.closest('.fl-card').classList.toggle('open'); }
  });
  flWireView(el);
  const fm = el.querySelector('#flMore'); if (fm) fm.onclick = () => { FL.limit = (FL.limit || 30) + 30; PAGES.news(null, true); };
  el.querySelector('#flF').onclick = e => { const b = e.target.closest('[data-fl]'); if (b) { FL.filter = b.dataset.fl; FL.limit = 30; PAGES.news(null, true); } };
  el.querySelector('#flRe').onclick = () => { FL.data = null; PAGES.news(null, true); flLoad(true); };
  if (!isRe && !FL.busy && (!d || Date.now() / 1000 - d.at > 90)) flLoad(false);
  clearInterval(FL.timer);                                   // 이 화면에 있는 동안 2분마다 새로
  FL.timer = setInterval(() => { if (route.page !== 'news') { clearInterval(FL.timer); return; } flLoad(false); }, 120000);
};

/* 💼 내 종목 뉴스 (v2.33) — 보유·관심 종목 뉴스만 빠르게 */
function flViewSeg() {
  return '<div class="seg fl-view"><button data-flv="flash" class="' + (FL.view === 'flash' ? 'on' : '') + '">📰 속보</button><button data-flv="mine" class="' + (FL.view === 'mine' ? 'on' : '') + '">💼 내 종목 뉴스</button><button data-flv="movers" class="' + (FL.view === 'movers' ? 'on' : '') + '">⚡ 오늘 급등락</button></div>';
}
function flWireView(el) {
  el.querySelector('.fl-view').onclick = e => { const b = e.target.closest('[data-flv]'); if (!b || FL.view === b.dataset.flv) return; FL.view = b.dataset.flv; window.scrollTo(0, 0); PAGES.news(null, false); };
  const L = el.querySelector('.fl-list');
  if (L && FL.view === 'mine') L.addEventListener('click', e => {
    const mi = e.target.closest('.fl-mi'), mo = e.target.closest('[data-flm]');
    if (mi) { e.preventDefault(); openExt(mi.dataset.u); return; }
    if (mo) { e.preventDefault(); mo.closest('.fl-card').classList.toggle('open'); }
  });
}
function newsMinePage(isRe) {
  const el = pageEl('news'), d = FL.my, stocks = myNewsItems();
  let items = (d && d.items) || [];
  const names = [...new Set(items.map(x => x.stock).filter(Boolean))];
  if (FL.myPick && !names.includes(FL.myPick)) FL.myPick = '';
  if (FL.myPick) items = items.filter(x => x.stock === FL.myPick);
  el.innerHTML = flViewSeg() + '<div class="page-head"><div><h1>💼 내 종목 뉴스</h1><div class="desc">보유 종목 💼 · 관심종목 ⭐ 뉴스만 · 최근 2일' + (d && d.at ? ' · ' + esc(ago(d.at * 1000)) + ' 확인' : '') + '</div></div>' +
      '<div class="actions"><button class="btn btn-outline" id="mnRe">' + icon('refresh', 'ic-sm') + '새로고침</button></div></div>' +
    (names.length ? '<div class="chips fl-chips" id="mnF"><button class="chip' + (!FL.myPick ? ' on' : '') + '" data-st="">전체 ' + ((d && d.items) || []).length + '</button>' +
      names.map(n => '<button class="chip' + (FL.myPick === n ? ' on' : '') + '" data-st="' + esc(n) + '">' + esc(n) + ' ' + d.items.filter(x => x.stock === n).length + '</button>').join('') + '</div>' : '') +
    '<div class="fl-list">' + (!stocks.length ? '<div class="empty" style="padding:30px 10px"><p>보유 종목이나 관심종목을 넣으면 그 종목 뉴스만 모아 보여 줘요.</p><button class="btn btn-primary" data-act="h-new">종목 추가</button></div>'
      : !d ? '<div class="ai-loading" style="padding:40px 10px"><div class="orb"></div><div>내 종목 ' + stocks.length + '개의 뉴스를 모으는 중이에요…</div></div>'
      : d.err ? '<p class="note">' + SERVER_DOWN + '</p>'
      : items.length ? items.map(x => flCard(x, [])).join('') : '<p class="note" style="padding:20px 4px">최근 2일 안에 나온 내 종목 뉴스가 없어요.</p>') + '</div>' +
    '<p class="note" style="margin:12px 2px 0">내 종목 최대 25개까지 · 같은 내용은 한 장으로 묶어요. 종목을 눌러 그 종목 뉴스만 볼 수 있어요.</p>';
  hydrateIcons(el); flWireView(el);
  const f = el.querySelector('#mnF'); if (f) f.onclick = e => { const b = e.target.closest('[data-st]'); if (b) { FL.myPick = b.dataset.st; newsMinePage(true); } };
  el.querySelector('#mnRe').onclick = () => { FL.my = null; newsMinePage(true); myNewsLoad(true); };
  if (!isRe && stocks.length && (!d || Date.now() / 1000 - d.at > 120)) myNewsLoad(false);
}


/* ⚡ 오늘 급등락 (v4.9) — 보유·관심 종목 중 크게 움직인 것 + 이유(뉴스) 바로 보기 */
function moversPage(isRe) {
  const el = pageEl('news'), th = FL.mvTh || MOVE_BIG, all = bigMovers(th);
  const up = all.filter(x => x.chg > 0), dn = all.filter(x => x.chg < 0);
  const KIND = { '뉴스로 설명됨': '📰', '시장 전체 흐름': '🌊', '업종 흐름': '🏭', '뉴스 없음': '🤷' };
  const row = x => {
    const d = _moveMem[x.ticker] && Math.abs(_moveMem[x.ticker].chg - x.chg) < 0.3 ? _moveMem[x.ticker] : null;
    return '<div class="mvp-row"><div class="mvp-top"><div class="mv-l"><b>' + esc(x.name) + '</b><span>' + (x.held ? '💼 보유' : '⭐ 관심') + (x.cur ? ' · ' + esc(priceTxt(x.cur, x.ccy)) : '') + '</span></div>' +
      '<i class="mv-chg ' + cls(x.chg) + '">' + (x.chg >= 0 ? '▲ ' : '▼ ') + Math.abs(x.chg).toFixed(2) + '%</i></div>' +
      (d ? '<button class="mvp-why" data-act="move-why" data-p="' + esc(JSON.stringify(x)) + '"><em>' + (KIND[d.kind] || '📰') + ' ' + esc(d.kind) + '</em><span>' + esc(d.reason) + '</span><i>자세히 ›</i></button>'
         : moveWhyBtn(x, 'btn-soft btn-sm mvp-ask')) + '</div>';
  };
  const sec = (t, arr) => arr.length ? '<div class="mvp-sec"><h3>' + t + ' <span class="muted">' + arr.length + '</span></h3>' + arr.map(row).join('') + '</div>' : '';
  const any = watchlist().some(w => w.ticker) || allHoldings().some(x => x.h.ticker);
  el.innerHTML = flViewSeg() + '<div class="page-head"><div><h1>⚡ 오늘 급등락</h1><div class="desc">내 보유 💼 · 관심 ⭐ 종목 중 오늘 크게 움직인 것 · 누르면 왜 움직였는지 뉴스로 찾아요</div></div>' +
      '<div class="actions"><button class="btn btn-outline" id="mvRe">' + icon('refresh', 'ic-sm') + '시세 갱신</button></div></div>' +
    '<div class="chips" id="mvTh">' + [2, 3, 5, 10].map(n => '<button class="chip' + (th === n ? ' on' : '') + '" data-th="' + n + '">±' + n + '% 이상</button>').join('') + '</div>' +
    (all.length ? (all.some(x => !_moveMem[x.ticker]) && (AI_STATUS && AI_STATUS.on) ? '<button class="btn btn-primary btn-block" id="mvAll" style="margin:10px 0">🔎 ' + Math.min(all.length, 8) + '종목 이유 한 번에 찾기</button>' : '') +
        sec('📈 급등', up) + sec('📉 급락', dn)
      : '<div class="empty" style="padding:36px 10px"><div class="ill">⚡</div><b>' + (any ? '오늘 ±' + th + '% 넘게 움직인 내 종목이 없어요' : '보유·관심 종목이 없어요') + '</b><p>' +
          (any ? '기준을 낮추거나(±2%) 시세를 갱신해 보세요.' : '관심 탭에서 종목을 담거나 계좌에 종목을 넣으면 여기서 급등락을 모아 보여 줘요.') + '</p></div>') +
    '<p class="note" style="margin-top:12px">등락률은 마지막 시세 갱신 기준이에요. 이유는 최근 이틀 뉴스·공시와 시장 흐름으로 AI가 추정한 해석이에요 · 투자 권유 아님.</p>';
  hydrateIcons(el); flWireView(el);
  el.querySelector('#mvTh').onclick = e => { const b = e.target.closest('[data-th]'); if (b) { FL.mvTh = +b.dataset.th; moversPage(true); } };
  el.querySelector('#mvRe').onclick = e => {
    const b = e.currentTarget; b.disabled = true;
    Promise.all([refreshPrices({ silent: true }).catch(() => {}), refreshWatchPrices(true).catch(() => {})]).finally(() => { if (route.page === 'news' && FL.view === 'movers') moversPage(true); });
  };
  const ab = el.querySelector('#mvAll');
  if (ab) ab.onclick = async () => {
    ab.disabled = true;
    const todo = all.filter(x => !_moveMem[x.ticker]).slice(0, 8); let n = 0;
    for (const x of todo) {
      ab.textContent = '🔎 이유 찾는 중… ' + (++n) + '/' + todo.length;
      try {
        const d = await api('/api/move-why', { method: 'POST', timeout: 120000, body: { ticker: x.ticker, market: x.market, name: x.name, chg: x.chg, price: x.cur } });
        if (d && d.status === 'ok') _moveMem[x.ticker] = d;
        else if (d && d.status === 'no_key') { toast('AI 연결이 필요해요'); break; }
      } catch (e) {}
      if (route.page !== 'news' || FL.view !== 'movers') return;
      const keep = ab.textContent; moversPage(true); const nb = document.getElementById('mvAll'); if (nb) { nb.disabled = true; nb.textContent = keep; }
    }
    if (route.page === 'news' && FL.view === 'movers') moversPage(true);
  };
}
