/* ==========================================================================
   persona.js — 🎭 내 AI 캐릭터 (v4.16)
   설문(투자자 정보)이 '무엇을 아는 사람이냐'라면, 캐릭터는 '어떻게 말하는 AI냐'.
   이름·말투·비유·설명 순서·유머·분위기·직설·이모지·말버릇·자기소개 + 개성 강도·다양성(온도).
   기기마다 고유 번호(seed)가 붙어, 같은 걸 골라도 사람마다 다른 '지문'(서버가 말버릇 3가지를 뽑음).
   사실·숫자·근거·결론은 바꾸지 않음 — 말하는 방식만.
   ========================================================================== */
'use strict';

const PS_TONE = [['polite', '🙇 정중한 존댓말'], ['friend', '😊 친근한 반말'], ['senior', '🧑‍🏫 선배처럼'], ['warm', '👵 손주처럼 다정하게'],
                 ['anchor', '🎙 뉴스 앵커처럼'], ['pro', '🧑‍💼 전문가처럼 건조하게'], ['coach', '🏋️ 코치처럼 힘 있게'], ['calm', '🧘 상담사처럼 차분히']];
const PS_META = [['none', '🚫 비유 거의 안 씀'], ['cook', '🍳 요리·음식'], ['farm', '🌾 농사·텃밭'], ['sport', '⚽ 스포츠'], ['baduk', '♟ 바둑·장기'], ['drive', '🚗 운전·길'],
                 ['weather', '🌦 날씨·계절'], ['fish', '🎣 낚시·바다'], ['kids', '👶 육아'], ['shop', '🏪 장사'], ['army', '🪖 군대·작전'], ['hike', '🥾 등산'],
                 ['game', '🎮 게임'], ['music', '🎵 음악'], ['health', '💪 건강·운동'], ['build', '🏗 집 짓기'], ['travel', '✈️ 여행'], ['drama', '🎬 드라마·영화']];
const PS_ORDER = [['first', '🎯 결론부터'], ['why', '🧱 근거 쌓고 결론'], ['ask', '❓ 먼저 짚고 나서'], ['story', '📖 이야기하듯']];
const PS_SLIDE = [['humor', '😄 유머', '진지하게', '자주 웃기게'], ['opt', '🌤 분위기', '신중·보수적', '희망적·밝게'], ['blunt', '🗣 표현', '부드럽게 돌려서', '직설적으로'],
                  ['emoji', '✨ 이모지', '안 씀', '자주'], ['str', '🎚 개성 강도', '살짝만', '뚜렷하게'], ['var', '🎲 다양성', '늘 비슷하게', '매번 다르게']];
const PS_AVATAR = ['🤖', '🦉', '🐻', '🦊', '🐱', '🐯', '🧑‍🏫', '👩‍💼', '🧙', '🦁', '🐢', '🐬', '🌟', '🍀', '☕', '📈'];
const PS_NAMES = ['비서', '길동이', '똑순이', '나침반', '등대', '참새', '올빼미', '거북이', '다람이', '해달', '별이', '바람', '이슬', '반디', '보리', '콩이', '여울', '마루'];
const PS_PRESETS = [
  ['👵 어르신 친구', { tone: 'warm', meta: 'farm', order: 'first', humor: 3, opt: 5, blunt: 3, emoji: 3, str: 7, var: 4 }],
  ['🧑‍💼 냉정한 애널리스트', { tone: 'pro', meta: 'none', order: 'first', humor: 0, opt: 3, blunt: 9, emoji: 0, str: 8, var: 2 }],
  ['😄 유쾌한 친구', { tone: 'friend', meta: 'sport', order: 'story', humor: 8, opt: 7, blunt: 6, emoji: 8, str: 8, var: 7 }],
  ['🧘 차분한 코치', { tone: 'calm', meta: 'hike', order: 'ask', humor: 2, opt: 5, blunt: 4, emoji: 2, str: 6, var: 3 }],
  ['🎙 앵커', { tone: 'anchor', meta: 'weather', order: 'first', humor: 1, opt: 5, blunt: 7, emoji: 1, str: 6, var: 3 }],
  ['🧑‍🏫 선생님', { tone: 'senior', meta: 'cook', order: 'why', humor: 4, opt: 5, blunt: 5, emoji: 4, str: 7, var: 5 }],
];
function personaNow() {
  if (!UI.persona || typeof UI.persona !== 'object') UI.persona = {};
  if (!UI.persona.seed) { UI.persona.seed = Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4); saveUI(); }   // 기기 고유 번호
  return UI.persona;
}
function personaName() { const p = personaNow(); return p.name ? (p.avatar || '🎭') + ' ' + p.name : ''; }
function personaHeader() {
  const p = personaNow(), out = ['seed=' + p.seed];
  ['name', 'tone', 'meta', 'order', 'catch', 'bio'].forEach(k => { if (p[k]) out.push(k + '=' + encodeURIComponent(String(p[k]).slice(0, k === 'bio' ? 200 : 40))); });
  PS_SLIDE.forEach(([k]) => { if (p[k] != null) out.push(k + '=' + (+p[k])); });
  return out.join(';');
}
function personaSummary() {
  const p = personaNow(), t = (PS_TONE.find(x => x[0] === p.tone) || [])[1], m = (PS_META.find(x => x[0] === p.meta) || [])[1];
  return p.name ? (p.avatar || '🎭') + ' ' + p.name + (t ? ' · ' + t.replace(/^\S+\s/, '') : '') + (m && p.meta !== 'none' ? ' · ' + m.replace(/^\S+\s/, '') + ' 비유' : '') : '아직 안 만듦 — 이름·말투·비유를 정해요';
}
function psWord(k, v) {
  const s = PS_SLIDE.find(x => x[0] === k); v = +v;
  return v <= 2 ? s[2] : v >= 8 ? s[3] : v === 5 ? '보통' : v < 5 ? '조금 ' + s[2] : '조금 ' + s[3];
}
/* 미리보기 — AI 호출 없이, 고른 값으로 '이렇게 말할 거예요' 예문 */
function psPreview(p) {
  const nm = p.name || '비서', tone = p.tone || 'polite', meta = p.meta || 'none', order = p.order || 'first';
  const metaLine = { cook: '불 조절이 중요한 요리처럼', farm: '씨 뿌리고 기다리는 농사처럼', sport: '전반전이 끝난 경기처럼', baduk: '포석이 끝난 바둑판처럼', drive: '안개 낀 고속도로처럼',
    weather: '장마 끝나고 개는 하늘처럼', fish: '물때를 기다리는 낚시처럼', kids: '아이 열 오를 때처럼', shop: '손님 뜸한 가게처럼', army: '정찰 뒤 작전처럼', hike: '정상 앞 마지막 능선처럼',
    game: '보스전 직전처럼', music: '후렴 들어가기 전처럼', health: '체중계 숫자처럼', build: '기초 공사 중인 집처럼', travel: '환승 공항에서처럼', drama: '다음 회 예고처럼' }[meta] || '';
  const core = { polite: '삼성전자는 오를 근거 3개·내릴 근거 2개로, 오를 근거 쪽이 조금 더 많습니다.', friend: '삼성전자, 오를 근거 3개에 내릴 근거 2개야. 오를 쪽이 살짝 많아.',
    senior: '삼성전자 보면요, 오를 근거 3개·내릴 근거 2개예요. 오를 쪽이 조금 앞서요.', warm: '삼성전자는요, 오를 이유가 세 가지, 내릴 이유가 두 가지예요. 오를 쪽이 조금 더 많아요.',
    anchor: '삼성전자, 상승 근거 3건 대 하락 근거 2건. 상승 쪽이 우세합니다.', pro: '삼성전자: 상승 근거 3, 하락 근거 2. 상승 우위.', coach: '삼성전자! 오를 근거 3개, 내릴 근거 2개. 오를 쪽이 앞서 있어요, 집중!',
    calm: '삼성전자는 오를 근거가 3개, 내릴 근거가 2개예요. 서두를 건 없고, 오를 쪽이 조금 더 많네요.' }[tone];
  const open = { first: '', why: '먼저 근거부터 볼게요. ', ask: '요즘 반도체 뉴스 보셨죠? ', story: '지난주부터 이야기가 좀 달라졌어요. ' }[order];
  const h = +(p.humor == null ? 5 : p.humor), e = +(p.emoji == null ? 5 : p.emoji);
  return (e > 5 ? '📊 ' : '') + open + (metaLine ? metaLine + ' ' : '') + core + (h >= 7 ? (tone === 'friend' ? ' (내릴 근거 2개는 자꾸 눈에 밟히긴 해 😅)' : ' 내릴 근거 2개가 조용히 손을 들고 있긴 하지만요 😄') : '') +
    (+(p.opt == null ? 5 : p.opt) <= 2 ? ' 다만 환율 부담은 먼저 보셔야 해요.' : '') + (p.catch ? ' ' + p.catch : '');
}
function openPersona() {
  const p = Object.assign({}, personaNow());
  const m = openModal({ title: '🎭 내 AI 캐릭터', size: 'wide', body: '', foot: '<button class="btn btn-gray" data-rand>🎲 랜덤</button><button class="btn btn-primary" data-ok>' + icon('check') + '저장</button>' });
  const draw = () => {
    m.setBody(
      '<p class="note" style="margin:0 0 10px">설문이 <b>‘나는 어떤 투자자냐’</b>라면, 캐릭터는 <b>‘AI가 어떻게 말하느냐’</b>예요. 천 명이 쓰면 천 가지 다른 답이 나오게 — <b>사실·근거·결론은 같고, 말하는 방식만</b> 달라져요.</p>' +
      '<div class="ah-sub" style="margin-top:0">빠른 조합</div><div class="chips">' + PS_PRESETS.map((x, i) => '<button class="chip" data-p="' + i + '">' + esc(x[0]) + '</button>').join('') + '</div>' +
      '<div class="ps-id"><div class="ps-av" id="psAv">' + (p.avatar || '🤖') + '</div><div style="flex:1"><div class="ah-sub" style="margin:0 0 4px">이름</div><div class="input-wrap"><input class="input" id="psName" maxlength="12" placeholder="예: 길동이, 나침반" value="' + esc(p.name || '') + '"><button class="btn btn-ghost btn-sm" id="psNameR" type="button">🎲</button></div></div></div>' +
      '<div class="chips ps-avs" id="psAvs">' + PS_AVATAR.map(a => '<button class="chip' + ((p.avatar || '🤖') === a ? ' on' : '') + '" data-av="' + a + '">' + a + '</button>').join('') + '</div>' +
      '<div class="ah-sub">말투</div><div class="chips" data-k="tone">' + PS_TONE.map(([v, l]) => '<button class="chip' + (p.tone === v ? ' on' : '') + '" data-v="' + v + '">' + l + '</button>').join('') + '</div>' +
      '<div class="ah-sub">비유 세계</div><div class="chips" data-k="meta">' + PS_META.map(([v, l]) => '<button class="chip' + (p.meta === v ? ' on' : '') + '" data-v="' + v + '">' + l + '</button>').join('') + '</div>' +
      '<div class="ah-sub">설명 순서</div><div class="chips" data-k="order">' + PS_ORDER.map(([v, l]) => '<button class="chip' + (p.order === v ? ' on' : '') + '" data-v="' + v + '">' + l + '</button>').join('') + '</div>' +
      '<div class="ah-sub">정도</div>' + PS_SLIDE.map(([k, t, l, r]) => { const v = p[k] == null ? 5 : +p[k];
        return '<div class="dn-sl"><div class="dn-t"><b>' + esc(t) + '</b><span id="psv-' + k + '">' + esc(psWord(k, v)) + '</span></div>' +
          '<input type="range" min="0" max="10" step="1" value="' + v + '" data-sl="' + k + '" class="' + (v !== 5 ? 'set' : '') + '">' +
          '<div class="dn-ends"><span>' + esc(l) + '</span><span>' + esc(r) + '</span></div></div>'; }).join('') +
      '<div class="ah-sub">말버릇 (선택)</div><input class="input" id="psCatch" maxlength="40" placeholder="예: 자, 정리해 볼까요 / 천천히 가요" value="' + esc(p.catch || '') + '">' +
      '<div class="ah-sub">AI가 알아 두면 좋은 나의 이야기 (선택)</div><textarea class="input" id="psBio" rows="3" maxlength="200" placeholder="예: 2년 전 급등주에 크게 데였어요. 요즘은 배당주 위주. 숫자 설명은 좋아하지만 영어 약자는 어려워요.">' + esc(p.bio || '') + '</textarea>' +
      '<div class="ps-prev"><b>💬 이렇게 말할 거예요</b><p id="psPrev">' + esc(psPreview(p)) + '</p><small>미리보기는 예문이에요 · 실제 답은 사실·근거에 따라 달라요</small></div>' +
      '<p class="note" style="margin-top:10px">🔒 캐릭터는 이 기기에만 저장돼요 · 고유 번호 <code>' + esc(String(p.seed).slice(0, 6)) + '</code> 덕분에 같은 걸 골라도 다른 사람과 말버릇이 달라요 · 캐릭터가 달라도 <b>사실·숫자·결론은 같아요</b>.</p>');
    const upd = () => { m.body.querySelector('#psPrev').textContent = psPreview(p); };
    m.body.querySelector('#psName').oninput = e => { p.name = e.target.value.trim(); upd(); };
    m.body.querySelector('#psNameR').onclick = () => { p.name = PS_NAMES[Math.floor(Math.random() * PS_NAMES.length)]; m.body.querySelector('#psName').value = p.name; upd(); };
    m.body.querySelector('#psCatch').oninput = e => { p.catch = e.target.value.trim(); upd(); };
    m.body.querySelector('#psBio').oninput = e => { p.bio = e.target.value.trim(); };
    m.body.querySelector('#psAvs').onclick = e => { const b = e.target.closest('[data-av]'); if (!b) return; p.avatar = b.dataset.av; m.body.querySelector('#psAv').textContent = p.avatar; m.body.querySelectorAll('#psAvs .chip').forEach(x => x.classList.toggle('on', x === b)); };
    m.body.querySelectorAll('[data-k]').forEach(box => box.onclick = e => { const b = e.target.closest('[data-v]'); if (!b) return; p[box.dataset.k] = b.dataset.v; box.querySelectorAll('.chip').forEach(x => x.classList.toggle('on', x === b)); upd(); });
    m.body.querySelectorAll('[data-sl]').forEach(sl => sl.oninput = () => { const k = sl.dataset.sl; p[k] = +sl.value; sl.classList.toggle('set', +sl.value !== 5); m.body.querySelector('#psv-' + k).textContent = psWord(k, sl.value); upd(); });
    m.body.addEventListener('click', e => { const b = e.target.closest('[data-p]'); if (!b) return; Object.assign(p, PS_PRESETS[+b.dataset.p][1]); if (!p.name) p.name = PS_NAMES[Math.floor(Math.random() * PS_NAMES.length)]; draw(); });
    hydrateIcons(m.body);
  };
  draw();
  m.foot.querySelector('[data-rand]').onclick = () => {
    const R = a => a[Math.floor(Math.random() * a.length)][0], S = () => Math.floor(Math.random() * 11);
    Object.assign(p, { name: PS_NAMES[Math.floor(Math.random() * PS_NAMES.length)], avatar: PS_AVATAR[Math.floor(Math.random() * PS_AVATAR.length)], tone: R(PS_TONE), meta: R(PS_META), order: R(PS_ORDER), humor: S(), opt: 3 + Math.floor(Math.random() * 5), blunt: S(), emoji: S(), str: 6 + Math.floor(Math.random() * 4), var: 3 + Math.floor(Math.random() * 6) });
    draw(); toast('🎲 새 캐릭터! 마음에 안 들면 또 눌러 보세요');
  };
  m.foot.querySelector('[data-ok]').onclick = () => {
    UI.persona = p; saveUI(); m.close();
    toast((p.name ? (p.avatar || '🎭') + ' ' + p.name + ' 캐릭터로' : '캐릭터를') + ' 저장했어요 — 이제 모든 AI 답이 이 말투로 나와요', 3200);
    if (['ai', 'settings'].includes(route.page)) rerender();
    try { refreshChatSet(); } catch (e) {}
  };
}
