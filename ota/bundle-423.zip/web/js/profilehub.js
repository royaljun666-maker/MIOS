/* ==========================================================================
   profilehub.js — 🧑 나의 투자 프로필 (v4.17) — 설문·DNA·캐릭터를 한 곳에서 보고 바꾸기
   "사용자를 완벽히 알아야 가장 안전한 대안을 줄 수 있다" — 빠진 항목을 한눈에, 각 줄을 누르면 그 질문으로 바로.
   ========================================================================== */
'use strict';

let _hubTab = 'survey';
function profileAnswerText(q, p) {
  const v = p[q.k];
  if (v == null || v === '') return '';
  if (q.type === 'num') return PROFILE_MAN(v);
  const o = (q.o || []).find(y => y[0] === String(v));
  return o ? o[1] : '';
}
function profileDone() {                                    // 답한 개수 / 지금 상황에 맞는 질문 개수
  const p = profile(), qs = profileQs(p);
  return { n: qs.filter(q => profileAnswerText(q, p)).length, total: qs.length };
}
function safetyFlags() {                                    // 앱이 설문에서 읽는 '안전 신호' (서버와 같은 기준)
  const p = profile(), f = [];
  if (p.emerg === '0') f.push('비상금 없음');
  if (p.debt === 'mid' || p.debt === 'high') f.push('이자 높은 빚으로 투자');
  if (p.debt_due === '1') f.push('1년 안 갚을 빚');
  if (p.pension === 'no' || p.income === 'none') f.push('수입·연금 없음');
  if (p.kids_cost === 'soon') f.push('1~2년 안 큰 지출');
  if (p.sleep === 'bad') f.push('손실 중 잠 못 잠');
  if (p.living === 'tight') f.push('생활비 빠듯');
  return f;
}
function openProfileHub(tab) {
  if (tab) _hubTab = tab;
  const m = openModal({ title: '🧑 나의 투자 프로필', size: 'wide', body: '' });
  const draw = () => {
    const p = profile(), d = profileDone(), fl = safetyFlags();
    const tabs = '<div class="seg lg hub-tabs">' + [['survey', '📋 설문'], ['dna', '🧬 DNA'], ['persona', '🎭 캐릭터']].map(([k, l]) => '<button data-ht="' + k + '" class="' + (_hubTab === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>';
    let body = '';
    if (_hubTab === 'survey') {
      const groups = [];
      profileQs(p).forEach(q => { const g = q.g || '👤 기본'; let G = groups.find(x => x.g === g); if (!G) { G = { g, qs: [] }; groups.push(G); } G.qs.push(q); });
      body = '<div class="hub-sum"><div class="hub-ring"><b>' + d.n + '</b><small>/ ' + d.total + '</small></div><div><b>' + (d.n >= d.total ? '모두 답했어요 👍' : (d.total - d.n) + '개가 비어 있어요') + '</b>' +
          '<span>AI가 나를 잘 알수록 <b>더 안전한 대안</b>을 먼저 보여 줘요. 답은 이 기기에만 저장돼요.</span></div></div>' +
        (fl.length ? '<div class="hub-flags">🛡 AI가 안전을 먼저 챙길 이유: ' + fl.map(x => '<i>' + esc(x) + '</i>').join('') + '</div>' : '') +
        (d.n < d.total ? '<button class="btn btn-primary btn-block" data-hub="fill" style="margin:8px 0 12px">' + icon('pencil', 'ic-sm') + '비어 있는 질문부터 채우기</button>' : '<button class="btn btn-soft btn-block" data-hub="all" style="margin:8px 0 12px">처음부터 다시 답하기</button>') +
        groups.map(G => '<div class="ah-sub">' + esc(G.g) + '</div>' + G.qs.map(q => { const a = profileAnswerText(q, p); return '<button class="hub-row' + (a ? '' : ' empty') + '" data-q="' + q.k + '"><span>' + esc(q.q) + '</span><b>' + (a ? esc(a) : '아직 안 답함') + '</b></button>'; }).join('')).join('') +
        '<div class="ah-sub">⚙️ 기본</div>' +
        '<button class="hub-row" data-hub="style"><span>매매 스타일</span><b>' + TRADE_STYLES[tradeStyle()].emoji + ' ' + esc(TRADE_STYLES[tradeStyle()].label) + '</b></button>' +
        '<button class="hub-row" data-hub="depth"><span>설명 방식</span><b>' + AI_DEPTHS[aiDepth()].emoji + ' ' + esc(AI_DEPTHS[aiDepth()].label) + '</b></button>' +
        '<button class="hub-row" data-hub="sec"><span>관심 섹터</span><b>' + esc(sectorText(3) || '안 정함') + '</b></button>';
    } else if (_hubTab === 'dna') {
      const dn = dnaNow();
      body = '<p class="note" style="margin:0 0 10px">성격·투자금 규모·버틸 수 있는 손실·무엇을 중시하는지 — <b>슬라이더로 직접</b> 정해요. 5(보통)에서 움직인 것만 AI에 반영돼요.</p>' +
        '<button class="btn btn-primary btn-block" data-hub="dna" style="margin-bottom:12px">' + icon('sliders', 'ic-sm') + '투자 DNA 열기 (' + esc(dnaSummary()) + ')</button>' +
        '<div class="ah-sub">고른 것</div>' + DNA_PICK.map(([k, t, ops]) => { const o = ops.find(x => x[0] === dn[k]); return '<button class="hub-row' + (o ? '' : ' empty') + '" data-hub="dna"><span>' + esc(t) + '</span><b>' + (o ? esc(o[1]) : '안 정함') + '</b></button>'; }).join('') +
        '<div class="ah-sub">슬라이더 (보통이 아닌 것)</div>' + (DNA_SLIDE.filter(([k]) => dn[k] != null && +dn[k] !== 5).map(([k, t, l, r]) => '<button class="hub-row" data-hub="dna"><span>' + esc(t) + '</span><b>' + esc(dnaWord(+dn[k], l, r)) + '</b></button>').join('') || '<p class="note" style="margin:0">모두 보통이에요. 열어서 조절해 보세요.</p>');
    } else {
      const ps = personaNow();
      const row = (t, v) => '<button class="hub-row' + (v ? '' : ' empty') + '" data-hub="persona"><span>' + t + '</span><b>' + (v ? esc(v) : '안 정함') + '</b></button>';
      body = '<p class="note" style="margin:0 0 10px">설문·DNA가 <b>‘나는 어떤 투자자냐’</b>라면, 캐릭터는 <b>‘AI가 어떻게 말하느냐’</b>예요. 사실·결론은 같고 말투만 달라져요.</p>' +
        '<button class="btn btn-primary btn-block" data-hub="persona" style="margin-bottom:12px">🎭 캐릭터 열기</button>' +
        row('이름', ps.name ? (ps.avatar || '🎭') + ' ' + ps.name : '') + row('말투', (PS_TONE.find(x => x[0] === ps.tone) || [])[1]) + row('비유 세계', (PS_META.find(x => x[0] === ps.meta) || [])[1]) +
        row('설명 순서', (PS_ORDER.find(x => x[0] === ps.order) || [])[1]) + PS_SLIDE.map(([k, t]) => row(t, ps[k] != null ? psWord(k, ps[k]) : '')).join('') +
        row('말버릇', ps.catch) + row('나의 이야기', ps.bio ? ps.bio.slice(0, 40) + (ps.bio.length > 40 ? '…' : '') : '');
    }
    m.setBody(tabs + '<div class="hub-body">' + body + '</div>');
    hydrateIcons(m.body);
  };
  draw();
  m.body.addEventListener('click', e => {
    const t = e.target.closest('[data-ht]'); if (t) { _hubTab = t.dataset.ht; draw(); return; }
    const q = e.target.closest('[data-q]'); if (q) { m.close(); openAiSetup(true, q.dataset.q); return; }
    const b = e.target.closest('[data-hub]'); if (!b) return;
    const a = b.dataset.hub; m.close();
    if (a === 'fill') { const p = profile(), first = profileQs(p).find(x => !profileAnswerText(x, p)); openAiSetup(true, first ? first.k : null); }
    else if (a === 'all') openAiSetup(true);
    else if (a === 'style') openAiSetup(true, '_st');
    else if (a === 'depth') openAiSetup(true, '_tn');
    else if (a === 'sec') openAiSetup(true, '_sec');
    else if (a === 'dna') openDna();
    else if (a === 'persona') openPersona();
  });
}
