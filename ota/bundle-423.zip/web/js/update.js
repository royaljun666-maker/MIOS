/* ==========================================================================
   update.js — 자동 업데이트 알림 · 사용 잠금(킬 스위치)
   앱을 켤 때 클라우드의 '관리 파일'(update.json)을 서버가 확인해서:
     · 새 버전 있으면  → "업데이트 있어요 · 받기" 안내
     · 사용 허용을 끄거나 파일을 지우면 → 사용 중지 화면으로 막음
   ========================================================================== */
'use strict';

let _upd = null;
function openApk(url) {
  if (!IS_APP && _upd && _upd.pc) url = _upd.pc;
  if (!url) { toast('내려받을 주소가 없어요. 관리 파일의 apk 주소를 확인해 주세요.', 3500); return; }
  try { if (IS_APP) location.href = url; else window.open(url, '_blank', 'noopener'); } catch (e) { location.href = url; }
}

/* 사용 중지 전체 화면 */
function appBlock(o) {
  let el = document.getElementById('appBlock');
  if (!el) { el = document.createElement('div'); el.id = 'appBlock'; el.className = 'appblock'; document.body.appendChild(el); }
  el.innerHTML =
    '<div class="ab-box"><div class="ab-ico">' + icon(o.icon || 'lock') + '</div>' +
    '<h2>' + esc(o.title) + '</h2><p>' + esc(o.msg).replace(/\n/g, '<br>') + '</p>' +
    '<div class="ab-acts">' +
      (o.apk ? '<button class="btn btn-primary btn-lg" id="abGet">' + icon('download') + '새 버전 받기</button>' : '') +
      '<button class="btn btn-gray" id="abRetry">' + icon('refresh', 'ic-sm') + '다시 확인</button>' +
    '</div></div>';
  hydrateIcons(el);
  document.documentElement.style.overflow = 'hidden';
  const g = el.querySelector('#abGet'); if (g) g.onclick = () => openApk(o.apk);
  el.querySelector('#abRetry').onclick = () => { el.querySelector('#abRetry').classList.add('loading'); checkUpdate(true); };
}
function clearBlock() { const el = document.getElementById('appBlock'); if (el) el.remove(); document.documentElement.style.overflow = ''; }

/* 위쪽 업데이트 안내 띠 */
function updateBanner(o) {
  if (document.getElementById('updBanner')) return;
  const b = document.createElement('div'); b.id = 'updBanner'; b.className = 'upd-banner';
  b.innerHTML = '<span class="ic" data-icon="download"></span><div class="ub-txt"><b>새 버전이 나왔어요' + (o.latest_name ? ' (v' + esc(o.latest_name) + ')' : '') + '</b>' +
    (o.notice ? '<span>' + esc(o.notice) + '</span>' : '<span>받기를 눌러 업데이트하세요. 지금 정보는 그대로 유지돼요.</span>') + '</div>' +
    '<button class="btn btn-primary btn-sm" id="ubGet">받기</button><button class="ub-x" id="ubX" aria-label="닫기">✕</button>';
  document.body.appendChild(b); hydrateIcons(b);
  document.body.classList.add('has-banner');
  b.querySelector('#ubGet').onclick = () => openApk(o.apk);
  b.querySelector('#ubX').onclick = () => { b.remove(); document.body.classList.remove('has-banner'); };
}

async function checkUpdate(manual) {
  let d;
  try { d = await api('/api/update', { timeout: 12000 }); }
  catch (e) {
    // 확인 실패 시 잠금 화면은 그대로 둠(눌러서 풀리면 안 됨) — 버튼만 원래대로
    if (manual) { const r = document.getElementById('abRetry'); if (r) r.classList.remove('loading'); toast('확인하지 못했어요. 잠시 후 다시 시도해 주세요'); }
    return;
  }
  _upd = d;
  if (!d || !d.configured) return;                 // 관리 파일 주소가 아직 설정 안 됨 → 평소대로
  const grace = d.grace_days || 7;

  // ① 사용 중지(관리 파일에서 껐거나 파일을 지움)
  if (d.status === 'deleted') {
    appBlock({ title: '앱 사용이 중지되었어요', icon: 'lock',
      msg: '지금은 이 앱을 쓸 수 없어요.\n만든 사람에게 문의해 주세요.' });
    return;
  }
  if (d.status === 'ok' && d.enabled === false) {
    appBlock({ title: '앱 사용이 잠시 중지되었어요', icon: 'lock',
      msg: d.notice || '점검 중이에요. 잠시 뒤 다시 켜 주세요.', apk: d.apk && d.latest > d.current ? d.apk : '' });
    return;
  }
  // ② 인터넷으로 오래 확인 못 함 → 유예 지나면 막기 (비행기모드 등 짧은 끊김은 통과)
  if (d.status === 'offline') {
    const days = d.days_since_ok;
    if (days != null && days > grace) {
      appBlock({ title: '인터넷 연결이 필요해요', icon: 'wifi',
        msg: '업데이트 확인을 ' + Math.floor(days) + '일 동안 못 했어요.\n인터넷에 연결한 뒤 다시 확인을 눌러 주세요.' });
    } else { clearBlock(); }
    return;
  }
  // ③ 정상 — 새 버전?
  clearBlock();
  if (d.support && typeof setSupportId === 'function') setSupportId(d.support.toss || '');   // 후원 토스 아이디(원격)
  if (typeof setRemote === 'function') setRemote(d);
  if (d.status === 'ok') setFeatures(d.features || []);                                          // 광고·제휴 자리, 추천 링크, 카카오페이(원격)
  otaNotice(d);
  apkNotice(d);
  if (d.status === 'ok' && d.latest > d.current) {
    if (d.require) {
      appBlock({ title: '업데이트가 필요해요', icon: 'download',
        msg: (d.notice || '새 버전으로 바꿔야 계속 쓸 수 있어요.') + '\n\n받기를 눌러 설치하면 지금 정보는 그대로 유지돼요.', apk: d.apk });
    } else { updateBanner(d); }
  } else if (manual) {
    toast('최신 버전을 쓰고 있어요');
  }
}

/* 자동 업데이트(폰): 새 기능을 받아 뒀거나 방금 적용됐을 때 알려 주기 */
function otaNotice(d) {
  const o = d && d.ota; if (!o) return;
  let seen = {}; try { seen = JSON.parse(localStorage.getItem('ota_seen') || '{}'); } catch (e) {}
  const name = c => 'v' + Math.floor(c / 100) + '.' + (c % 100);
  if (o.applied && seen.applied !== o.applied) {
    seen.applied = o.applied;
    setTimeout(() => toast('✨ ' + name(o.applied) + '(으)로 자동 업데이트됐어요', 4000), 1200);
  } else if (o.ready && o.ready > (o.applied || d.current)) {
    applyOta(o.ready);                              // 받아 둔 게 있으면 바로 적용
  }
  try { localStorage.setItem('ota_seen', JSON.stringify(seen)); } catch (e) {}
}

/* 자동 업데이트 즉시 적용 (v1.8~)
   앱을 켜고 몇 초 뒤 새 묶음을 받았는지 확인 → 받았으면 '업데이트 중' 화면 → 서버가 새 코드로 갈아 끼움 → 새로고침.
   다시 켤 필요 없음. 실패하면 지금 버전 그대로 쓰고 다음 실행 때 적용. */
let _otaBusy = false;
function otaWatch() {                              // 폰 앱·설치된 PC판 (서버가 ota 상태를 알려 줄 때만 동작)
  [7000, 15000, 30000, 60000].forEach(t => setTimeout(otaPoll, t));
}
async function otaPoll() {
  if (_otaBusy) return;
  let d; try { d = await api('/api/update', { timeout: 12000 }); } catch (e) { return; }
  const o = d && d.ota;
  if (o && o.ready && o.ready > (o.applied || d.current)) applyOta(o.ready);
}
async function applyOta(code) {
  if (_otaBusy) return;
  // 입력 중이거나 창이 열려 있으면 잠시 뒤에
  const typing = document.activeElement && /INPUT|TEXTAREA/.test(document.activeElement.tagName);
  if (typing || _modals.length || document.querySelector('.intro')) { setTimeout(() => applyOta(code), 5000); return; }
  _otaBusy = true;
  const vn = 'v' + Math.floor(code / 100) + '.' + (code % 100);
  const ov = document.createElement('div'); ov.className = 'ota-ov';
  ov.innerHTML = '<div class="ota-box"><div class="ota-ico">' + icon('sparkles') + '<i></i></div><b>새 버전 ' + vn + '(으)로 업데이트 중…</b>' +
    '<span>잠깐이면 돼요. 내 정보는 그대로예요.</span><div class="ota-bar"><i></i></div></div>';
  document.body.appendChild(ov); hydrateIcons(ov);
  let r = null;
  try { r = await api('/api/ota/apply', { method: 'POST', body: {}, timeout: 30000 }); } catch (e) {}
  if (r && r.ok) {
    ov.querySelector('b').textContent = vn + ' 준비 완료!';
    setTimeout(() => location.reload(), 900);
  } else {
    ov.remove(); _otaBusy = false;
    toast('새 기능을 받아 뒀어요. 다음에 앱을 켤 때 적용돼요', 4000);
  }
}

/* 화면은 자동 업데이트로 최신인데, 설치된 앱(APK) 자체가 오래돼 새로 깔아야 하는 기능이 있을 때 — 하루 한 번 팝업 */
function apkNotice(d) {
  if (!IS_APP || !d || !d.apk_code || !d.apk || !(d.latest > d.apk_code)) return;
  const k = 'apk_ask_' + d.latest;
  try { if (localStorage.getItem(k) === todayKey()) return; localStorage.setItem(k, todayKey()); } catch (e) {}
  const show = () => {
    if (document.querySelector('.intro') || _modals.length) { setTimeout(show, 800); return; }
    const m = openModal({ title: '📲 새 앱 설치가 필요해요', body:
      '<p style="margin:0 0 10px;line-height:1.65">' + esc(d.notice || '새 버전이 나왔어요.') + '</p>' +
      '<div class="callout info">' + icon('info', 'ic-sm') + '<div>화면·AI 개선은 자동으로 받았지만, <b>뒤로가기 같은 앱 기본 동작</b>은 새 앱(v' + esc(d.latest_name) + ')을 설치해야 바뀌어요. 지우지 말고 그대로 설치하면 내 정보는 남아요.</div></div>',
      foot: '<button class="btn btn-gray" data-no>나중에</button><button class="btn btn-primary" data-yes>' + icon('download') + '지금 받기</button>' });
    m.foot.querySelector('[data-no]').onclick = () => m.close();
    m.foot.querySelector('[data-yes]').onclick = () => { m.close(); openApk(d.apk); };
  };
  show();
}

/* 시작 애니메이션이 나오는 동안 업데이트 (v2.10~)
   새 묶음이 있으면 애니메이션을 잠깐 붙잡고 '새 버전 받는 중…' → 받으면 바로 적용·새로고침 → 새 버전으로 시작.
   20초 안에 못 받으면 그냥 시작하고, 받는 대로 평소처럼 적용 */
async function introUpdate() {
  const intro = document.querySelector('.intro');
  if (!intro) return;
  const txt = intro.querySelector('.ib-load-t');
  const release = () => { window._introHold = 0; const i = document.querySelector('.intro'); if (i && i._late && window._introFinish) window._introFinish(); };
  let d; try { d = await api('/api/update', { timeout: 9000 }); } catch (e) { return; }
  const latest = d && d.ota_latest || 0, cur = d && d.current || 0;
  if (!(d && d.status === 'ok' && d.ota && latest > cur) || (d.apk_code && d.ota_min_app > d.apk_code)) return;   // d.ota 없음 = 자동 업데이트 안 되는 곳
  if (!document.querySelector('.intro')) return;          // 이미 넘겼으면 평소 방식으로
  window._introHold = 1; _otaBusy = true;
  const vn = 'v' + Math.floor(latest / 100) + '.' + (latest % 100);
  if (txt) txt.textContent = '✨ 새 버전 ' + vn + ' 받는 중…';
  intro.classList.add('ib-upd');
  const t0 = Date.now(); let ready = d.ota && d.ota.ready;
  while (!(ready >= latest) && Date.now() - t0 < 20000) {
    await new Promise(r => setTimeout(r, 1000));
    try { const s = await api('/api/ota/state', { timeout: 4000 }); ready = s.ota && s.ota.ready; if (s.ota && s.ota.error) break; } catch (e) { break; }
  }
  if (ready >= latest) {
    if (txt) txt.textContent = '✨ ' + vn + ' 적용하는 중…';
    let r = null; try { r = await api('/api/ota/apply', { method: 'POST', body: {}, timeout: 30000 }); } catch (e) {}
    if (r && r.ok) {
      try { localStorage.setItem('ota_seen', JSON.stringify({ applied: latest })); sessionStorage.setItem('otaJust', vn); } catch (e) {}
      location.reload(); return;
    }
  }
  _otaBusy = false;
  if (txt) txt.textContent = '시작하는 중…';
  release();
}
// 시작 화면에서 업데이트하고 새로고침된 직후 한 번 알림
try { const j = sessionStorage.getItem('otaJust'); if (j) { window._otaJustLoaded = 1; sessionStorage.removeItem('otaJust'); if (!['4.12'].includes(String(j).replace(/^v/, ''))) setTimeout(() => toast('✨ ' + j + '(으)로 업데이트됐어요', 3500), 1200); } } catch (e) {}
