/* ==========================================================================
   calc.js — 🧮 계산기 (v4.20)
   ① 수익률: 내 가격·지금 가격·수량 → 수익률·수익금 (달러면 원화 환산까지)
   ② 불타기·물타기: 지금 평균·수량 + 추가로 살 가격·수량 → 새 평균·지금 시세 기준 손익·본전 가격
   ③ 추세추종 프랍 리스크: 계좌·1회 위험 %·진입·손실 제한선 → 살 수 있는 수량·포지션 금액·R
   계산만 해요 — 사라·팔라는 말은 없어요. 숫자는 내가 넣은 값으로만 계산.
   ========================================================================== */
'use strict';

const CALC_KEY = 'calc_last_v1';
let _calcTab = 'ret';
function calcLoad() { try { return JSON.parse(localStorage.getItem(CALC_KEY) || '{}') || {}; } catch (e) { return {}; } }
function calcSave(v) { try { localStorage.setItem(CALC_KEY, JSON.stringify(v)); } catch (e) {} }
const cN = v => { const n = parseFloat(String(v == null ? '' : v).replace(/[^0-9.\-]/g, '')); return isFinite(n) ? n : 0; };
function cMoney(v, ccy) {                                  // 통화 표시 (달러는 소수 2자리)
  if (!isFinite(v)) return '-';
  return ccy === 'USD' ? '$' + (Math.abs(v) >= 1000 ? nf(Math.round(v), 0) : v.toFixed(2)) : nf(Math.round(v), 0) + '원';
}
const cSign = v => (v > 0 ? '+' : '');
function cPct(v) { return isFinite(v) ? cSign(v) + v.toFixed(2) + '%' : '-'; }
function cKrw(v, ccy) { return ccy === 'USD' ? '<small class="cv-krw">≈ ' + (v >= 0 ? '+' : '-') + nf(Math.round(Math.abs(v) * fx()), 0) + '원 ($1=' + nf(fx(), 0) + '원)</small>' : ''; }

function openCalc(preset) {
  const L = Object.assign({ ccy: 'KRW' }, calcLoad(), preset || {});
  if (preset && preset.tab) _calcTab = preset.tab;
  const m = openModal({ title: '🧮 계산기', size: 'wide', body: '' });
  const inp = (id, label, val, ph, step) => '<label class="cl-f"><span>' + label + '</span><input class="input tnum" id="' + id + '" inputmode="decimal" step="' + (step || 'any') + '" value="' + (val != null && val !== '' ? esc(String(val)) : '') + '" placeholder="' + (ph || '') + '"></label>';
  const draw = () => {
    const ccy = L.ccy === 'USD' ? 'USD' : 'KRW', u = ccy === 'USD' ? '$' : '원';
    const tabs = '<div class="seg lg cl-tabs">' + [['ret', '📈 수익률'], ['avg', '🧪 물·불타기'], ['risk', '🏁 프랍']].map(([k, l]) => '<button data-ct="' + k + '" class="' + (_calcTab === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>' +
      '<div class="cl-top"><div class="seg"><button data-ccy="KRW" class="' + (ccy === 'KRW' ? 'on' : '') + '">원화</button><button data-ccy="USD" class="' + (ccy === 'USD' ? 'on' : '') + '">달러</button></div>' +
        (L.name ? '<span class="cl-name">' + esc(L.name) + '</span>' : '') + '</div>';
    let body = '';
    if (_calcTab === 'ret') body =
      '<div class="cl-grid">' + inp('cBuy', '내 가격 (' + u + ')', L.buy, ccy === 'USD' ? '예: 50' : '예: 71000') + inp('cNow', '지금 가격 (' + u + ')', L.now, ccy === 'USD' ? '예: 53.22' : '예: 74500') + inp('cQty', '수량 (주)', L.qty, '예: 100') + '</div>' +
      '<div class="cl-out" id="cOut"></div>' +
      '<div class="cl-what"><b>이 값이면?</b><div class="chips" id="cWhat">' + [-20, -10, -5, 5, 10, 20, 50, 100].map(p => '<button class="chip" data-w="' + p + '">' + cSign(p) + p + '%</button>').join('') + '</div><div id="cWhatOut" class="note" style="margin:6px 0 0"></div></div>';
    else if (_calcTab === 'avg') body =
      '<div class="ah-sub">지금 들고 있는 것</div><div class="cl-grid">' + inp('aAvg', '평균 가격 (' + u + ')', L.aAvg, ccy === 'USD' ? '예: 50' : '예: 71000') + inp('aQty', '수량 (주)', L.aQty, '예: 100') + '</div>' +
      '<div class="ah-sub">추가로 산다면</div><div class="cl-grid">' + inp('aPx', '살 가격 (' + u + ')', L.aPx, ccy === 'USD' ? '예: 45' : '예: 65000') + inp('aN', '수량 (주)', L.aN, '예: 50') + inp('aNow', '지금 가격 (' + u + ') · 선택', L.aNow, '비우면 살 가격') + '</div>' +
      '<div class="chips" id="aQuick">' + [['같은 수량', 'same'], ['절반', 'half'], ['두 배', 'double'], ['같은 금액', 'money']].map(([l, k]) => '<button class="chip" data-aq="' + k + '">' + l + '</button>').join('') + '</div>' +
      '<div class="cl-out" id="aOut"></div>';
    else body =
      '<p class="note" style="margin:0 0 8px">추세추종 프랍 트레이더가 쓰는 <b>정해진 위험으로 수량 정하기</b>예요. 한 번 틀려도 계좌의 1~2%만 잃게 수량을 거꾸로 계산해요.</p>' +
      '<div class="cl-grid">' + inp('rAcc', '계좌 크기 (' + u + ')', L.rAcc, ccy === 'USD' ? '예: 10000' : '예: 30000000') + inp('rPct', '1회 위험 (%)', L.rPct != null ? L.rPct : 1, '예: 1') + inp('rIn', '진입 가격 (' + u + ')', L.rIn, ccy === 'USD' ? '예: 53.22' : '예: 74500') +
        inp('rStop', '손실 제한선 (' + u + ')', L.rStop, '예: 진입보다 아래') + inp('rAtr', '하루 평균 변동폭 ATR (' + u + ') · 선택', L.rAtr, '있으면 2×ATR 제안') + inp('rTgt', '기대 보상 배수 R · 선택', L.rTgt != null ? L.rTgt : 2, '예: 2') + '</div>' +
      '<div class="chips" id="rQuick">' + [['위험 0.5%', 'p0.5'], ['1%', 'p1'], ['2%', 'p2'], ['제한선 = 2×ATR', 'atr2'], ['제한선 = 진입 −5%', 's5'], ['−8%', 's8']].map(([l, k]) => '<button class="chip" data-rq="' + k + '">' + l + '</button>').join('') + '</div>' +
      '<div class="cl-out" id="rOut"></div>' +
      '<button class="btn btn-primary btn-block" data-act="prop-coach" style="margin-top:12px">🏁 내 실제 계좌를 프랍 규칙으로 점검 (AI)</button>' +
      '<details class="cl-guide"><summary>🏁 추세추종 프랍 트레이더 기준이 뭐예요?</summary><ul>' +
        '<li><b>위험부터 정한다</b> — 종목·방향보다 먼저 "이번에 틀리면 얼마 잃을지"를 계좌의 0.5~2%로 못 박고, 수량은 거기서 거꾸로 나와요.</li>' +
        '<li><b>R로 센다</b> — 1R = 1회 위험 금액. 결과를 +2R, −1R처럼 세요. 승률 40%라도 평균 +2R이면 남아요.</li>' +
        '<li><b>추세 따라가기</b> — 20일·60일 평균선 위에서 신고가 근처, 거래량 늘 때를 추세로 봐요. 평균선 아래·신저가 근처는 추세 꺾임 신호.</li>' +
        '<li><b>손실 제한선은 변동폭으로</b> — 하루 평균 변동폭(ATR)의 2~3배 밖에 둬야 평소 흔들림에 안 걸려요. 제한선이 가까우면 수량이 커져 위험해요.</li>' +
        '<li><b>하루·한 달 한도</b> — 하루 −2R, 한 달 −6R 같은 선을 넘으면 그날·그달은 쉬어요. 프랍 회사의 가장 흔한 규칙이에요.</li>' +
        '<li><b>기록</b> — 모든 거래를 R로 기록하고 월말에 기대값(승률×평균이익 − 패률×평균손실)을 봐요.</li>' +
        '</ul><p class="note" style="margin:6px 0 0">계산과 일반적인 기준 설명이에요. 특정 종목을 사라·팔라는 뜻이 아니에요 · 판단은 본인.</p></details>';
    m.setBody(tabs + body + '<p class="note" style="margin-top:12px">내가 넣은 숫자로만 계산해요 · 수수료·세금은 빼고 계산 · 참고용</p>');
    wire(); calc();
  };
  const out = (id, html) => { const e = m.body.querySelector(id); if (e) e.innerHTML = html; };
  const calc = () => {
    const ccy = L.ccy === 'USD' ? 'USD' : 'KRW';
    if (_calcTab === 'ret') {
      const b = cN(L.buy), n = cN(L.now), q = cN(L.qty) || 0;
      if (!(b > 0 && n > 0)) { out('#cOut', '<div class="cv-empty">내 가격과 지금 가격을 넣어 주세요</div>'); out('#cWhatOut', ''); return; }
      const r = (n / b - 1) * 100, pl = (n - b) * q, val = n * q, cost = b * q;
      out('#cOut', '<div class="cv-hero ' + cls(r) + '"><b>' + cPct(r) + '</b><span>' + (q ? cSign(pl) + cMoney(pl, ccy) : '수량을 넣으면 수익금도') + '</span>' + (q ? cKrw(pl, ccy) : '') + '</div>' +
        (q ? '<div class="cv-rows"><div><span>산 금액</span><b>' + cMoney(cost, ccy) + '</b></div><div><span>지금 평가</span><b>' + cMoney(val, ccy) + '</b></div><div><span>1주당</span><b class="' + cls(n - b) + '">' + cSign(n - b) + cMoney(n - b, ccy) + '</b></div>' +
          '<div><span>본전까지</span><b>' + (r < 0 ? '+' + (b / n * 100 - 100).toFixed(2) + '% 올라야' : '이미 본전 위') + '</b></div></div>' : ''));
      const w = L.what; if (w != null) { const px = b * (1 + w / 100); out('#cWhatOut', cSign(w) + w + '%면 가격 <b>' + cMoney(px, ccy) + '</b>' + (q ? ' · 수익금 <b class="' + cls(w) + '">' + cSign(px * q - cost) + cMoney(px * q - cost, ccy) + '</b>' : '') + ' · 지금 가격에서 ' + cPct((px / n - 1) * 100) + ' 거리'); }
    } else if (_calcTab === 'avg') {
      const a = cN(L.aAvg), q = cN(L.aQty), px = cN(L.aPx), n = cN(L.aN), now = cN(L.aNow) || px;
      if (!(a > 0 && q > 0 && px > 0 && n > 0)) { out('#aOut', '<div class="cv-empty">평균·수량과 살 가격·수량을 넣어 주세요</div>'); return; }
      const newAvg = (a * q + px * n) / (q + n), kind = px > a ? '🔥 불타기 (평균 올라감)' : px < a ? '💧 물타기 (평균 내려감)' : '같은 가격';
      const plNow0 = (now - a) * q, plNow1 = (now - newAvg) * (q + n), add = px * n;
      out('#aOut', '<div class="cv-hero flat"><span class="cv-kind">' + kind + '</span><b>' + cMoney(a, ccy) + ' → ' + cMoney(newAvg, ccy) + '</b><span>새 평균 · ' + cPct((newAvg / a - 1) * 100) + ' · 총 ' + nf(q + n, 0) + '주 · 추가 ' + cMoney(add, ccy) + ' 필요</span></div>' +
        '<div class="cv-rows"><div><span>지금 가격 ' + cMoney(now, ccy) + ' 기준 손익</span><b class="' + cls(plNow1) + '">' + cSign(plNow1) + cMoney(plNow1, ccy) + ' (' + cPct((now / newAvg - 1) * 100) + ')</b></div>' +
          '<div><span>추가 안 샀을 때</span><b class="' + cls(plNow0) + '">' + cSign(plNow0) + cMoney(plNow0, ccy) + ' (' + cPct((now / a - 1) * 100) + ')</b></div>' +
          '<div><span>본전 가격</span><b>' + cMoney(newAvg, ccy) + (now < newAvg ? ' (+' + (newAvg / now * 100 - 100).toFixed(2) + '% 올라야)' : '') + '</b></div>' +
          '<div><span>총 투입</span><b>' + cMoney(a * q + add, ccy) + '</b></div></div>' +
        (px < a ? '<div class="cv-warn">💧 물타기는 평균을 낮추는 대신 <b>한 종목 비중과 손실 금액이 커져요</b>. 같은 −10%가 나면 손실이 ' + cMoney((a * q + add) * 0.1, ccy) + '로 늘어요.</div>' : px > a ? '<div class="cv-warn">🔥 불타기는 추세가 이어질 때 유리하지만 <b>평균이 올라 되돌림에 약해져요</b>. 새 평균 아래로 ' + ((1 - (newAvg - (newAvg - a)) / newAvg) * 100).toFixed(1) + '%만 내려와도 추가분은 손실이에요.</div>' : ''));
    } else {
      const acc = cN(L.rAcc), pct = cN(L.rPct), inn = cN(L.rIn), atr = cN(L.rAtr), tgt = cN(L.rTgt) || 2; let stop = cN(L.rStop);
      if (!(acc > 0 && pct > 0 && inn > 0)) { out('#rOut', '<div class="cv-empty">계좌 크기·위험 %·진입 가격을 넣어 주세요</div>'); return; }
      if (!(stop > 0) && atr > 0) stop = inn - 2 * atr;
      if (!(stop > 0) || stop >= inn) { out('#rOut', '<div class="cv-empty">손실 제한선(진입보다 낮은 가격)을 넣거나 ATR을 넣어 주세요</div>'); return; }
      const riskAmt = acc * pct / 100, perShare = inn - stop, qty = Math.floor(riskAmt / perShare), pos = qty * inn, posPct = pos / acc * 100, stopPct = (stop / inn - 1) * 100;
      const tgtPx = inn + perShare * tgt;
      const warn = [];
      if (posPct > 30) warn.push('포지션이 계좌의 ' + posPct.toFixed(0) + '% — 한 종목 비중이 커요. 제한선이 너무 가깝거나 위험 %가 큰 거예요.');
      if (atr > 0 && perShare < 1.5 * atr) warn.push('제한선이 하루 변동폭(ATR ' + cMoney(atr, ccy) + ')의 ' + (perShare / atr).toFixed(1) + '배 — 평소 흔들림에도 닿을 수 있어요. 보통 2~3배를 둬요.');
      if (pct > 2) warn.push('1회 위험 ' + pct + '%는 프랍 기준(0.5~2%)보다 커요. 10번 연속 틀리면 ' + (100 - Math.pow(1 - pct / 100, 10) * 100).toFixed(0) + '%가 사라져요.');
      out('#rOut', '<div class="cv-hero flat"><span class="cv-kind">1R = ' + cMoney(riskAmt, ccy) + ' (계좌의 ' + pct + '%)</span><b>' + nf(qty, 0) + '주</b><span>포지션 ' + cMoney(pos, ccy) + ' · 계좌의 ' + posPct.toFixed(1) + '%</span>' + cKrw(pos, ccy) + '</div>' +
        '<div class="cv-rows"><div><span>진입 → 제한선</span><b>' + cMoney(inn, ccy) + ' → ' + cMoney(stop, ccy) + ' (' + cPct(stopPct) + ')</b></div><div><span>1주당 위험</span><b>' + cMoney(perShare, ccy) + '</b></div>' +
          '<div><span>' + tgt + 'R 가격 (기대 보상)</span><b>' + cMoney(tgtPx, ccy) + ' (' + cPct((tgtPx / inn - 1) * 100) + ')</b></div><div><span>하루 −2R · 한 달 −6R 한도</span><b>' + cMoney(riskAmt * 2, ccy) + ' · ' + cMoney(riskAmt * 6, ccy) + '</b></div>' +
          '<div><span>승률 40%·평균 +' + tgt + 'R 기대값</span><b class="' + cls(0.4 * tgt - 0.6) + '">' + cSign(0.4 * tgt - 0.6) + (0.4 * tgt - 0.6).toFixed(2) + 'R / 거래</b></div></div>' +
        warn.map(w => '<div class="cv-warn">⚠️ ' + w + '</div>').join(''));
    }
  };
  const wire = () => {
    m.body.querySelectorAll('input').forEach(i => i.oninput = () => { const map = { cBuy: 'buy', cNow: 'now', cQty: 'qty', aAvg: 'aAvg', aQty: 'aQty', aPx: 'aPx', aN: 'aN', aNow: 'aNow', rAcc: 'rAcc', rPct: 'rPct', rIn: 'rIn', rStop: 'rStop', rAtr: 'rAtr', rTgt: 'rTgt' }; L[map[i.id]] = i.value; calcSave(L); calc(); });
    const w = m.body.querySelector('#cWhat'); if (w) w.onclick = e => { const b = e.target.closest('[data-w]'); if (!b) return; L.what = +b.dataset.w; w.querySelectorAll('.chip').forEach(x => x.classList.toggle('on', x === b)); calc(); };
    const aq = m.body.querySelector('#aQuick'); if (aq) aq.onclick = e => { const b = e.target.closest('[data-aq]'); if (!b) return; const q = cN(L.aQty), a = cN(L.aAvg), px = cN(L.aPx) || a; const k = b.dataset.aq;
      L.aN = k === 'same' ? q : k === 'half' ? Math.round(q / 2) : k === 'double' ? q * 2 : px > 0 ? Math.floor(a * q / px) : q; m.body.querySelector('#aN').value = L.aN; calcSave(L); calc(); };
    const rq = m.body.querySelector('#rQuick'); if (rq) rq.onclick = e => { const b = e.target.closest('[data-rq]'); if (!b) return; const k = b.dataset.rq, inn = cN(L.rIn), atr = cN(L.rAtr);
      if (k[0] === 'p') { L.rPct = +k.slice(1); m.body.querySelector('#rPct').value = L.rPct; }
      else if (k === 'atr2' && inn > 0 && atr > 0) { L.rStop = +(inn - 2 * atr).toFixed(4); m.body.querySelector('#rStop').value = L.rStop; }
      else if (k[0] === 's' && inn > 0) { L.rStop = +(inn * (1 - (+k.slice(1)) / 100)).toFixed(4); m.body.querySelector('#rStop').value = L.rStop; }
      calcSave(L); calc(); };
  };
  m.body.addEventListener('click', e => {
    const t = e.target.closest('[data-ct]'); if (t) { _calcTab = t.dataset.ct; draw(); return; }
    const c = e.target.closest('[data-ccy]'); if (c) { L.ccy = c.dataset.ccy; calcSave(L); draw(); }
  });
  draw();
}
/* 종목 화면·보유 상세에서 값 미리 채워 열기 */
function openCalcFor(x) {                 // {name, ccy, avg, cur, qty, tab}
  const ccy = x.ccy === 'USD' ? 'USD' : 'KRW';
  openCalc({ name: x.name, ccy, buy: x.avg || '', now: x.cur || '', qty: x.qty || '', aAvg: x.avg || '', aQty: x.qty || '', aPx: x.cur || '', aNow: x.cur || '', rIn: x.cur || '', tab: x.tab || (x.avg ? 'ret' : 'risk') });
}

/* 🏁 프랍 코치 (v4.21) — 내 실제 계좌를 프랍 트레이더의 위험 관리 규칙으로 점검 */
function openPropCoach() {
  if (!(AI_STATUS && AI_STATUS.on)) { needAI(openPropCoach); return; }
  const G = grand(), hs = allHoldings().map(x => { const v = hv(x.h); return { h: x.h, v }; }).filter(x => x.h.ticker && x.v.qty > 0 && x.v.valK > 0);
  if (!hs.length || !(G.asset > 0)) { toast('계좌에 종목과 수량을 먼저 넣어 주세요'); return; }
  const riskPct = +(UI.propRisk || 1);
  const body = { risk_pct: riskPct, account: { asset: G.asset, cash: G.cash, stock: G.stock, day: G.day },
    holdings: hs.map(({ h, v }) => ({ ticker: h.ticker, name: dispName(h), market: mkt(h), weight: +(v.valK / G.asset * 100).toFixed(1), ret: +v.ret.toFixed(1), day: v.chg != null ? +v.chg.toFixed(2) : null, valK: Math.round(v.valK), qty: v.qty })) };
  const m = openAiModal('🏁 프랍 코치 — 내 계좌 규칙 점검', '프랍 트레이딩 데스크의 <b>위험 관리 규칙</b>(1회 위험·전체 노출·비중·하루 한도·추세)과 내 실제 계좌를 비교해요. 규칙과 현재를 보여 줄 뿐, 사라·팔라는 말은 하지 않아요.',
    '종목 ' + hs.length + '개의 추세·변동폭·위험 노출을 계산하는 중…');
  const seg = '<div class="pc-risk"><span>1회 위험(1R) = 계좌의</span><div class="seg">' + [0.5, 1, 2].map(p => '<button data-pr="' + p + '" class="' + (riskPct === p ? 'on' : '') + '">' + p + '%</button>').join('') + '</div></div>';
  api('/api/prop-coach', { method: 'POST', body, timeout: 180000 }).then(d => {
    if (m.closed) return;
    if (!d || d.status !== 'ok') { m.setBody(d && d.status === 'no_key' ? noKeyHtml() : '<p class="note">' + esc((d && d.text) || 'AI 답을 받지 못했어요') + '</p>'); return; }
    const S = d.summary || {}, rows = d.rows || [];
    const kpi = (l, v, c) => '<div><span>' + l + '</span><b' + (c ? ' class="' + c + '"' : '') + '>' + v + '</b></div>';
    const rCls = r => r == null ? '' : r > 1.5 ? 'down' : r > 1 ? 'flat' : 'up';
    const tCls = t => t === '상승 추세' ? 'up' : t === '하락 추세' ? 'down' : 'flat';
    m.setBody(aiStyleBar() + seg +
      '<div class="pc-kpi">' + kpi('1R', nf(S.one_r || 0, 0) + '원') + kpi('총 위험 노출', (S.tot_risk_r != null ? S.tot_risk_r + 'R' : '-'), S.tot_risk_r > 6 ? 'down' : S.tot_risk_r > 4 ? 'flat' : 'up') +
        kpi('현금 비중', (S.cash_pct || 0) + '%') + kpi('상위 3종목', (S.top3 || 0) + '%', S.top3 > 50 ? 'down' : '') + kpi('오늘', S.day_r != null ? (S.day_r >= 0 ? '+' : '') + S.day_r + 'R' : '-', S.day_r != null && S.day_r <= -2 ? 'down' : '') + kpi('추세 ↑/↓', (S.up || 0) + ' / ' + (S.down || 0)) + '</div>' +
      '<div class="pc-tbl"><div class="pc-h"><span>종목</span><span>비중</span><span>추세</span><span>ATR/일</span><span>위험 노출</span></div>' +
        rows.map(r => '<div class="pc-r"><span><b>' + esc(r.name) + '</b></span><span>' + r.weight + '%</span><span class="' + tCls(r.trend) + '">' + esc(r.trend || '-') + '</span><span>' + (r.atr_pct != null ? r.atr_pct + '%' : '-') + '</span><span class="' + rCls(r.risk_r) + '">' + (r.risk_r != null ? r.risk_r + 'R' : '-') + '</span></div>').join('') + '</div>' +
      '<p class="note" style="margin:6px 0 12px">위험 노출 = 모든 종목에 2×ATR 밖 손실 제한선을 둔다고 가정했을 때 잃을 수 있는 금액 ÷ 1R · 앱이 일봉으로 계산</p>' +
      '<div class="ai-out">' + renderAiText(d.text) + '</div>');
    hydrateIcons(m.body);
    m.body.querySelectorAll('[data-pr]').forEach(b => b.onclick = () => { UI.propRisk = +b.dataset.pr; saveUI(); m.close(); openPropCoach(); });
  }).catch(() => { if (!m.closed) m.setBody('<p class="note">' + SERVER_DOWN + '</p>'); });
}
