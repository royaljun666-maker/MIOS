/* ==========================================================================
   quant.js — 📐 퀀트 랩 (Quant Lab)
   · 퀀트 엔진(서버 quant.py)이 실제 일봉 데이터로 계산 → 화면은 숫자를 그대로 보여 주고, AI는 그 결과만 해설
   · 탭: 시장(국면·섹터 강도) / 내 종목(전략 조건 상태) / 조건 검색 / 백테스트(과거 검증)
   · 계산하지 못한 값은 '데이터 없음' — 가짜 숫자 없음
   ========================================================================== */
'use strict';

const QL = { tab: 'market', market: null, signals: null, scan: null, bt: null, strategies: null, secKey: 'kr', busy: {} };
const qd = ts => { if (!ts) return '-'; const d = new Date(ts * 1000); return d.getFullYear() + '.' + (d.getMonth() + 1) + '.' + d.getDate(); };
const qn = (v, d) => v == null || !isFinite(v) ? '데이터 없음' : nf(v, d == null ? 2 : d);
const qp = (v, d) => v == null || !isFinite(v) ? '데이터 없음' : (v > 0 ? '+' : '') + Number(v).toFixed(d == null ? 1 : d) + '%';
const VERDICT_TONE = { '상승 조건 모두 충족': 'up', '상승 조건 충족 (보유 중)': 'up', '상승 조건 유지 중': 'flat', '과열·비중 주의 조건 충족': 'warn', '하락 조건 충족': 'down', '조건 미충족': 'flat', '데이터 부족': 'muted' };

PAGES.quant = function (params, re) {
  const el = pageEl('quant');
  if (params && params.tab) { QL.tab = params.tab; params.tab = null; }
  if (params && params.bt) { QL.btPreset = params.bt; params.bt = null; QL.tab = 'bt'; }
  const tabs = [['market', '시장'], ['mine', '내 종목'], ['scan', '조건 검색'], ['bt', '백테스트']];
  el.innerHTML =
    '<div class="page-head"><div><h1>📐 퀀트 랩</h1><div class="desc">실제 일봉 데이터로 계산한 신호·검증 · AI는 계산 결과만 해설</div></div></div>' +
    '<div class="ql-warn">' + icon('info', 'ic-sm') + '<span>과거 데이터로 계산한 <b>참고 정보</b>예요. 과거 성과는 미래 수익을 보장하지 않고, 투자 권유가 아니에요. 실제 주문은 하지 않아요.</span></div>' +
    '<div class="seg lg ql-tabs">' + tabs.map(([k, l]) => '<button data-qt="' + k + '" class="' + (QL.tab === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>' +
    '<div id="qlBody"></div>';
  hydrateIcons(el);
  el.querySelector('.ql-tabs').onclick = e => { const b = e.target.closest('[data-qt]'); if (!b) return; QL.tab = b.dataset.qt; el.querySelectorAll('[data-qt]').forEach(x => x.classList.toggle('on', x === b)); qlRender(); };
  qlRender();
};

function qlRender() {
  const box = document.getElementById('qlBody'); if (!box) return;
  ({ market: qlMarket, mine: qlMine, scan: qlScan, bt: qlBt })[QL.tab](box);
  hydrateIcons(box);
}
function qlLoading(msg) { return '<div class="ai-loading" style="padding:34px 10px"><div class="orb"></div><div>' + msg + '<br><span style="font-size:.8rem">실제 일봉 데이터를 받아 계산 중이에요</span></div></div>'; }
function qlFail(msg) { return '<div class="callout warn">' + icon('alert', 'ic-sm') + '<div>' + msg + '</div></div>'; }
function qlConds(list) { return '<ul class="ql-conds">' + (list || []).map(c => '<li class="' + (c.ok ? 'ok' : 'no') + '">' + (c.ok ? '✓' : '✗') + ' ' + esc(c.t) + '</li>').join('') + '</ul>'; }
function qlExplainBtn(kind) { return '<button class="btn btn-soft btn-sm" data-qx="' + kind + '">' + icon('sparkles', 'ic-sm') + 'AI 해설</button>'; }
function qlWireExplain(box, kind, getData) {
  box.querySelectorAll('[data-qx="' + kind + '"]').forEach(b => b.onclick = () => {
    if (!(AI_STATUS && AI_STATUS.on)) { needAI(() => {}); return; }
    const m = openAiModal('🤖 AI 해설', '퀀트 엔진이 계산한 숫자만 사용해 설명해요.', 'AI가 계산 결과를 읽는 중…');
    api('/api/quant/explain', { method: 'POST', body: { kind, data: getData() }, timeout: 120000 })
      .then(d => { if (m.closed) return; m.setBody(d.status === 'ok' ? '<div class="ai-out">' + renderAiText(d.text) + '</div><div class="ai-legal">' + DISCLAIMER + '</div>' : d.status === 'no_key' ? noKeyHtml() : qlFail(esc(d.text || '해설을 받지 못했어요'))); })
      .catch(() => { if (!m.closed) m.setBody(qlFail(SERVER_DOWN)); });
  });
}

/* ── 시장: 국면 + 섹터 강도 ── */
function qlMarket(box) {
  if (!QL.market) {
    box.innerHTML = qlLoading('시장 국면과 섹터 강도를 계산하는 중…');
    if (!QL.busy.market) {
      QL.busy.market = 1;
      api('/api/quant/market', { timeout: 120000 }).then(d => { QL.market = d; }).catch(() => { QL.market = { err: 1 }; })
        .finally(() => { QL.busy.market = 0; if (route.page === 'quant' && QL.tab === 'market') qlRender(); });
    }
    return;
  }
  if (QL.market.err) { box.innerHTML = qlFail(SERVER_DOWN) + '<button class="btn btn-soft" data-qr>다시 시도</button>'; box.querySelector('[data-qr]').onclick = () => { QL.market = null; qlRender(); }; return; }
  const d = QL.market;
  const reg = (k, r) => !r || r.state === '데이터 없음' || r.state === '데이터 부족'
    ? '<div class="card ql-reg"><div class="ql-reg-h"><b>' + (k === 'kr' ? '🇰🇷 ' : '🇺🇸 ') + esc((r && r.name) || '') + '</b><span class="ql-chip muted">데이터 없음</span></div></div>'
    : '<div class="card ql-reg"><div class="ql-reg-h"><b>' + (k === 'kr' ? '🇰🇷 ' : '🇺🇸 ') + esc(r.name) + '</b><span class="ql-chip ' + r.tone + '">' + esc(r.state) + '</span></div>' +
      '<div class="ql-kv"><span>종가</span><b>' + qn(r.close) + '</b><span>200일선</span><b>' + qn(r.ma200) + '</b><span>고점 대비</span><b>' + qp(r.from_high) + '</b>' +
        '<span>20일 / 60일</span><b>' + qp(r.ret20) + ' / ' + qp(r.ret60) + '</b><span>변동성(연)</span><b>' + qp(r.vol20, 0).replace('+', '') + '</b><span>RSI</span><b>' + qn(r.rsi, 0) + '</b></div>' +
      qlConds((r.why || []).map(([t, ok]) => ({ t, ok }))) + '<div class="ql-src">기준 ' + qd(r.asof) + ' · Yahoo Finance 일봉</div></div>';
  const sec = d.sectors[QL.secKey] || { items: [] };
  const mx = Math.max(1, ...sec.items.filter(x => x.score != null).map(x => Math.abs(x.score)));
  box.innerHTML = '<div class="ql-regs">' + reg('kr', d.regime.kr) + reg('us', d.regime.us) + '</div>' +
    '<div class="card"><div class="card-head"><h3>' + icon('layers', 'ic-sm') + '섹터 상대강도</h3><div class="seg"><button data-sk="kr" class="' + (QL.secKey === 'kr' ? 'on' : '') + '">국내</button><button data-sk="us" class="' + (QL.secKey === 'us' ? 'on' : '') + '">미국</button></div></div>' +
      '<p class="note" style="margin:0 0 10px">섹터 대표 ETF의 수익률에서 ' + esc(sec.bench || '') + '(20일 ' + qp(sec.b20) + ', 60일 ' + qp(sec.b60) + ') 수익률을 뺀 값. 점수 = 20일·60일 초과수익의 평균.</p>' +
      '<div class="ql-secs">' + sec.items.map(x => x.score == null
        ? '<div class="ql-sec"><span>' + esc(x.name) + '</span><div class="ql-bar"></div><b class="muted">데이터 없음</b></div>'
        : '<div class="ql-sec"><span>' + esc(x.name) + '</span><div class="ql-bar"><i class="' + (x.score >= 0 ? 'up' : 'down') + '" style="width:' + (Math.abs(x.score) / mx * 100).toFixed(0) + '%"></i></div>' +
          '<b class="' + cls(x.score) + '">' + qp(x.score) + '</b><em>20일 ' + qp(x.rel20) + ' · 60일 ' + qp(x.rel60) + '</em></div>').join('') + '</div>' +
      '<div class="ql-src">시장 폭(상승·하락 종목 비율): ' + esc(d.breadth) + '</div></div>' +
    '<div class="ql-actions">' + qlExplainBtn('market') + '<button class="btn btn-ghost btn-sm" data-qr>' + icon('refresh', 'ic-sm') + '다시 계산</button></div>';
  box.querySelectorAll('[data-sk]').forEach(b => b.onclick = () => { QL.secKey = b.dataset.sk; qlRender(); });
  box.querySelector('[data-qr]').onclick = () => { QL.market = null; qlRender(); };
  qlWireExplain(box, 'market', () => ({ regime: d.regime, sectors: { [QL.secKey]: d.sectors[QL.secKey] }, breadth: d.breadth }));
}

/* ── 내 종목: 전략 조건 상태 (매매 의견 아님) ── */
function qlItems() {
  const G = grand(), p = pol(), out = [], seen = new Set();
  allHoldings().forEach(x => {
    const t = (x.h.ticker || '').toUpperCase(); if (!t || seen.has(t)) return; seen.add(t);
    const v = hv(x.h), T = accT(x.a);
    out.push({ ticker: t, name: dispName(x.h), market: mkt(x.h), held: true, weight: T.asset > 0 ? +(v.valK / T.asset * 100).toFixed(1) : null,
      target: hasT(x.h) ? num(x.h.target) : null, single_max: p.single });
  });
  watchlist().forEach(w => { const t = (w.ticker || '').toUpperCase(); if (!t || seen.has(t)) return; seen.add(t); out.push({ ticker: t, name: dispName(w), market: w.market || (w.ccy === 'USD' ? 'us' : 'kr'), held: false }); });
  return out;
}
function qlMine(box) {
  const items = qlItems();
  if (!items.length) { box.innerHTML = '<div class="card"><div class="empty"><b>분석할 종목이 없어요</b><p>계좌에 종목을 넣거나 관심종목을 담으면, 종목마다 판단 가이드를 계산해요.</p></div></div>'; return; }
  if (!QL.signals || QL.signals.style !== tradeStyle()) {
    box.innerHTML = qlLoading(items.length + '개 종목의 신호를 계산하는 중…');
    if (!QL.busy.sig) {
      QL.busy.sig = 1;
      api('/api/quant/signals', { method: 'POST', body: { items, style: tradeStyle() }, timeout: 180000 }).then(d => { QL.signals = d; }).catch(() => { QL.signals = { err: 1, style: tradeStyle() }; })
        .finally(() => { QL.busy.sig = 0; if (route.page === 'quant' && QL.tab === 'mine') qlRender(); });
    }
    return;
  }
  if (QL.signals.err) { box.innerHTML = qlFail(SERVER_DOWN) + '<button class="btn btn-soft" data-qr>다시 시도</button>'; box.querySelector('[data-qr]').onclick = () => { QL.signals = null; qlRender(); }; return; }
  const d = QL.signals;
  box.innerHTML = '<div class="card"><div class="card-head"><h3>' + icon('target', 'ic-sm') + '종목별 전략 조건 상태</h3><span class="muted" style="font-size:.8rem">' + TRADE_STYLES[tradeStyle()].emoji + ' ' + TRADE_STYLES[tradeStyle()].label + ' 기준</span></div>' +
    '<p class="note" style="margin:0 0 10px">4가지 조건(큰 추세·정배열·60일 모멘텀·과열 아님) + 보유 비중 + 시장 국면으로 판단해요. 누르면 근거와 무효 조건이 보여요.</p>' +
    '<div class="ql-list">' + d.items.map((x, i) => '<button class="ql-row" data-qi="' + i + '"><div class="mid"><b>' + esc(x.name) + '</b><span>' + esc(x.ticker) + (x.held ? ' · 보유' : ' · 관심') +
      (x.obs ? ' · RSI ' + qn(x.obs.rsi, 0) + ' · 60일 ' + qp(x.obs.ret60) : '') + '</span></div>' +
      (x.score != null ? '<span class="ql-dots">' + [0, 1, 2, 3].map(k => '<i class="' + (k < x.score ? 'on' : '') + '"></i>').join('') + '</span>' : '') +
      '<span class="ql-chip ' + (VERDICT_TONE[x.verdict] || 'muted') + '">' + esc(x.verdict) + '</span></button>').join('') + '</div></div>' +
    '<div class="ql-actions"><button class="btn btn-ghost btn-sm" data-qr>' + icon('refresh', 'ic-sm') + '다시 계산</button></div>';
  box.querySelectorAll('[data-qi]').forEach(b => b.onclick = () => qlGuideModal(d.items[+b.dataset.qi], d));
  box.querySelector('[data-qr]').onclick = () => { QL.signals = null; qlRender(); };
}
function qlGuideModal(x, all) {
  const reg = all.regime && all.regime[x.market];
  const o = x.obs || {};
  const m = openModal({ title: esc(x.name) + ' · 전략 조건 상태', size: 'wide', body:
    '<div class="ql-verdict ' + (VERDICT_TONE[x.verdict] || 'muted') + '">' + esc(x.verdict) + (x.score != null ? '<span>조건 ' + x.score + '/4</span>' : '') + '</div>' +
    (x.why ? qlFail(esc(x.why.join(' · '))) : '') +
    (x.obs ? '<div class="as-h">① 관측된 데이터 (' + esc((x.data && qd(x.data.last)) || '-') + ' 종가 기준)</div>' +
      '<div class="ql-kv"><span>종가</span><b>' + qn(o.close) + '</b><span>20일선</span><b>' + qn(o.ma20) + '</b><span>60일선</span><b>' + qn(o.ma60) + '</b><span>120일선</span><b>' + qn(o.ma120) + '</b>' +
        '<span>RSI(14)</span><b>' + qn(o.rsi, 0) + '</b><span>60일 수익률</span><b>' + qp(o.ret60) + '</b><span>52주 고점 대비</span><b>' + qp(o.from_high) + '</b><span>변동성(연)</span><b>' + qp(o.vol20, 0).replace('+', '') + '</b></div>' +
      '<div class="as-h">② 매매 조건 (' + esc(x.basis || '') + ')</div>' + qlConds(x.conds) +
      '<div class="as-h">③ 하락 조건</div>' + qlConds([x.sell_rule]) +
      '<div class="as-h">④ 시장 상황</div><p class="note" style="margin:0">' + esc((reg && reg.name) || '') + ': <b>' + esc((reg && reg.state) || '데이터 없음') + '</b></p>' +
      (x.held && x.weight != null ? '<p class="note" style="margin:4px 0 0">이 종목 계좌 비중 ' + x.weight + '%' + (x.single_max ? ' (권장 한 종목 ' + x.single_max + '% 이하)' : '') + '</p>' : '') +
      ((x.notes || []).length ? '<div class="as-h">⑤ 주의</div><ul class="ql-conds">' + x.notes.map(n => '<li class="no">! ' + esc(n) + '</li>').join('') + '</ul>' : '') +
      '<div class="as-h">⑥ 이 판단이 무효가 되는 조건</div><ul class="ql-conds">' + (x.invalid || []).map(n => '<li>· ' + esc(n) + '</li>').join('') + '</ul>' +
      '<div class="ql-src">' + esc((x.data && x.data.source) || '') + ' · ' + esc((x.data && x.data.symbol) || '') + ' · ' + ((x.data && x.data.bars) || 0) + '일치 · 엔진 v' + esc(all.version || '') +
        (x.data && x.data.stale_days > 4 ? ' · ⚠ 마지막 데이터가 ' + x.data.stale_days + '일 전' : '') + '</div>' : ''),
    foot: '<button class="btn btn-gray" data-bt>백테스트</button>' + (x.obs ? qlExplainBtn('guide').replace('btn-sm', 'btn-primary') : '') });
  m.foot.querySelector('[data-bt]').onclick = () => { m.close(); go('quant', { bt: { ticker: x.ticker, name: x.name, market: x.market } }); };
  qlWireExplain(m.foot, 'guide', () => ({ item: x, regime: reg, style: tradeStyle() }));
}

/* ── 스캐너 ── */
function qlStrategies(cb) {
  if (QL.strategies) { cb(QL.strategies); return; }
  api('/api/quant/strategies').then(d => { QL.strategies = d.strategies || []; QL.conds = d.conds || []; cb(QL.strategies); }).catch(() => cb([]));
}
/* ── 조건 검색기 (AI 없음 · 내가 고른 숫자 조건으로만) ── */
// 조건별 기본값 (값이 없는 조건은 null)
const QC_DEF = { above20: null, above60: null, above120: null, aligned: null, rsi_min: 30, rsi_max: 40, ret20_min: 5, ret60_min: 10, ret60_max: -15, near_high: 5, far_high: 25, vol_spike: 2, vol_max: 30,
  above200: null, golden: 10, dead: 10, macd_up: null, bb_low: 2, bb_high: null, up_days: 3, gap_up: 2, near_low: 15, ret5_min: 5, ret5_max: -7, ma20_gap: 8, price_min: 1000, price_max: 100000 };
const QC_V1 = ['above20', 'above60', 'above120', 'aligned', 'rsi_min', 'rsi_max', 'ret20_min', 'ret60_min', 'ret60_max', 'near_high', 'far_high', 'vol_spike', 'vol_max'];
// 조건 묶음(화면에서 무리 지어 보여 주기) — v2.21 고도화
const QC_GROUPS = [['📈 추세', ['above20', 'above60', 'above120', 'above200', 'aligned', 'golden', 'dead', 'macd_up']],
  ['🌡 과열·침체', ['rsi_min', 'rsi_max', 'bb_low', 'bb_high', 'ma20_gap']], ['🚀 수익률·모멘텀', ['ret5_min', 'ret5_max', 'ret20_min', 'ret60_min', 'ret60_max', 'up_days', 'gap_up']],
  ['🏔 고점·저점', ['near_high', 'far_high', 'near_low']], ['🔊 거래량·변동성', ['vol_spike', 'vol_max']], ['💲 가격대', ['price_min', 'price_max']]];
const QC_PRESETS = [
  ['🚀 추세 강한 종목', [['above60'], ['aligned'], ['ret60_min', 10], ['near_high', 10]]],
  ['🪂 상승 추세 속 눌림', [['above120'], ['rsi_max', 40], ['ret20_min', -100]]],
  ['🧲 많이 빠진 종목(역발상)', [['far_high', 30], ['ret60_max', -15], ['rsi_max', 35]]],
  ['🔊 거래량 터진 종목', [['vol_spike', 2.5], ['above20']]],
  ['🛡 덜 출렁이는 우량주', [['vol_max', 30], ['above120']]],
];
const QC_PRESETS2 = [
  ['✨ 골든크로스 막 나옴', [['golden', 10], ['above60'], ['macd_up']]],
  ['🌱 바닥권에서 반등 시작', [['near_low', 20], ['up_days', 3], ['macd_up']]],
  ['🎯 볼린저 하단 눌림', [['bb_low', 2], ['above200']]],
  ['🔥 단기 급등 (5일)', [['ret5_min', 8], ['vol_spike', 2]]],
  ['🩸 단기 급락 (반등 노림)', [['ret5_max', -8], ['ma20_gap', 8], ['above200']]],
];
function qcPresets() { return feat('scan2') ? QC_PRESETS.concat(QC_PRESETS2) : QC_PRESETS; }
function qcSets() { try { const v = JSON.parse(localStorage.getItem('ql_mysets') || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
function qcSaveSets(v) { try { localStorage.setItem('ql_mysets', JSON.stringify(v.slice(0, 8))); } catch (e) {} }
function qlScan(box) {
  QL.scanUni = QL.scanUni || 'kr_large'; QL.scanSid = QL.scanSid || 'composite';
  QL.scanMode = QL.scanMode || 'custom';
  QL.qc = QL.qc || QC_PRESETS[0][1].map(([id, v]) => ({ id, v: v != null ? v : QC_DEF[id] }));
  if (QL.need == null) QL.need = 0;                          // 0 = 모두 충족
  qlStrategies(list => {
    const st = list.find(s => s.id === QL.scanSid) || {};
    const res = QL.scan, on = id => QL.qc.find(c => c.id === id);
    const condList = (QL.conds || []).filter(c => feat('scan2') || QC_V1.includes(c.id));
    const condRow = c => {
      const sel = on(c.id), hasV = QC_DEF[c.id] != null;
      const parts = c.t.split('값');
      const lab = hasV ? esc(parts[0]) + '<input class="input tnum qc-v" data-v="' + c.id + '" inputmode="decimal" value="' + esc(sel ? sel.v : QC_DEF[c.id]) + '">' + esc(parts.slice(1).join('값')) : esc(c.t);
      return '<label class="qc-row' + (sel ? ' on' : '') + '"><input type="checkbox" data-c="' + c.id + '"' + (sel ? ' checked' : '') + '><span>' + lab + '</span></label>';
    };
    const condRows = feat('scan2')
      ? QC_GROUPS.map(([g, ids]) => { const cs = condList.filter(c => ids.includes(c.id)); return cs.length ? '<div class="qc-g">' + g + '</div>' + cs.map(condRow).join('') : ''; }).join('')
      : condList.map(condRow).join('');
    const sets = qcSets();
    const n = QL.qc.length;
    const custom = '<div class="ah-sub">빠르게 고르기</div><div class="chips" id="qcP">' + qcPresets().map((p, i) => '<button class="chip" data-p="' + i + '">' + esc(p[0]) + '</button>').join('') +
        sets.map((x, i) => '<button class="chip mine" data-ms="' + i + '">⭐ ' + esc(x.name) + '<i data-del="' + i + '" aria-label="지우기">✕</i></button>').join('') + '</div>' +
      '<div class="ah-sub">내 조건 <span class="muted">(' + n + '개 선택 · 숫자는 바꿀 수 있어요)</span></div><div class="qc-list" id="qcL">' + condRows + '</div>' +
      '<div class="ah-sub">몇 개를 만족하면?</div><div class="seg" id="qcN"><button data-n="0" class="' + (!QL.need ? 'on' : '') + '">모두</button>' +
        [1, 2, 3].filter(k => k < n).map(k => '<button data-n="' + k + '" class="' + (QL.need === k ? 'on' : '') + '">' + k + '개 이상</button>').join('') + '</div>' +
      (feat('scan2') ? '<div class="ah-sub">정렬</div><div class="seg" id="qcSort">' + [['met', '많이 충족'], ['ret60', '60일 수익률'], ['ret20', '20일 수익률'], ['rsi_low', 'RSI 낮은 순']].map(([k, l]) => '<button data-so="' + k + '" class="' + ((QL.sort || 'met') === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>' : '') +
      '<button class="btn btn-ghost btn-sm" id="qcSave" style="margin-top:10px">' + icon('star', 'ic-sm') + '이 조건을 내 검색식으로 저장</button>';
    const strat = '<div class="ah-sub">전략</div><div class="chips" id="qsS">' + list.map(s => '<button class="chip' + (QL.scanSid === s.id ? ' on' : '') + '" data-s="' + s.id + '">' + esc(s.name) + '</button>').join('') + '</div>' +
      (st.id ? '<div class="ql-strat"><b>신호 켜짐 조건</b> ' + esc(st.buy) + '<br><b>신호 꺼짐 조건</b> ' + esc(st.sell) + '<br><span class="muted">' + esc(st.kind) + ' · 어울리는 스타일: ' + esc(st.fit) + ' · ' + esc(st.status) + ' · v' + esc(st.version) + '</span></div>' : '');
    box.innerHTML = '<div class="card"><div class="card-head"><h3>' + icon('radar', 'ic-sm') + '조건 검색기</h3></div>' +
      '<div class="qc-intro">📐 <b>AI 없이, 내가 정한 숫자 조건으로만</b> 걸러요. 같은 조건이면 언제나 같은 결과 — 내 방식대로 찾는 도구예요.' +
        '<br><span class="muted">뉴스·테마로 새 아이디어를 원하면 → <a data-nav="ai">AI 탭의 AI 아이디어 발굴</a></span></div>' +
      '<div class="ah-sub">어디서 찾을까요?</div><div class="chips" id="qsU">' + [['kr_large', '국내 대형주 30'], ['us_large', '미국 대형주 30'], ['mine', '내 종목·관심']].concat(feat('scan2') ? [['kr_kosdaq', '코스닥 대표 20'], ['kr_etf', '국내 ETF'], ['us_etf', '미국 ETF']] : []).map(([k, l]) => '<button class="chip' + (QL.scanUni === k ? ' on' : '') + '" data-u="' + k + '">' + l + '</button>').join('') + '</div>' +
      '<div class="seg" id="qsM" style="margin-top:12px"><button data-m="custom" class="' + (QL.scanMode === 'custom' ? 'on' : '') + '">내 조건 만들기</button><button data-m="strat" class="' + (QL.scanMode === 'strat' ? 'on' : '') + '">전략 규칙으로</button></div>' +
      (QL.scanMode === 'custom' ? custom : strat) +
      '<button class="btn btn-primary btn-block" id="qsGo" style="margin-top:12px"' + (QL.scanMode === 'custom' && !n ? ' disabled' : '') + '>' + icon('search', 'ic-sm') + '조건에 맞는 종목 찾기</button></div>' +
      '<div id="qsRes">' + (QL.busy.scan ? qlLoading('종목들을 하나씩 계산하는 중…') : res ? qlScanRes(res) : '') + '</div>';
    hydrateIcons(box);
    const re = () => { QL.scan = null; qlRender(); };
    box.querySelector('#qsU').onclick = e => { const b = e.target.closest('[data-u]'); if (b) { QL.scanUni = b.dataset.u; re(); } };
    box.querySelector('#qsM').onclick = e => { const b = e.target.closest('[data-m]'); if (b) { QL.scanMode = b.dataset.m; re(); } };
    const sS = box.querySelector('#qsS'); if (sS) sS.onclick = e => { const b = e.target.closest('[data-s]'); if (b) { QL.scanSid = b.dataset.s; re(); } };
    const L = box.querySelector('#qcL');
    if (L) {
      L.onchange = e => {
        const c = e.target.dataset.c, v = e.target.dataset.v;
        if (c) { if (e.target.checked) QL.qc.push({ id: c, v: QC_DEF[c] }); else QL.qc = QL.qc.filter(x => x.id !== c); if (QL.need >= QL.qc.length) QL.need = 0; re(); }
        if (v) { const x = on(v), val = parseFloat(e.target.value); if (isFinite(val)) { if (x) x.v = val; else { QL.qc.push({ id: v, v: val }); re(); } } }
      };
      box.querySelector('#qcP').onclick = e => {
        const d = e.target.closest('[data-del]');
        if (d) { e.stopPropagation(); const v = qcSets(); v.splice(+d.dataset.del, 1); qcSaveSets(v); re(); return; }
        const p = e.target.closest('[data-p]'), ms = e.target.closest('[data-ms]');
        if (p) { QL.qc = qcPresets()[+p.dataset.p][1].map(([id, v]) => ({ id, v: v != null ? v : QC_DEF[id] })); QL.need = 0; re(); }
        if (ms) { const x = qcSets()[+ms.dataset.ms]; if (x) { QL.qc = x.qc.map(c => Object.assign({}, c)); QL.need = x.need || 0; re(); } }
      };
      const so = box.querySelector('#qcSort'); if (so) so.onclick = e => { const b = e.target.closest('[data-so]'); if (b) { QL.sort = b.dataset.so; re(); } };
      box.querySelector('#qcN').onclick = e => { const b = e.target.closest('[data-n]'); if (b) { QL.need = +b.dataset.n; re(); } };
      box.querySelector('#qcSave').onclick = () => {
        if (!QL.qc.length) return;
        const name = (prompt('검색식 이름 (예: 내 눌림목)', '') || '').trim().slice(0, 16); if (!name) return;
        const v = qcSets().filter(x => x.name !== name); v.unshift({ name, qc: QL.qc, need: QL.need }); qcSaveSets(v); toast('⭐ "' + name + '" 저장했어요'); re();
      };
    }
    box.querySelector('#qsGo').onclick = () => {
      if (QL.busy.scan) return;
      QL.busy.scan = 1; QL.scan = null; qlRender();
      const items = qlItems().map(x => ({ ticker: x.ticker, name: x.name }));
      const body = { universe: QL.scanUni, strategy: QL.scanSid, items };
      if (QL.scanMode === 'custom') { body.custom = QL.qc; body.need = QL.need || QL.qc.length; body.sort = QL.sort || 'met'; }
      api('/api/quant/scan', { method: 'POST', body, timeout: 240000 })
        .then(d => { QL.scan = d; }).catch(() => { QL.scan = { err: 1 }; }).finally(() => { QL.busy.scan = 0; if (route.page === 'quant' && QL.tab === 'scan') qlRender(); });
    };
    const rb = box.querySelector('#qsRes');
    rb.querySelectorAll('[data-hit]').forEach(b => b.onclick = () => { const h = QL.scan.hits[+b.dataset.hit]; go('quant', { bt: { ticker: h.ticker, name: h.name, market: h.market, strategy: QL.scan.custom ? 'composite' : QL.scan.strategy } }); });
    qlWireExplain(rb, 'scan', () => ({ strategy: QL.scan && QL.scan.custom ? { name: '내 조건', conds: QL.qc } : st, hits: (QL.scan && QL.scan.hits || []).slice(0, 12), checked: QL.scan && QL.scan.checked }));
  });
}
function qlScanRes(d) {
  if (d.err) return qlFail(SERVER_DOWN);
  const row = (h, i) => '<button class="ql-row" data-hit="' + i + '"><div class="mid"><b>' + esc(h.name || h.ticker) + '</b><span>' + esc(h.ticker) + ' · 종가 ' + qn(h.close) +
      ' · RSI ' + qn(h.rsi, 0) + ' · 20일 ' + qp(h.ret20) + ' · 60일 ' + qp(h.ret60) + ' · ' + qd(h.asof) + '</span>' +
      (h.conds ? '<div class="qc-hits">' + h.conds.map(c => '<span class="' + (c.ok ? 'ok' : 'no') + '">' + (c.ok ? '✓ ' : '✗ ') + esc(c.obs) + '</span>').join('') + '</div>' : '') + '</div>' +
      '<span class="ql-chip ' + (h.signal.new ? 'up' : 'flat') + '">' + esc(h.signal.state) + '</span></button>';
  return '<div class="card"><div class="card-head"><h3>찾은 종목 ' + d.hits.length + '개</h3><span class="muted" style="font-size:.8rem">' + d.checked + '개 계산' + (d.failed.length ? ' · 데이터 없음 ' + d.failed.length : '') + '</span></div>' +
    (d.hits.length ? '<div class="ql-list">' + d.hits.map(row).join('') + '</div>'
      : '<p class="note">지금 이 조건을 만족하는 종목이 없어요.' + (d.custom ? ' 조건을 줄이거나 \'몇 개 이상\'으로 바꿔 보세요.' : '') + '</p>') +
    '<p class="note" style="margin:10px 0 0">누르면 그 종목으로 백테스트해요. 조건을 만족했다는 뜻일 뿐, 수익을 보장하지 않아요.</p>' +
    (d.hits.length ? '<div class="ql-actions">' + qlExplainBtn('scan') + '</div>' : '') + '</div>';
}

/* ── 백테스트 ── */
function qlBt(box) {
  const pre = QL.btPreset || {};
  QL.btIn = Object.assign({ ticker: '', name: '', market: '', strategy: 'trend', period: '3y', stop: '', take: '' }, QL.btIn || {}, pre);
  if (pre.strategy) QL.btIn.strategy = pre.strategy;
  QL.btPreset = null;
  const I = QL.btIn;
  const picks = qlItems().slice(0, 12);
  qlStrategies(list => {
    const st = list.find(s => s.id === I.strategy) || {};
    box.innerHTML = '<div class="card"><div class="card-head"><h3>' + icon('activity', 'ic-sm') + '전략 백테스트</h3></div>' +
      '<div class="field"><label>종목 (이름이나 코드)</label><div class="input-wrap"><span class="prefix-ic">' + icon('search') + '</span><input class="input" id="btQ" value="' + esc(I.name || I.ticker) + '" placeholder="예: 삼성전자, 005930, AAPL" autocomplete="off"></div><div class="sr" id="btSr"></div></div>' +
      (picks.length ? '<div class="chips">' + picks.map((p, i) => '<button class="chip' + (I.ticker === p.ticker ? ' on' : '') + '" data-pk="' + i + '" title="' + esc(p.name) + '">' + esc(shortNm(p.name)) + '</button>').join('') + '</div>' : '') +
      '<div class="ah-sub">전략</div><div class="chips" id="btS">' + list.map(s => '<button class="chip' + (I.strategy === s.id ? ' on' : '') + '" data-s="' + s.id + '">' + esc(s.name) + '</button>').join('') + '</div>' +
      (st.id ? '<div class="ql-strat"><b>신호 켜짐</b> ' + esc(st.buy) + '<br><b>신호 꺼짐</b> ' + esc(st.sell) + '<br><span class="muted">신호는 그날 종가로 정하고 다음 날 시가에 사고팔아요 (미래 데이터 안 씀)</span></div>' : '') +
      '<div class="ah-sub">기간</div><div class="seg" id="btP">' + [['1y', '1년'], ['3y', '3년'], ['5y', '5년']].map(([k, l]) => '<button data-p="' + k + '" class="' + (I.period === k ? 'on' : '') + '">' + l + '</button>').join('') + '</div>' +
      '<div class="row" style="margin-top:12px"><div class="field"><label>손실 제한 % (선택)</label><input class="input tnum" id="btStop" inputmode="decimal" placeholder="예: 8" value="' + esc(I.stop) + '"></div>' +
        '<div class="field"><label>익절 % (선택)</label><input class="input tnum" id="btTake" inputmode="decimal" placeholder="예: 20" value="' + esc(I.take) + '"></div></div>' +
      '<p class="note" style="margin:0">비용: 수수료 ' + nf(num(S.settings.feeRate) || 0.015, 3) + '% (사고팔 때 각각) · 매도세 ' + nf(num(S.settings.taxRate) || 0.18, 2) + '% (국내만) · 슬리피지 0.05%</p>' +
      '<button class="btn btn-primary btn-block" id="btGo" style="margin-top:12px">' + icon('activity', 'ic-sm') + '백테스트 실행</button></div>' +
      '<div id="btRes">' + (QL.busy.bt ? qlLoading('과거 데이터로 매매를 재현하는 중…') : QL.bt ? qlBtRes(QL.bt) : '') + '</div>';
    hydrateIcons(box);
    const q = box.querySelector('#btQ'), sr = box.querySelector('#btSr');
    const pick = p => { Object.assign(I, { ticker: p.ticker, name: p.name, market: p.market }); q.value = p.name; sr.innerHTML = ''; };
    q.addEventListener('input', debounce(async () => {
      const v = q.value.trim(); I.ticker = ''; if (!v) { sr.innerHTML = ''; return; }
      try { const r = await api('/api/search?q=' + encodeURIComponent(v), { timeout: 12000 }); sr.innerHTML = (r || []).slice(0, 5).map((x, i) => '<button data-r="' + i + '"><div class="mid"><b>' + esc(x.name) + '</b><span>' + esc(x.ticker) + '</span></div></button>').join(''); sr._r = r; } catch (e) {}
    }, 300));
    sr.onclick = e => { const b = e.target.closest('[data-r]'); if (b) pick(sr._r[+b.dataset.r]); };
    box.querySelectorAll('[data-pk]').forEach(b => b.onclick = () => { pick(picks[+b.dataset.pk]); box.querySelectorAll('[data-pk]').forEach(x => x.classList.toggle('on', x === b)); });
    box.querySelector('#btS').onclick = e => { const b = e.target.closest('[data-s]'); if (b) { I.strategy = b.dataset.s; I.stop = box.querySelector('#btStop').value; I.take = box.querySelector('#btTake').value; qlRender(); } };
    box.querySelector('#btP').onclick = e => { const b = e.target.closest('[data-p]'); if (b) { I.period = b.dataset.p; box.querySelectorAll('#btP button').forEach(x => x.classList.toggle('on', x === b)); } };
    box.querySelector('#btGo').onclick = () => {
      if (!I.ticker && /^[0-9A-Za-z.\-]{1,10}$/.test(q.value.trim())) I.ticker = q.value.trim().toUpperCase();
      if (!I.ticker) { toast('종목을 골라 주세요'); q.focus(); return; }
      I.stop = box.querySelector('#btStop').value; I.take = box.querySelector('#btTake').value;
      QL.busy.bt = 1; QL.bt = null; qlRender();
      const params = {}; if (num(I.stop) > 0) params.stop = num(I.stop); if (num(I.take) > 0) params.take = num(I.take);
      api('/api/quant/backtest', { method: 'POST', timeout: 120000, body: { ticker: I.ticker, market: I.market, strategy: I.strategy, period: I.period, params,
        costs: { fee: num(S.settings.feeRate) || 0.015, tax: num(S.settings.taxRate) || 0.18, slip: 0.05 } } })
        .then(d => { QL.bt = Object.assign({ name: I.name || I.ticker }, d); }).catch(() => { QL.bt = { ok: false, error: SERVER_DOWN }; })
        .finally(() => { QL.busy.bt = 0; if (route.page === 'quant' && QL.tab === 'bt') qlRender(); });
    };
    const rb = box.querySelector('#btRes');
    qlWireExplain(rb, 'backtest', () => { const r = Object.assign({}, QL.bt.result); delete r.curve; return { stock: QL.bt.name, ticker: QL.bt.ticker, data: QL.bt.data, result: r }; });
  });
}
function qlBtRes(d) {
  if (!d.ok) return qlFail(esc(d.error || '백테스트를 하지 못했어요'));
  const r = d.result, A = r.all, B = r.bench, D = r.dev, T = r.test, ccyUsd = d.market === 'us';
  const row = (l, a, b, f) => '<tr><td>' + l + '</td><td>' + f(a) + '</td><td>' + f(b) + '</td></tr>';
  const p1 = v => qp(v), p0 = v => v == null ? '-' : nf(v, 0), p2 = v => v == null ? '-' : nf(v, 2);
  const warnOver = D.total != null && T.total != null && D.cagr != null && T.cagr != null && D.cagr > 0 && T.cagr < D.cagr * 0.3;
  return '<div class="card"><div class="card-head"><h3>' + esc(d.name) + ' · ' + esc(r.name) + '</h3><span class="muted" style="font-size:.78rem">' + qd(d.data.first) + ' ~ ' + qd(d.data.last) + '</span></div>' +
    '<div class="ql-sig ' + (r.signal.new ? 'up' : r.signal.want ? 'flat' : 'muted') + '">오늘(마지막 종가) 기준: <b>' + esc(r.signal.state) + '</b></div>' +
    qlCurve(r.curve) +
    '<table class="ql-tbl"><tr><th></th><th>이 전략</th><th>그냥 보유</th></tr>' +
      row('누적 수익률', A.total, B.total, p1) + row('연환산 수익률', A.cagr, B.cagr, p1) + row('최대 낙폭(MDD)', A.mdd, B.mdd, p1) +
      row('변동성(연)', A.vol, B.vol, v => qp(v, 0).replace('+', '')) + row('샤프 비율', A.sharpe, B.sharpe, p2) +
      '<tr><td>거래 횟수 · 승률</td><td>' + p0(A.trades) + '회 · ' + (A.win == null ? '-' : nf(A.win, 0) + '%') + '</td><td>-</td></tr>' +
      '<tr><td>손익비 · 평균 보유</td><td>' + p2(A.pf) + ' · ' + (A.avg_hold == null ? '-' : nf(A.avg_hold, 0) + '일') + '</td><td>-</td></tr>' +
      '<tr><td>시장에 머문 비율</td><td>' + (A.exposure == null ? '-' : nf(A.exposure, 0) + '%') + '</td><td>100%</td></tr></table>' +
    '<div class="as-h">개발 구간 vs 검증 구간 (과최적화 점검)</div>' +
    '<table class="ql-tbl"><tr><th></th><th>개발 ' + qd(r.split.dev_from) + '~</th><th>검증 ' + qd(r.split.test_from) + '~</th></tr>' +
      row('누적 수익률', D.total, T.total, p1) + row('연환산', D.cagr, T.cagr, p1) + row('MDD', D.mdd, T.mdd, p1) + row('거래 횟수', D.trades, T.trades, p0) + '</table>' +
    (warnOver ? '<div class="callout warn" style="margin-top:8px">' + icon('alert', 'ic-sm') + '<div>검증 구간 성과가 개발 구간보다 크게 낮아요 — <b>과최적화</b>일 수 있어요.</div></div>' : '') +
    (A.trades != null && A.trades < 5 ? '<div class="callout gray" style="margin-top:8px">' + icon('info', 'ic-sm') + '<div>거래가 ' + A.trades + '번뿐이라 통계적으로 믿기 어려워요. 기간을 늘려 보세요.</div></div>' : '') +
    (r.trades.length ? '<div class="as-h">최근 거래</div><div class="ql-trades">' + r.trades.slice(-8).reverse().map(t => '<div><span>' + qd(t.in) + ' → ' + qd(t.out) + ' (' + t.days + '일)</span><b class="' + cls(t.ret) + '">' + qp(t.ret) + '</b><em>' + esc(t.why) + '</em></div>').join('') + '</div>' : '') +
    '<div class="ql-src">' + esc(d.data.source) + ' · ' + esc(d.data.symbol || '') + ' · 비용 반영(수수료 ' + r.costs.fee + '% · 매도세 ' + r.costs.tax + '% · 슬리피지 ' + r.costs.slip + '%) · 엔진 v' + esc(r.version) +
      (d.data.stale_days > 4 ? ' · ⚠ 마지막 데이터가 ' + d.data.stale_days + '일 전' : '') + '<br>수정주가·배당·상장폐지 종목은 반영되지 않을 수 있어요(생존편향).</div>' +
    '<div class="ql-actions">' + qlExplainBtn('backtest') + '</div></div>';
}
function qlCurve(pts) {
  if (!pts || pts.length < 2) return '';
  const W = 600, H = 160, ys = pts.flatMap(p => [p[1], p[2]]), lo = Math.min(...ys), hi = Math.max(...ys), sp = hi - lo || 1;
  const X = i => (i / (pts.length - 1) * (W - 8) + 4).toFixed(1), Y = v => (H - 6 - (v - lo) / sp * (H - 16)).toFixed(1);
  const line = k => pts.map((p, i) => (i ? 'L' : 'M') + X(i) + ',' + Y(p[k])).join('');
  return '<div class="ql-curve"><svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none" role="img" aria-label="자산 곡선"><path d="' + line(2) + '" fill="none" stroke="var(--text-3)" stroke-width="1.6" stroke-dasharray="4 3"/>' +
    '<path d="' + line(1) + '" fill="none" stroke="var(--brand)" stroke-width="2.4"/></svg><div class="ql-leg"><span><i style="background:var(--brand)"></i>이 전략</span><span><i style="background:var(--text-3)"></i>그냥 보유</span></div></div>';
}
