/* ==========================================================================
   poll.js — 🗳 공개 투표 (텃밭투자집사 전용) — 팝업으로 뜸 (v4.37 · v4.38 더 빨리)
   · 앱을 켜면 투표 팝업이 떠서 모두가 보고 참여 · 기기당 한 표 · 실시간 결과
   · 질문은 update.json "tb".poll 에서, 집계는 쿠폰 서버로. 기기 코드만 보냄(개인정보 없음).
   · 서버가 투표를 지원하고(새 코드) 투표가 있을 때만 떠요. 앱을 켤 때마다 한 번 떠요 (마감 뒤에는 하루 한 번).
   ========================================================================== */
'use strict';

let POLL = null;           // { poll:{id,q,options,until,closed}, counts:[], total, mine }
let _pollShowVote = false; // '다시 투표'로 선택지 다시 보기
let _pollBusy = false;
let _pollModal = null;
let _pollTries = 0;
let _pollShown = false;   // 이번 실행에서 팝업을 띄웠는지

let _pollLoading = false;
async function pollLoad() {
  if (ED !== 'tb' || POLL || _pollLoading) return;
  _pollLoading = true;
  let d = null;
  try { d = await api('/api/poll', { timeout: 12000 }); } catch (e) {}
  _pollLoading = false;
  if (!d || !d.ok || !d.poll) return;    // 투표 없음·서버 미지원·아직 준비 전 → 다음 시도에서 다시
  POLL = d; _pollShowVote = false;
  pollMaybePopup();
}

/* 앱이 자리잡은 뒤(잠금·인트로·다른 창이 없을 때) 하루 한 번 팝업 */
function pollMaybePopup() {
  if (!POLL || !POLL.poll || ED !== 'tb') return;
  if (document.getElementById('pollPop')) return;                 // 이미 떠 있음
  if (_pollShown) return;                                         // 이번에 앱을 켠 뒤 이미 한 번 띄움 (v4.38: 앱을 켤 때마다 한 번)
  if (POLL.poll.closed) { try { if (localStorage.getItem('pollpop_' + POLL.poll.id) === todayKey()) return; } catch (e) {} }   // 마감 뒤에는 하루 한 번만
  const blocked = document.getElementById('licLock') || document.getElementById('consentLock') ||
    document.querySelector('.intro') || document.getElementById('appBlock') || (window._modals && _modals.length);
  if (blocked) {                                                  // 다른 화면이 있으면 잠시 뒤 다시
    if (_pollTries++ < 150) setTimeout(pollMaybePopup, 400);   // v4.38: 0.4초마다 확인 → 인트로가 끝나는 즉시 뜸
    return;
  }
  openPollPopup();
}

function openPollPopup() {
  if (!POLL || !POLL.poll || document.getElementById('pollPop')) return;
  _pollShown = true;
  try { localStorage.setItem('pollpop_' + POLL.poll.id, todayKey()); } catch (e) {}
  _pollModal = openModal({ title: '🗳 함께 정해요', body: '<div class="poll-inner"></div>' });
  if (_pollModal && _pollModal.el) _pollModal.el.id = 'pollPop';
  _pollModal.onClose = null;
  renderPoll();
}

function pollPct(n, total) { return total > 0 ? Math.round((n / total) * 100) : 0; }

/* 열려 있는 모든 투표 영역(.poll-inner = 팝업) 다시 그리기 */
function renderPoll() {
  const inners = document.querySelectorAll('.poll-inner');
  if (!inners.length || !POLL) return;
  const p = POLL.poll, opts = p.options || [], mine = (POLL.mine == null ? -1 : POLL.mine);
  const counts = POLL.counts || opts.map(() => 0), total = POLL.total || 0;
  const voted = mine >= 0, showResult = (voted || p.closed) && !_pollShowVote;
  let body;
  if (showResult) {
    body = '<div class="poll-bars">' + opts.map((o, i) => {
      const c = counts[i] || 0, pct = pollPct(c, total);
      return '<div class="poll-bar' + (i === mine ? ' mine' : '') + '"><div class="poll-bl"><span>' + esc(o) + (i === mine ? ' <b class="poll-you">내 선택</b>' : '') + '</span><b>' + pct + '%</b></div>' +
        '<div class="poll-track"><i style="width:' + pct + '%"></i></div><small>' + nf(c, 0) + '표</small></div>';
    }).join('') + '</div>' +
      '<div class="poll-foot"><span>' + (p.closed ? '🔒 마감됐어요' : '총 ' + nf(total, 0) + '명 참여') + '</span>' +
      (!p.closed && voted ? '<button class="btn btn-soft btn-sm" data-poll="revote">표 바꾸기</button>' : '') + '</div>' +
      (p.closed ? '' : '<button class="btn btn-primary btn-block" data-poll="close" style="margin-top:12px">닫기</button>');
  } else {
    body = '<div class="poll-opts">' + opts.map((o, i) =>
      '<button class="poll-opt' + (i === mine ? ' mine' : '') + '" data-pollv="' + i + '"' + (_pollBusy ? ' disabled' : '') + '>' + esc(o) + '</button>').join('') + '</div>' +
      '<div class="poll-note">기기당 한 표예요. 바꾸고 싶으면 다시 누르면 돼요. <b>기기 코드와 선택 항목만</b> 저장되고 이름·연락처는 저장하지 않아요.</div>';
  }
  const html = '<h3 class="poll-q">' + esc(p.q) + '</h3>' +
    (p.until && !p.closed ? '<div class="poll-until">~' + esc(p.until) + '까지</div>' : '') + body;
  inners.forEach(el => { el.innerHTML = html; try { hydrateIcons(el); } catch (e) {} });
}

async function pollVote(choice) {
  if (_pollBusy || !POLL) return;
  _pollBusy = true; renderPoll();
  let r = null;
  try { r = await api('/api/poll/vote', { method: 'POST', body: { choice: choice }, timeout: 15000 }); } catch (e) {}
  _pollBusy = false;
  if (!r || !r.ok) { toast((r && r.error) || SERVER_DOWN, 3500); renderPoll(); return; }
  POLL.counts = r.counts; POLL.total = r.total; POLL.mine = r.mine; _pollShowVote = false;
  renderPoll();
  try { fxConfetti(1200); } catch (e) {}
  toast('🗳 투표했어요! 결과를 함께 봐요', 2500);
}

document.addEventListener('click', e => {
  const v = e.target.closest('[data-pollv]');
  if (v) { pollVote(+v.dataset.pollv); return; }
  const b = e.target.closest('[data-poll]');
  if (!b) return;
  if (b.dataset.poll === 'revote') { _pollShowVote = true; renderPoll(); }
  else if (b.dataset.poll === 'close' && _pollModal) { _pollModal.close(); }
});

/* 시작: 앱이 켜진 뒤 몇 번 시도 (잠금 해제·인트로 끝난 뒤 팝업) */
(function pollBoot() {
  if (typeof window === 'undefined') return;
  /* v4.38: 켜자마자 미리 받아 둠 (받아지면 인트로가 끝나는 즉시 팝업) */
  const boot = () => { if (ED === 'tb') { [200, 1200, 2500, 4500, 8000, 16000].forEach(t => setTimeout(() => { if (!POLL) pollLoad(); }, t)); } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
function homePollCard() { return ''; }   /* 홈에는 넣지 않음 (팝업으로만) */
