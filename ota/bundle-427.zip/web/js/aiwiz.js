/* ==========================================================================
   aiwiz.js — 🧓 아주 쉬운 'AI 켜기' 도우미 (v4.15)
   API 가 뭔지 몰라도: 큰 글씨 · 한 화면에 한 가지 · 그림 설명 · 복사만 하면 앱이 알아서 연결.
   · 키가 들어 있는 카톡 메시지를 통째로 붙여넣어도 키만 골라냄
   · 앱으로 돌아오면 복사해 둔 키를 스스로 찾아봄 (폰: 앱 안 서버가 클립보드에서 'AIza…' 키만 확인)
   · 가족(자녀)이 대신 만들어 카톡으로 보내 주는 길도 안내
   ========================================================================== */
'use strict';

const GKEY_RE = /AIza[0-9A-Za-z_\-]{35}/;
const AISTUDIO_URL = 'https://aistudio.google.com/app/apikey';
let _wz = null;                                          // 열려 있는 도우미 { m, step, watching }

function openAiWizard(after) {
  if (_wz && !_wz.m.closed) return;
  const m = openModal({ title: '🤖 AI 비서 켜기', size: 'wide', body: '' });
  m.el && m.el.classList && m.el.classList.add('wz-modal');
  _wz = { m, step: 'intro', watching: false, after };
  UI.aiWizSeen = 1; saveUI();
  wzDraw();
}

function wzBtn(t, attrs, cls) { return '<button class="wz-btn ' + (cls || '') + '" ' + attrs + '>' + t + '</button>'; }
function wzDraw(extra) {
  const W = _wz; if (!W || W.m.closed) return;
  const S = W.step;
  let h = '';
  if (S === 'intro') h =
    '<div class="wz-hero">🤖</div><h2 class="wz-h">AI 비서를 켜 볼까요?</h2>' +
    '<p class="wz-p">구글이 <b>무료</b>로 주는 <b>‘AI 열쇠’</b>를 한 번만 받아 오면 돼요.<br>돈은 들지 않아요. 3분이면 끝나요.</p>' +
    '<div class="wz-box">🔑 <b>AI 열쇠(키)</b>는 <b>AIza</b>로 시작하는 긴 영어·숫자 글자예요.<br>이 열쇠가 있어야 AI가 뉴스를 읽고 설명해 줄 수 있어요.</div>' +
    wzBtn('👍 제가 해 볼게요', 'data-wz="self"', 'pri') +
    wzBtn('👨‍👩‍👧 가족이 대신 해 줄 거예요', 'data-wz="family"') +
    wzBtn('🔑 열쇠를 이미 받아 뒀어요 (붙여넣기)', 'data-wz="paste"', 'ghost') +
    '<button class="wz-later" data-wz="later">나중에 할게요</button>';
  else if (S === 'gmail') h =
    '<div class="wz-step">1 / 3</div><h2 class="wz-h">구글 계정(지메일)이 있으세요?</h2>' +
    '<p class="wz-p">유튜브·지메일·플레이스토어를 쓰고 계시면 <b>이미 있어요</b>.<br>안드로이드 폰이면 거의 다 있어요.</p>' +
    wzBtn('네, 있어요', 'data-wz="open"', 'pri') +
    wzBtn('잘 모르겠어요 / 없어요', 'data-wz="nogmail"') +
    '<button class="wz-later" data-wz="back">← 처음으로</button>';
  else if (S === 'nogmail') h =
    '<h2 class="wz-h">괜찮아요 😊</h2>' +
    '<p class="wz-p">다음 화면에서 구글이 <b>로그인</b>을 물어보면,<br>폰에 있는 계정을 고르기만 하면 돼요.<br><br>정말 계정이 없으면 <b>가족에게 부탁</b>하는 게 가장 쉬워요.</p>' +
    wzBtn('그래도 해 볼게요', 'data-wz="open"', 'pri') +
    wzBtn('👨‍👩‍👧 가족에게 부탁할게요', 'data-wz="family"') +
    '<button class="wz-later" data-wz="back">← 처음으로</button>';
  else if (S === 'open') h =
    '<div class="wz-step">2 / 3</div><h2 class="wz-h">구글에서 열쇠 받아 오기</h2>' +
    '<p class="wz-p">아래 파란 버튼을 누르면 구글 화면이 열려요.<br>거기서 <b>이 순서대로</b>만 누르세요.</p>' +
    '<ol class="wz-ol">' +
      '<li><b>로그인</b>을 물어보면 내 계정 고르기<br><small>처음이면 ‘동의’ 체크 → <b>계속</b></small></li>' +
      '<li>파란 버튼 누르기<div class="wz-mock"><span class="mk-blue">🔑 API 키 만들기</span><small>(영어로 <b>Create API key</b> 일 수도 있어요)</small></div></li>' +
      '<li>긴 열쇠 글자 옆 <b>복사</b> 누르기<div class="wz-mock"><span class="mk-key">AIzaSy••••••••••••</span><span class="mk-copy">📋 복사</span></div></li>' +
      '<li><b>이 앱으로 돌아오기</b> — 앱이 알아서 연결해요 ✨</li></ol>' +
    wzBtn('① 구글 열쇠 화면 열기', 'data-wz="go"', 'pri big') +
    '<button class="wz-later" data-wz="paste">복사했어요 → 붙여넣기 화면으로</button>';
  else if (S === 'paste') h =
    '<div class="wz-step">3 / 3</div><h2 class="wz-h">복사한 열쇠를 넣어 주세요</h2>' +
    '<p class="wz-p">아래 칸을 <b>손가락으로 꾹</b> 누르면<br><b>‘붙여넣기’</b>가 나와요. 그걸 누르세요.</p>' +
    '<textarea class="wz-in" id="wzIn" rows="3" placeholder="여기를 꾹 눌러 붙여넣기&#10;(카톡 메시지를 통째로 붙여넣어도 돼요)" autocomplete="off" autocapitalize="off" spellcheck="false"></textarea>' +
    '<div class="wz-msg" id="wzMsg"></div>' +
    wzBtn('📋 붙여넣기 버튼으로 넣기', 'data-wz="clip"') +
    wzBtn('✅ 연결하기', 'data-wz="connect"', 'pri') +
    '<button class="wz-later" data-wz="open">← 구글에서 열쇠 받는 방법 다시 보기</button>';
  else if (S === 'found') h =
    '<div class="wz-hero">🔑</div><h2 class="wz-h">열쇠를 찾았어요!</h2>' +
    '<p class="wz-p">복사해 두신 열쇠예요:<br><b class="wz-key">' + esc(W.found.slice(0, 6) + '…' + W.found.slice(-4)) + '</b></p>' +
    wzBtn('✅ 이 열쇠로 연결하기', 'data-wz="usefound"', 'pri big') +
    '<button class="wz-later" data-wz="paste">다른 열쇠를 넣을게요</button>';
  else if (S === 'busy') h =
    '<div class="wz-hero spin">⏳</div><h2 class="wz-h">AI에게 인사하는 중…</h2><p class="wz-p">열쇠가 맞는지 확인하고 있어요. 잠시만요.</p>';
  else if (S === 'done') h =
    '<div class="wz-hero">🎉</div><h2 class="wz-h">AI 비서가 켜졌어요!</h2>' +
    '<p class="wz-p">AI의 첫인사:<br><b>“' + esc((extra && extra.reply) || '안녕하세요!') + '”</b></p>' +
    '<div class="wz-box">이제 종목을 누르고 <b>✨ AI 분석</b>을 누르면<br>AI가 뉴스와 숫자를 쉽게 설명해 줘요.</div>' +
    wzBtn('📋 오늘의 브리핑 받아 보기', 'data-wz="try"', 'pri') +
    wzBtn('닫기', 'data-wz="close"');
  else if (S === 'fail') h =
    '<div class="wz-hero">😥</div><h2 class="wz-h">연결이 안 됐어요</h2>' +
    '<p class="wz-p">' + esc((extra && extra.error) || '열쇠를 다시 확인해 주세요') + '</p>' +
    '<div class="wz-box">💡 구글 화면에서 <b>📋 복사</b>를 한 번 더 누르고 오면 대부분 해결돼요.<br>열쇠는 <b>AIza</b>로 시작하는 <b>39글자</b>예요.</div>' +
    wzBtn('다시 붙여넣기', 'data-wz="paste"', 'pri') +
    wzBtn('구글에서 다시 받기', 'data-wz="open"') +
    wzBtn('👨‍👩‍👧 가족에게 부탁하기', 'data-wz="family"', 'ghost');
  else if (S === 'family') h =
    '<div class="wz-hero">👨‍👩‍👧</div><h2 class="wz-h">가족에게 부탁하기</h2>' +
    '<ol class="wz-ol">' +
      '<li>아래 <b>[부탁 메시지 복사]</b>를 누르세요</li>' +
      '<li>카카오톡에서 자녀에게 <b>붙여넣어 보내세요</b></li>' +
      '<li>자녀가 열쇠를 <b>카톡으로 보내 주면</b>,<br>그 메시지를 <b>꾹 눌러 ‘복사’</b></li>' +
      '<li>이 앱을 열면 <b>알아서 연결</b>돼요 ✨</li></ol>' +
    wzBtn('📨 부탁 메시지 복사', 'data-wz="askcopy"', 'pri big') +
    wzBtn('열쇠를 받았어요 → 붙여넣기', 'data-wz="paste"') +
    '<button class="wz-later" data-wz="back">← 처음으로</button>';
  W.m.setBody('<div class="wz">' + h + '</div>');
  W.m.setFoot && W.m.setFoot('');
  const inp = W.m.body.querySelector('#wzIn');
  if (inp) inp.addEventListener('input', () => { const k = (inp.value.match(GKEY_RE) || [])[0]; const msg = W.m.body.querySelector('#wzMsg'); if (k) { msg.className = 'wz-msg good'; msg.textContent = '✅ 열쇠를 찾았어요! 연결할게요…'; setTimeout(() => wzConnect(inp.value), 400); } else if (inp.value.trim().length > 10) { msg.className = 'wz-msg bad'; msg.textContent = '열쇠(AIza로 시작)가 안 보여요. 구글 화면에서 복사를 다시 눌러 주세요.'; } });
}

async function wzTryClip(quiet) {                            // 복사해 둔 열쇠 스스로 찾기
  const W = _wz; if (!W || W.m.closed || ['busy', 'done'].includes(W.step)) return false;
  let k = '';
  try { const d = await api('/api/ai/clip-key', { timeout: 5000 }); if (d && d.ok) k = d.key; } catch (e) {}
  if (!k) { try { const t = await navigator.clipboard.readText(); k = (String(t || '').match(GKEY_RE) || [])[0] || ''; } catch (e) {} }
  if (k) { W.found = k; W.step = 'found'; wzDraw(); return true; }
  if (!quiet) toast('복사한 열쇠를 못 찾았어요. 아래 칸을 꾹 눌러 붙여넣어 주세요', 3500);
  return false;
}
async function wzConnect(text) {
  const W = _wz; if (!W || W.step === 'busy') return;
  if (!GKEY_RE.test(String(text || ''))) { W.step = 'fail'; wzDraw({ error: '열쇠(AIza로 시작하는 39글자)를 찾지 못했어요.' }); return; }
  W.step = 'busy'; wzDraw();
  let d = null;
  try { d = await api('/api/ai/quick-setup', { method: 'POST', body: { text }, timeout: 80000 }); } catch (e) { d = { ok: false, error: SERVER_DOWN }; }
  if (W.m.closed) return;
  if (d && d.ok) {
    W.step = 'done'; wzDraw(d);
    try { await loadAIStatus(); } catch (e) {}
    try { fxConfetti(2200); } catch (e) {}
    if (route.page === 'ai' || route.page === 'settings') rerender && rerender();
  } else { W.step = 'fail'; wzDraw(d); }
}
function wzCopy(text) {
  try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text); return true; } } catch (e) {}
  try { const t = document.createElement('textarea'); t.value = text; t.style.position = 'fixed'; t.style.opacity = '0'; document.body.appendChild(t); t.select(); const ok = document.execCommand('copy'); t.remove(); return ok; } catch (e) { return false; }
}

document.addEventListener('click', async e => {
  const b = e.target.closest('[data-wz]'); if (!b || !_wz) return;
  const W = _wz, a = b.dataset.wz;
  if (a === 'self') { W.step = 'gmail'; wzDraw(); }
  else if (a === 'nogmail') { W.step = 'nogmail'; wzDraw(); }
  else if (a === 'open') { W.step = 'open'; wzDraw(); }
  else if (a === 'back') { W.step = 'intro'; wzDraw(); }
  else if (a === 'family') { W.step = 'family'; wzDraw(); }
  else if (a === 'paste') { if (!(await wzTryClip(true))) { W.step = 'paste'; wzDraw(); } }
  else if (a === 'go') { W.watching = true; openExt(AISTUDIO_URL); setTimeout(() => { if (_wz && !_wz.m.closed && _wz.step === 'open') { _wz.step = 'paste'; wzDraw(); } }, 1500); }
  else if (a === 'clip') { const ok = await wzTryClip(false); if (!ok) { const i = W.m.body.querySelector('#wzIn'); if (i) i.focus(); } }
  else if (a === 'connect') { const i = W.m.body.querySelector('#wzIn'); wzConnect(i ? i.value : ''); }
  else if (a === 'usefound') wzConnect(W.found);
  else if (a === 'askcopy') {
    const msg = '부탁이 있어! ' + BRAND.name + ' 앱에 AI를 켜고 싶어 🙏\n1) ' + AISTUDIO_URL + ' 에 들어가서\n2) 파란 "API 키 만들기(Create API key)" 누르고\n3) 나온 키(AIza로 시작)를 복사해서 카톡으로 보내 줘!\n(구글이 무료로 주는 거라 돈은 안 들어)';
    toast(wzCopy(msg) ? '📨 복사했어요! 카카오톡에서 자녀에게 붙여넣어 보내세요' : '복사가 안 됐어요. 화면을 자녀에게 보여 주세요', 4000);
  }
  else if (a === 'try') { W.m.close(); _wz = null; if (typeof W.after === 'function') W.after(); else { const x = ACT['ai-brief-all']; if (x) x(); } }
  else if (a === 'close' || a === 'later') { W.m.close(); _wz = null; if (a === 'later') toast('AI 탭이나 설정에서 언제든 켤 수 있어요', 3000); }
});
// 구글 화면에서 열쇠를 복사하고 앱으로 돌아오면 → 스스로 찾아서 연결 제안
document.addEventListener('visibilitychange', () => {
  if (document.hidden || !_wz || _wz.m.closed) return;
  if (['open', 'paste', 'family', 'fail'].includes(_wz.step)) setTimeout(() => wzTryClip(true), 500);
});

/* 처음 설치하고 AI가 꺼져 있으면 한 번 도우미 띄우기 (시작 화면·동의·설문이 끝난 뒤) */
function maybeAiWizard(tries) {
  tries = tries || 0;
  if (UI.aiWizSeen || (AI_STATUS && AI_STATUS.on)) return;
  const busy = (typeof _modals !== 'undefined' && _modals.length) || document.querySelector('.intro, #consentLock, #licLock, #appBlock, .nudge');
  if (busy || !AI_STATUS) { if (tries < 40) setTimeout(() => maybeAiWizard(tries + 1), 5000); return; }
  openAiWizard();
}
