/* ==========================================================================
   rules.js — 🌱 담쌤의 가르침(투자 원칙) 열 가지 + 내 규칙 (v4.49 · v4.50 이름 바꿈)
   원칙을 '읽는 글'로 두지 않고, 모의투자에서 사고파는 순간에 앱이 원칙대로 움직이게 하는 바탕.
   · RULES10  : 열 가지 원칙 (퀴즈 해설·내 규칙 화면이 함께 씀)
   · 내 규칙  : 한 종목 비중 · 나눠 사는 횟수 · 남겨 둘 현금 · 다시 보는 주기 — 사용자가 직접 정함
   앱은 '무엇을 사고팔지' 말하지 않고, 본인이 정한 규칙을 지켰는지만 비춰 줌. 막지 않음.
   ========================================================================== */
'use strict';

// 화면에 보이는 이름 (v4.51): 텃밭투자집사 = '담쌤의 가르침' · 내 투자 비서 = '투자 원칙'
const RULES_NAME = ED === 'tb' ? '담쌤의 가르침' : '투자 원칙', RULES_ONE = ED === 'tb' ? '가르침' : '원칙';
const RULES10 = [
  ['🏡', '내 삶에 맞게 짜요', '투자는 내 나이·소득·쓸 돈·환경에 맞춰 계획을 세우는 일이에요. 좋다는 기업을 그냥 사는 게 아니에요.'],
  ['💰', '여윳돈으로만 해요', '잃어도 생활이 흔들리지 않는 돈으로 해요. 빚내서 하지 않아요.'],
  ['🔍', '모르는 것은 사지 않아요', '무슨 일로 돈을 버는 회사인지 내 말로 설명할 수 있을 때만 사요.'],
  ['🧺', '나눠 담아요', '한 종목, 한 분야에 몰아 담지 않아요.'],
  ['🪜', '나눠서 사고, 나눠서 팔아요', '한 번에 다 사지도, 한 번에 다 팔지도 않아요. 여러 번에 나눠요.'],
  ['⚖️', '가격과 가치를 구분해요', '좋은 회사라도 비싸게 사면 좋은 투자가 아니에요.'],
  ['⏳', '길게 봐요', '내일 주가는 아무도 몰라요. 시간을 내 편으로 둬요.'],
  ['🙅', '남과 비교하지 않아요', '남의 수익과 견주면 급하게 따라 사게 돼요. 내 속도로 가요.'],
  ['🧘', '감정으로 사고팔지 않아요', '급하게 오를 때 올라타지 않고, 무서울 때 던지지 않아요. 미리 정한 계획대로 해요.'],
  ['🚨', '보장된 수익은 없어요', '수익을 보장한다는 말은 사기예요.'],
];
function ruleTag(n) { n = +n; return n >= 1 && n <= 10 ? RULES10[n - 1][0] + ' ' + RULES_ONE + ' ' + n + ' · ' + RULES10[n - 1][1] : '📘 기본 용어·뉴스 읽기'; }
function rulesOn() { return feat('rules') && feat('paper'); }

function openRules10(focus) {
  focus = +focus || 0;
  const m = openModal({ title: '🌱 ' + RULES_NAME + ' 열 가지', body:
    '<div class="ru-lead">무엇을 살지 알려 주는 글이 아니에요.<br><b>어떤 마음으로 투자할지</b>를 정리한 기준이에요.</div>' +
    RULES10.map((r, i) => '<div class="ru-item' + (focus === i + 1 ? ' on' : '') + '" id="ru10_' + (i + 1) + '"><div class="ru-ico">' + r[0] + '</div><div><b><i>' + (i + 1) + '</i>' + esc(r[1]) + '</b><p>' + esc(r[2]) + '</p></div></div>').join('') +
    '<p class="note" style="margin:12px 2px 0">이 ' + RULES_ONE + '은 투자 권유가 아니에요. 스스로 판단하기 위한 기준이고, 투자 판단과 책임은 각자에게 있어요.</p>' });
  if (focus) setTimeout(() => { const e = m.body.querySelector('#ru10_' + focus); if (e && e.scrollIntoView) e.scrollIntoView({ block: 'center' }); }, 120);
}

/* ── 내 규칙 ─────────────────────────────────────────────────────────────── */
const RU_OPT = {
  max: [[10, '10%'], [15, '15%'], [20, '20%'], [25, '25%'], [30, '30%']],
  split: [[2, '2번'], [3, '3번'], [4, '4번'], [5, '5번']],
  cash: [[10, '10%'], [20, '20%'], [30, '30%'], [40, '40%']],
  review: [[7, '1주'], [30, '1달'], [90, '3달']],
};
function ruHasRisk() { try { return !!profile().risk; } catch (e) { return false; } }
function ruSuggest() {                                     // 설문의 '손실 때 반응'으로 처음 값을 골라 줌 (본인이 바꿀 수 있음)
  let risk = ''; try { risk = String(profile().risk || ''); } catch (e) {}
  if (risk === 'low') return { max: 15, split: 4, cash: 30, review: 30 };
  if (risk === 'high') return { max: 25, split: 3, cash: 10, review: 30 };
  return { max: 20, split: 3, cash: 20, review: 30 };
}
function ruRaw() { const s = S.settings; if (!s.rules || typeof s.rules !== 'object') s.rules = {}; return s.rules; }
function RU() {
  const d = ruSuggest(), r = ruRaw(), o = {};
  Object.keys(RU_OPT).forEach(k => { const v = +r[k]; o[k] = RU_OPT[k].some(x => x[0] === v) ? v : d[k]; });
  return o;
}
function rulesSet() { return !!ruRaw().set; }
function ruReviewTxt(days) { const o = RU_OPT.review.find(x => x[0] === +days); return o ? o[1] : days + '일'; }

function openMyRules(after) {
  const cur = RU(), was = rulesSet();
  const row = (k, t, d) => '<div class="ru-set"><b>' + t + '</b><span>' + d + '</span><div class="seg ru-seg" data-k="' + k + '">' +
    RU_OPT[k].map(x => '<button data-v="' + x[0] + '" class="' + (cur[k] === x[0] ? 'on' : '') + '">' + x[1] + '</button>').join('') + '</div></div>';
  const m = openModal({ title: '🧭 내 규칙 정하기', sticky: true, body:
    '<div class="ru-lead">내 삶에 맞게 <b>직접</b> 정해요. 정답은 없어요.<br>앱은 이 규칙을 지켰는지만 비춰 줘요. 넘어도 막지 않아요.' +
      (was ? '' : '<br><small>처음 값은 ' + (ruHasRisk() ? '투자자 설문 답을 바탕으로' : '흔히 쓰는 값으로') + ' 골라 뒀어요.</small>') + '</div>' +
    row('max', '한 종목은 얼마까지', '한 종목이 내 모의계좌에서 차지할 수 있는 가장 큰 비중') +
    row('split', '살 때는 몇 번에 나눠서', '한 종목을 한 번에 다 사지 않고 나눠 사는 횟수') +
    row('cash', '현금은 얼마 이상 남기기', '급하게 내릴 때 버티고, 기회가 왔을 때 쓸 여유') +
    row('review', '산 종목을 다시 보는 주기', '산 이유가 그대로인지 점검하는 간격') +
    '<p class="note" style="margin:12px 2px 0">모의투자 연습에 쓰는 내 기준이에요. 투자 권유가 아니에요. <a class="lnk" data-ru10>' + RULES_NAME + ' 보기</a></p>',
    foot: '<button class="btn btn-primary btn-block btn-lg" id="ruSave">' + (was ? '저장' : '이 규칙으로 시작') + '</button>' });
  m.body.addEventListener('click', e => {
    if (e.target.closest('[data-ru10]')) { openRules10(); return; }
    const b = e.target.closest('.ru-seg button'); if (!b) return;
    const seg = b.parentNode; cur[seg.dataset.k] = +b.dataset.v;
    seg.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b));
  });
  m.foot.querySelector('#ruSave').onclick = () => {
    const r = ruRaw(); Object.keys(RU_OPT).forEach(k => { r[k] = cur[k]; }); r.set = true; r.at = Date.now();
    save(); m.close(); toast('🧭 내 규칙을 저장했어요', 2200);
    if (typeof after === 'function') after(); else if (route.page && PAGES[route.page]) go(route.page, route.params, true);
  };
}

/* 지금 모의계좌가 내 규칙 안에 있는지 */
function ruStatus() {
  const r = RU(), P = PP(), g = G(), V = paperValue(), eq = g.pts + V.v;
  const ws = P.pos.map(p => { const c = paperCur(p.t) || p.avg; return { p, w: eq > 0 ? c * p.qty * paperRate(p.ccy) / eq * 100 : 0 }; }).sort((a, b) => b.w - a.w);
  const now = Date.now();
  return { r, eq, top: ws[0] || null, cashPct: eq > 0 ? g.pts / eq * 100 : 100,
    due: P.pos.filter(p => p.review && p.review <= now),
    big: P.hist.filter(h => h.k === 'buy' && h.big && now - h.at < 30 * 86400000).length, hasPos: P.pos.length > 0 };
}
function rulesCardHtml() {
  if (!rulesOn()) return '';
  if (!rulesSet()) return '<div class="card ru-card ru-new"><div><b>🧭 내 규칙을 먼저 정해 볼까요?</b><span>한 종목 비중, 나눠 사는 횟수, 남겨 둘 현금을 내 삶에 맞게 정해 두면 사고팔 때 앱이 비춰 줘요.</span></div>' +
    '<button class="btn btn-primary btn-sm" data-act="my-rules">정하기</button></div>';
  const s = ruStatus(), r = s.r, pc = v => Math.round(v) + '%';
  const line = (t, d, ok, okT, ngT, act) => '<div class="ru-row"' + (act ? ' data-act="' + act + '"' : '') + '><div><b>' + t + '</b><small>' + d + '</small></div><span class="' + (ok ? 'ok' : 'ng') + '">' + (ok ? okT : ngT) + '</span></div>';
  return '<div class="card ru-card"><div class="ru-head"><b>🧭 내 규칙</b><span><a class="lnk" data-act="rules10">' + RULES_NAME + '</a> · <a class="lnk" data-act="my-rules">바꾸기</a></span></div>' +
    line('한 종목은 ' + r.max + '%까지', s.top ? '지금 가장 큰 종목 ' + esc(s.top.p.n) + ' ' + pc(s.top.w) : '아직 산 종목이 없어요', !s.top || s.top.w <= r.max + .5, '지키는 중', '넘었어요') +
    line('살 때는 ' + r.split + '번에 나눠서', s.big ? '최근 한 달, 한 번에 크게 산 적 ' + s.big + '번' : '최근 한 달, 한 번에 크게 산 적 없음', !s.big, '지키는 중', '살펴보세요') +
    line('현금은 ' + r.cash + '% 이상 남겨요', '지금 현금 ' + pc(s.cashPct), s.cashPct >= r.cash - .5, '지키는 중', '모자라요') +
    line('산 종목은 ' + ruReviewTxt(r.review) + '마다 다시 봐요', s.due.length ? '다시 볼 종목 ' + s.due.length + '개 · 눌러서 보기' : (s.hasPos ? '아직 볼 때가 안 됐어요' : '아직 산 종목이 없어요'), !s.due.length, '지키는 중', '볼 때 됐어요', s.due.length ? 'paper-review-next' : '') +
    '</div>';
}

/* 다시 볼 때가 된 종목: 산 이유를 다시 보여 주고, 그대로인지 물음 */
function openPaperReview(t) {
  const P = PP(), p = t ? P.pos.find(x => x.t === String(t).toUpperCase()) : ruStatus().due[0];
  if (!p) { toast('지금 다시 볼 종목이 없어요'); return; }
  const c = paperCur(p.t) || p.avg, pl = (c / p.avg - 1) * 100, days = Math.max(0, Math.round((Date.now() - (p.whyAt || p.at || Date.now())) / 86400000)), r = RU();
  const m = openModal({ title: '🔔 다시 볼 때예요 · ' + esc(p.n), body:
    '<div class="pp-why"><small>' + (days ? days + '일 전' : '오늘') + ', 살 때 내가 적은 이유</small>' + (p.why ? '“' + esc(p.why) + '”' : '<i>이유를 적지 않았어요</i>') + '</div>' +
    '<div class="pp-head"><div><span>평균 산 값</span><b>' + esc(priceTxt(p.avg, p.ccy)) + '</b></div><div><span>지금</span><b>' + esc(priceTxt(c, p.ccy)) + ' <em class="' + cls(pl) + '">' + pct(pl) + '</em></b></div></div>' +
    '<div class="ru-q">그 이유가 지금도 그대로인가요?</div>' +
    '<p class="note" style="margin:0 0 4px">값이 오르내린 것과 이유가 바뀐 것은 다른 일이에요. 회사 소식과 실적을 한 번 살펴보고 골라 주세요.</p>',
    foot: '<div class="row-btns pp-btns"><button class="btn btn-outline btn-lg" style="flex:1" id="rvNo">바뀌었어요</button><button class="btn btn-primary btn-lg" style="flex:1" id="rvYes">그대로예요</button></div>' });
  m.foot.querySelector('#rvYes').onclick = () => {
    p.review = Date.now() + r.review * 86400000; p.rv = (p.rv || 0) + 1; save(); m.close();
    toast('🔔 ' + ruReviewTxt(r.review) + ' 뒤에 다시 알려 드릴게요', 2400); paperRerender();
  };
  m.foot.querySelector('#rvNo').onclick = () => {
    p.review = Date.now() + r.review * 86400000; save(); m.close();
    openPaperTrade({ ticker: p.t, name: p.n, market: p.mkt, ccy: p.ccy, mode: 'sell' });
  };
}
