"""
가격·뉴스 심부름꾼 서버 (price_server.py)
=========================================

이 작은 서버는 '가격'과 '뉴스'만 알려줍니다. 나머지(화면·계좌·비중 등)는 HTML 앱이 합니다.

켜는 법:
    pip install flask flask-cors requests beautifulsoup4
    python price_server.py
    → http://localhost:8000 접속해서 'OK'가 보이면 켜진 것입니다.

HTML 앱에서 부르는 주소:
    GET /price?ticker=005930&market=kr     -> {"price":71500, "status":"ok", ...}
    GET /price?ticker=AAPL&market=us        -> {"price":231.4, ...}
    GET /prices?items=005930:kr,AAPL:us     -> {"005930:kr":{...}, "AAPL:us":{...}}  (한 번에 여러 개)
    GET /news?ticker=005930&market=kr       -> [{"title","url","date"}, ...]

주의: 네이버/야후 화면을 읽어오는 비공식 방식입니다. 화면 변경·접속 제한·지연이 있을 수 있어요.
같은 집 와이파이의 폰에서 쓰려면 host=0.0.0.0 으로 떠 있으니, 폰 브라우저는 PC의 IP로 접속하면 됩니다.
"""

import re
import hashlib
import csv
import io
import os
import json
import time
import threading
from datetime import datetime
from xml.etree import ElementTree as ET

import sys

# 휴대용 파이썬(._pth)에서도 같은 폴더의 모듈을 찾도록
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 검은 창 없이(pythonw) 실행되면 출력할 곳이 없으므로 userdata/server.log 로 보냄
if sys.stdout is None or sys.stderr is None:
    _logdir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "userdata")
    os.makedirs(_logdir, exist_ok=True)
    _logpath = os.path.join(_logdir, "server.log")
    if os.path.exists(_logpath) and os.path.getsize(_logpath) > 1_000_000:
        os.replace(_logpath, _logpath + ".old")  # 너무 커지지 않게 한 번 넘김
    _log = open(_logpath, "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stdout or _log
    sys.stderr = sys.stderr or _log

import requests
from bs4 import BeautifulSoup
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

import ai_engine
import market_data

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024
# 예전 화면(파일로 연 HTML)이 쓰던 시세·뉴스 주소만 다른 출처에서 부를 수 있게 허용.
# 내 자산 데이터·AI 설정 주소는 이 앱 화면에서만 쓸 수 있습니다.
LEGACY_OPEN = ("/price", "/prices", "/news", "/fx")
CORS(app, resources={r"^/(price|prices|news|fx)$": {"origins": "*"}})
app.register_blueprint(ai_engine.bp)
app.register_blueprint(market_data.bp)
try:                                    # Quant Lab (퀀트 엔진) — 파일이 없는 예전 묶음에서도 앱은 켜지게
    import quant
    app.register_blueprint(quant.bp)
except ImportError:
    quant = None


# ── 자동 업데이트 즉시 적용(v1.8~): 서버를 끄지 않고 새 코드로 갈아 끼움 ──────────
# 요청은 이 바깥 껍데기를 거쳐, 새 묶음을 불러왔으면 그 앱으로 넘어감(같은 주소라 화면 저장값 유지).
_SWAP = {"app": None}


class _SwapWSGI:
    def __init__(self, inner):
        self.inner = inner

    def __call__(self, environ, start_response):
        nxt = _SWAP["app"]
        return (nxt or self.inner)(environ, start_response)


app.wsgi_app = _SwapWSGI(app.wsgi_app)

_LAN_ACTIVE = False  # 실행 시 '휴대폰에서도 보기' 설정에 따라 정해짐


@app.before_request
def _guard():
    """① 이 PC 전용 모드면 다른 기기 접속 차단  ② 다른 웹사이트가 몰래 부르는 것 차단"""
    import ipaddress
    ra = request.remote_addr or ""
    try:
        ip = ipaddress.ip_address(ra)
        local = ip.is_loopback
        private = ip.is_private or local
    except ValueError:
        local = private = False
    if not local and (not _LAN_ACTIVE or not private):
        return ("이 앱은 이 PC에서만 열 수 있게 설정되어 있어요. (설정 → 고급 → 휴대폰에서도 보기)", 403)
    if request.path not in LEGACY_OPEN and request.headers.get("Sec-Fetch-Site") == "cross-site":
        return jsonify({"error": "다른 사이트에서의 요청은 막혀 있어요"}), 403

def _read_version():
    """버전 번호는 version.txt 한 곳에서만 관리 (PC 프로그램·폰 앱·배포 파일 이름이 모두 이걸 따름)"""
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "version.txt"), encoding="utf-8") as f:
            return "v" + f.read().strip()
    except OSError:
        return "v?"


SERVER_VERSION = _read_version()  # 설정 → 고급 → 앱 정보 에 표시됩니다.
HERE = os.path.dirname(os.path.abspath(__file__))


def _version_code():
    """versionName(1.3) → 숫자(103). 폰 앱은 환경변수로 더 정확히 넘겨줌."""
    env = os.environ.get("ASSET_APP_VERSIONCODE")
    if env and env.isdigit():
        return int(env)
    try:
        parts = SERVER_VERSION.lstrip("v").split(".")
        return int(parts[0]) * 100 + (int(parts[1]) if len(parts) > 1 else 0)
    except (ValueError, IndexError):
        return 0


# 클라우드에 둔 '관리 파일'(update.json) 주소. 여기에 한 번 넣으면 PC·폰 앱 모두 이 주소를 씁니다.
# 비워 두면 업데이트 확인·사용 잠금 없이 평소대로 작동합니다.
# ※ 반드시 '로그인 없이' 열리는 주소여야 합니다(비공개 저장소 주소는 404 → 모든 앱이 잠김).
UPDATE_URL_DEFAULT = "https://raw.githubusercontent.com/royaljun666-maker/MIOS/main/update.json"


def _update_url():
    """관리 파일 주소. 우선순위: 환경변수 → update_url.txt → UPDATE_URL_DEFAULT."""
    env = (os.environ.get("ASSET_UPDATE_URL") or "").strip()
    if env.startswith("http"):
        return env
    try:
        with open(os.path.join(HERE, "update_url.txt"), encoding="utf-8") as f:
            u = f.read().strip()
            if u.startswith("http"):
                return u
    except OSError:
        pass
    return UPDATE_URL_DEFAULT if UPDATE_URL_DEFAULT.startswith("http") else None
WEB_DIR = os.environ.get("ASSET_WEB_DIR") or os.path.join(HERE, "web")  # 폰 앱은 화면 파일 위치를 따로 넘겨줌

# ── DART(전자공시) OpenAPI 키 (선택) ─────────────────────────────────────
# 한국 기업의 '공식 확정 재무'(영업이익·순이익·자본 → ROE) 다년치를 받는 무료 키.
# 앱 ⚙️ 설정 → '고급'에서 넣습니다(opendart.fss.or.kr 무료 발급). 없으면 DART 정보만 빠집니다.
DART_API_KEY = (os.environ.get("DART_API_KEY")
                or (ai_engine.load_settings().get("dart_key") or "").strip() or None)

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0 Safari/537.36"
    ),
    "Referer": "https://finance.naver.com/",
}

# 네이버 모바일/JSON API는 Referer·Origin을 확인합니다(없으면 409 StockConflict).
API_HEADERS = {
    "User-Agent": HEADERS["User-Agent"],
    "Referer": "https://m.stock.naver.com/",
    "Origin": "https://m.stock.naver.com",
    "Accept": "application/json",
}

# 야후 파이낸스 전용 헤더(네이버 Referer 제거 — 야후엔 방해됨)
YAHOO_HEADERS = {
    "User-Agent": HEADERS["User-Agent"],
    "Accept": "application/json,text/plain,*/*",
    "Accept-Language": "en-US,en;q=0.9",
}

# 간단 TTL 캐시 (반복 호출 줄여 속도 개선)
from concurrent.futures import ThreadPoolExecutor

_CACHE = {}

def _cache_get(key, ttl):
    v = _CACHE.get(key)
    if v and (time.time() - v[0]) < ttl:
        return v[1]
    return None

def _cache_set(key, val):
    _CACHE[key] = (time.time(), val)


# ── 야후 인증 세션(crumb+쿠키) ──────────────────────────────────────────
# 야후 quoteSummary/quote 는 이제 '쿠키 + crumb' 없이는 401을 던진다(PEG·ROE·영업이익이
# 안 나오던 주범). 한 번 쿠키를 받아 crumb 을 발급받고 30분 캐시해 재사용한다.
_YS = {"session": None, "crumb": None, "ts": 0.0}


def _yahoo_session():
    """(requests.Session, crumb) 반환. 실패 시 crumb=None(그래도 세션은 줌)."""
    now = time.time()
    if _YS["session"] is not None and _YS["crumb"] and (now - _YS["ts"]) < 1800:
        return _YS["session"], _YS["crumb"]
    s = requests.Session()
    s.headers.update(YAHOO_HEADERS)
    # 1) 쿠키 받기(여러 진입점 시도 — 한 곳이 막혀도 다른 곳에서 쿠키가 잡힘)
    for u in ("https://fc.yahoo.com",
              "https://finance.yahoo.com",
              "https://finance.yahoo.com/quote/AAPL"):
        try:
            s.get(u, timeout=TIMEOUT)
        except Exception:
            pass
        if s.cookies:
            break
    # 2) crumb 발급
    crumb = None
    for u in ("https://query2.finance.yahoo.com/v1/test/getcrumb",
              "https://query1.finance.yahoo.com/v1/test/getcrumb"):
        try:
            r = s.get(u, timeout=TIMEOUT)
            txt = (r.text or "").strip()
            if r.status_code == 200 and txt and "<" not in txt and len(txt) < 60:
                crumb = txt
                break
        except Exception:
            continue
    _YS["session"], _YS["crumb"], _YS["ts"] = s, crumb, now
    return s, crumb


def _decode_best(content: bytes) -> str:
    """헤더의 charset을 믿지 않고, 한글이 가장 많이/깨끗하게 나오는 인코딩을 고른다."""
    best, best_score = None, -10 ** 9
    for enc in ("utf-8", "euc-kr", "cp949"):
        try:
            t = content.decode(enc)
        except Exception:
            continue
        hangul = sum(1 for ch in t if "\uac00" <= ch <= "\ud7a3")
        broken = t.count("\ufffd")
        score = hangul - broken * 8
        if score > best_score:
            best, best_score = t, score
    return best if best is not None else content.decode("utf-8", errors="replace")
TIMEOUT = 6


# ---------------------------------------------------------------------------
# 공통
# ---------------------------------------------------------------------------
def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# 국내 종목코드: 숫자 6자리(005930) 또는 영문이 섞인 새 형식 6자리(0023B0 — 2025년 이후 상장 ETF 등)
_KR_CODE = re.compile(r"\d[0-9A-Z]{5}")


def normalize_kr(ticker: str) -> str:
    t = str(ticker).strip().upper()
    if t.endswith((".KS", ".KQ")):
        t = t[:-3]
    if _KR_CODE.fullmatch(t):
        return t                      # 영문 섞인 코드는 그대로 (글자를 지우면 전혀 다른 종목이 됨)
    digits = re.sub(r"[^0-9]", "", t)
    return digits.zfill(6)[-6:] if digits else t


def guess_market(ticker: str, market: str) -> str:
    m = (market or "").strip().lower()
    if m in ("kr", "us"):
        return m
    # 시장 미지정: 숫자만(또는 숫자로 시작하는 6자리 국내 코드)이면 한국, 아니면 미국으로 추정
    t = str(ticker).strip().upper()
    return "kr" if (re.fullmatch(r"\d{1,6}", t) or _KR_CODE.fullmatch(t)) else "us"


# ---------------------------------------------------------------------------
# 가격
# ---------------------------------------------------------------------------
def _num_from(s):
    if s is None:
        return None
    m = re.search(r"-?\d[\d,]*\.?\d*", str(s))
    if not m:
        return None
    try:
        v = float(m.group(0).replace(",", ""))
        return v
    except Exception:
        return None


def _kr_fundamentals(d):
    """네이버 JSON에서 이름/PER/PBR/추정(Forward)PER 추출.
    국내는 totalInfos, 해외(worldstock)는 stockItemTotalInfos 에 들어있음."""
    name = per = pbr = fper = None
    if not isinstance(d, dict):
        return name, per, pbr, fper
    name = d.get("stockName") or d.get("name")
    infos = []
    for k in ("totalInfos", "stockItemTotalInfos", "totalInfo"):
        v = d.get(k)
        if isinstance(v, list):
            infos += v
    for it in infos:
        if not isinstance(it, dict):
            continue
        key = str(it.get("key") or it.get("title") or "")
        code = str(it.get("code") or "")
        low = (key + " " + code).lower()
        val = it.get("value")
        if "per" in low and ("추정" in key or "forward" in low or "fwd" in low or "est" in low):
            fper = fper if fper is not None else _num_from(val)
        elif key.upper() == "PER" or code.lower() == "per":
            per = per if per is not None else _num_from(val)
        elif key.upper() == "PBR" or code.lower() == "pbr":
            pbr = pbr if pbr is not None else _num_from(val)
    return name, per, pbr, fper


def price_kr(ticker: str) -> dict:
    code = normalize_kr(ticker)
    out = {"ticker": code, "market": "kr", "currency": "KRW", "price": None,
           "name": None, "per": None, "pbr": None, "forward_per": None,
           "peg": None, "roe": None, "op_income": None, "op_margin": None,
           "market_cap": None, "eps": None, "asof": None,
           "peg_growth": None, "peg_native": None, "peg_basis": None,
           "eps_f": None, "ltg": None, "eps_rev": None,
           "trend_class": None, "op_trend": None, "roe_trend": None,
           "val_warn": [], "val_srcs": [], "mcap_ccy": "KRW",
           "naver_url": f"https://finance.naver.com/item/main.naver?code={code}",
           "status": "fail", "checked_at": _now()}
    naver_d = None  # 통합 API 응답(시총·EPS 등 추가 추출에 재사용)

    # 1) 통합 API (UTF-8 JSON): 이름·PER·PBR·추정PER + 가격(백업). 두 주소 모두 시도.
    for u in (f"https://m.stock.naver.com/api/stock/{code}/integration",
              f"https://api.stock.naver.com/stock/{code}/integration"):
        try:
            r = requests.get(u, headers=API_HEADERS, timeout=TIMEOUT)
            r.raise_for_status()
            d = r.json()
            naver_d = d
            nm, per, pbr, fper = _kr_fundamentals(d)
            if nm and not out["name"]:
                out["name"] = str(nm).strip()
            if per is not None and out["per"] is None:
                out["per"] = per
            if pbr is not None and out["pbr"] is None:
                out["pbr"] = pbr
            if fper is not None and out["forward_per"] is None:
                out["forward_per"] = fper
            cp = d.get("closePrice") if isinstance(d, dict) else None
            if isinstance(cp, str) and cp and out["price"] is None:
                v = _num_from(cp)
                if v and v > 0:
                    out["price"] = int(v)
                    out["status"] = "ok"
            if out["per"] is not None or out["pbr"] is not None:
                break  # 펀더멘털을 얻었으면 충분
        except Exception:
            continue

    # 2) 실시간 폴링 JSON으로 현재가 갱신(이름 백업)
    try:
        u = f"https://polling.finance.naver.com/api/realtime/domestic/stock/{code}"
        r = requests.get(u, headers=API_HEADERS, timeout=TIMEOUT)
        r.raise_for_status()
        d = r.json()
        datas = (d.get("datas") or []) if isinstance(d, dict) else []
        if datas:
            row = datas[0]
            if not out["name"] and (row.get("nm") or row.get("name") or row.get("stockName")):
                out["name"] = str(row.get("nm") or row.get("name") or row.get("stockName")).strip()
            nv = row.get("nv") or row.get("closePrice")
            if nv is not None:
                v = int(str(nv).replace(",", ""))
                if v > 0:
                    out["price"] = v
                    out["status"] = "ok"
            fr = row.get("fluctuationsRatioRaw") or row.get("fluctuationsRatio")
            if fr not in (None, ""):
                try:
                    out["change_pct"] = round(float(str(fr).replace(",", "")), 2)
                except ValueError:
                    pass
    except Exception:
        pass

    # 3) HTML 폴백 (가격/이름). 인코딩 헤더 무시, 한글 우선 디코딩.
    if out["price"] is None or out["name"] is None:
        try:
            u = f"https://finance.naver.com/item/main.naver?code={code}"
            r = requests.get(u, headers=HEADERS, timeout=TIMEOUT)
            r.raise_for_status()
            soup = BeautifulSoup(_decode_best(r.content), "html.parser")
            if out["name"] is None:
                nm = soup.select_one(".wrap_company h2 a") or soup.select_one(".wrap_company h2")
                if nm and nm.get_text(strip=True):
                    out["name"] = nm.get_text(strip=True)
            if out["price"] is None:
                tag = soup.select_one("p.no_today span.blind")
                if tag:
                    v = int(tag.get_text(strip=True).replace(",", ""))
                    if v > 0:
                        out["price"] = v
                        out["status"] = "ok"
        except Exception as e:
            if out["status"] == "fail":
                out["status"] = f"fail: {type(e).__name__}"

    # 4) 펀더멘털 묶음(시총·EPS·PEG·ROE·영업이익): 야후(.KS/.KQ, 숫자 원본) + 네이버 보강
    try:
        fb = _fund_bundle(code, "kr", naver_dict=naver_d)
        if out["per"] is None:
            out["per"] = fb.get("per")
        if out["pbr"] is None:
            out["pbr"] = fb.get("pbr")
        if out["forward_per"] is None:
            out["forward_per"] = fb.get("fper")
        for k in ("peg", "roe", "op_income", "op_margin", "market_cap", "eps", "asof",
                  "peg_growth", "peg_native", "peg_basis", "eps_f", "ltg", "eps_rev",
                  "trend_class", "op_trend", "roe_trend", "val_warn", "val_srcs"):
            out[k] = fb.get(k)
        out["mcap_ccy"] = fb.get("ccy") or "KRW"
    except Exception:
        pass
    return out


def _naver_world_code(ticker):
    """미국 티커 → 네이버 해외 심볼(reutersCode, 예: AAPL.O / ETN.N). 실패 시 None."""
    t = str(ticker).upper().strip()
    ck = "wcode:" + t
    cached = _cache_get(ck, 86400)  # 심볼은 잘 안 변함 → 하루 캐시
    if cached is not None:
        return cached or None
    result = None
    for u in (f"https://api.stock.naver.com/stock/search?query={t}&pageSize=10&page=1",
              f"https://m.stock.naver.com/front-api/search/autoComplete?query={t}&target=stock"):
        try:
            r = requests.get(u, headers=API_HEADERS, timeout=TIMEOUT)
            r.raise_for_status()
            d = r.json()
            cands = []
            def collect(x):
                if isinstance(x, list):
                    for e in x:
                        collect(e)
                elif isinstance(x, dict):
                    if x.get("reutersCode") or x.get("symbolCode") or x.get("code"):
                        cands.append(x)
                    for v in x.values():
                        if isinstance(v, (list, dict)):
                            collect(v)
            collect(d)
            for c in cands:
                rc = str(c.get("reutersCode") or c.get("symbolCode") or c.get("code") or "")
                if rc.split(".")[0].upper() == t:
                    result = rc
                    break
            if result:
                break
        except Exception:
            continue
    _cache_set(ck, result or "")  # 실패(None)도 빈문자열로 캐시해 반복 조회 방지
    return result


def _us_fundamentals_naver(ticker, code=None):
    """네이버 해외 통합 API에서 PER/PBR/추정PER. 실패 시 (None,None,None)."""
    code = code or _naver_world_code(ticker)
    t = str(ticker).upper().strip()
    syms = []
    for s in ([code] if code else []) + [t + ".O", t + ".N", t]:
        if s and s not in syms:
            syms.append(s)
    for sym in syms:
        for u in (f"https://api.stock.naver.com/stock/{sym}/basic",
                  f"https://api.stock.naver.com/stock/{sym}/integration",
                  f"https://m.stock.naver.com/api/stock/{sym}/basic"):
            try:
                r = requests.get(u, headers=API_HEADERS, timeout=TIMEOUT)
                r.raise_for_status()
                d = r.json()
                _, per, pbr, fper = _kr_fundamentals(d)
                if per is not None or pbr is not None:
                    return per, pbr, fper
            except Exception:
                continue
    return None, None, None


def _us_fundamentals(sym):
    """야후 quoteSummary(crumb 인증)에서 PER/PBR/추정PER + PEG/ROE/영업이익/영업이익률/시총.
    crumb+쿠키 세션을 사용해 401을 우회한다. 실패 시 빈 dict.
    반환 키: per, pbr, fper, peg, roe(%), op_income, op_margin(%), market_cap"""
    out = {}
    from urllib.parse import quote
    modules = ("summaryDetail,defaultKeyStatistics,financialData,"
               "price,incomeStatementHistory,earningsTrend")
    try:
        s, crumb = _yahoo_session()
        res = None
        for host in ("query1", "query2"):
            url = (f"https://{host}.finance.yahoo.com/v10/finance/quoteSummary/{sym}"
                   f"?modules={modules}&corsDomain=finance.yahoo.com&formatted=false")
            if crumb:
                url += "&crumb=" + quote(crumb, safe="")
            try:
                r = s.get(url, timeout=TIMEOUT)
                if r.status_code in (401, 403):
                    # 크럼 만료 추정 → 세션 새로 받아 한 번 더
                    _YS["crumb"] = None
                    s, crumb = _yahoo_session()
                    if crumb:
                        url2 = (f"https://{host}.finance.yahoo.com/v10/finance/quoteSummary/{sym}"
                                f"?modules={modules}&corsDomain=finance.yahoo.com&formatted=false"
                                f"&crumb=" + quote(crumb, safe=""))
                        r = s.get(url2, timeout=TIMEOUT)
                r.raise_for_status()
                j = r.json()
                if (j.get("quoteSummary") or {}).get("result"):
                    res = j["quoteSummary"]["result"][0]
                    break
            except Exception:
                continue
        if not res:
            return out

        sd = res.get("summaryDetail", {}) or {}
        ks = res.get("defaultKeyStatistics", {}) or {}
        fd = res.get("financialData", {}) or {}
        pr = res.get("price", {}) or {}
        ish = res.get("incomeStatementHistory", {}) or {}

        def g(d, k):
            v = d.get(k)
            return v.get("raw") if isinstance(v, dict) else v

        out["per"] = g(sd, "trailingPE")
        out["fper"] = g(sd, "forwardPE") or g(ks, "forwardPE")
        out["pbr"] = g(ks, "priceToBook")
        # ★ PEG: 고PER을 성장성과 교차검증하기 위한 핵심 숫자(마스터 철학)
        out["peg"] = g(ks, "pegRatio")
        if out["peg"] is None:
            out["peg"] = g(ks, "trailingPegRatio")
        roe = g(fd, "returnOnEquity")
        out["roe"] = round(roe * 100, 1) if isinstance(roe, (int, float)) else None
        opm = g(fd, "operatingMargins")
        out["op_margin"] = round(opm * 100, 1) if isinstance(opm, (int, float)) else None
        out["market_cap"] = g(pr, "marketCap") or g(sd, "marketCap")
        out["eps_t"] = g(ks, "trailingEps")          # 실적 EPS(TTM)
        out["eps_f"] = g(ks, "forwardEps")           # 추정 EPS(forward)
        out["price"] = g(pr, "regularMarketPrice")   # 현재가(역산 PER 검증용)
        stmts = ish.get("incomeStatementHistory", []) or []
        out["op_income"] = g(stmts[0], "operatingIncome") if stmts else None
        # 펀더멘털 '기준 시점'(확정 실적의 회계 기준일): 최신 손익계산서 endDate → 없으면 최근분기
        def _ts2ym(ts):
            try:
                from datetime import datetime, timezone
                return datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime("%Y-%m")
            except Exception:
                return None
        end0 = g(stmts[0], "endDate") if stmts else None
        out["asof"] = _ts2ym(end0) or _ts2ym(g(ks, "mostRecentQuarter"))
        # 장기성장률(5y) + 추정 EPS 상향/하향 트렌드("앞으로 돈 계속 벌까"의 핵심 신호)
        trend = (res.get("earningsTrend", {}) or {}).get("trend", []) or []

        def _find(per):
            for t in trend:
                if isinstance(t, dict) and t.get("period") == per:
                    return t
            return None
        t5 = _find("+5y")
        ltg = g(t5, "growth") if t5 else None
        out["ltg"] = round(ltg * 100, 1) if isinstance(ltg, (int, float)) else None
        t1 = _find("+1y")
        if t1:
            ep = t1.get("epsTrend", {}) or {}
            cur, old = g(ep, "current"), g(ep, "90daysAgo")
            if isinstance(cur, (int, float)) and isinstance(old, (int, float)) and old != 0:
                out["eps_rev"] = round((cur - old) / abs(old) * 100, 1)  # 최근 90일 추정EPS 변화율%
    except Exception:
        pass
    return out


# ── 펀더멘털 보조: 한글 금액/퍼센트 파싱 + 네이버 추가지표 + 통합 묶음 ──
_FUND_TTL = 3600  # 펀더멘털 1시간 캐시(분기마다 바뀌므로 매번 안 가져와도 됨)


def _parse_amount_kr(s):
    """'485조 4,321억' / '1,234억' / '12.3조' / 순수숫자 → 원(KRW) float. 실패 None."""
    if s is None:
        return None
    t = str(s).strip().replace(",", "").replace(" ", "")
    if not t:
        return None
    total, matched = 0.0, False
    for unit, mul in (("조", 1e12), ("억", 1e8), ("만", 1e4)):
        m = re.search(r"(-?\d+(?:\.\d+)?)" + unit, t)
        if m:
            total += float(m.group(1)) * mul
            matched = True
    if matched:
        return total
    m = re.fullmatch(r"-?\d+(?:\.\d+)?", t)
    return float(t) if m else None


def _parse_pct(s):
    """'12.34%' / '12.34' → 12.34 float. 실패 None."""
    if s is None:
        return None
    m = re.search(r"-?\d+(?:\.\d+)?", str(s).replace(",", ""))
    return float(m.group(0)) if m else None


def _naver_extra(d):
    """네이버 통합 응답 totalInfos에서 시가총액·EPS·ROE 추출(있는 것만). dict."""
    out = {"market_cap": None, "eps": None, "eps_f": None, "roe": None}
    if not isinstance(d, dict):
        return out
    infos = []
    for k in ("totalInfos", "stockItemTotalInfos", "totalInfo"):
        v = d.get(k)
        if isinstance(v, list):
            infos += v
    for it in infos:
        if not isinstance(it, dict):
            continue
        key = str(it.get("key") or it.get("title") or "")
        code = str(it.get("code") or "").lower()
        ku = key.upper()
        val = it.get("value")
        if out["market_cap"] is None and ("시가총액" in key or code in ("marketvalue", "marketcap")):
            out["market_cap"] = _parse_amount_kr(val)
        elif out["eps_f"] is None and ("추정" in key and "EPS" in ku):
            out["eps_f"] = _num_from(val)              # 추정(forward) EPS
        elif out["eps"] is None and (ku == "EPS" or code == "eps"):
            out["eps"] = _num_from(val)                # 실적 EPS
        elif out["roe"] is None and ("ROE" in ku or code == "roe"):
            out["roe"] = _parse_pct(val)
    return out


def _yahoo_symbols(ticker, market, world_code=None):
    """야후 quoteSummary용 심볼 후보. 한국은 .KS(코스피)·.KQ(코스닥), 미국은 티커 그대로."""
    t = str(ticker).strip().upper()
    is_kr = (market or "").lower() == "kr" or bool(re.fullmatch(r"\d{4,6}", t or ""))
    if is_kr:
        code = normalize_kr(t)
        return [code + ".KS", code + ".KQ"]
    return [t]


def _naver_kr_dict(code):
    """국내 종목 네이버 통합 응답(dict). 시총·EPS·PER/PBR 추출용. 실패 None."""
    for u in (f"https://m.stock.naver.com/api/stock/{code}/integration",
              f"https://api.stock.naver.com/stock/{code}/integration"):
        try:
            r = requests.get(u, headers=API_HEADERS, timeout=TIMEOUT)
            r.raise_for_status()
            d = r.json()
            if isinstance(d, dict):
                return d
        except Exception:
            continue
    return None


def _naver_world_dict(ticker, world_code=None):
    """미국 종목 네이버 해외 통합 응답(dict). EPS·PER/PBR 추출용(시총은 통화 모호 → 미사용). 실패 None."""
    code = world_code or _naver_world_code(ticker)
    t = str(ticker).upper().strip()
    syms = []
    for s in ([code] if code else []) + [t + ".O", t + ".N", t]:
        if s and s not in syms:
            syms.append(s)
    for sym in syms:
        for u in (f"https://api.stock.naver.com/stock/{sym}/integration",
                  f"https://api.stock.naver.com/stock/{sym}/basic"):
            try:
                r = requests.get(u, headers=API_HEADERS, timeout=TIMEOUT)
                r.raise_for_status()
                d = r.json()
                if isinstance(d, dict) and (d.get("totalInfos") or d.get("stockItemTotalInfos")):
                    return d
            except Exception:
                continue
    return None


def _fmt_n(v):
    """경고 메시지용 짧은 숫자 표기."""
    try:
        v = float(v)
    except (TypeError, ValueError):
        return str(v)
    if abs(v) >= 1e8:
        return f"{v/1e8:.0f}억"
    return f"{int(v)}" if v == int(v) else f"{v:.2f}"


def _avg(vals):
    vals = [v for v in vals if isinstance(v, (int, float))]
    return sum(vals) / len(vals) if vals else None


def _diverge(vals, ratio=1.5):
    vals = [abs(v) for v in vals if isinstance(v, (int, float)) and v != 0]
    return len(vals) >= 2 and (max(vals) / min(vals)) > ratio


def _verify_val(srcs):
    """여러 소스의 밸류에이션을 교차·평균하고 경고를 단다.
    각 소스 dict: src(이름)·per·fper·pbr·market_cap·eps_t·eps_f·peg_native·price.
    - PER/추정PER/PBR/시총: 값 있는 소스끼리 평균, 1.5배 이상 벌어지면 '소스 불일치' 경고.
    - PER 역산: 현재가 ÷ 실적EPS 와 보고 PER이 1.5배 이상 다르면 경고.
    - PEG: 소스별 (추정PER ÷ 1년 추정EPS성장률)로 '투명' 계산해 평균 + 성장률 공개.
            성장률이 비정상(>50% 또는 ≤0 — 시클리컬)이거나 이상치면 신뢰낮음 경고."""
    srcs = [s for s in srcs if s]
    out = {"per": None, "fper": None, "pbr": None, "market_cap": None,
           "peg": None, "peg_growth": None, "peg_native": None, "peg_basis": None,
           "eps_f": None, "ltg": None, "eps_rev": None,
           "sources": [s.get("src") for s in srcs], "warn": []}

    def col(k):
        return [s.get(k) for s in srcs if isinstance(s.get(k), (int, float))]

    for k, label in (("per", "PER"), ("fper", "추정PER"), ("pbr", "PBR"), ("market_cap", "시총")):
        vals = col(k)
        out[k] = _avg(vals)
        if _diverge(vals):
            out["warn"].append(label + " 소스 불일치(" + " vs ".join(_fmt_n(v) for v in vals) + ")")

    for s in srcs:
        p, e, rep = s.get("price"), s.get("eps_t"), s.get("per")
        if all(isinstance(x, (int, float)) for x in (p, e, rep)) and e > 0 and rep > 0:
            bc = p / e
            if bc / rep > 1.5 or rep / bc > 1.5:
                out["warn"].append(s.get("src", "?") + " PER 역산 불일치(보고 "
                                   + _fmt_n(rep) + " vs 역산 " + _fmt_n(bc) + ")")

    # 투명 PEG: 분모 우선순위 = 장기성장(5y) > 1년 성장. 보류하지 않고, '어느 성장 기준'인지 함께 보고.
    pegs, growths, bases = [], [], []
    eps_fs, ltgs, revs = [], [], []
    for s in srcs:
        f, et, ef = s.get("fper"), s.get("eps_t"), s.get("eps_f")
        ltg = s.get("ltg")
        if isinstance(ef, (int, float)):
            eps_fs.append(ef)
        if isinstance(ltg, (int, float)):
            ltgs.append(ltg)
        if isinstance(s.get("eps_rev"), (int, float)):
            revs.append(s.get("eps_rev"))
        if not (isinstance(f, (int, float)) and f > 0):
            continue
        gr, basis = None, None
        if isinstance(ltg, (int, float)) and ltg > 0:
            gr, basis = ltg, "5년"
        elif all(isinstance(x, (int, float)) for x in (et, ef)) and et > 0:
            g1 = (ef / et - 1) * 100
            if g1 > 0:
                gr, basis = g1, "1년"
        if gr is not None:
            pegs.append(f / gr)
            growths.append(gr)
            bases.append(basis)
    natives = col("peg_native")
    if pegs:
        out["peg"] = round(_avg(pegs), 2)
        out["peg_growth"] = round(_avg(growths), 1)
        out["peg_basis"] = bases[0] if bases else None
    elif natives:
        out["peg"] = round(_avg(natives), 2)
        out["peg_basis"] = "출처"
    out["peg_native"] = round(_avg(natives), 2) if natives else None
    out["eps_f"] = round(_avg(eps_fs), 2) if eps_fs else None       # 추정(1년후) EPS
    out["ltg"] = round(_avg(ltgs), 1) if ltgs else None             # 장기성장률(5y)
    out["eps_rev"] = round(_avg(revs), 1) if revs else None         # 추정EPS 90일 변화율%

    g = out["peg_growth"]
    if isinstance(g, (int, float)) and out.get("peg_basis") == "1년" and (g > 50 or g <= 0):
        out["warn"].append("PEG는 1년 성장 기준(시클리컬이라 참고용)")
    if _diverge(pegs + natives, ratio=2.5):
        out["warn"].append("PEG 소스 격차 큼 — 참고만")
    return out


def _dart_parse_int(s):
    """'1,234,567' / '-1,234' / '△1,234' / '' → int 또는 None."""
    if s is None:
        return None
    t = str(s).strip().replace(",", "").replace(" ", "")
    if not t or t in ("-", "—"):
        return None
    neg = False
    if t.startswith("△") or t.startswith("(") and t.endswith(")"):
        neg = True
        t = t.strip("△()")
    if t.startswith("-"):
        neg = True
        t = t[1:]
    try:
        v = int(float(t))
        return -v if neg else v
    except ValueError:
        return None


_DART_CORP = {"map": None, "ts": 0.0}


def _dart_corp_map():
    """stock_code(6자리) → corp_code(8자리) 매핑. corpCode.xml(zip) 1회 받아 파일·메모리 캐시."""
    if _DART_CORP["map"] is not None and (time.time() - _DART_CORP["ts"]) < 86400:
        return _DART_CORP["map"]
    cache_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dart_corp.json")
    if os.environ.get("ASSET_DATA_DIR"):  # 폰 앱: 쓸 수 있는 앱 저장 공간에 캐시
        cache_path = os.path.join(os.environ["ASSET_DATA_DIR"], "dart_corp.json")
    # 디스크 캐시(7일) 우선
    try:
        if os.path.exists(cache_path) and (time.time() - os.path.getmtime(cache_path)) < 7 * 86400:
            with open(cache_path, "r", encoding="utf-8") as f:
                m = json.load(f)
            if m:
                _DART_CORP["map"], _DART_CORP["ts"] = m, time.time()
                return m
    except Exception:
        pass
    if not DART_API_KEY:
        return {}
    m = {}
    try:
        import zipfile
        url = f"https://opendart.fss.or.kr/api/corpCode.xml?crtfc_key={DART_API_KEY}"
        r = requests.get(url, timeout=TIMEOUT + 10)
        r.raise_for_status()
        zf = zipfile.ZipFile(io.BytesIO(r.content))
        xml = zf.read(zf.namelist()[0])
        root = ET.fromstring(xml)
        for li in root.iter("list"):
            sc = (li.findtext("stock_code") or "").strip()
            cc = (li.findtext("corp_code") or "").strip()
            if sc and cc and sc != " " and len(sc) == 6:
                m[sc] = cc
        if m:
            try:
                with open(cache_path, "w", encoding="utf-8") as f:
                    json.dump(m, f)
            except Exception:
                pass
            _DART_CORP["map"], _DART_CORP["ts"] = m, time.time()
    except Exception:
        pass
    return m


def _dart_corp_code(stock_code):
    return _dart_corp_map().get(normalize_kr(stock_code))


def _dart_acnt(corp, year):
    """fnlttSinglAcnt(주요계정) 1회 → {year: {sales,op,ni,equity}} (당기/전기/전전기 3개년)."""
    out = {}
    try:
        url = ("https://opendart.fss.or.kr/api/fnlttSinglAcnt.json"
               f"?crtfc_key={DART_API_KEY}&corp_code={corp}&bsns_year={year}&reprt_code=11011")
        r = requests.get(url, timeout=TIMEOUT)
        j = r.json()
        if j.get("status") != "000":
            return out
        rows = j.get("list", []) or []
        fsd = "CFS" if any(x.get("fs_div") == "CFS" for x in rows) else "OFS"  # 연결 우선
        want = {"매출액": "sales", "영업이익": "op", "당기순이익": "ni", "자본총계": "equity"}
        cols = {"thstrm_amount": year, "frmtrm_amount": year - 1, "bfefrmtrm_amount": year - 2}
        for x in rows:
            if x.get("fs_div") != fsd:
                continue
            nm = (x.get("account_nm") or "").replace(" ", "")
            if nm not in want:
                continue
            for col, y in cols.items():
                v = _dart_parse_int(x.get(col))
                if v is not None:
                    out.setdefault(y, {})[want[nm]] = v
    except Exception:
        pass
    return out


def _classify_trend(series):
    """연도별 영업이익 추세 분류 한 줄."""
    pts = [(y, series[y].get("op")) for y in sorted(series) if isinstance(series[y].get("op"), (int, float))]
    v = [p[1] for p in pts]
    if len(v) < 3:
        return "데이터부족", pts
    rec = v[-3:]
    if rec[2] > rec[1] > rec[0]:
        return "우상향(최근 3년 연속 증가)", pts
    if rec[2] < rec[1] < rec[0]:
        return "우하향(최근 3년 연속 감소)", pts
    pos = [x for x in v if x > 0] or [1]
    if max(v) / min(pos) > 3 or (min(v) < 0 < max(v)):
        return "시클리컬(변동 큼/적자 전환 이력)", pts
    return "혼조(뚜렷한 추세 없음)", pts


_DART_FIN_TTL = 6 * 3600


def _dart_financials(stock_code):
    """DART에서 다년치 영업이익·순이익·매출·자본 + ROE + 추세. 실패 시 None."""
    if not DART_API_KEY:
        return None
    ck = "dart:" + normalize_kr(stock_code)
    c = _cache_get(ck, _DART_FIN_TTL)
    if c is not None:
        return c or None
    corp = _dart_corp_code(stock_code)
    if not corp:
        _cache_set(ck, "")
        return None
    series = {}
    yr = datetime.now().year
    for base in (yr - 1, yr - 2, yr - 4):  # 겹쳐서 ~6개년 확보(미신고 연도는 자동 skip)
        d = _dart_acnt(corp, base)
        for y, vals in d.items():
            series.setdefault(y, {}).update(vals)
    if not series:
        _cache_set(ck, "")
        return None
    # ROE·영업이익률 연도별
    for y, v in series.items():
        if isinstance(v.get("ni"), (int, float)) and isinstance(v.get("equity"), (int, float)) and v["equity"]:
            v["roe"] = round(v["ni"] / v["equity"] * 100, 1)
        if isinstance(v.get("op"), (int, float)) and isinstance(v.get("sales"), (int, float)) and v["sales"]:
            v["opm"] = round(v["op"] / v["sales"] * 100, 1)
    cls, op_pts = _classify_trend(series)
    latest = max(series)
    out = {"corp_code": corp, "latest_year": latest, "series": series,
           "op_income": series[latest].get("op"), "roe": series[latest].get("roe"),
           "op_margin": series[latest].get("opm"), "asof": f"{latest}-12",
           "trend_class": cls,
           "op_trend": [(y, series[y].get("op")) for y in sorted(series)],
           "roe_trend": [(y, series[y].get("roe")) for y in sorted(series)]}
    _cache_set(ck, out)
    return out


def _fund_bundle(ticker, market, naver_dict=None, world_code=None):
    """PER/PBR/추정PER/PEG/ROE/영업이익/영업이익률/시총/EPS 통합 묶음.
    1순위: 야후 quoteSummary(crumb 인증; .KS/.KQ 또는 미국 티커 — 숫자 원본, 통화 일관).
    보강:  네이버 totalInfos(PER/PBR·EPS, 그리고 한국은 시총·ROE까지).
    1시간 캐시. 통화(ccy)는 한국=KRW, 미국=USD."""
    is_kr = (market or "").lower() == "kr" or bool(re.fullmatch(r"\d{4,6}", str(ticker).strip() or ""))
    ck = "fund:" + str(ticker).upper() + ":" + ("kr" if is_kr else "us")
    cached = _cache_get(ck, _FUND_TTL)
    if cached is not None:
        return cached
    out = {"per": None, "pbr": None, "fper": None, "peg": None, "roe": None,
           "op_income": None, "op_margin": None, "market_cap": None, "eps": None,
           "asof": None, "peg_growth": None, "peg_native": None, "peg_basis": None,
           "eps_f": None, "ltg": None, "eps_rev": None,
           "trend_class": None, "op_trend": None, "roe_trend": None,
           "val_warn": [], "val_srcs": [], "ccy": "KRW" if is_kr else "USD"}
    # 네이버 dict 확보(미국은 해외 통합, 한국은 통합) — 야후가 막혀도 PER/PBR·EPS는 건진다
    if naver_dict is None:
        try:
            naver_dict = (_naver_kr_dict(normalize_kr(ticker)) if is_kr
                          else _naver_world_dict(ticker, world_code))
        except Exception:
            naver_dict = None

    # ── 소스 ① 야후 ──
    yf = {}
    for sym in _yahoo_symbols(ticker, market, world_code):
        cand = _us_fundamentals(sym)
        if cand and (cand.get("per") is not None or cand.get("market_cap") is not None
                     or cand.get("roe") is not None):
            yf = cand
            break
    # ── 소스 ② 네이버 ──
    nx = _naver_extra(naver_dict) if naver_dict is not None else {}
    nm, nper, npbr, nfper = (_kr_fundamentals(naver_dict) if naver_dict is not None
                             else (None, None, None, None))

    # 단일성 지표(있는 쪽 사용): ROE·영업이익·EPS·기준시점
    out["roe"] = yf.get("roe") if yf.get("roe") is not None else nx.get("roe")
    out["op_income"] = yf.get("op_income")
    out["op_margin"] = yf.get("op_margin")
    out["asof"] = yf.get("asof")
    out["eps"] = yf.get("eps_t") if yf.get("eps_t") is not None else nx.get("eps")

    # ── 교차검증·평균 (PER/추정PER/PBR/시총/PEG) ──
    yahoo_src = {"src": "야후", "per": yf.get("per"), "fper": yf.get("fper"),
                 "pbr": yf.get("pbr"), "market_cap": yf.get("market_cap"),
                 "eps_t": yf.get("eps_t"), "eps_f": yf.get("eps_f"),
                 "ltg": yf.get("ltg"), "eps_rev": yf.get("eps_rev"),
                 "peg_native": yf.get("peg"), "price": yf.get("price")}
    naver_src = {"src": "네이버", "per": nper, "fper": nfper, "pbr": npbr,
                 "market_cap": (nx.get("market_cap") if is_kr else None),  # 미국 시총은 통화 모호 → 제외
                 "eps_t": nx.get("eps"), "eps_f": nx.get("eps_f"),
                 "ltg": None, "eps_rev": None,
                 "peg_native": None, "price": None}
    v = _verify_val([yahoo_src, naver_src])
    out["per"] = v["per"]
    out["fper"] = v["fper"]
    out["pbr"] = v["pbr"]
    out["market_cap"] = v["market_cap"]
    out["peg"] = v["peg"]
    out["peg_growth"] = v["peg_growth"]
    out["peg_native"] = v["peg_native"]
    out["peg_basis"] = v["peg_basis"]
    out["eps_f"] = v["eps_f"]
    out["ltg"] = v["ltg"]
    out["eps_rev"] = v["eps_rev"]
    out["val_warn"] = v["warn"]
    out["val_srcs"] = [s for s in v["sources"] if s]

    # ── DART(공식 확정 재무): 한국 종목의 영업이익·ROE·다년치 추세를 권위 있게 덮어씀 ──
    if is_kr:
        try:
            dt = _dart_financials(ticker)
            if dt:
                if dt.get("op_income") is not None:
                    out["op_income"] = dt["op_income"]
                if dt.get("roe") is not None:
                    out["roe"] = dt["roe"]
                if dt.get("op_margin") is not None:
                    out["op_margin"] = dt["op_margin"]
                if dt.get("asof"):
                    out["asof"] = dt["asof"]
                out["trend_class"] = dt.get("trend_class")
                out["op_trend"] = dt.get("op_trend")
                out["roe_trend"] = dt.get("roe_trend")
                out["val_srcs"] = out["val_srcs"] + ["DART"]
        except Exception:
            pass
    _cache_set(ck, out)
    return out


def _fmt_krw_big(v):
    """큰 원화 금액 → '485.1조원' / '3,200억원' / '5,400만원'. 실패 None."""
    try:
        v = float(v)
    except (TypeError, ValueError):
        return None
    a = abs(v)
    sgn = "-" if v < 0 else ""
    if a >= 1e12:
        return f"{sgn}{a/1e12:.1f}조원"
    if a >= 1e8:
        return f"{sgn}{a/1e8:,.0f}억원"
    if a >= 1e4:
        return f"{sgn}{a/1e4:,.0f}만원"
    return f"{sgn}{a:,.0f}원"


def _fmt_money_big(v, ccy):
    """통화에 맞춰 큰 금액 포맷. KRW=조/억원, 그 외=$T/B/M."""
    if (ccy or "USD").upper() == "KRW":
        return _fmt_krw_big(v)
    return _fmt_usd_big(v)


def price_us(ticker: str) -> dict:
    sym = str(ticker).strip().upper()
    out = {"ticker": sym, "market": "us", "currency": "USD", "price": None,
           "name": None, "per": None, "pbr": None, "forward_per": None,
           "peg": None, "roe": None, "op_income": None, "op_margin": None,
           "market_cap": None, "eps": None, "asof": None,
           "peg_growth": None, "peg_native": None, "peg_basis": None,
           "eps_f": None, "ltg": None, "eps_rev": None,
           "trend_class": None, "op_trend": None, "roe_trend": None,
           "val_warn": [], "val_srcs": [], "mcap_ccy": "USD",
           "naver_url": f"https://m.stock.naver.com/search/index?query={sym}",
           "status": "fail", "checked_at": _now()}
    # 1) 야후 차트 API (키 불필요)
    try:
        url = f"https://query1.finance.yahoo.com/v8/finance/chart/{sym}?range=1d&interval=1d"
        r = requests.get(url, headers=HEADERS, timeout=TIMEOUT)
        r.raise_for_status()
        meta = r.json()["chart"]["result"][0]["meta"]
        nm = meta.get("longName") or meta.get("shortName")
        if nm:
            out["name"] = nm
        price = meta.get("regularMarketPrice")
        if price:
            out["price"] = round(float(price), 4)
            out["status"] = "ok"
            pc = meta.get("chartPreviousClose") or meta.get("previousClose")
            if pc:
                out["change_pct"] = round((float(price) - float(pc)) / float(pc) * 100, 2)
    except Exception:
        pass
    # 2) 백업: stooq CSV (가격만)
    if out["price"] is None:
        try:
            url = f"https://stooq.com/q/l/?s={sym.lower()}.us&f=sd2t2ohlcv&h&e=csv"
            r = requests.get(url, headers=HEADERS, timeout=TIMEOUT)
            r.raise_for_status()
            rows = list(csv.DictReader(io.StringIO(r.text)))
            if rows and rows[0].get("Close") not in (None, "", "N/D"):
                out["price"] = round(float(rows[0]["Close"]), 4)
                out["status"] = "ok"
        except Exception as e:
            if out["status"] == "fail":
                out["status"] = f"fail: {type(e).__name__}"
    # 3) 펀더멘털 + 네이버 링크: 해외 심볼 1회 해석
    wcode = _naver_world_code(sym)
    out["naver_url"] = (f"https://m.stock.naver.com/worldstock/stock/{wcode}/total"
                        if wcode else f"https://m.stock.naver.com/search/index?query={sym}")
    per, pbr, fper = _us_fundamentals_naver(sym, wcode)
    out["per"], out["pbr"], out["forward_per"] = per, pbr, fper
    # 펀더멘털 묶음(PEG·ROE·영업이익·시총·EPS): 야후(미국 티커, 숫자 원본)
    try:
        fb = _fund_bundle(sym, "us", naver_dict=None, world_code=wcode)
        if out["per"] is None:
            out["per"] = fb.get("per")
        if out["pbr"] is None:
            out["pbr"] = fb.get("pbr")
        if out["forward_per"] is None:
            out["forward_per"] = fb.get("fper")
        for k in ("peg", "roe", "op_income", "op_margin", "market_cap", "eps", "asof",
                  "peg_growth", "peg_native", "peg_basis", "eps_f", "ltg", "eps_rev",
                  "trend_class", "op_trend", "roe_trend", "val_warn", "val_srcs"):
            out[k] = fb.get(k)
        out["mcap_ccy"] = fb.get("ccy") or "USD"
    except Exception:
        pass
    return out


def get_price(ticker: str, market: str) -> dict:
    return price_kr(ticker) if guess_market(ticker, market) == "kr" else price_us(ticker)


def get_fx() -> dict:
    """USD/KRW 환율. 야후(KRW=X) → 실패 시 stooq(usdkrw)."""
    out = {"pair": "USD/KRW", "rate": None, "status": "fail", "checked_at": _now()}
    try:
        url = "https://query1.finance.yahoo.com/v8/finance/chart/KRW=X?range=1d&interval=1d"
        r = requests.get(url, headers=HEADERS, timeout=TIMEOUT)
        r.raise_for_status()
        rate = r.json()["chart"]["result"][0]["meta"].get("regularMarketPrice")
        if rate:
            out["rate"] = round(float(rate), 2)
            out["status"] = "ok"
            return out
    except Exception:
        pass
    try:
        url = "https://stooq.com/q/l/?s=usdkrw&f=sd2t2ohlcv&h&e=csv"
        r = requests.get(url, headers=HEADERS, timeout=TIMEOUT)
        r.raise_for_status()
        rows = list(csv.DictReader(io.StringIO(r.text)))
        if rows and rows[0].get("Close") not in (None, "", "N/D"):
            out["rate"] = round(float(rows[0]["Close"]), 2)
            out["status"] = "ok"
    except Exception as e:
        out["status"] = f"fail: {type(e).__name__}"
    return out


# ---------------------------------------------------------------------------
# 뉴스
# ---------------------------------------------------------------------------
def google_news(query: str, hl: str, gl: str, ceid: str, limit: int = 40,
                within_days: int = None) -> list:
    """구글 뉴스 RSS(안정적인 XML)에서 제목/링크/날짜를 읽습니다.
    within_days 를 주면 'when:Nd' 연산자로 구글이 애초에 최근 N일만 검색하게 한다."""
    from urllib.parse import quote_plus
    q = query
    if within_days:
        q = f"{query} when:{int(within_days)}d"  # 구글 뉴스 최근 N일 검색 연산자
    items = []
    try:
        url = f"https://news.google.com/rss/search?q={quote_plus(q)}&hl={hl}&gl={gl}&ceid={ceid}"
        r = requests.get(url, headers=HEADERS, timeout=TIMEOUT)
        r.raise_for_status()
        root = ET.fromstring(r.content)
        for item in root.iter("item"):
            title = (item.findtext("title") or "").strip()
            link = (item.findtext("link") or "").strip()
            date = (item.findtext("pubDate") or "").strip()
            if title:
                items.append({"title": title, "url": link, "date": date})
            if len(items) >= limit:
                break
    except Exception:
        return []
    return items


def _parse_news_dt(date_str):
    """RFC822 pubDate → aware datetime. 실패 None."""
    if not date_str:
        return None
    try:
        from email.utils import parsedate_to_datetime
        from datetime import timezone
        dt = parsedate_to_datetime(date_str)
        if dt is None:
            return None
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None


def _sort_news_desc(items):
    """최신순(내림차순) 정렬. 날짜 없는 건 맨 뒤로."""
    from datetime import datetime, timezone
    floor = datetime.min.replace(tzinfo=timezone.utc)
    return sorted(items or [], key=lambda n: (_parse_news_dt(n.get("date")) or floor), reverse=True)


def _merge_news(primary, secondary):
    """두 뉴스 목록을 번갈아 끼워 합치고 제목 중복 제거(해외 시각이 위로 올라오게)."""
    out, seen = [], set()
    i = 0
    while i < max(len(primary), len(secondary)):
        for src in (primary, secondary):
            if i < len(src):
                t = src[i].get("title", "")
                key = re.sub(r"\s+", "", t)[:40]
                if t and key not in seen:
                    seen.add(key)
                    out.append(src[i])
        i += 1
    return out


MAX_NEWS_DAYS = 7  # ★ 하드 상한: 이보다 오래된 뉴스는 화면에도, AI 분석에도 일절 쓰지 않는다.


def _news_age_ok(date_str, days, strict=True):
    """date가 days일 이내면 True. strict면 '날짜 없음/파싱 실패/미래 날짜'는 제외(False).
    화면·AI에 쓰는 경로는 strict=True 로 호출해, 날짜를 못 믿는 오래된 뉴스를 걸러낸다."""
    if not date_str:
        return not strict
    try:
        from email.utils import parsedate_to_datetime
        from datetime import datetime, timezone
        dt = parsedate_to_datetime(date_str)
        if dt is None:
            return not strict
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        age = (datetime.now(timezone.utc) - dt).total_seconds()
        if age < -86400:  # 미래 날짜(파싱 오류) → 신뢰 못 함
            return not strict
        return age <= days * 86400 + 3600
    except Exception:
        return not strict


def _fresh(items, days=MAX_NEWS_DAYS, strict=True):
    """days일 이내(엄격)만 남긴다. 기본은 7일 하드 상한."""
    days = min(max(int(days or 1), 1), MAX_NEWS_DAYS)
    return [n for n in (items or []) if _news_age_ok(n.get("date"), days, strict)]


def _merge_many(lists):
    """여러 소스 뉴스 목록을 라운드로빈으로 섞고 제목 중복 제거(다양성 위해 번갈아 끼움)."""
    out, seen = [], set()
    maxlen = max((len(l) for l in lists), default=0)
    for i in range(maxlen):
        for l in lists:
            if i < len(l):
                t = (l[i].get("title") or "").strip()
                key = re.sub(r"\s+", "", t)[:40]
                if t and key not in seen:
                    seen.add(key)
                    out.append(l[i])
    return out


def _yahoo_news(symbols, limit=12):
    """야후 파이낸스 RSS 헤드라인(구글과 다른 소스 → 다양성 확보). 실패 시 []."""
    out = []
    for sym in symbols:
        try:
            url = (f"https://feeds.finance.yahoo.com/rss/2.0/headline?s={sym}"
                   "&region=US&lang=en-US")
            r = requests.get(url, headers=HEADERS, timeout=TIMEOUT)
            r.raise_for_status()
            root = ET.fromstring(r.content)
            for item in root.iter("item"):
                title = (item.findtext("title") or "").strip()
                link = (item.findtext("link") or "").strip()
                date = (item.findtext("pubDate") or "").strip()
                if title:
                    out.append({"title": title, "url": link, "date": date})
                if len(out) >= limit:
                    break
            if out:
                break
        except Exception:
            continue
    return out


def _within_days(date_str, days):
    """(레거시) 관대한 판정: 날짜 없음/파싱 실패는 포함(True). 신규 경로는 _news_age_ok 사용."""
    return _news_age_ok(date_str, days, strict=False)


def get_news_recent(ticker, market, name, days=2, min_keep=2):
    """최근 days일 뉴스만(엄격). 너무 적으면 7일까지만 넓힌다 — 절대 7일을 넘기지 않음."""
    allnews = get_news(ticker, market, name)  # 이미 7일 이내(엄격)로 걸러져 옴
    days = min(max(int(days or 1), 1), MAX_NEWS_DAYS)
    steps = sorted({days, min(days + 2, MAX_NEWS_DAYS), MAX_NEWS_DAYS})
    for d in steps:
        kept = _fresh(allnews, d, strict=True)
        if len(kept) >= min_keep or d >= MAX_NEWS_DAYS:
            return kept
    return _fresh(allnews, MAX_NEWS_DAYS, strict=True)


def get_news_hours(ticker, market, name, hours):
    """최근 hours시간 이내 뉴스만(엄격). 브리핑 기간 선택(12시간/3일/7일)용 — 넓히지 않음."""
    from datetime import datetime, timezone
    hours = min(max(int(hours or 12), 1), MAX_NEWS_DAYS * 24)
    out = []
    for n in get_news(ticker, market, name):
        dt = _parse_news_dt(n.get("date"))
        if dt is None:
            continue
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        age = (datetime.now(timezone.utc) - dt).total_seconds()
        if -3600 <= age <= hours * 3600:
            out.append(n)
    return out


def get_sector(ticker, market, name=""):
    """네이버에서 종목의 업종(섹터) 한글명. 실패 시 '기타'."""
    t = str(ticker).strip()
    ck = "sector:" + t + ":" + (market or "")
    cached = _cache_get(ck, 86400)
    if cached is not None:
        return cached
    sector = "기타"
    is_kr = guess_market(t, market) == "kr"
    urls = []
    if is_kr:
        code = normalize_kr(t)
        urls = [f"https://m.stock.naver.com/api/stock/{code}/basic",
                f"https://api.stock.naver.com/stock/{code}/basic"]
    else:
        wc = _naver_world_code(t) or (t.upper() + ".O")
        urls = [f"https://api.stock.naver.com/stock/{wc}/basic"]
    for u in urls:
        try:
            r = requests.get(u, headers=API_HEADERS, timeout=TIMEOUT)
            r.raise_for_status()
            d = r.json()
            ic = d.get("industryCodeType") if isinstance(d, dict) else None
            if isinstance(ic, dict) and ic.get("industryGroupKor"):
                sector = str(ic["industryGroupKor"]).strip()
                break
        except Exception:
            continue
    _cache_set(ck, sector)
    return sector


def get_news(ticker: str, market: str, name: str = "") -> list:
    """여러 각도(구글 뉴스 다중 쿼리)+다른 소스(야후 RSS)를 섞어 다양하게 가져온 뒤,
    ★ 7일을 넘는(또는 날짜 불명) 뉴스는 모두 제거하고 돌려준다(화면·AI 공통)."""
    name = (name or "").strip()
    ck = "news:" + (ticker or "") + ":" + (market or "") + ":" + name
    cached = _cache_get(ck, 600)  # 뉴스는 10분 캐시(반복 호출 제거)
    if cached:  # 빈 결과는 캐시하지 않음(일시 차단 시 0건이 굳는 것 방지)
        return cached

    is_kr = guess_market(ticker, market) == "kr"
    if is_kr:
        base = name if name else normalize_kr(ticker)
        # 같은 종목을 여러 각도로 — 서로 다른 매체/관점이 섞이게
        tasks = [
            (base + " 주가", "ko", "KR", "KR:ko", 18),
            (base + " 실적", "ko", "KR", "KR:ko", 10),
            (base + " 전망", "ko", "KR", "KR:ko", 10),
            (base + " Korea stock", "en-US", "US", "US:en", 12),  # 해외 시각
        ]
        ysyms = [normalize_kr(ticker) + ".KS", normalize_kr(ticker) + ".KQ"]
    else:
        base = name if name else str(ticker).upper()
        tasks = [
            (base + " stock", "en-US", "US", "US:en", 18),
            (base + " earnings", "en-US", "US", "US:en", 10),
            (base + " news", "en-US", "US", "US:en", 10),
        ]
        ysyms = [str(ticker).upper()]

    lists = []
    with ThreadPoolExecutor(max_workers=6) as ex:
        # 구글 뉴스 여러 각도 — 애초에 최근 7일만 검색(when:7d)
        futs = [ex.submit(google_news, t[0], t[1], t[2], t[3], t[4], MAX_NEWS_DAYS) for t in tasks]
        yfut = ex.submit(_yahoo_news, ysyms, 12)             # 야후 RSS(다른 소스)
        for f in futs:
            try:
                lists.append(f.result() or [])
            except Exception:
                lists.append([])
        try:
            lists.append(yfut.result() or [])
        except Exception:
            lists.append([])

    result = _merge_many(lists)                  # 다양한 소스 섞고 중복 제거
    result = _fresh(result, MAX_NEWS_DAYS, True)  # ★ 7일 하드 상한(오래된/날짜불명 제외)
    result = _sort_news_desc(result)             # 최신 기사가 위로
    if result:  # 성공한 경우에만 캐시
        _cache_set(ck, result)
    return result


# ---------------------------------------------------------------------------
# AI 인사이트 (수색자 = 사실 분류 + 규칙 낭독, 조언 금지)
# ---------------------------------------------------------------------------
#  ★ 키는 앱 화면 ⚙️ 설정 → 'AI 연결'에서 넣습니다(이 PC의 userdata/settings.json 에만 저장).
#     예전 방식(환경변수 GEMINI_API_KEY 등)도 그대로 동작합니다.
#  실제 호출·여러 AI 회사 지원·자동 대체는 ai_engine.py 가 담당합니다.

AI_TIMEOUT = ai_engine.AI_TIMEOUT


def _ai_config():
    """키 존재 확인용 — 첫 후보 (provider, key, model). 없으면 (None, None, None)."""
    c = ai_engine.candidates()
    return (c[0][0], c[0][1] or "local", c[0][2]) if c else (None, None, None)


# 무료·가벼운 모델도 형식을 안 깨고 답하도록 매번 붙이는 공통 지시
_FORMAT_SYSTEM = (
    "당신은 한국어로 답하는 투자 비서입니다. 아주 중요한 규칙:\n"
    "1) 사용자가 준 '## 제목'들을 하나도 빠뜨리지 말고, 글자 그대로, 준 순서대로 쓰세요.\n"
    "2) 각 제목 아래 내용을 채우세요. 제목을 바꾸거나 합치거나 새 제목을 만들지 마세요.\n"
    "3) '방향: 상승 70%'처럼 형식을 정확히 지정한 줄은 그 형식 그대로 쓰세요.\n"
    "4) 영어로 쓰지 말고 쉬운 한국어로. 인사말·사과·맺음말 없이 바로 내용만.")

# JSON으로만 답해야 하는 기능(브리핑·발굴)에 붙이는 지시
_JSON_SYSTEM = (
    "당신은 한국어 투자 비서입니다. 반드시 사용자가 지정한 JSON 배열 '하나'로만 답하세요.\n"
    "코드펜스(```), 설명, 인사말 없이 '[' 로 시작해 ']' 로 끝내세요. 모든 글자는 쉬운 한국어로.")


# AI 설명 방식 — 사용자의 주식 실력에 맞춰 답변의 길이·깊이·내용 자체를 바꿈.
# 화면이 'X-AI-Depth' 머리글로 보냄 (간략·쉽게·진중·전문가·선생님). (값, 길이 배율)
DEPTH_GUIDE = {
    "brief": ("""[설명 방식: 간략하게 — 바쁜 사용자]
- 형식(제목·JSON 등)은 그대로. 각 항목은 1~2줄, 결론·확률·할 일·핵심 근거만.
- 설명·비유·반복은 빼고 숫자와 결론 위주로.""", 0.8),
    "easy": ("""[설명 방식: 쉽게 — 주식 초보]
- 형식은 그대로 지키되, 항목마다 2~4줄로 충분히 풀어서. 짧게 끊지 마세요.
- 모든 전문용어는 괄호로 쉬운 뜻, 숫자는 '그래서 좋은 건지 나쁜 건지'까지.
- 생활 비유를 1~2개 넣어 감이 오게. 초보가 다음에 무엇을 확인하면 되는지도 한 줄.""", 1.4),
    "serious": ("""[설명 방식: 진중하게 — 신중한 투자자]
- 형식은 그대로 지키되, 항목마다 3~5줄로 근거를 꼼꼼히. 과장·유행어·이모지 남발 금지.
- 좋은 근거와 반대 근거를 함께, 위험 요인은 발생 가능성과 영향 크기까지.
- 가능한 곳에 '낙관 / 기본 / 비관' 세 가지 시나리오와 각 확률을 붙이세요(JSON이면 insight 안에 짧게).""", 1.7),
    "expert": ("""[설명 방식: 전문가처럼 — 경험 많은 투자자]
- 형식은 그대로 지키되, 증권사 리포트 수준으로 상세히. 전문 용어(PER·PBR·EV/EBITDA·컨센서스·수급·이평 배열·RSI·MACD 등)를 그대로 써도 됩니다.
- 밸류에이션(과거 평균·업종 대비), 실적 추정 방향, 외국인·기관 수급, 기술적 수치, 업종·경쟁사 비교, 다가오는 촉매(실적일·정책·지표 발표)를 짚으세요.
- 항목마다 3~6줄, 숫자 근거를 최대한 많이. 단, 자료에 없는 숫자는 지어내지 말고 '자료 없음'.""", 1.9),
    "teacher": ("""[설명 방식: 선생님처럼 — 배우고 싶은 사용자]
- 형식은 그대로 지키되, 항목마다 '무엇 → 왜 그런지 → 예를 들면' 순서로 3~5줄 차근차근.
- 처음 나오는 개념은 한 번씩 정의해 주고, 이 종목 숫자로 직접 계산하듯 보여 주세요.
- 마지막에 '📚 오늘의 투자 공부:' 한 단락(3줄 안팎)으로 오늘 배운 개념을 정리(JSON 답변이면 insight 안에 한 줄).""", 1.7),
}


def depth_rule(depth):
    return DEPTH_GUIDE.get((depth or "").strip(), DEPTH_GUIDE["easy"])


def _req_depth():
    try:
        from flask import request as _rq
        return _rq.headers.get("X-AI-Depth", "")
    except Exception:
        return ""


def _ai_complete(prompt: str, max_out: int = 1000, system: str = _FORMAT_SYSTEM):
    """반환: (text, provider, model, error) — 성공 시 error=None.
    사용자가 고른 설명 방식(간략·쉽게·진중·전문가·선생님)을 지시문에 붙이고, 답변 길이 한도도 그만큼 늘림."""
    rule, mult = depth_rule(_req_depth())
    system = (system or "") + "\n" + rule
    prof = ai_engine.req_profile_text()      # 투자자 설문(나이·직업·목적·경험·위험 감내) — 모든 분석에 반영
    if prof:
        system += "\n" + prof
    max_out = min(8192, int(max_out * mult))
    return ai_engine.complete(prompt=prompt, max_out=max_out, temperature=0.6, system=system)


def _fmt_usd_big(v):
    """큰 달러 숫자를 사람이 읽기 쉽게: 3.21T / 845.0B / 12.3M / 1,234."""
    try:
        v = float(v)
    except (TypeError, ValueError):
        return None
    a = abs(v)
    sgn = "-" if v < 0 else ""
    if a >= 1e12:
        return f"{sgn}${a/1e12:.2f}T"
    if a >= 1e9:
        return f"{sgn}${a/1e9:.1f}B"
    if a >= 1e6:
        return f"{sgn}${a/1e6:.1f}M"
    return f"{sgn}${a:,.0f}"


def _fund_line(f):
    """프롬프트용 지표 블록. 미래(추정)/실적을 명확히 구분 + PEG 성장 기준 공개 + 기준 시점."""
    def s(v, suf=""):
        return (f"{v}{suf}" if v is not None else "데이터없음")
    ccy = f.get("ccy") or f.get("mcap_ccy") or "USD"
    asof = f.get("asof") or "기준시점 불명"
    peg = s(f.get("peg"))
    basis = f.get("peg_basis")
    gr = f.get("peg_growth")
    peg_note = ""
    if isinstance(gr, (int, float)):
        peg_note = f" ({basis or '?'} 성장 {gr}% 기준)" if basis else f" (성장 {gr}% 기준)"
    nat = f.get("peg_native")
    nat_note = f" / 출처PEG {nat}" if isinstance(nat, (int, float)) else ""
    val = (f"PER(실적) {s(f.get('per'))} · 추정PER(향후1년) {s(f.get('forward_per'))} · "
           f"PBR {s(f.get('pbr'))} · PEG {peg}{peg_note}{nat_note} · "
           f"시총 {_fmt_money_big(f.get('market_cap'), ccy) or '데이터없음'}")
    rev = f.get("eps_rev")
    rev_note = ""
    if isinstance(rev, (int, float)):
        arrow = "상향" if rev > 1 else ("하향" if rev < -1 else "보합")
        rev_note = f" · 추정EPS 90일 {rev:+.1f}%({arrow})"
    fund = (f"ROE {s(f.get('roe'), '%')} · 영업이익률 {s(f.get('op_margin'), '%')} · "
            f"영업이익 {_fmt_money_big(f.get('op_income'), ccy) or '데이터없음'} · "
            f"EPS(실적) {s(f.get('eps'))} · 추정EPS(향후1년) {s(f.get('eps_f'))}{rev_note}  "
            f"(확정 실적 기준: {asof})")
    # DART 다년치 영업이익 추세(있으면) — '돈 계속 벌까'의 구조적 근거
    trend = f.get("op_trend")
    tcls = f.get("trend_class")
    if trend:
        parts = [f"{y} {_fmt_money_big(val, ccy)}" for y, val in trend if isinstance(val, (int, float))]
        if parts:
            fund += "\n[영업이익 다년 추세(DART 공식)] " + " → ".join(parts) + (f"  · 분류: {tcls}" if tcls else "")
    return val, fund


# 초보자도 바로 알아듣는 말투 — 모든 AI 답변에 공통으로 붙는 규칙
EASY_RULES = """[말투 규칙 — 반드시 지킬 것]
- 투자를 처음 하는 사람도 한 번에 알아듣게, 쉬운 우리말로 짧게 쓰세요. 한 줄에 한 가지 내용.
- 전문용어는 피하고, 꼭 쓰면 바로 뒤 괄호에 쉬운 뜻을 붙이세요. 예: PER(주가가 1년 이익의 몇 배인지)
- 숫자에는 의미를 붙이세요. 예: "영업이익률 52% → 100원 팔면 52원이 남는 아주 높은 수준"
- 자료에 없는 사실은 지어내지 마세요. 모르면 "자료로는 알 수 없어요"라고 쓰세요.
- 아부·과장 금지. 좋은 점과 나쁜 점을 똑같이 솔직하게.
- 애매하게 돌려 말하지 말고 결론을 분명하게 말하세요."""


# 마음 급한 한국 투자자용 — '그래서 사? 말아? 언제?'에 바로 답하는 투자비서 말투
QUICK_RULES = """[투자비서 규칙 — 반드시 지킬 것]
- 바쁜 한국 투자자용입니다. 첫 줄에 결론부터. "그래서 사? 말아? 지금? 언제?"에 3초 안에 답이 되게.
- 숫자로 구체적으로: 확률, 현재가 대비 몇 %, 참고 가격대처럼. "상황을 지켜보자" 같은 빈말 금지.
- 뉴스는 '사실 → 주가에 주는 영향(오름/내림 · 강/중/약 · 얼마나 오래)'까지 꼭 이어서 말하세요.
- 시장 흐름(금리·환율·반도체/업종 분위기·외국인 수급·세계 이슈)과 연결해서 '왜 지금 이 뉴스가 중요한지' 설명.
- 확률은 '느낌'으로 고르지 말고 아래 점수표로 계산한 1% 단위 숫자를 쓰세요 (예: 37%, 58%, 73%, 84%).
  기본 50에서 시작 → 항목마다 더하고 빼기: 추세(이동평균·주가 위치) ±0~12 / 실적·성장 ±0~10 / 주가 수준(싸다·비싸다) ±0~8
  / 뉴스·재료 ±0~10 / 시장·업종 분위기 ±0~8 / 수급·거래량 ±0~6 / 위험(악재·변동성) -0~10 → 합계를 10~90으로 자르기.
- 55·60·65처럼 5로 끝나는 숫자, 50은 쓰지 마세요. 55~65 사이에 몰아서 답하지 말고, 근거가 한쪽으로 쏠리면 75~88이나 15~30처럼 과감하게.
  반대로 근거가 정말 엇갈릴 때만 45~55 근처.
- 의견은 확률과 맞춰야 해요: 72% 이상 → 매수 쪽, 40% 이하 → 비중 축소·매도 쪽, 그 사이 → 분할 매수·보유.
- 참고 가격대(매수·손절·목표)는 현재가 기준 %와 가격으로. 단, 어디까지나 참고선이라는 점을 짧게 밝히세요."""

# 투자 성향별 — 보는 것과 판단 기간이 다름
STYLE_GUIDE = {
    "long": "장기투자(1년 이상): 회사가 꾸준히 돈을 버는 힘, 성장성, 주가가 싼지(밸류에이션)가 핵심. 단기 등락은 무시하고 분할 매수 관점.",
    "swing": "스윙매매(몇 주~3개월): 실적 발표·업황 흐름, 주가 추세(이동평균), 거래량, 다가오는 재료(실적일·정책)를 봄.",
    "day": "단타(하루~1주): 오늘·이번 주 뉴스 재료, 거래량 급증, 테마 순환, 수급(외국인·기관)과 변동성. 손절 기준이 생명.",
    "scalp": "스캘핑(몇 분~하루): 장중 재료·호가 흐름·변동성만. ※이 앱 시세는 15~20분 늦어 실제 매매 타이밍엔 못 씀 — 분위기·재료 파악용.",
}
STYLE_LABEL = {"long": "장기투자", "swing": "스윙매매", "day": "단타", "scalp": "스캘핑"}
STYLE_HORIZON = {"long": "앞으로 1년", "swing": "앞으로 1~3개월", "day": "앞으로 1주일", "scalp": "오늘~내일"}

# 종목 발굴 — 성향마다 '고르는 기준'이 완전히 달라서 후보가 겹치지 않게 함
DISCOVER_RULES = {
    "long": {
        "pick": [
            "3~5년 이상 커질 큰 흐름(메가트렌드) 한가운데 있고, 그 흐름에서 1~2등 하는 회사",
            "최근 3년 매출·영업이익이 꾸준히 늘었고 적자가 아님, ROE(자기자본이익률) 10% 이상이 이상적",
            "부채가 과하지 않고 현금을 잘 버는 회사, 배당이나 자사주 매입 같은 주주환원이 있으면 가점",
            "경쟁사가 쉽게 못 따라오는 강점(기술·브랜드·점유율·규제 장벽)이 있음",
            "지금 주가가 이익에 비해 과하게 비싸지 않음(업종 평균·과거 평균과 비교)",
            "단기 등락과 상관없이 몇 년 들고 가며 분할 매수할 수 있는 종목",
        ],
        "avoid": ["최근 며칠 급등한 테마주·작전성 소형주", "적자 기업·임상 단계 바이오처럼 결과가 한 번에 갈리는 종목",
                  "뉴스 하나로 움직이는 단기 재료주", "레버리지·인버스 ETF"],
        "catalyst": "앞으로 1~3년 동안 이익을 키울 구조적 이유(신시장·점유율·가격 인상 등) 한 줄",
        "entry": "분할 매수 계획 한 줄 (예: '3번에 나눠, 조정 때마다 1/3씩')",
        "count": "5~6",
    },
    "swing": {
        "pick": [
            "앞으로 1~3개월 안에 주가를 움직일 '날짜가 정해진' 재료가 있음(실적 발표·신제품 출시·정책 시행·수주 발표)",
            "실적이 바닥을 찍고 좋아지는 중(턴어라운드)이거나, 업황 사이클이 막 올라가기 시작한 업종",
            "주가가 20일·60일 이동평균선 위로 올라서는 중(추세 전환 초입) + 거래량이 늘어나는 중",
            "시가총액은 중형주(대략 5천억~10조원, 미국은 20억~500억 달러) 위주 — 움직임과 안정성의 균형",
            "증권사 목표가 상향·실적 추정치 상향이 이어지는 종목이면 가점",
        ],
        "avoid": ["이미 몇 달 동안 크게 올라 추세가 꺾이는 종목", "재료 날짜가 없는 막연한 기대주",
                  "하루 거래대금이 너무 적어 사고팔기 어려운 종목", "몇 년 보고 사는 초대형 안정주(장기투자용)"],
        "catalyst": "1~3개월 안의 구체적 재료와 예상 시기 한 줄 (예: '11월 초 3분기 실적 발표')",
        "entry": "추세 기준 진입 조건 한 줄 (예: '20일선 위에서 거래량 늘며 직전 고점 돌파 시')",
        "count": "5",
    },
    "day": {
        "pick": [
            "이번 주(1~5일) 안에 뉴스 재료가 살아 있는 종목: 정책 발표·대형 수주·임상 결과·신제품·테마 순환",
            "최근 거래대금이 평소보다 크게 늘어난 종목(사람과 돈이 몰리는 중), 거래대금 상위권",
            "하루 변동폭이 커서(평균 3~8%) 며칠 사이 수익 기회가 있는 중소형·테마 대장주",
            "외국인·기관 순매수가 갑자기 늘었거나, 급등 뒤 눌림(조정)에서 다시 힘을 받는 자리",
            "같은 테마에서 '대장주'(가장 먼저·가장 크게 움직이는 종목)를 우선",
        ],
        "avoid": ["거래가 한산한 대형 안정주(움직임이 작아 단타에 안 맞음)", "재료가 이미 끝난(발표 후 하루 이상 지난) 종목",
                  "관리종목·거래정지 위험·상장폐지 사유가 있는 종목", "몇 년짜리 이야기만 있는 장기 성장주"],
        "catalyst": "이번 주 재료와 날짜 한 줄 (예: '목요일 정부 지원책 발표 예정')",
        "entry": "단타 진입·손절 기준 한 줄 (예: '시가 위 유지 시 진입, -3% 이탈 시 바로 손절')",
        "count": "5",
    },
    "scalp": {
        "pick": [
            "장중 유동성이 최상위인 종목: 거래대금이 매우 크고 호가가 촘촘해 바로 사고팔 수 있음",
            "오늘 장에서 움직일 이슈(해외 증시·환율·전일 미국 업종 흐름·오늘 공시)가 있는 종목",
            "하루 안에 1~3%씩 자주 출렁이는 변동성 — 대형 테마주, 지수·업종 ETF(레버리지 포함 가능)",
            "미국 장에 민감한 국내 종목(반도체·2차전지 등)처럼 오늘 아침 방향이 분명한 종목 가점",
            "※ 이 앱 시세는 15~20분 늦음 — '오늘 지켜볼 감시 목록'으로 제시",
        ],
        "avoid": ["하루 거래대금이 적어 호가가 비는 소형주(스캘핑 불가)", "며칠~몇 달 보는 재료(스윙·장기용)",
                  "동시호가·VI(변동성 완화장치)가 자주 걸리는 초소형 급등주", "실적·밸류에이션만 좋은 조용한 종목"],
        "catalyst": "오늘 장중 움직임을 만들 이슈 한 줄 (예: '간밤 엔비디아 +4% → 국내 반도체 동조 기대')",
        "entry": "장중 참고 조건 한 줄 (예: '시가 이후 첫 눌림에서만, 목표 +1.5% / 손절 -0.8%')",
        "count": "4~5",
    },
}


def _style(style):
    """예전 앱의 'scalp'(단타/스캘핑 묶음)도 그대로 받아 줌. 모르는 값이면 장기."""
    return style if style in STYLE_GUIDE else "long"


def _market_context():
    """AI에게 넘길 '지금 시장 상황' — 핵심 지표 + 시장 헤드라인. 20분 캐시."""
    c = _cache_get("ai_mkt_ctx", 1200)
    if c is not None:
        return c
    lines, heads = [], []
    try:
        lines = market_data.market_context_lines()
    except Exception:
        lines = []
    try:
        heads = get_market_headlines(days=2, limit_per=5)[:10]
    except Exception:
        heads = []
    txt = ("[지금 시장 상황 — 지표]\n" + ("\n".join("- " + l for l in lines) or "- (지표를 못 가져옴)") +
           "\n[요즘 시장 뉴스 제목]\n" + ("\n".join("- " + h for h in heads) or "- (없음)"))
    _cache_set("ai_mkt_ctx", txt)
    return txt


ai_engine.MARKET_CTX_FN = lambda: _market_context()   # AI 대화에도 지금 시장 상황을 넣어 줌

# ── AI 대화: 질문에 나온 종목은 서버가 실제 시세·지표를 확인해서 넣어 줌 (AI가 가격을 추측하지 않게) ──
_Q_STOP = set("오늘 내일 어제 지금 요즘 최근 주식 종목 시장 증시 어때 어떻게 어떨까 뭐 뭘 무엇 사도 팔아 팔까 살까 매수 매도 추천 전망 주가 가격 얼마 분석 "
              "해줘 알려줘 좋아 괜찮아 괜찮을까 계좌 우리 그리고 정도 이번 다음 미국 한국 국내 해외 코스피 코스닥 나스닥 투자 수익 손실 "
              "포트폴리오 비중 섹터 업종 테마 반도체 배터리 이차전지 바이오 금리 환율 달러 뉴스 이유 때문 앞으로 언제 얼마나 정말 진짜 "
              "보유 관심 장기 단기 스윙 단타 배당 성장 가치 위험 안전 하락 상승 폭락 급등 차트 지지 저항 손절 익절 목표".split())
_Q_JOSA = re.compile(r"(이랑|에서|으로|까지|부터|이나|이는|에는|은|는|이|가|을|를|도|의|에|랑|와|과|로|만|요|좀|주가|주식)$")
_Q_ETF = re.compile(r"KODEX|TIGER|KBSTAR|ACE|SOL|ARIRANG|HANARO|KOSEF|RISE|PLUS|TIMEFOLIO|KIWOOM", re.I)
_Q_NOT_TICKER = {"AI", "ETF", "PER", "PBR", "ROE", "EPS", "USA", "KR", "US", "IPO", "CEO", "GDP", "CPI", "FOMC", "HBM", "MDD", "RSI",
                 "MACD", "OK", "VS", "PCE", "FED", "ECB", "BOK", "EV", "IT", "TV", "PC", "AR", "VR", "SMR", "LNG", "API", "PPI", "YTD"}


def _chat_pick_stocks(q, known):
    picks = []

    def add(t, m, n):
        t = (t or "").strip().upper()
        if t and len(picks) < 4 and all(p[0] != t for p in picks):
            picks.append((t, m or ("kr" if re.fullmatch(r"\d[0-9A-Z]{5}", t) else "us"), n))
    for k in known or []:                                   # 내 보유·관심 종목 이름/코드가 질문에 있으면
        name, t = str(k.get("name") or ""), str(k.get("ticker") or "")
        if (len(name) >= 2 and name in q) or (t and re.search(r"(?<![0-9A-Za-z])" + re.escape(t) + r"(?![0-9A-Za-z])", q, re.I)):
            add(t, k.get("market"), name)
    for code in re.findall(r"(?<!\d)(\d{6})(?!\d)", q):
        add(code, "kr", None)
    for t in re.findall(r"\$?\b([A-Z]{2,5})\b", q):
        if t not in _Q_NOT_TICKER:
            add(t, "us", None)
    words = []
    for w in re.findall(r"[가-힣A-Za-z0-9&]{2,}", q):
        w2 = _Q_JOSA.sub("", w)
        if len(w2) >= 2 and w2 not in _Q_STOP and re.search(r"[가-힣]", w2) and w2 not in words:
            words.append(w2)
    for w in words[:5]:
        if len(picks) >= 4:
            break
        try:
            res = market_data.search_stocks(w)
        except Exception:
            res = []
        for r in res[:5]:
            nm = str(r.get("name") or "").replace(" ", "")
            if _Q_ETF.search(nm) and not _Q_ETF.search(w):
                continue
            if nm == w or (len(w) >= 3 and (nm.startswith(w) or nm.endswith(w))) or (len(w) == 2 and nm.startswith(w) and len(nm) <= 4):
                add(r.get("ticker"), r.get("market"), r.get("name"))
                break
    return picks


def _chat_quote_line(t, m, n):
    try:
        p = get_price(t, m) or {}
    except Exception:
        p = {}
    price = p.get("price")
    ccy = p.get("currency") or ("KRW" if m == "kr" else "USD")
    fmt = (lambda v: f"{v:,.0f}원") if ccy == "KRW" else (lambda v: f"${v:,.2f}")
    name = p.get("name") or n or t
    if not price:
        return f"- {name}({t}): ⚠ 실시간 시세를 확인하지 못함 → 이 종목의 가격·수익률은 말하지 말고 '시세를 확인하지 못했다'고 할 것"
    parts = [f"현재가 {fmt(price)}"]
    if p.get("change_pct") is not None:
        parts.append(f"전일 대비 {p['change_pct']:+.2f}%")
    for k, lab in (("per", "PER"), ("pbr", "PBR")):
        if p.get(k):
            parts.append(f"{lab} {p[k]:.1f}")
    try:
        d = market_data.chart_rows(t, m, "1y", "1d")
        if d and len(d["rows"]) >= 60:
            ind = market_data.tech_indicators(d["rows"])
            parts.append(f"20일선 {fmt(ind['ma'][20])}, 60일선 {fmt(ind['ma'][60])}" + (f", 120일선 {fmt(ind['ma'][120])}" if ind["ma"].get(120) else ""))
            parts.append(f"RSI {ind['rsi']:.0f}")
            rr = ", ".join(f"{k} {v:+.1f}%" for k, v in ind["ret"].items() if v is not None)
            if rr:
                parts.append("수익률 " + rr)
            parts.append(f"52주 고가 {fmt(ind['hi52'])}(현재 {ind['from_hi']:+.1f}%)·저가 {fmt(ind['lo52'])}")
            if ind.get("cross"):
                parts.append(ind["cross"])
    except Exception:
        pass
    asof = p.get("asof") or _now()
    return f"- {name}({t}, {'국내' if m == 'kr' else '미국'}): " + " · ".join(parts) + f" [기준 {asof}]"


def _chat_quotes(q, known):
    picks = _chat_pick_stocks(q, known)
    if not picks:
        return ""
    with ThreadPoolExecutor(max_workers=4) as ex:
        lines = list(ex.map(lambda p: _chat_quote_line(*p), picks))
    return "[방금 앱이 확인한 실제 시세·지표 — 질문에 나온 종목]\n" + "\n".join(lines)


ai_engine.QUOTE_FN = _chat_quotes


def build_insight_prompt(name, ticker, price, fund, rule, headlines, mine="", style="", market_ctx="") -> str:
    head_block = "\n".join("- " + h for h in headlines) if headlines else "- (가져온 뉴스 없음)"
    val_line, fund_line = _fund_line(fund or {})
    warns = (fund or {}).get("val_warn") or []
    warn_block = ("\n[주의: 출처끼리 숫자가 다른 지표]\n" + "\n".join("- " + w for w in warns) +
                  "\n→ 이 지표는 단정하지 말고 '출처마다 달라 참고만'이라고 쓰세요.\n") if warns else ""
    rule_block = f"\n[내가 정해 둔 규칙 — 꼭 비춰서 말해 줄 것]\n- {rule.strip()}\n" if (rule or "").strip() else ""
    mine_block = f"\n[내 보유 상황]\n- {mine}\n" if mine else ""
    st = _style(style)
    label, horizon = STYLE_LABEL[st], STYLE_HORIZON[st]
    others = [k for k in ("long", "swing", "day", "scalp") if k != st]
    emo = {"long": "📈", "swing": "🔁", "day": "⚡", "scalp": "⏱️"}

    return f"""당신은 한국 개인투자자의 똑똑한 투자비서입니다. 증권사 애널리스트처럼 분석하되, 초보도 바로 쓸 수 있게 말합니다.
이 사용자의 투자 성향은 '{label}'입니다. 모든 판단을 이 성향 기준({horizon})으로 하세요.
성향 설명: {STYLE_GUIDE[st]}

{QUICK_RULES}
{EASY_RULES}

[자료]
종목: {name} ({ticker or "코드없음"}) · 현재가 {price or "?"}
주가 수준 지표: {val_line}
실적 지표: {fund_line}
{warn_block}{mine_block}{rule_block}
이 종목 최근 뉴스 제목(최신순):
{head_block}

{market_ctx or "[지금 시장 상황] (자료 없음)"}

[출력 형식] 아래 제목을 그대로, 이 순서로. 인사말·맺음말 금지.

## AI 의견
(정확히 아래 5줄.)
방향: 상승 73% ({horizon} · {label} 기준)   ← 또는 "하락 64% (…)". 점수표로 계산한 1% 단위, 10~90, 50·5로 끝나는 수 금지.
계산: 기본 50 → 추세 +8 · 실적 +6 · 주가 수준 -4 · 뉴스 +7 · 시장 +3 · 수급 +2 · 위험 -5 = 67   ← 실제 판단으로 채우기, 합계가 방향 숫자와 같아야 함
의견: 적극 매수 / 매수 / 분할 매수 / 보유 / 비중 축소 / 매도 중 하나
할 일: 초보도 바로 알아듣는 행동 한 문장, 강하게. 예: "지금 사지 마세요. 2만 원 아래로 내려오면 그때 1/3만 사세요" / "들고 계세요. 1만8천 원 깨지면 파세요"
이유: 가장 큰 이유 한 문장

## 전문가 6인 투표
(서로 다른 6명의 투자 전문가가 각자 자기 기준으로만 이 종목을 따로 판단했다고 생각하고, 정확히 아래 6줄. 서로 의견이 달라도 됩니다 — 억지로 맞추지 마세요.)
- 가치투자자(버핏식, 싸고 좋은 회사인가): 매수 / 보유 / 매도 중 하나 · 확신 0~100 — 이유 한 구절(자료의 숫자로)
- 성장투자자(린치식, 이익이 크게 늘 회사인가): … · 확신 … — …
- 역발상투자자(남들이 몰릴 때 조심, 버려질 때 기회): … · 확신 … — …
- 차트 분석가(추세·이동평균·거래량): … · 확신 … — …
- 수급·시장 분석가(시장 분위기·금리·환율·외국인): … · 확신 … — …
- 뉴스 분석가(최근 재료가 이익에 주는 영향): … · 확신 … — …
※ 위 'AI 의견'의 확률·의견은 이 6명의 투표(확신까지 반영)와 점수표를 합쳐서 나온 결론이어야 해요.

## 3초 요약
(지금 할 행동을 한 줄로. 예: "지금은 관망, 2% 더 빠지면 1/3만 분할 매수")

## 뉴스가 주가에 주는 영향
(중요한 뉴스 3~6개. 한 뉴스에 한 줄, 아래 형식 그대로.)
- 📰 (사실 한 줄) → 📈 상승 요인·강 (또는 📉 하락 요인·중 / ➖ 영향 적음) · (언제까지: 며칠/몇 주/몇 달) — (왜: 이익·수급·시장 흐름과 연결해 한마디)

## 시장 흐름과 연결
(지금 시장 상황 자료를 근거로 2~4줄. 금리·환율·업종 분위기·외국인 수급·세계 이슈가 이 종목에 순풍인지 역풍인지.)

## 좋은 점
- 2~3개, 짧게

## 조심할 점
- 2~3개, 짧게

## 숫자로 쉽게 보기
- 지표 3~4개만: "지표 값 → 쉬운 뜻 → 보통과 비교해 어떤지"

## {label} 전략 (참고선)
(현재가 기준으로 숫자를 넣어서. 자료가 없으면 %만.)
- 🎯 매수 참고: (가격 또는 현재가 대비 %) — 한 번에 말고 몇 번에 나눠서
- 🛑 손절 참고: (가격/%) — 이 아래로 가면 판단이 틀린 것
- 🏁 목표 참고: (가격/%) — {horizon} 기준
- ⏰ 체크할 때: (실적 발표일, 지표 발표, 장 시작 30분 등 이 성향에 맞게)

## 다른 성향이라면
- {emo[others[0]]} {STYLE_LABEL[others[0]]}: (한 문장)
- {emo[others[1]]} {STYLE_LABEL[others[1]]}: (한 문장)
- {emo[others[2]]} {STYLE_LABEL[others[2]]}: (한 문장)

## 내 상황에서는
- 내 보유 비중·수익률·내 규칙에 비춰 1~3개 (자료 없으면 이 제목 빼기)

## 이 의견이 바뀌는 신호
- 이런 일이 생기면 판단을 바꿔야 한다는 신호 2개
"""


# ---------------------------------------------------------------------------
# 라우트
# ---------------------------------------------------------------------------
def _nocache(resp):
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    return resp


@app.get("/")
def root():
    """주소만 치고 들어와도 앱 화면으로 보냅니다. 상태 확인은 /api/status"""
    from flask import redirect
    return redirect("/app")


@app.get("/api/status")
def route_status():
    return jsonify({"ok": True, "version": SERVER_VERSION, "ai": ai_engine.status_summary(),
                    "dart": bool(DART_API_KEY), "old_ui": _old_ui() is not None,
                    "version_code": _version_code(), "update_configured": bool(_update_url())})


_UPDATE_STATE = os.path.join(ai_engine.DATA_DIR, "update_state.json")


def _upd_mark_ok():
    try:
        os.makedirs(ai_engine.DATA_DIR, exist_ok=True)
        with open(_UPDATE_STATE, "w", encoding="utf-8") as f:
            json.dump({"last_ok": time.time()}, f)
    except OSError:
        pass


def _upd_days_since_ok():
    try:
        with open(_UPDATE_STATE, encoding="utf-8") as f:
            return (time.time() - float(json.load(f).get("last_ok") or 0)) / 86400.0
    except (OSError, ValueError):
        return None


@app.get("/api/update")
def route_update():
    """클라우드의 '관리 파일'을 확인해 ① 새 버전 있는지 ② 사용 허용 상태인지 알려줌.
    네트워크 접속은 서버(파이썬)가 하므로 브라우저 CORS 문제 없음."""
    url = _update_url()
    cur = _version_code()
    ota, apk_code = None, None
    try:                                   # 폰 앱: 자동 업데이트 묶음 상태(받아 둠/적용됨) + 설치된 APK 버전
        import android_main
        ota = android_main.ota_status()
        apk_code = android_main._app_code()
    except Exception:
        ota = _pc_ota_status()
    if not url:
        return jsonify({"configured": False, "current": cur, "ota": ota})
    try:
        r = requests.get(url, timeout=8, headers={"Cache-Control": "no-cache"})
        if r.status_code in (404, 410):
            return jsonify({"configured": True, "status": "deleted", "current": cur,
                            "days_since_ok": _upd_days_since_ok()})
        r.raise_for_status()
        m = r.json()
        _upd_mark_ok()
        _ota_kick(int((m.get("ota") or {}).get("code") or 0), int((m.get("ota") or {}).get("min_app") or 0), url)
        return jsonify({
            "configured": True, "status": "ok", "current": cur,
            "enabled": bool(m.get("enabled", True)),
            "latest": int(m.get("latest") or 0),
            "latest_name": str(m.get("version") or ""),
            "apk": str(m.get("apk") or ""),
            "notice": str(m.get("notice") or ""),
            "require": bool(m.get("require", False)),
            "grace_days": int(m.get("grace_days") or 7),
            "pc": str(m.get("pc") or ""),
            "ota": ota, "apk_code": apk_code,
            "support": m.get("support") if isinstance(m.get("support"), dict) else {},
            "promo": m.get("promo") if isinstance(m.get("promo"), list) else [],   # 광고·제휴 자리(원격)
            "license": _lic_save_cfg(m.get("license")),                       # 이용권(쿠폰) 설정(원격)
            "ota_latest": int((m.get("ota") or {}).get("code") or 0),           # 시작 화면에서 업데이트 기다릴지 판단
            "ota_min_app": int((m.get("ota") or {}).get("min_app") or 0),
        })
    except (ValueError, TypeError, AttributeError, requests.exceptions.RequestException) as e:
        # 404가 아닌 오류(인터넷 끊김·파일 깨짐 등) → '확인 불가'. 며칠 유예는 화면에서 판단.
        return jsonify({"configured": True, "status": "offline", "current": cur,
                        "days_since_ok": _upd_days_since_ok(), "err": type(e).__name__})


# ── 이용권(쿠폰) ─────────────────────────────────────────────────────────
# 쿠폰 번호는 주인 PC의 생성기(owner_tools/coupon_maker.py)로만 만듦. 공개 저장소(MIOS)의 coupons.json 에는
# 번호가 아니라 해시만 올라가서, 목록을 봐도 번호를 알 수 없음. 앱은 입력한 번호의 해시가 목록에 있으면 기간을 더해 줌.
#   coupons.json = {"v":1, "codes": {해시: {"p":"m1","d":30,"x":"2027-12-31"}}, "revoked": [해시, ...]}
#   update.json  = "license": {"required": true, "contact": "https://…", "plans": [{"name":"1개월","days":30,"price":"9,900원"}, …]}
_LIC_PATH = os.path.join(ai_engine.DATA_DIR, "license.json")
_LIC_LOCK = threading.Lock()
_LIC_PLANS = [{"name": "무료 체험", "days": 7, "price": "무료"}, {"name": "1개월", "days": 30, "price": ""},
              {"name": "3개월", "days": 90, "price": ""}, {"name": "6개월", "days": 180, "price": ""}]


def coupon_hash(code):
    norm = re.sub(r"[^0-9A-Z]", "", str(code or "").upper())
    return norm, hashlib.sha256(("asset-coupon:" + norm).encode()).hexdigest()


def _lic_read():
    try:
        with open(_LIC_PATH, encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _lic_write(d):
    os.makedirs(os.path.dirname(_LIC_PATH), exist_ok=True)
    tmp = _LIC_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False)
    os.replace(tmp, _LIC_PATH)


def _lic_save_cfg(cfg):
    """update.json 의 license 설정을 기억 (인터넷이 끊겨도 같은 규칙으로)."""
    cfg = cfg if isinstance(cfg, dict) else {}
    out = {"required": bool(cfg.get("required", False)), "contact": str(cfg.get("contact") or "")[:300],
           "api": str(cfg.get("api") or "")[:300] if str(cfg.get("api") or "").startswith("https://") else "",
           "contact_label": str(cfg.get("contact_label") or "")[:40], "notice": str(cfg.get("notice") or "")[:300],
           "plans": cfg.get("plans") if isinstance(cfg.get("plans"), list) else _LIC_PLANS}
    with _LIC_LOCK:
        d = _lic_read()
        d["cfg"] = out
        _lic_write(d)
    return out


_DEV_ID = None


def _device_id():
    """이 기기 고유 번호 (쿠폰 1개 = 기기 1대). 폰: 안드로이드 기기 번호(앱을 다시 깔아도 같음), PC: 네트워크 장치 번호."""
    global _DEV_ID
    if _DEV_ID:
        return _DEV_ID
    raw = None
    try:
        from java import jclass                                   # 폰(Chaquopy)
        from com.chaquo.python import Python as _Py
        ctx = _Py.getPlatform().getApplication()
        aid = jclass("android.provider.Settings$Secure").getString(ctx.getContentResolver(), "android_id")
        if aid:
            raw = "android:" + str(aid)
    except Exception:
        raw = None
    if not raw:
        try:
            import uuid
            node = uuid.getnode()
            if not (node >> 40) & 1:                              # 진짜 장치 번호일 때만 (임시 번호 제외)
                import platform
                raw = "pc:%012x:%s" % (node, platform.node())
        except Exception:
            raw = None
    if not raw:                                                   # 마지막 수단: 이 기기에 저장한 임의 번호
        with _LIC_LOCK:
            d = _lic_read()
            if not d.get("rand"):
                d["rand"] = hashlib.sha256(os.urandom(32)).hexdigest()[:24]
                _lic_write(d)
            raw = "rand:" + d["rand"]
    _DEV_ID = hashlib.sha256(("asset-dev:" + raw).encode()).hexdigest()[:20].upper()
    return _DEV_ID


def _lic_api(url, payload):
    """구글 시트 쿠폰 서버 호출 (Apps Script 웹 앱)."""
    r = requests.post(url, json=payload, timeout=25, headers={"Content-Type": "application/json"})
    r.raise_for_status()
    return r.json()


def _lic_now(d, server_ts=None):
    """시계를 뒤로 돌려 기간을 늘리는 것 방지: 지금까지 본 가장 늦은 시각을 기준으로."""
    now = time.time()
    seen = max(float(d.get("seen") or 0), float(server_ts or 0))
    return max(now, seen)


def _lic_until(d, revoked=()):
    """쿠폰별 기간을 이어 붙임. 시트의 [만료일](u)이 있는 쿠폰은 그 날짜를 그대로 씀 (주인이 시트에서 날짜를 바꾸면 반영)."""
    until = 0.0
    for r in sorted(d.get("used") or [], key=lambda x: x.get("at", 0)):
        if r.get("h") in revoked:
            continue
        if r.get("u"):
            until = max(until, float(r["u"]))
            continue
        start = max(until, float(r.get("at") or 0))
        until = start + float(r.get("d") or 0) * 86400
    return until


def _coupons_url():
    u = _update_url() or ""
    return u.rsplit("/", 1)[0] + "/coupons.json" if u.startswith("http") else ""


def _fetch_coupons():
    """반환 (목록, 서버 시각). raw 주소가 캐시로 늦으면 GitHub API 로 한 번 더."""
    url = _coupons_url()
    if not url:
        raise ValueError("no-url")
    r = requests.get(url + "?t=%d" % int(time.time()), timeout=10, headers={"Cache-Control": "no-cache"})
    r.raise_for_status()
    srv = None
    try:
        from email.utils import parsedate_to_datetime
        srv = parsedate_to_datetime(r.headers.get("Date")).timestamp()
    except Exception:
        srv = None
    return r.json(), srv


def _fetch_coupons_api():
    m = re.match(r"https://raw\.githubusercontent\.com/([^/]+)/([^/]+)/([^/]+)/(.*)$", _coupons_url())
    if not m:
        return None
    owner, repo, branch, path = m.groups()
    r = requests.get(f"https://api.github.com/repos/{owner}/{repo}/contents/{path}", params={"ref": branch}, timeout=10,
                     headers={"Accept": "application/vnd.github.raw+json"})
    return r.json() if r.ok else None


def _lic_state(d, now):
    cfg = d.get("cfg") or {"required": False, "plans": _LIC_PLANS}
    until = float(d.get("until") or 0)
    left = until - now
    return {"required": bool(cfg.get("required")), "active": left > 0, "until": int(until * 1000),
            "days_left": max(0, int((left + 86399) // 86400)) if left > 0 else 0,
            "plan": (d.get("used") or [{}])[-1].get("name", "") if d.get("used") else "",
            "count": len(d.get("used") or []), "contact": cfg.get("contact", ""), "contact_label": cfg.get("contact_label", ""),
            "notice": cfg.get("notice", ""), "plans": cfg.get("plans") or _LIC_PLANS,
            "device": "-".join(_device_id()[i:i + 4] for i in (0, 4, 8)), "server": bool(cfg.get("api"))}


@app.get("/api/license")
def route_license():
    """이용권 상태. 하루 몇 번은 쿠폰 목록을 다시 확인해 취소된 쿠폰을 반영."""
    with _LIC_LOCK:
        d = _lic_read()
    now = _lic_now(d)
    every = 3600 if (d.get("cfg") or {}).get("api") else 6 * 3600     # 구글 시트를 쓰면 1시간마다 (만료일·취소 반영)
    if d.get("used") and now - float(d.get("checked") or 0) > every:
        try:
            api = (d.get("cfg") or {}).get("api")
            if api:                                   # 구글 시트 서버: 취소·다른 기기로 옮긴 쿠폰 빼기
                items = [{"c": r.get("c", ""), "h": r.get("h"), "at": int(float(r.get("at") or 0) * 1000)} for r in d.get("used") or []]
                res = _lic_api(api, {"action": "check", "device": _device_id(), "items": items})
                st = res.get("items") or {}
                revoked = {r.get("h") for r in d.get("used") or [] if (st.get(r.get("c") or r.get("h")) or {}).get("st") in ("revoked", "other", "gone")}
                srv = (res.get("time") or 0) / 1000 or None
                news = {k: v.get("until") for k, v in st.items() if isinstance(v, dict) and v.get("until")}
                if news:                              # 시트 [만료일]을 다시 읽어 반영
                    with _LIC_LOCK:
                        d2 = _lic_read()
                        for r in d2.get("used") or []:
                            u = news.get(r.get("c") or r.get("h"))
                            if u:
                                r["u"] = float(u) / 1000
                        _lic_write(d2)
            else:
                cj, srv = _fetch_coupons()
                revoked = set(cj.get("revoked") or [])
            with _LIC_LOCK:
                d = _lic_read()
                d["until"] = _lic_until(d, revoked)
                d["checked"] = now
                d["seen"] = _lic_now(d, srv)
                _lic_write(d)
            now = _lic_now(d)
        except Exception:
            pass
    else:
        with _LIC_LOCK:
            d = _lic_read()
            d["seen"] = now
            _lic_write(d)
    return jsonify(_lic_state(d, now))


@app.post("/api/license/redeem")
def route_license_redeem():
    if not ai_engine._local_request():
        return jsonify({"ok": False, "error": "허용되지 않은 요청"}), 403
    code = (request.get_json(force=True, silent=True) or {}).get("code") or ""
    norm, h = coupon_hash(code)
    if len(norm) < 8:
        return jsonify({"ok": False, "error": "쿠폰 번호를 끝까지 입력해 주세요"})
    with _LIC_LOCK:
        d = _lic_read()
    if any(r.get("h") == h for r in d.get("used") or []):
        return jsonify({"ok": False, "error": "이미 이 기기에 등록한 쿠폰이에요"})
    api = (d.get("cfg") or {}).get("api")
    if api:                                           # 구글 시트 서버: 처음 쓴 기기에 묶음 (1쿠폰 = 1기기)
        try:
            res = _lic_api(api, {"action": "redeem", "code": norm, "device": _device_id(),
                                 "base": int(max(float(d.get("until") or 0), time.time()) * 1000)})
        except Exception:
            return jsonify({"ok": False, "error": "쿠폰 서버에 연결하지 못했어요. 인터넷을 확인하고 다시 눌러 주세요"})
        if not res.get("ok"):
            return jsonify({"ok": False, "error": str(res.get("error") or "쿠폰을 확인하지 못했어요")[:120]})
        days = int(res.get("days") or 0)
        if days <= 0:
            return jsonify({"ok": False, "error": "쿠폰 정보가 이상해요. 판매자에게 문의해 주세요"})
        with _LIC_LOCK:
            d = _lic_read()
            srv = (res.get("time") or 0) / 1000 or None
            now = _lic_now(d, srv)
            at = float(res.get("at") or now * 1000) / 1000
            rec = {"h": h, "c": norm, "d": days, "at": at, "name": str(res.get("name") or "")[:20]}
            if res.get("until"):
                rec["u"] = float(res["until"]) / 1000
            d.setdefault("used", []).append(rec)
            d["until"] = _lic_until(d)
            d["seen"], d["checked"] = now, now
            _lic_write(d)
        st = _lic_state(d, now)
        st.update(ok=True, added=days, name=str(res.get("name") or ""), again=bool(res.get("again")))
        return jsonify(st)
    try:
        cj, srv = _fetch_coupons()
    except Exception:
        return jsonify({"ok": False, "error": "인터넷에 연결한 뒤 다시 눌러 주세요"})
    codes = cj.get("codes") or {}
    if h not in codes and h not in (cj.get("revoked") or []):
        try:                                   # 방금 만든 쿠폰은 raw 주소에 몇 분 늦게 보일 수 있음
            cj2 = _fetch_coupons_api()
            if cj2:
                cj, codes = cj2, cj2.get("codes") or {}
        except Exception:
            pass
    if h in (cj.get("revoked") or []):
        return jsonify({"ok": False, "error": "사용이 취소된 쿠폰이에요"})
    c = codes.get(h)
    if not c:
        return jsonify({"ok": False, "error": "없는 쿠폰 번호예요. 다시 확인해 주세요"})
    now = _lic_now(d, srv)
    if c.get("x") and datetime.fromtimestamp(now).strftime("%Y-%m-%d") > str(c["x"]):
        return jsonify({"ok": False, "error": "등록 기한(" + str(c["x"]) + ")이 지난 쿠폰이에요"})
    days = int(c.get("d") or 0)
    if days <= 0:
        return jsonify({"ok": False, "error": "쿠폰 정보가 이상해요. 판매자에게 문의해 주세요"})
    name = {"free7": "무료 체험", "m1": "1개월", "m3": "3개월", "m6": "6개월", "y1": "1년", "owner": "관리자"}.get(c.get("p"), str(days) + "일")
    with _LIC_LOCK:
        d = _lic_read()
        d.setdefault("used", []).append({"h": h, "d": days, "at": now, "name": name})
        d["until"] = _lic_until(d, set(cj.get("revoked") or []))
        d["seen"], d["checked"] = now, now
        _lic_write(d)
    st = _lic_state(d, now)
    st.update(ok=True, added=days, name=name)
    return jsonify(st)


_OTA_KICK = {"at": 0.0, "busy": False}


def _ota_kick(latest, min_app, url):
    """새 묶음 받기 다시 시작 (v2.17).
    예전엔 앱 '프로세스'가 처음 켜질 때 한 번만 받았음 → 뒤로가기로 화면만 닫았다 다시 열면(폰은 프로세스가 살아 있음)
    새 버전이 나와도 받기가 안 돌아서, 시작 화면이 '받는 중'으로 기다리다 그냥 넘어가는 일이 반복됐음."""
    now = time.time()
    if not latest or latest <= _version_code() or _OTA_KICK["busy"] or now - _OTA_KICK["at"] < 45:
        return
    try:
        import android_main as am
    except Exception:
        am = None
    if am is not None:
        st = am.ota_status()
        app_code = am._app_code()
        if int(st.get("ready") or 0) >= latest or app_code < min_app:
            return
        files_dir = os.path.dirname(ai_engine.DATA_DIR)
        am._ota["error"] = ""                     # 예전 실패 기록 때문에 시작 화면이 바로 포기하지 않게

        def run():
            try:
                cur = _version_code()
                got = am._download_ota(files_dir, app_code, cur, url)
                if not got:                       # 이미 받아 둔 묶음이 있는데 아직 적용 안 된 경우
                    root = am._ota_root(files_dir)
                    c = int((am._read_json(os.path.join(root, "state.json"), {}) or {}).get("current") or 0)
                    if c > cur and os.path.isfile(os.path.join(root, str(c), "py", "price_server.py")):
                        got = c
                if got:
                    am._ota.update(ready=got, error="")
            except Exception as e:
                am._ota["error"] = (type(e).__name__ + ": " + str(e))[:120]
            finally:
                _OTA_KICK["busy"] = False
    else:
        try:
            import pc_update as pu
        except Exception:
            return
        if not pu.enabled(HERE) or pu.STATE.get("checking") or int(pu.STATE.get("ready") or 0) >= latest:
            return

        def run():
            try:
                pu.STATE["error"] = ""
                pu._run(HERE, _version_code(), url)
            finally:
                _OTA_KICK["busy"] = False
    _OTA_KICK.update(at=now, busy=True)
    threading.Thread(target=run, name="ota-kick", daemon=True).start()


def _pc_ota_status():
    """PC판 자동 업데이트 상태 (설치된 PC 앱에서만, 아니면 None)."""
    try:
        import pc_update
        return pc_update.status() if pc_update.enabled(HERE) else None
    except Exception:
        return None


@app.post("/api/quant/explain")
def route_quant_explain():
    """퀀트 엔진 결과를 AI가 쉬운 말로 해설. 엔진에 없는 숫자는 만들지 않게."""
    q = request.get_json(force=True, silent=True) or {}
    kind = str(q.get("kind") or "")[:20]
    payload = json.dumps(q.get("data") or {}, ensure_ascii=False)[:9000]
    what = {"guide": "보유·관심 종목의 판단 가이드", "backtest": "전략 백테스트(과거 검증)", "market": "시장 국면과 섹터 강도", "scan": "종목 스캐너 결과"}.get(kind, "퀀트 분석 결과")
    prompt = f"""아래는 이 앱의 퀀트 엔진이 '실제 일봉 데이터'로 계산한 {what} 결과(JSON)입니다.

[규칙 — 꼭 지킬 것]
- 아래 JSON에 있는 숫자만 쓰세요. 새로운 가격·지표·수익률·확률을 만들거나 기억으로 채우지 마세요.
- JSON에 없는 값은 '데이터 없음'이라고 하세요. 데이터 기준일(last·asof, 유닉스 시각)이 오래됐으면 먼저 알려 주세요.
- 판단은 '검토' 수준의 참고 정보로 표현하고, 확정적인 예측·매수 지시처럼 말하지 마세요.
- 백테스트라면: 개발 구간(dev)과 검증 구간(test) 성과가 크게 다르면 '과최적화 가능성'을 경고하고, 그냥 들고 있기(bench)와 비교하세요.
  거래 횟수가 적으면(5회 미만) 통계적으로 믿기 어렵다고 말하세요.
- 구성: ① 한 줄 결론 ② 충족된 조건 / 충족되지 않은 조건 ③ 시장·섹터 상황 ④ 과거 검증 성과의 의미 ⑤ 위험과 판단이 무효가 되는 조건 ⑥ 다음에 지켜볼 것
- 마지막 줄: '과거 데이터에 기반한 참고 정보이며 투자 권유가 아니에요.'

[결과 JSON]
{payload}
"""
    text, prov, mdl, err = _ai_complete(prompt, max_out=1800)
    if err == "NO_KEY":
        return jsonify({"status": "no_key"}), 200
    if not text:
        return jsonify({"status": "fail", "text": "AI 호출 실패: " + str(err)[:200]}), 200
    return jsonify({"status": "ok", "provider": prov, "model": mdl, "text": text}), 200


@app.get("/api/ota/state")
def route_ota_state():
    """폰 앱: 업데이트 묶음 받기 진행 상태 (시작 화면이 가볍게 물어봄)."""
    try:
        import android_main
        return jsonify({"ota": android_main.ota_status(), "current": _version_code()})
    except Exception:
        return jsonify({"ota": _pc_ota_status(), "current": _version_code()})


@app.post("/api/ota/apply")
def route_ota_apply():
    """폰 앱: 방금 받은 업데이트 묶음을 지금 바로 적용(새 모듈을 불러와 요청을 넘김)."""
    if not ai_engine._local_request():
        return jsonify({"ok": False, "error": "허용되지 않은 요청"}), 403
    android_main = None
    try:
        import android_main
        st = android_main.ota_status()
    except Exception:
        st = _pc_ota_status() or {}               # PC판: 받은 파일이 이미 앱 폴더에 들어가 있음
    code = int(st.get("ready") or 0)
    if not code or code <= _version_code():
        return jsonify({"ok": False, "error": "적용할 업데이트가 없어요"})
    if android_main is not None:
        d = os.path.join(os.path.dirname(ai_engine.DATA_DIR), "ota", str(code))
        py, web = os.path.join(d, "py"), os.path.join(d, "web")
    else:
        py, web = HERE, os.path.join(HERE, "web")
    if not (os.path.isfile(os.path.join(py, "price_server.py")) and os.path.isfile(os.path.join(web, "index.html"))):
        return jsonify({"ok": False, "error": "묶음 파일이 없어요"})
    import importlib
    names = ("price_server", "ai_engine", "market_data", "pc_update", "quant")
    saved = {n: sys.modules.get(n) for n in names}
    env_old = {k: os.environ.get(k) for k in ("ASSET_WEB_DIR", "ASSET_APP_VERSIONCODE")}
    try:
        for n in names:
            sys.modules.pop(n, None)
        added = py not in sys.path               # PC판은 앱 폴더(이미 경로에 있음)를 그대로 씀
        if added:
            sys.path.insert(0, py)
        os.environ["ASSET_WEB_DIR"], os.environ["ASSET_APP_VERSIONCODE"] = web, str(code)
        new = importlib.import_module("price_server")
    except Exception as e:                       # 새 코드가 안 불러와지면 지금 버전 그대로
        for n, m in saved.items():
            if m is not None:
                sys.modules[n] = m
        if added and py in sys.path:
            sys.path.remove(py)
        for k, v in env_old.items():
            if v is not None:
                os.environ[k] = v
        return jsonify({"ok": False, "error": type(e).__name__})
    _SWAP["app"] = new.app
    try:
        if android_main is not None:
            android_main._ota.update(applied=code, ready=0)
        else:
            import pc_update as _pu                 # 새로 불러온 쪽에 기록 (화면이 '업데이트됐어요' 알림)
            _pu.STATE.update(applied=code, ready=0)
    except Exception:
        pass
    return jsonify({"ok": True, "code": code})


@app.post("/api/settings/dart")
def route_set_dart():
    """DART 키 저장(선택). 빈 값이면 삭제."""
    global DART_API_KEY
    if not ai_engine._local_request():
        return jsonify({"ok": False, "error": "허용되지 않은 요청"}), 403
    d = request.get_json(force=True, silent=True) or {}
    key = str(d.get("key") or "").strip()
    s = ai_engine.load_settings()
    s["dart_key"] = key
    ai_engine.save_settings(s)
    DART_API_KEY = os.environ.get("DART_API_KEY") or key or None
    _CACHE.clear()
    return jsonify({"ok": True, "dart": bool(DART_API_KEY)})


# ── 내 자산 데이터 자동 백업 (userdata/portfolio.json + 날짜별 사본) ─────────
DATA_PATH = os.path.join(ai_engine.DATA_DIR, "portfolio.json")
BACKUP_DIR = os.path.join(ai_engine.DATA_DIR, "backups")
_DATA_LOCK = threading.Lock()


def _count_accounts(st):
    try:
        return sum(len(p.get("accounts") or []) for p in (st.get("people") or []))
    except Exception:
        return 0


@app.get("/api/data")
def route_data_get():
    try:
        with open(DATA_PATH, "r", encoding="utf-8") as f:
            return jsonify({"state": json.load(f)})
    except FileNotFoundError:
        return jsonify({"state": None})
    except Exception as e:
        return jsonify({"state": None, "error": type(e).__name__})


@app.put("/api/data")
def route_data_put():
    if not ai_engine._local_request():
        return jsonify({"ok": False}), 403
    d = request.get_json(force=True, silent=True) or {}
    st = d.get("state")
    if not isinstance(st, dict) or not isinstance(st.get("people"), list):
        return jsonify({"ok": False, "error": "형식 오류"}), 400
    with _DATA_LOCK:
        # 실수로 빈 데이터가 기존 자산을 덮어쓰지 않게(모두 지우기는 force)
        if not d.get("force") and _count_accounts(st) == 0 and os.path.exists(DATA_PATH):
            try:
                with open(DATA_PATH, "r", encoding="utf-8") as f:
                    if _count_accounts(json.load(f)) > 0:
                        return jsonify({"ok": False, "kept": True})
            except Exception:
                pass
        os.makedirs(BACKUP_DIR, exist_ok=True)
        body = json.dumps(st, ensure_ascii=False)
        day = datetime.now().strftime("%Y-%m-%d")
        # 덮어쓰기 직전 버전은 항상 portfolio-prev.json 으로, 그날의 '첫 버전'은 날짜별 파일로 보존
        if os.path.exists(DATA_PATH):
            try:
                import shutil
                shutil.copyfile(DATA_PATH, os.path.join(BACKUP_DIR, "portfolio-prev.json"))
                daily = os.path.join(BACKUP_DIR, f"portfolio-{day}.json")
                if not os.path.exists(daily):
                    shutil.copyfile(DATA_PATH, daily)
            except OSError:
                pass
        tmp = DATA_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(body)
        os.replace(tmp, DATA_PATH)
        olds = sorted(x for x in os.listdir(BACKUP_DIR) if x.startswith("portfolio-") and x.endswith(".json"))
        for x in olds[:-14]:
            try:
                os.remove(os.path.join(BACKUP_DIR, x))
            except OSError:
                pass
    return jsonify({"ok": True})


def _local_ips():
    import socket
    ips = []
    try:
        s_ = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s_.connect(("8.8.8.8", 80))  # 실제로 보내지 않음 — 내 PC의 대표 주소 확인용
        ips.append(s_.getsockname()[0])
        s_.close()
    except Exception:
        pass
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            if ip not in ips and not ip.startswith("127."):
                ips.append(ip)
    except Exception:
        pass
    return [ip for ip in ips if ip.startswith(("192.168.", "10.", "172."))]


@app.get("/api/settings/lan")
def route_lan_get():
    s = ai_engine.load_settings()
    return jsonify({"enabled": bool(s.get("lan_access")), "active": _LAN_ACTIVE,
                    "urls": [f"http://{ip}:8000" for ip in _local_ips()] if _LAN_ACTIVE else []})


@app.post("/api/settings/lan")
def route_lan_set():
    if not ai_engine._local_request():
        return jsonify({"ok": False}), 403
    d = request.get_json(force=True, silent=True) or {}
    s = ai_engine.load_settings()
    s["lan_access"] = bool(d.get("enabled"))
    ai_engine.save_settings(s)
    return jsonify({"ok": True, "enabled": s["lan_access"], "restart": s["lan_access"] != _LAN_ACTIVE})


@app.get("/app")
def serve_app():
    """새 화면(web/index.html). 예전 화면은 /old 로 볼 수 있습니다."""
    if os.path.exists(os.path.join(WEB_DIR, "index.html")):
        return _nocache(send_from_directory(WEB_DIR, "index.html"))
    return serve_old_app()


@app.get("/web/<path:fn>")
def serve_web(fn):
    return _nocache(send_from_directory(WEB_DIR, fn))


def _old_ui():
    """예전 화면 파일 위치 (folder, name). 새로 설치한 PC에는 없음 → None."""
    for folder, name in ((HERE, "portfolio-pc.html"), (HERE, "portfolio.html"),
                         (os.path.join(HERE, "_backup"), "portfolio-pc_v38.html"),
                         (os.path.join(HERE, "_backup", "old_files"), "portfolio-pc.html")):
        if os.path.exists(os.path.join(folder, name)):
            return folder, name
    return None


@app.get("/old")
def serve_old_app():
    found = _old_ui()
    if found:
        return _nocache(send_from_directory(*found))
    return ("화면 파일을 찾을 수 없어요. 앱 폴더의 web 폴더가 그대로 있는지 확인해 주세요.", 404)


@app.get("/price")
def route_price():
    ticker = request.args.get("ticker", "")
    market = request.args.get("market", "")
    if not ticker:
        return jsonify({"status": "fail: no ticker"}), 400
    return jsonify(get_price(ticker, market))


@app.get("/prices")
def route_prices():
    """items=005930:kr,AAPL:us  형식으로 한 번에 여러 개. (병렬 조회로 빠르게)"""
    items = request.args.get("items", "")
    raws = [x.strip() for x in items.split(",") if x.strip()]

    def _one(raw):
        if ":" in raw:
            ticker, market = raw.split(":", 1)
        else:
            ticker, market = raw, ""
        return raw, get_price(ticker.strip(), market.strip())

    result = {}
    if raws:
        with ThreadPoolExecutor(max_workers=8) as ex:
            for raw, val in ex.map(_one, raws):
                result[raw] = val
    return jsonify(result)


@app.get("/news")
def route_news():
    ticker = request.args.get("ticker", "")
    market = request.args.get("market", "")
    name = request.args.get("name", "")
    if not ticker and not name:
        return jsonify([]), 400
    return jsonify(get_news(ticker, market, name))


_DAY_NEWS_CACHE = {}


@app.get("/api/day-news")
def route_day_news():
    """차트에서 누른 날짜 전후의 뉴스 (v2.18). 구글 뉴스의 after:/before: 날짜 검색을 씀.
    그날 뉴스가 적으면 앞뒤로 넓혀 보고, 종목 뉴스가 없으면 그날 시장(코스피·미국 증시) 뉴스를 붙임."""
    from datetime import date as _date, timedelta
    ticker = (request.args.get("ticker", "") or "").strip()
    name = (request.args.get("name", "") or "").strip()
    try:
        day = _date.fromisoformat((request.args.get("date", "") or "")[:10])
    except ValueError:
        return jsonify({"ok": False, "error": "날짜 형식이 맞지 않아요"}), 400
    if not (ticker or name):
        return jsonify({"ok": False, "error": "종목이 필요해요"}), 400
    is_kr = guess_market(ticker, request.args.get("market", "")) == "kr"
    base = name or (normalize_kr(ticker) if is_kr else ticker.upper())
    ck = (base, is_kr, day.isoformat())
    hit = _DAY_NEWS_CACHE.get(ck)
    if hit and time.time() - hit[0] < 3 * 3600:
        return jsonify(hit[1])
    lang = ("ko", "KR", "KR:ko") if is_kr else ("en-US", "US", "US:en")

    def search(q, span):
        a, b = day - timedelta(days=span), day + timedelta(days=span + 1)     # before: 는 그날을 포함하지 않음
        return google_news(f"{q} after:{a.isoformat()} before:{b.isoformat()}", *lang, limit=30)

    def near(items):
        out, seen = [], set()
        for it in items:
            dt = _parse_news_dt(it.get("date"))
            t = (it.get("title") or "").strip()
            k = re.sub(r"\s+", "", t.split(" - ")[0])[:40]
            if not t or k in seen:
                continue
            seen.add(k)
            if dt:                                   # 기사 시각을 그 나라 날짜로 (UTC 그대로면 한국 아침 기사가 전날로 잡힘)
                dt = dt + timedelta(hours=9 if is_kr else -5)
            gap = abs((dt.date() - day).days) if dt else 9
            out.append(dict(it, gap=gap, day=dt.date().isoformat() if dt else ""))
        out.sort(key=lambda x: (x["gap"], x.get("day", "")))
        return out

    q = f'"{base}"' if is_kr else (f'"{name}" OR {ticker.upper()}' if name and ticker else base)
    items, span = [], 0
    for span in (1, 3, 7):
        items = near(search(q, span))
        if len(items) >= 4:
            break
    market = []
    if len(items) < 3:
        market = near(search("코스피 증시" if is_kr else "stock market Wall Street", 1))[:6]
    res = {"ok": True, "date": day.isoformat(), "span": span, "items": items[:12], "market": market,
           "query": base}
    _DAY_NEWS_CACHE[ck] = (time.time(), res)
    if len(_DAY_NEWS_CACHE) > 300:
        _DAY_NEWS_CACHE.pop(next(iter(_DAY_NEWS_CACHE)))
    return jsonify(res)


@app.post("/api/day-why")
def route_day_why():
    """그날 주가가 왜 움직였는지 — 위 뉴스 제목만 근거로 AI가 짧게 정리."""
    q = request.get_json(force=True, silent=True) or {}
    name = str(q.get("name") or "")[:40]
    day = str(q.get("date") or "")[:10]
    move = str(q.get("move") or "")[:80]
    heads = [str(h)[:160] for h in (q.get("heads") or [])][:14]
    mk = [str(h)[:160] for h in (q.get("market") or [])][:6]
    prompt = f"""{name} 주가가 {day}에 이렇게 움직였어요: {move}

[그 무렵 이 종목 뉴스 제목 (날짜 포함)]
{chr(10).join("- " + h for h in heads) or "(없음)"}
{("[그날 시장 뉴스]" + chr(10) + chr(10).join("- " + h for h in mk)) if mk else ""}

[규칙]
- 위 뉴스 제목에 있는 사실만 근거로 쓰세요. 제목에 없는 사건·숫자를 지어내지 마세요.
- 뉴스와 주가 움직임이 잘 맞지 않거나 근거가 부족하면 "뉴스로는 뚜렷한 이유를 찾기 어려워요"라고 솔직히 말하고,
  시장 전체 흐름·수급 같은 가능성을 '추정'이라고 밝히며 짧게.
- 쉬운 우리말로, 아래 형식 그대로. 인사말 없이.

## 그날 무슨 일이?
(가장 그럴듯한 이유 한두 줄 — 결론부터)

## 근거가 된 뉴스
- 2~4개, 뉴스 → 주가에 준 영향 한 줄씩

## 지금 보면
(이 일이 지금도 영향을 주는지, 지나간 일인지 한 줄)"""
    text, prov, mdl, err = _ai_complete(prompt, max_out=900)
    if err == "NO_KEY":
        return jsonify({"status": "no_key"}), 200
    if not text:
        return jsonify({"status": "fail", "text": "AI 호출 실패: " + str(err)[:200]}), 200
    return jsonify({"status": "ok", "provider": prov, "model": mdl, "text": text}), 200


@app.get("/insight")
def route_insight():
    provider, key, model = _ai_config()
    if not key:
        # 키가 없어도 화면이 안 깨지게 200으로 안내만 반환
        return jsonify({"status": "no_key", "text":
            "AI 키가 설정되어 있지 않습니다.\n서버 PC에서 환경변수(GEMINI_API_KEY 또는 "
            "ANTHROPIC_API_KEY)를 넣고 서버를 다시 켜세요."}), 200

    ticker = request.args.get("ticker", "")
    market = request.args.get("market", "")
    name = request.args.get("name", "")
    price = request.args.get("price", "")
    per = request.args.get("per", "")
    pbr = request.args.get("pbr", "")
    rule = request.args.get("rule", "")
    if not (ticker or name):
        return jsonify({"status": "fail", "text": "종목명 또는 종목코드가 필요합니다."}), 200

    # 뉴스: 목표가/투자의견 변경 뉴스를 먼저 모으고(우선), 일반 뉴스를 뒤에 붙임
    is_kr = guess_market(ticker, market) == "kr"
    base = name if name else (normalize_kr(ticker) if is_kr else str(ticker).upper())
    target_news = []
    try:
        if is_kr:
            target_news = google_news(base + " 목표주가", "ko", "KR", "KR:ko", 6, MAX_NEWS_DAYS)
        else:
            target_news = google_news(base + " price target", "en-US", "US", "US:en", 6, MAX_NEWS_DAYS)
    except Exception:
        target_news = []
    try:
        general = get_news(ticker, market, name)
    except Exception:
        general = []
    merged = _merge_news(target_news, general)  # 목표가 뉴스가 앞으로
    merged = _fresh(merged, MAX_NEWS_DAYS, True)  # ★ 7일 넘는/날짜불명 뉴스는 AI에 안 씀
    merged = _sort_news_desc(merged)              # 최신순
    headlines = [n["title"] for n in merged if n.get("title")][:12]

    # 펀더멘털: 1순위 프런트가 저장해 보낸 값(시세 불러올 때 채워둔 것), 비면 즉석 조회.
    def _arg_num(name_):
        return _num_from(request.args.get(name_, ""))
    mcap_ccy = (request.args.get("mcap_ccy", "") or ("KRW" if is_kr else "USD")).upper()
    fund = {"per": _num_from(per), "pbr": _num_from(pbr),
            "forward_per": _arg_num("forward_per"),
            "peg": _arg_num("peg"), "roe": _arg_num("roe"),
            "op_income": _arg_num("op_income"), "op_margin": _arg_num("op_margin"),
            "market_cap": _arg_num("market_cap"), "eps": _arg_num("eps"),
            "asof": (request.args.get("asof", "") or None),
            "peg_growth": None, "peg_native": None, "val_warn": [], "ccy": mcap_ccy}
    # 교차검증된 묶음을 항상 한 번 받아(1시간 캐시) 평균값·불일치 경고를 AI에 그대로 전달.
    if (ticker or "").strip():
        try:
            fb = _fund_bundle(str(ticker).strip(), "kr" if is_kr else "us")
            for k in ("per", "pbr", "peg", "roe", "op_income", "op_margin",
                      "market_cap", "eps", "asof", "peg_growth", "peg_native",
                      "peg_basis", "eps_f", "ltg", "eps_rev",
                      "trend_class", "op_trend", "roe_trend"):
                if fb.get(k) is not None:
                    fund[k] = fb[k]
            if fb.get("fper") is not None:
                fund["forward_per"] = fb["fper"]
            fund["val_warn"] = fb.get("val_warn") or []
            fund["ccy"] = fb.get("ccy") or fund["ccy"]
        except Exception:
            pass

    mine = []
    if request.args.get("weight"):
        mine.append(f"계좌에서 이 종목 비중 {request.args.get('weight')}%")
    if request.args.get("ret"):
        mine.append(f"내 수익률 {request.args.get('ret')}%")
    if request.args.get("avg"):
        mine.append(f"내 평균 매입가 {request.args.get('avg')}")
    style = request.args.get("style", "")
    mctx = _market_context()
    past = (request.args.get("past", "") or "").strip()[:600]      # 이 종목의 지난 AI 판단 → 실제 결과 (기기에 저장된 성적표)
    if past:
        mctx = (mctx or "") + ("\n\n[이 종목에 대한 지난 AI 판단과 실제 결과 — 틀렸던 이유를 생각해 같은 실수를 반복하지 마세요]\n" + past)
    prompt = build_insight_prompt(name or ticker, ticker, price, fund, rule, headlines, " · ".join(mine), style, mctx)
    text, prov, mdl, err = _ai_complete(prompt, max_out=3100)
    if err == "NO_KEY":
        return jsonify({"status": "no_key", "text": "AI 키가 설정되어 있지 않습니다."}), 200
    if not text:
        return jsonify({"status": "fail",
                        "text": "AI 호출 실패(모든 키 소진/오류): " + str(err)[:300]}), 200
    return jsonify({"status": "ok", "provider": prov, "model": mdl,
                    "headline_count": len(headlines), "text": text}), 200


def _fmt_px(v, ccy):
    if v is None:
        return "?"
    return ("$%s" % format(v, ",.2f")) if ccy == "USD" else ("%s원" % format(round(v), ","))


def build_chart_prompt(name, ticker, ccy, ind, intraday, style):
    st = _style(style)
    label, horizon = STYLE_LABEL[st], STYLE_HORIZON[st]
    P = lambda v: _fmt_px(v, ccy)
    pct = lambda v: ("%+.1f%%" % v) if v is not None else "?"
    ma = ind["ma"]
    ma_line = " / ".join("%d일선 %s(현재가 %s)" % (n, P(ma[n]), pct((ind["last"] / ma[n] - 1) * 100) if ma[n] else "?")
                         for n in (5, 20, 60, 120) if ma[n])
    macd_state = ("MACD가 시그널 위(상승 힘)" if ind["macd_hist"] > 0 else "MACD가 시그널 아래(하락 힘)") + \
        (", 막대가 커지는 중" if ind["macd_hist_prev"] is not None and abs(ind["macd_hist"]) > abs(ind["macd_hist_prev"]) else ", 막대가 줄어드는 중")
    data = f"""종목: {name} ({ticker}) · 현재가 {P(ind['last'])}
이동평균: {ma_line}
{ind['cross'] or '최근 20·60일선 교차 없음'}
RSI(14): {ind['rsi']:.0f}  (70 넘으면 과열, 30 아래면 침체)
MACD: {macd_state}
거래량: 최근 5일 평균이 20일 평균의 {ind['vol_ratio']:.2f}배
변동성(ATR14): 하루 평균 {ind['atr_pct']:.1f}% 움직임
수익률: 1주 {pct(ind['ret']['1주'])} · 1달 {pct(ind['ret']['1달'])} · 3달 {pct(ind['ret']['3달'])} · 1년 {pct(ind['ret']['1년'])}
52주: 최고 {P(ind['hi52'])}(현재 {pct(ind['from_hi'])}) · 최저 {P(ind['lo52'])}(현재 {pct(ind['from_lo'])})
최근 20일 범위: 저점 {P(ind['sup20'])} ~ 고점 {P(ind['res20'])} · 60일 범위: {P(ind['sup60'])} ~ {P(ind['res60'])}
{intraday}"""
    return f"""당신은 한국 개인투자자의 차트 분석 투자비서입니다. 아래 [차트 자료](앱이 계산한 실제 숫자)만으로 기술적 분석을 하세요.
사용자 성향: {label} — {STYLE_GUIDE[st]}  판단 기간: {horizon}.

{QUICK_RULES}
{EASY_RULES}
- 숫자는 [차트 자료]에 있는 것만 쓰고 새로 지어내지 마세요. 가격대는 자료의 이동평균·고점·저점·변동성을 근거로.

[차트 자료]
{data}

[출력 형식] 아래 제목을 그대로, 이 순서로. 인사말 금지.

## AI 의견
방향: 상승 68% ({horizon} · {label} 기준)   ← 또는 "하락 61% (…)". 점수표로 계산한 1% 단위, 10~90, 50·5로 끝나는 수 금지.
계산: 기본 50 → 추세 +9 · 위치 -3 · 모멘텀 +6 · 거래량 +2 · 변동성 -4 = 60   ← 실제 차트로 채우기, 합계가 방향 숫자와 같아야 함
의견: 적극 매수 / 매수 / 분할 매수 / 보유 / 비중 축소 / 매도 중 하나
할 일: 초보도 바로 알아듣는 행동 한 문장, 강하게 (가격 넣어서)
이유: 차트에서 가장 큰 근거 한 문장

## 전문가 6인 투표
(서로 다른 6명이 각자 자기 기준으로만 따로 판단했다고 생각하고, 정확히 아래 6줄. 억지로 의견을 맞추지 마세요.)
- 추세 추종가(이동평균 배열·방향): 매수 / 보유 / 매도 중 하나 · 확신 0~100 — 이유 한 구절(자료의 숫자로)
- 모멘텀 투자자(최근 1~3개월 상승 힘): … · 확신 … — …
- 역발상투자자(과열·과매도 RSI, 52주 위치): … · 확신 … — …
- 돌파 매매가(최근 고점·저점 돌파 여부): … · 확신 … — …
- 거래량 분석가(거래량 증가·감소의 의미): … · 확신 … — …
- 위험 관리자(변동성·손절 거리·하락 위험): … · 확신 … — …
※ 위 'AI 의견'의 확률·의견은 이 6명의 투표(확신까지 반영)와 점수표를 합쳐서 나온 결론이어야 해요.

## 3초 요약
(차트 모양과 지금 할 일 한 줄)

## 차트 한눈에
- 추세: 상승 / 횡보 / 하락 중 하나 + 이유(이동평균 배열)
- 위치: 52주·최근 범위 안에서 어디쯤인지
- 힘: RSI·MACD·거래량으로 본 매수세/매도세

## 지표 쉽게 읽기
- 이동평균: (값 → 뜻)
- RSI: (값 → 뜻)
- MACD: (상태 → 뜻)
- 거래량: (배수 → 뜻)

## 지지선·저항선
- 🟦 지지(받쳐 주는 가격): (가격 1~2개와 근거)
- 🟥 저항(막히는 가격): (가격 1~2개와 근거)

## {label} 매매 참고선
참고선: 매수 (가격) / 손절 (가격) / 목표 (가격)
(위 한 줄은 숫자만 바꿔서 이 모양 그대로 쓰세요. 원화는 '원', 달러는 '$' 붙여서.)
- 왜 이 가격인지 한 줄씩

## 이런 모양이 나오면 주의
- 판단을 바꿔야 하는 차트 신호 2개
"""


@app.get("/api/ai/chart")
def route_ai_chart():
    ticker = (request.args.get("ticker") or "").strip()
    market = (request.args.get("market") or "").strip().lower()
    name = request.args.get("name", "") or ticker
    style = _style(request.args.get("style") or request.headers.get("X-AI-Style", ""))
    if not ticker:
        return jsonify({"status": "fail", "text": "종목 코드가 있어야 차트를 분석할 수 있어요."}), 200
    d = market_data.chart_rows(ticker, market, "1y", "1d")
    if not d or len(d["rows"]) < 60:
        return jsonify({"status": "fail", "text": "차트 자료(최근 1년 시세)를 가져오지 못했어요. 잠시 후 다시 시도해 주세요."}), 200
    rows = d["rows"]
    ind = market_data.tech_indicators(rows)
    ccy = "USD" if (d.get("currency") or "").upper() == "USD" else "KRW"
    intraday = ""
    if style in ("day", "scalp"):                        # 단타·스캘핑: 최근 5일 30분봉 흐름도
        try:
            m5 = market_data.chart_rows(ticker, market, "5d", "30m")
            if m5 and m5["rows"]:
                r5 = m5["rows"]
                intraday = "최근 5일 30분봉: 시작 %s → 지금 %s, 5일 고점 %s · 저점 %s" % (
                    _fmt_px(r5[0]["o"], ccy), _fmt_px(r5[-1]["c"], ccy),
                    _fmt_px(max(r["h"] for r in r5), ccy), _fmt_px(min(r["l"] for r in r5), ccy))
        except Exception:
            pass
    prompt = build_chart_prompt(name, ticker, ccy, ind, intraday, style)
    text, prov, mdl, err = _ai_complete(prompt, max_out=2700)
    if err == "NO_KEY":
        return jsonify({"status": "no_key", "text": "AI 키가 설정되어 있지 않습니다."}), 200
    if not text:
        return jsonify({"status": "fail", "text": "AI 호출 실패: " + str(err)[:200]}), 200
    closes = [[r["t"], r["c"]] for r in rows[-130:]]
    cs = [r["c"] for r in rows]
    ma = lambda n: [[rows[i]["t"], sum(cs[i - n + 1:i + 1]) / n] for i in range(len(rows) - 130, len(rows)) if i >= n - 1]
    return jsonify({"status": "ok", "provider": prov, "model": mdl, "text": text, "ccy": ccy,
                    "chart": {"points": closes, "ma20": ma(20), "ma60": ma(60),
                              "sup": ind["sup60"], "res": ind["res60"], "rsi": round(ind["rsi"]), "last": ind["last"]}}), 200


@app.get("/review")
def route_review():
    provider, key, model = _ai_config()
    if not key:
        return jsonify({"status": "no_key", "text":
            "AI 키가 설정되어 있지 않습니다. 서버 PC에서 환경변수를 넣고 다시 켜세요."}), 200
    policy = request.args.get("policy", "보수형")
    facts = request.args.get("facts", "")
    name = request.args.get("name", "")
    if not facts.strip():
        return jsonify({"status": "fail", "text": "계좌 수치가 비어 있습니다."}), 200

    prompt = f"""당신은 투자 초보에게 내 계좌 상태를 쉽게 설명해 주는 솔직한 투자 선생님입니다.
아래 [계좌 숫자]는 앱이 정확히 계산한 사실입니다. 숫자를 바꾸거나 새로 만들지 마세요.
기준은 '{policy}' 투자 성향입니다.

{EASY_RULES}

[계좌 숫자 — {name or "전체"}]
{facts}

[출력 형식] 아래 제목을 그대로, 이 순서로만. 인사말 금지.

## 계좌 점수
(정확히 아래 2줄 형식)
점수: 0~100 사이 숫자 하나 (기준을 잘 지킬수록 높게)
한마디: 이 계좌를 한 문장으로 (예: "한 종목에 너무 몰린, 공격적인 계좌예요")

## 한 줄 요약
(지금 계좌 상태를 1~2문장으로)

## 잘 되어 있는 점
- 1~3개

## 고치면 좋은 점
- 기준을 벗어난 항목을 쉬운 말로. 왜 위험한지 쉬운 비유 한 줄. (예: "달걀을 한 바구니에 담으면 떨어뜨렸을 때 다 깨져요")

## 숫자 풀이
- 항목마다 "이름(쉬운 뜻): 내 숫자 vs 기준 → 괜찮음/부족/넘침"

## 이렇게 하면 좋아져요
- 구체적이고 분명하게 2~3개. 어떤 비중을 몇 %까지 낮추거나 올리면 기준에 맞는지 숫자로.
"""
    text, prov, mdl, err = _ai_complete(prompt, max_out=1400)
    if err == "NO_KEY":
        return jsonify({"status": "no_key", "text": "AI 키가 설정되어 있지 않습니다."}), 200
    if not text:
        return jsonify({"status": "fail",
                        "text": "AI 호출 실패(모든 키 소진/오류): " + str(err)[:300]}), 200
    return jsonify({"status": "ok", "provider": prov, "model": mdl, "text": text}), 200


def build_briefing_prompt(stocks, mode="detail", style="", market_ctx="", period=""):
    """stocks: [{name,ticker,rule,headlines:[...]}]. mode: detail(자세히) / summary(요약·한 줄)."""
    blocks = []
    for s in stocks:
        hs = "\n".join("    · " + h for h in s.get("headlines", [])) or "    · (뉴스 없음)"
        rule = (s.get("rule") or "").strip()
        rline = f"\n    [내 규칙] {rule}" if rule else ""
        blocks.append(f"- {s.get('name') or s.get('ticker')} ({s.get('ticker') or '코드없음'}){rline}\n{hs}")
    body = "\n".join(blocks)
    principles = """당신은 투자 초보를 위해 내 종목 뉴스를 쉽게 정리해 주는 솔직한 비서입니다.
판단 기준: 회사가 '돈을 버는 힘(이익)'에 영향을 주는 소식인가? 하루 주가 등락·단순 화제는 '큰 영향 없음(gray)'.
뉴스 '제목'에 적힌 사실만 쓰고 지어내지 마세요. 증권사 목표가 등은 "○○증권은 …로 봤다"처럼 출처를 밝히세요.
쉬운 우리말로 짧게. 전문용어는 괄호로 뜻을 붙이세요. 애매하게 돌려 말하지 말고 분명하게."""

    if mode == "rich":
        st = _style(style)
        label, horizon = STYLE_LABEL[st], STYLE_HORIZON[st]
        return f"""당신은 한국 개인투자자의 똑똑한 투자비서입니다. 내 종목·관심종목 뉴스를 보고 '주가에 어떤 영향이 있을지'를 정리합니다.
이 사용자의 성향: {label} — {STYLE_GUIDE[st]}
판단 기간: {horizon}. 뉴스 기간: {period or "최근"}.

{QUICK_RULES}
판단 기준: 회사가 '돈을 버는 힘(이익)'과 '수급(사려는 돈)'에 영향을 주는가? 단순 화제·하루 등락은 gray.
뉴스 '제목'에 적힌 사실만 쓰고 지어내지 마세요. 증권사 목표가 등은 "○○증권은 …로 봤다"처럼 출처를 밝히세요.

{market_ctx or ""}

오직 JSON 배열로만(코드펜스·설명 없이):
[{{"name":"","ticker":"","flag":"green|red|gray","up":정수,"opinion":"","headline":"","impact":"","macro":"","action":"","insight":""}}]
- flag: green=주가에 좋은 소식 / red=나쁜 소식 / gray=큰 영향 없음(뉴스 없음 포함)
- up: {horizon} 동안 주가가 오를 확률. 위 점수표로 계산한 1% 단위 정수(예: 37, 58, 74). 10~90, 50과 5로 끝나는 수 금지, 종목마다 근거 차이만큼 뚜렷하게 다르게.
- opinion: "적극 매수" / "매수" / "분할 매수" / "보유" / "비중 축소" / "매도" 중 하나
- headline: 가장 중요한 뉴스 한 줄(쉬운 말로 다듬되 사실은 그대로). 뉴스가 없으면 "기간 내 새 뉴스 없음".
- impact: 그 뉴스가 주가에 주는 영향 한 줄. 형식: "📈 상승 요인·강 · 며칠~몇 주 — 이유" (📉 하락 요인 / ➖ 영향 적음)
- macro: 지금 시장 흐름(금리·환율·업종 분위기·외국인 수급·세계 이슈)과 연결한 한 줄.
- action: {label} 기준으로 지금 할 일 한 줄. 초보도 바로 알아듣게 명령형으로 분명하게, 숫자 넣어서(예: "지금 사지 마세요. 현재가 -3% 근처에서 1/3만 사고, -8% 깨지면 파세요").
- insight: 초보가 알아야 할 핵심 1~2문장.
모든 종목을 빠짐없이 포함하라.

[종목과 뉴스 제목]
{body}
"""
    if mode == "summary":
        return f"""{principles}

출력은 '한 종목당 정확히 한 줄'. JSON·코드펜스·설명·인사말 절대 금지.
형식(파이프 | 로 구분, 한 줄에 하나):
플래그|티커|종목명|한줄이유
- 플래그: red(이익 훼손 우려) / green(이익 성장 신호) / gray(소음·특이사항 없음)
- 한줄이유: 이익 구조 관점에서 아주 짧게(20자 이내). gray면 "소음".
모든 종목을 빠짐없이, 한 줄씩.

[종목과 뉴스 제목]
{body}
"""
    return f"""{principles}
오직 아래 JSON 배열로만 답하라. 코드펜스(```)·설명·인사말 없이 JSON만:
[{{"name":"","ticker":"","flag":"red|green|gray","reason":"","short":"","long":""}}]
- flag: red=이익 구조 훼손 우려 / green=이익 구조 성장 신호 / gray=소음·특이사항 없음
- reason: 그렇게 본 이유 한 줄(제목 근거). gray면 "구조적 이슈 없음(소음)".
- short(단기 관점): 단발·모멘텀으로 보이는지 한 줄.
- long(중장기 관점): 이익 구조 관점 한 줄. 제목만으론 단정하지 말고 "신호일 수 있으니 실적·본문 확인" 식으로.
모든 종목을 빠짐없이 포함하라.

[종목과 뉴스 제목]
{body}
"""


def _parse_briefing_lines(text):
    """요약 모드: '플래그|티커|종목명|이유' 줄들을 파싱. 잘린 마지막 줄은 자동 무시."""
    rows = []
    for ln in (text or "").splitlines():
        ln = ln.strip().strip("`").strip()
        if "|" not in ln:
            continue
        parts = [p.strip() for p in ln.split("|")]
        if len(parts) < 4:
            continue
        flag = parts[0].lower()
        if flag not in ("red", "green", "gray"):
            continue
        rows.append({"flag": flag, "ticker": parts[1], "name": parts[2], "reason": parts[3]})
    return rows


@app.post("/briefing")
def route_briefing():
    items = []
    mode = "detail"
    try:
        data = request.get_json(force=True, silent=True) or {}
        items = data.get("items") or []
        mode = (data.get("mode") or "detail").strip().lower()
    except Exception:
        items = []
    days_req = 0
    try:
        days_req = int(data.get("days") or 0)
    except Exception:
        days_req = 0
    try:
        hours_req = int(data.get("hours") or 0)
    except Exception:
        hours_req = 0
    style = str(data.get("style") or "")
    if mode not in ("detail", "summary", "rich"):
        mode = "detail"
    if not items:
        return jsonify({"status": "fail", "text": "종목이 없습니다."}), 200
    items = items[:25]  # 과도한 호출 방지

    # 종목당 뉴스 상한(비용 방어: 기간이 길어도 넣는 양은 비슷하게)
    n_head = 5 if mode == "rich" else (2 if mode == "summary" else 3)
    # 기간: 클라이언트가 days를 보내면 사용(1~14일), 아니면 모드 기본값
    news_days = days_req if 1 <= days_req <= 14 else (2 if mode != "rich" else 7)

    def _one(it):
        ticker = str(it.get("ticker") or "").strip()
        name = str(it.get("name") or "").strip()
        market = str(it.get("market") or "").strip()
        rule = str(it.get("rule") or "").strip()
        if not (ticker or name):
            return None
        try:
            if hours_req > 0:
                news = get_news_hours(ticker, market, name, hours_req)[:n_head]
            else:
                news = get_news_recent(ticker, market, name, days=news_days, min_keep=1)[:n_head]
            heads = [n["title"] for n in news if n.get("title")]
        except Exception:
            heads = []
        sector = "기타"
        if mode == "rich":
            try:
                sector = get_sector(ticker, market, name)
            except Exception:
                sector = "기타"
        if it.get("watch"):
            rule = ("[관심종목·아직 안 가짐] " + rule).strip()
        return {"name": name, "ticker": ticker, "rule": rule, "headlines": heads, "sector": sector,
                "watch": bool(it.get("watch"))}

    # 종목별 뉴스(+섹터) 수집을 동시에(순차 → 병렬) — 속도 대폭 개선
    stocks = []
    with ThreadPoolExecutor(max_workers=8) as ex:
        for s in ex.map(_one, items):
            if s:
                stocks.append(s)

    if not stocks:
        return jsonify({"status": "fail", "text": "분석할 종목이 없습니다."}), 200

    if hours_req > 0:
        period = "최근 12시간" if hours_req <= 12 else "최근 %d일" % round(hours_req / 24)
    else:
        period = "최근 %d일" % news_days
    prompt = build_briefing_prompt(stocks, mode, style, _market_context() if mode == "rich" else "", period)
    max_out = 4000 if mode == "rich" else (2800 if mode == "summary" else 2200)
    text, prov, mdl, err = _ai_complete(prompt, max_out=max_out,
                                        system=(_JSON_SYSTEM if mode != "summary" else _FORMAT_SYSTEM))
    if err == "NO_KEY":
        return jsonify({"status": "no_key", "text": "AI 키가 설정되어 있지 않습니다."}), 200
    if not text:
        return jsonify({"status": "fail", "text": "AI 호출 실패(모든 키 소진/오류): " + str(err)[:200]}), 200

    rule_by, sector_by = {}, {}
    watch_set = {(s["ticker"] or s["name"]) for s in stocks if s.get("watch")}
    name_to_ticker, ticker_set = {}, set()
    for s in stocks:
        k = (s["ticker"] or s["name"])
        rule_by[k] = s["rule"].replace("[관심종목·아직 안 가짐]", "").strip()
        sector_by[k] = s.get("sector", "기타")
        if s["ticker"]:
            ticker_set.add(s["ticker"])
        nm = re.sub(r"\s+", "", (s["name"] or "")).lower()
        if nm and s["ticker"]:
            name_to_ticker[nm] = s["ticker"]

    if mode == "summary":
        parsed = _parse_briefing_lines(text)
        if not parsed:
            return jsonify({"status": "ok_text", "provider": prov, "model": mdl, "text": text}), 200
        for row in parsed:
            k = (str(row.get("ticker") or "").strip() or str(row.get("name") or "").strip())
            row["rule"] = rule_by.get(k, "")
        return jsonify({"status": "ok", "mode": "summary", "provider": prov, "model": mdl, "items": parsed}), 200

    # rich / detail: JSON 파싱(코드펜스 제거 후)
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```[a-zA-Z]*\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    parsed = None
    try:
        parsed = json.loads(cleaned)
    except Exception:
        m = re.search(r"\[.*\]", cleaned, re.S)
        if m:
            try:
                parsed = json.loads(m.group(0))
            except Exception:
                parsed = None
    truncated = False
    if not isinstance(parsed, list):
        # 잘렸어도 살리기: 완성된 { ... } 객체만 하나씩 긁어 파싱(날것 노출 방지)
        salvaged = []
        for m in re.finditer(r"\{[^{}]*\}", cleaned, re.S):
            try:
                obj = json.loads(m.group(0))
                if isinstance(obj, dict) and (obj.get("name") or obj.get("ticker")):
                    salvaged.append(obj)
            except Exception:
                continue
        if salvaged:
            parsed = salvaged
            truncated = True
        else:
            return jsonify({"status": "fail", "provider": prov, "model": mdl,
                            "text": "분석 결과를 정리하지 못했어요(응답이 잘렸습니다). 종목 수를 줄이거나 다시 시도해 주세요."}), 200

    # 티커 교정(AI가 지어낸 티커를 우리가 보낸 값으로 덮음) + 규칙·섹터 부착
    out = []
    for row in parsed:
        if not isinstance(row, dict):
            continue
        rt = str(row.get("ticker") or "").strip()
        nm = re.sub(r"\s+", "", str(row.get("name") or "")).lower()
        if rt not in ticker_set and nm in name_to_ticker:
            row["ticker"] = name_to_ticker[nm]  # 이름이 맞으면 정확한 티커로 교정
            rt = row["ticker"]
        k = (rt or str(row.get("name") or "").strip())
        row["rule"] = rule_by.get(k, "")
        row["sector"] = sector_by.get(k, "기타")
        row["watch"] = k in watch_set
        try:                                   # 확률은 10~90으로 고정
            row["up"] = min(90, max(10, int(round(float(row.get("up"))))))
        except (TypeError, ValueError):
            row.pop("up", None)
        out.append(row)
    resp = {"status": "ok", "mode": mode, "provider": prov, "model": mdl, "items": out, "period": period}
    if truncated:
        resp["note"] = "일부 종목은 응답이 잘려 빠졌을 수 있어요."
    return jsonify(resp), 200


# ---------------------------------------------------------------------------
# 톱다운 통찰: ① 내 포트 누적 브리핑 ② 시장 전체 헤드라인(사각지대)
# ---------------------------------------------------------------------------
def get_market_headlines(days=3, limit_per=10):
    """시장 전반 헤드라인(내 종목과 무관). 어떤 섹터/테마가 시장에서 뜨는지 재료."""
    queries = [
        ("코스피 주도주 업종", "ko", "KR", "KR:ko"),
        ("증시 강세 테마", "ko", "KR", "KR:ko"),
        ("52주 신고가 종목", "ko", "KR", "KR:ko"),
        ("stock market sector leaders", "en-US", "US", "US:en"),
        ("hot stock sector today", "en-US", "US", "US:en"),
    ]
    seen, heads = set(), []
    cap = min(max(int(days or 1), 1), MAX_NEWS_DAYS)
    with ThreadPoolExecutor(max_workers=5) as ex:
        results = ex.map(lambda q: google_news(q[0], q[1], q[2], q[3], limit_per, cap), queries)
    for lst in results:
        for n in lst:
            if not _news_age_ok(n.get("date"), cap, strict=True):  # ★ 오래된/날짜불명 제외
                continue
            t = (n.get("title") or "").strip()
            key = re.sub(r"\s+", "", t)[:40]
            if t and key not in seen:
                seen.add(key)
                heads.append(t)
    return heads[:60]


def build_topdown_prompt(port_summary, market_heads):
    port_block = port_summary or "(아직 누적된 브리핑 데이터가 부족합니다)"
    mkt_block = "\n".join("- " + h for h in market_heads) if market_heads else "- (시장 헤드라인 없음)"
    
    return f"""당신은 투자 초보에게 '요즘 시장의 큰 흐름'을 쉽게 설명해 주는 솔직한 투자 선생님입니다.
아래 자료만 보고 판단하세요.

{QUICK_RULES}
{EASY_RULES}

{_market_context()}

[내 종목들의 최근 뉴스 신호]
{port_block}

[요즘 시장 전체 뉴스 제목]
{mkt_block}

[출력 형식] 아래 제목을 그대로, 이 순서로만. 인사말 금지.

## 시장 분위기
(정확히 아래 2줄 형식. 확률은 1% 단위로 따져서(예: 63%, 41%), 50%와 5로 끝나는 수는 쓰지 마세요.)
방향: 앞으로 1개월 국내외 주식시장이 오를 확률 62% (또는 "내릴 확률 58%") — 확률은 10~90 사이
한마디: 지금 시장을 한 문장으로

## 한 줄 요약
(요즘 시장에서 가장 큰 흐름 1~2문장)

## 요즘 돈이 몰리는 곳
- 분야 2~3개: 무엇 → 왜 (뉴스 근거)

## 요즘 힘이 빠지는 곳
- 1~2개

## 내 종목들과 비교하면
- 내 종목들이 이 흐름에 올라타 있는지, 빠져 있는지 (자료가 부족하면 "브리핑을 며칠 받으면 더 정확해져요")

## 눈여겨볼 만한 분야
- 조건으로 2개 (예: "AI 데이터센터에 전력 장비를 대는 회사")

## 가장 조심할 위험
- 한 가지만, 무슨 일이 생기면 시장이 크게 흔들릴지
"""


@app.post("/topdown")
def route_topdown():
    """톱다운 통찰: 내 포트 누적 신호 + 시장 헤드라인 → 섹터/방향(종목 추천 아님)."""
    try:
        data = request.get_json(force=True, silent=True) or {}
    except Exception:
        data = {}
    port_summary = str(data.get("port_summary") or "").strip()[:6000]

    try:
        market_heads = get_market_headlines(days=3, limit_per=10)
    except Exception:
        market_heads = []

    prompt = build_topdown_prompt(port_summary, market_heads)
    secs = ai_engine.req_sectors()
    if secs:   # 관심 섹터를 따로 점검
        prompt += f"""

[내 관심 섹터]
{ai_engine.sector_lines(secs)}
- 답의 끝에 '## 🎯 내 관심 섹터 점검' 단락을 넣어, 섹터마다 한 줄씩: 요즘 흐름(강세/중립/약세), 이유, 앞으로 볼 뉴스·일정.
- 위 시장 흐름 분석과 연결해, 지금 관심 섹터 중 어디가 상대적으로 유리한지 순서를 매겨 주세요."""
    text, prov, mdl, err = _ai_complete(prompt, max_out=2200 + (300 if secs else 0))
    if err == "NO_KEY":
        return jsonify({"status": "no_key", "text": "AI 키가 설정되어 있지 않습니다."}), 200
    if not text:
        return jsonify({"status": "fail", "text": "AI 호출 실패: " + str(err)[:200]}), 200
    return jsonify({"status": "ok", "provider": prov, "model": mdl,
                    "text": text, "market_count": len(market_heads)}), 200


@app.post("/discover")
def route_discover():
    """종목 발굴(추천): 내가 가진 종목·관심종목과 시장 뉴스를 보고 '참고용 후보'를 제안.
    실제 매수 지시가 아니라 '이런 걸 찾아볼 만하다'는 참고. 면책은 화면에서 표시."""
    provider, key, model = _ai_config()
    if not key:
        return jsonify({"status": "no_key", "text": "AI 키가 설정되어 있지 않습니다."}), 200
    try:
        data = request.get_json(force=True, silent=True) or {}
    except Exception:
        data = {}
    have = str(data.get("have") or "").strip()[:2000]      # 이미 가진/관심 종목 요약
    style = (data.get("style") or "").strip()
    try:
        market_heads = get_market_headlines(days=4, limit_per=12)
    except Exception:
        market_heads = []
    mkt = "\n".join("- " + h for h in market_heads[:50]) if market_heads else "- (시장 헤드라인 없음)"
    st = _style(style)
    secs = ai_engine.req_sectors(data.get("sectors"))
    sector_block = (f"""
[내 관심 섹터 — 이번 추천의 중점 (아주 중요)]
{ai_engine.sector_lines(secs)}
- 후보의 대부분(최소 70%)을 위 관심 섹터 안에서 고르세요. 나머지는 관심 섹터의 공급망·수혜 종목만 허용.
- 관심 섹터가 여러 개면 섹터마다 골고루 나누세요 (한 섹터에 몰지 말 것). 섹터 안에서도 세부 업종을 섞으세요.
- theme 맨 앞에 해당 섹터 이름을 [반도체]처럼 대괄호로 붙이세요.
- 관심 섹터 안에 이 성향 기준을 통과하는 종목이 정말 없으면 억지로 넣지 말고, why 에 그 사실을 밝히세요.
""" if secs else "")
    avoid = [str(x).strip() for x in (data.get("avoid") or []) if str(x).strip()][:40]
    same_kind = "세부 " if secs else ""
    avoid_block = ("\n[다른 성향에서 이미 추천한 종목 — 이번엔 절대 다시 고르지 말 것]\n- " + ", ".join(avoid) + "\n") if avoid else ""
    others = "\n".join(f"  · {STYLE_LABEL[k]}: {DISCOVER_RULES[k]['pick'][0]}" for k in DISCOVER_RULES if k != st)
    R = DISCOVER_RULES[st]
    prompt = f"""당신은 한국 개인투자자의 종목 발굴 투자비서입니다. 이번 요청은 오직 '{STYLE_LABEL[st]}' 성향 전용 후보 발굴입니다.
판단 기간: {STYLE_HORIZON[st]}. 성향 설명: {STYLE_GUIDE[st]}
[이 기능의 역할 — 숫자 조건 검색기와 다르게] 차트 숫자(이동평균·RSI 등)로 거르는 건 앱의 '조건 검색기'가 따로 합니다.
여기서는 '이야기'로 찾으세요: 새로 생긴 테마·정책·수주·신제품·업황 변화·산업 구조 변화 같은 재료로, 사용자가 아직 모를 만한 종목.
뻔한 시가총액 최상위 종목만 나열하지 말고, 재료가 분명하면 중소형주도 포함하세요(단 위험을 분명히).

{QUICK_RULES}
{EASY_RULES}

[{STYLE_LABEL[st]} 후보를 고르는 기준 — 전부 지킬 것]
{chr(10).join("- " + x for x in R["pick"])}

[{STYLE_LABEL[st]} 후보에서 반드시 뺄 것]
{chr(10).join("- " + x for x in R["avoid"])}

[성향끼리 겹치지 않게 — 아주 중요]
- 성향마다 좋은 종목은 완전히 다릅니다. 다른 성향은 이렇게 고릅니다(참고용, 이런 종목은 고르지 말 것):
{others}
- 누구에게나 무난한 초대형 우량주(예: 시가총액 1~5위권)를 습관적으로 넣지 마세요. 이 성향 기준을 '가장 잘' 통과하는 종목만.
- 후보끼리도 같은 {same_kind}업종이 2개를 넘지 않게 섞으세요.
{avoid_block}{sector_block}
- 반드시 '실제로 상장된' 한국·미국 종목만. 지어내지 마세요. 종목명과 코드를 함께.
- 내가 이미 가진/관심 종목은 빼세요.
- 추천은 참고일 뿐 매수 지시가 아님을 전제로, 그래도 분명하게 골라 주세요.

{_market_context()}

[요즘 시장 뉴스]
{mkt}

[내가 이미 가진/관심 종목]
{have or "(없음)"}

[출력 형식] 오직 아래 JSON 배열로만. 코드펜스·설명 없이. {R["count"]}개.
[{{"name":"","ticker":"","market":"kr|us","up":정수,"theme":"","why":"","fit":"","catalyst":"","entry":"","risk":""}}]
- name: 종목명 / ticker: 코드(한국 6자리, 미국 영문) / market: kr 또는 us
- up: {STYLE_HORIZON[st]} 동안 오를 확률(점수표로 계산한 1% 단위 정수, 10~90, 50과 5로 끝나는 수 금지, 후보마다 다르게)
- theme: 이 종목이 올라탄 흐름 한 구절 (예: "AI 전력", "비만치료제")
- why: 왜 지금 볼 만한지 한 문장
- fit: 왜 '{STYLE_LABEL[st]}'에 맞는지 — 위 기준 중 어떤 걸 통과했는지 구체적으로 한 문장
- catalyst: {R["catalyst"]}
- entry: {R["entry"]} — 원·달러 가격을 기억으로 적지 말고 '현재가 대비 -3%', '20일선 근처'처럼 비율·기준으로만 (앱이 실제 현재가를 따로 확인해 붙여요)
- risk: 이 성향 기준에서 가장 큰 위험 한 줄
"""
    text, prov, mdl, err = _ai_complete(prompt, max_out=2600, system=_JSON_SYSTEM)
    if err == "NO_KEY":
        return jsonify({"status": "no_key"}), 200
    if not text:
        return jsonify({"status": "fail", "text": "AI 호출 실패: " + str(err)[:200]}), 200
    import re as _re
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = _re.sub(r"^```[a-zA-Z]*\s*", "", cleaned)
        cleaned = _re.sub(r"\s*```$", "", cleaned)
    items = None
    try:
        items = json.loads(cleaned)
    except Exception:
        m = _re.search(r"\[.*\]", cleaned, _re.S)
        if m:
            try:
                items = json.loads(m.group(0))
            except Exception:
                items = None
    if not isinstance(items, list):
        return jsonify({"status": "ok_text", "provider": prov, "model": mdl, "text": text}), 200
    out = []
    for it in items:
        if isinstance(it, dict) and (it.get("name") or it.get("ticker")):
            out.append(it)

    def _verify(it):                      # AI가 고른 종목의 실제 시세 확인 (없으면 '확인 안 됨'으로 표시)
        t = str(it.get("ticker") or "").strip().upper()
        m = "us" if (it.get("market") == "us" or re.match(r"^[A-Z]", t)) else "kr"
        try:
            p = get_price(t, m) if t else {}
        except Exception:
            p = {}
        if p and p.get("price"):
            it["price_now"], it["price_ccy"] = p["price"], p.get("currency") or ("KRW" if m == "kr" else "USD")
            it["price_chg"], it["price_at"] = p.get("change_pct"), p.get("asof") or _now()
            if p.get("name"):
                it["name_checked"] = p["name"]
        else:
            it["price_now"] = None
        return it
    with ThreadPoolExecutor(max_workers=6) as ex:
        out = list(ex.map(_verify, out[:8]))
    return jsonify({"status": "ok", "provider": prov, "model": mdl, "items": out,
                    "market_count": len(market_heads)}), 200


@app.get("/debug_us")
def route_debug_us():
    """진단용: 미국 티커의 네이버 해외 심볼·PER/PBR 원본 구조를 확인."""
    t = (request.args.get("ticker") or request.args.get("code") or "").strip().upper()
    code = _naver_world_code(t)
    sym = code or (t + ".O")
    rep = {"server_version": SERVER_VERSION, "ticker": t, "naver_code": code,
           "naver_fundamentals(per,pbr,fwd)": _us_fundamentals_naver(t),
           "sources": {}}
    cands = {
        "api_basic": f"https://api.stock.naver.com/stock/{sym}/basic",
        "api_integration": f"https://api.stock.naver.com/stock/{sym}/integration",
    }
    for tag, u in cands.items():
        try:
            r = requests.get(u, headers=API_HEADERS, timeout=TIMEOUT)
            info = {"http": r.status_code}
            try:
                d = r.json()
                if isinstance(d, dict):
                    info["top_keys"] = list(d.keys())[:45]
                    for fk in ("totalInfos", "stockItemTotalInfos"):
                        v = d.get(fk)
                        if isinstance(v, list):
                            info[fk] = [{"code": x.get("code"), "key": x.get("key"), "value": x.get("value")}
                                        for x in v if isinstance(x, dict)]
                    info["extracted(name,per,pbr,fwd)"] = _kr_fundamentals(d)
                else:
                    info["body_head"] = r.text[:1200]
            except Exception as e:
                info["json_error"] = f"{type(e).__name__}"
                info["body_head"] = r.text[:600]
            rep["sources"][tag] = info
        except Exception as e:
            rep["sources"][tag] = {"error": f"{type(e).__name__}: {e}"[:160]}
    return jsonify(rep)


@app.get("/debug_kr")
def route_debug_kr():
    """진단용: 네이버가 이 PC에서 실제로 뭘 주는지(이름·PER·PBR 포함) 보여줍니다."""
    code = normalize_kr(request.args.get("code", "") or request.args.get("ticker", ""))
    rep = {"server_version": SERVER_VERSION, "code": code, "price_kr_result": price_kr(code), "sources": {}}

    # 통합 API: 펀더멘털 구조를 자세히 (두 주소 모두, 모바일 헤더 사용)
    for tag, u in (("m_integration", f"https://m.stock.naver.com/api/stock/{code}/integration"),
                   ("api_integration", f"https://api.stock.naver.com/stock/{code}/integration")):
        try:
            r = requests.get(u, headers=API_HEADERS, timeout=TIMEOUT)
            info = {"http": r.status_code, "ctype": r.headers.get("Content-Type", "")}
            try:
                d = r.json()
                info["top_keys"] = list(d.keys())[:40] if isinstance(d, dict) else "(list)"
                info["stockName"] = d.get("stockName") if isinstance(d, dict) else None
                ti = d.get("totalInfos") if isinstance(d, dict) else None
                if isinstance(ti, list):
                    info["totalInfos"] = [{"code": x.get("code"), "key": x.get("key"), "value": x.get("value")}
                                          for x in ti if isinstance(x, dict)]
                else:
                    info["body_head"] = r.text[:1500]
                info["extracted(name,per,pbr,fwd)"] = _kr_fundamentals(d)
            except Exception as e:
                info["json_error"] = f"{type(e).__name__}: {e}"
                info["body_head"] = r.text[:500]
            rep["sources"][tag] = info
        except Exception as e:
            rep["sources"][tag] = {"error": f"{type(e).__name__}: {e}"[:200]}

    # 폴링(가격·이름)
    for k, u in {"polling": f"https://polling.finance.naver.com/api/realtime/domestic/stock/{code}",
                 "m_basic": f"https://m.stock.naver.com/api/stock/{code}/basic"}.items():
        try:
            r = requests.get(u, headers=API_HEADERS, timeout=TIMEOUT)
            rep["sources"][k] = {"http": r.status_code, "body": r.text[:400]}
        except Exception as e:
            rep["sources"][k] = {"error": f"{type(e).__name__}: {e}"[:200]}
    return jsonify(rep)


@app.get("/shutdown")
def route_shutdown():
    """앱 종료 버튼이 부릅니다. 0.6초 뒤 서버 프로세스를 완전히 끕니다."""
    def _stop():
        time.sleep(0.6)
        os._exit(0)
    threading.Thread(target=_stop, daemon=True).start()
    return jsonify({"status": "ok", "text": "서버를 끕니다."})


@app.get("/fx")
def route_fx():
    return jsonify(get_fx())


@app.get("/debug_dart")
def route_debug_dart():
    """DART 진단: 키 유효성 + corp_code 매핑 + 다년치 영업이익/ROE 추세.
    예) /debug_dart?ticker=000660"""
    t = (request.args.get("ticker") or "").strip()
    if not t:
        return jsonify({"error": "ticker 필요. 예: /debug_dart?ticker=000660"}), 400
    rep = {"server_version": SERVER_VERSION, "ticker": t,
           "dart_key_set": bool(DART_API_KEY),
           "corp_map_size": len(_dart_corp_map()),
           "corp_code": _dart_corp_code(t)}
    try:
        rep["financials"] = _dart_financials(t)
    except Exception as e:
        rep["error"] = f"{type(e).__name__}: {e}"[:200]
    return jsonify(rep)


@app.get("/debug_fund")
def route_debug_fund():
    """펀더멘털 진단: 야후 crumb 상태 + 야후/네이버 각 소스 원본 + 최종 묶음을 한눈에.
    예) /debug_fund?ticker=AAPL&market=us   /debug_fund?ticker=005930&market=kr"""
    t = (request.args.get("ticker") or "").strip()
    market = (request.args.get("market") or "").strip()
    if not t:
        return jsonify({"error": "ticker 가 필요합니다. 예: /debug_fund?ticker=AAPL&market=us"}), 400
    is_kr = guess_market(t, market) == "kr"
    # 캐시 무시하고 새로 보기 위해 fund 캐시 키 제거
    _CACHE.pop("fund:" + t.upper() + ":" + ("kr" if is_kr else "us"), None)
    _YS["crumb"] = None  # crumb도 새로 받아 상태 확인
    s, crumb = _yahoo_session()
    rep = {"server_version": SERVER_VERSION, "ticker": t, "market": "kr" if is_kr else "us",
           "yahoo_crumb_ok": bool(crumb),
           "yahoo_cookies": len(s.cookies) if s else 0,
           "yahoo_symbols_tried": _yahoo_symbols(t, market)}
    # 야후 각 심볼 원본
    rep["yahoo_raw"] = {}
    for sym in _yahoo_symbols(t, market):
        rep["yahoo_raw"][sym] = _us_fundamentals(sym)
    # 네이버 원본 추출
    try:
        nd = _naver_kr_dict(normalize_kr(t)) if is_kr else _naver_world_dict(t)
        rep["naver_extra"] = _naver_extra(nd) if nd else None
        rep["naver_per_pbr_fwd"] = _kr_fundamentals(nd)[1:] if nd else None
    except Exception as e:
        rep["naver_error"] = f"{type(e).__name__}: {e}"[:160]
    # 최종 묶음(앱이 실제로 쓰는 값)
    rep["final_bundle"] = _fund_bundle(t, "kr" if is_kr else "us")
    return jsonify(rep)


def _port_busy(port):
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s_:
        s_.settimeout(0.5)
        return s_.connect_ex(("127.0.0.1", port)) == 0


def _open_browser_when_ready(url, port):
    import webbrowser

    def _wait():
        for _ in range(60):
            if _port_busy(port):
                webbrowser.open(url)
                return
            time.sleep(0.25)
    threading.Thread(target=_wait, daemon=True).start()


if __name__ == "__main__":
    import logging
    import webbrowser
    PORT = 8000
    URL = f"http://localhost:{PORT}/app"
    want_open = "--open" in sys.argv
    if _port_busy(PORT):
        # 이미 켜져 있으면(아이콘을 두 번 누른 경우 등) 브라우저만 열고 끝
        print("이미 켜져 있어요. 브라우저에서 앱을 엽니다.")
        if want_open:
            webbrowser.open(URL)
        sys.exit(0)
    _LAN_ACTIVE = bool(ai_engine.load_settings().get("lan_access"))
    host = "0.0.0.0" if _LAN_ACTIVE else "127.0.0.1"  # 기본: 이 PC에서만
    logging.getLogger("werkzeug").setLevel(logging.WARNING)  # 접속 로그로 창이 지저분해지지 않게
    st = ai_engine.status_summary()
    print("=" * 60)
    print(f"  내 투자 비서가 켜졌습니다  ({SERVER_VERSION})")
    print(f"  앱 주소 : {URL}")
    if _LAN_ACTIVE:
        for ip in _local_ips():
            print(f"  휴대폰  : http://{ip}:{PORT}  (같은 와이파이)")
    print("  AI 연결 : " + (f"{st['provider']} / {st['model']}" if st["on"] else "아직 없음 (앱 → 설정 → AI 연결)"))
    print("")
    print("  ※ 이 검은 창을 닫으면 앱이 꺼집니다. 쓰는 동안은 최소화(_)만 해 두세요.")
    print("=" * 60)
    if want_open:
        _open_browser_when_ready(URL, PORT)
    try:                                     # PC판 자동 업데이트 (설치된 앱 폴더에서만)
        import pc_update
        pc_update.start(HERE, _version_code(), _update_url())
    except Exception:
        pass
    app.run(host=host, port=PORT, debug=False, threaded=True)