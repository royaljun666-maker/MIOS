/* ==========================================================================
   pages.js — 홈 · 내 계좌(+종목 상세) · 시장 · 자산 기록
   ========================================================================== */
'use strict';

const PAGES = {};
let route = { page: 'home', params: {} };
let curAccId = null, selH = null;

function pageEl(name) { return document.getElementById('page-' + name); }
function rerender() { if (PAGES[route.page]) PAGES[route.page](route.params || {}, true); refreshChrome(); }

/* 사이드바·상단바의 사람 이름, AI 상태 등 */
function refreshChrome() {
  const p = P(), n = accounts().length;
  const ini = (p.name || '나').trim().slice(0, 1);
  ['sbAvatar', 'mAvatar'].forEach(id => { const e = document.getElementById(id); if (e) e.textContent = ini; });
  document.getElementById('sbName').textContent = p.name;
  document.getElementById('mName').textContent = p.name;
  document.getElementById('sbSub').textContent = '계좌 ' + n + '개 · ' + korUnit(grand().asset);
}

/* ========================================================================
   홈
   ======================================================================== */
PAGES.home = function (params, re) {
  const el = pageEl('home');
  const G = grand(), accs = accounts();
  const hist = P().history.slice().sort((a, b) => a.date < b.date ? -1 : 1);
  const refreshed = UI.lastRefresh ? '시세 ' + ago(UI.lastRefresh) + ' 갱신' : '시세를 아직 불러오지 않았어요';

  const heroDelta = accs.length ?
    '<div class="delta"><span class="muted dl-k">평가손익</span><span class="pl ' + cls(G.pl) + '">' + arrow(G.pl) + ' ' + wonS(G.pl) + ' (' + pct(G.ret) + ')</span>' +
    (G.day != null ? '<span class="today ' + cls(G.day) + '" data-tip="가장 최근 거래일의 등락 기준이에요">하루 ' + wonS(G.day) + (G.dayPct != null ? ' (' + pct(G.dayPct) + ')' : '') + '</span>' : '') + '</div>' : '';

  const hero =
    '<div class="card hero hero-x span-8"><i class="fx-orb o1"></i><i class="fx-orb o2"></i>' +
      '<div class="label">' + icon('wallet', 'ic-sm') + '총 자산 <span class="muted" style="font-weight:500;font-size:.82rem">모든 계좌 주식 + 현금</span></div>' +
      '<div class="total"><span id="heroTotal">' + nf(Math.round(G.asset), 0) + '</span><small>원</small></div>' +
      (G.asset >= 10000 ? '<div class="approx">약 ' + korUnit(G.asset) + '</div>' : '') +
      heroDelta +
      (accs.length ?
        '<div class="hero-mini"><span>원금 <b>' + korUnit(G.cost) + '</b></span><span>주식 <b>' + korUnit(G.stock) + '</b></span><span>현금 <b>' + korUnit(G.cash) + '</b></span><span>$1 = <b>' + nf(fx(), 0) + '원</b></span>' +
          (G.us > 0 && G.asset > 0 ? '<span data-tip="달러로 된 자산(해외 주식)은 환율이 오르면 원화로 늘고, 내리면 줄어요">달러 자산 <b>' + (G.us / G.asset * 100).toFixed(0) + '%</b> · 환율 10원↑ <b>' + wonS(G.us / fx() * 10) + '</b></span>' : '') + '</div>' +
        '<div class="hero-chart">' + (hist.length >= 2 ? '<div class="sb-cap"><span>자산 변화 (기록 ' + hist.length + '개)</span><a class="more" data-nav="history" style="cursor:pointer">자세히 ›</a></div><div id="homeChart"></div>' :
          '<div class="callout gray">' + icon('info', 'ic-sm') + '<div>시세를 갱신하면 그날 자산이 <b>자동으로 기록</b>돼요. 기록이 2일 이상 쌓이면 여기 <b>자산 변화 그래프</b>가 그려집니다.</div></div>') + '</div>'
      : '<div class="callout info" style="margin-top:20px">' + icon('info', 'ic-sm') + '<div>아직 계좌가 없어요. <b>계좌를 만들고 가진 주식을 넣으면</b> 총자산·수익률이 자동으로 계산돼요.</div></div>' +
        '<button class="btn btn-primary btn-lg" style="margin-top:16px" data-act="acc-new">' + icon('plus') + '첫 계좌 만들기</button>') +
    '</div>';

  // 자산 구성
  const mode = UI.homeAlloc === 'acc' ? 'acc' : 'type';
  let segs;
  if (mode === 'acc') segs = accs.map(a => { const t = accT(a); return { label: a.name, value: t.asset, color: aColor(a), amt: won(t.asset) }; });
  else segs = [
    { label: '국내 주식', value: G.kr, color: 'var(--c1)', amt: won(G.kr) },
    { label: '해외 주식', value: G.us, color: 'var(--c2)', amt: won(G.us) },
    { label: '현금', value: G.cash, color: 'var(--c-other)', amt: won(G.cash) },
  ];
  segs = foldSegs(segs.filter(s => s.value > 0), 7);
  const tot = segs.reduce((s, x) => s + x.value, 0);
  const alloc =
    '<div class="card span-4" id="allocCard">' +
      '<div class="card-head"><h3>' + icon('pie', 'ic-sm') + '자산 구성</h3>' +
        '<div class="seg"><button data-act="home-alloc" data-v="type" class="' + (mode === 'type' ? 'on' : '') + '">종류별</button><button data-act="home-alloc" data-v="acc" class="' + (mode === 'acc' ? 'on' : '') + '">계좌별</button></div></div>' +
      (tot > 0 ? '<div class="alloc" style="flex-direction:column;align-items:stretch">' +
        '<div style="align-self:center">' + donut(segs, { size: 176, center: '<span>총 자산</span><b>' + compactKRW(G.asset) + '원</b>' }) + '</div>' +
        legendHtml(segs, tot, true) + '</div>'
      : '<div class="empty" style="padding:30px 10px"><div class="ill">' + icon('pie') + '</div><p>종목을 넣으면 자산 구성이 보여요.</p></div>') +
    '</div>';

  // 오늘 확인할 것 (한눈에 보는 할 일)
  const today = accs.length ? homeTodayCard() : '';

  // 시장 띠
  const qa = (ic, t, act, cls) => '<button class="qa ' + cls + '" ' + act + '><span class="qa-ico">' + icon(ic) + '</span><b>' + t + '</b></button>';
  const strip = '<div class="span-12 qa-row">' +
    qa('clipboard', 'AI 브리핑', 'data-act="ai-brief-all"', 'q1') + qa('activity', '차트 분석', 'data-act="ai-chart-pick"', 'q2') +
    qa('globe', '시장', 'data-nav="market"', 'q3') + qa('plus', '종목 추가', 'data-act="h-new"', 'q4') + '</div>';
  // 🗓 장 브리핑 바로가기 (v2.26) — 지금 시간에 맞는 것을 한 번에
  const sbk = feat('brief') ? sbNow() : '', sbt = sbk ? SB.find(x => x[0] === sbk) : null;
  const sbHome = sbt ? '<div class="span-12 sb-home"><button class="sb-main" data-act="sbrief" data-k="' + sbk + '"><span class="sb-ic">🗓</span><div><b>' + esc(sbt[1]) + ' 브리핑</b><em>' + esc(sbt[2]) + ' · 눌러서 바로 받기</em></div><i>›</i></button>' +
    '<button class="sb-other" data-act="ai-sb-open">다른 브리핑</button></div>' : '';

  // 계좌 목록
  const accRows = accs.map(a => {
    const t = accT(a), w = G.asset > 0 ? t.asset / G.asset * 100 : 0;
    return '<div class="li acc-li" data-act="open-acc" data-a="' + a.id + '">' +
      '<div class="logo" style="background:' + aColor(a) + '">' + esc((a.name || '?').slice(0, 1)) + '</div>' +
      '<div class="mid"><b>' + esc(a.name) + '</b><span>종목 ' + a.holdings.length + '개 · 비중 ' + w.toFixed(0) + '%</span></div>' +
      '<div class="end"><b>' + won(t.asset) + '</b><span class="' + cls(t.pl) + '">' + pct(t.ret) + '</span></div></div>';
  }).join('');
  const accBox = '<div class="card span-8"><div class="card-head"><h3>' + icon('card', 'ic-sm') + '내 계좌 <span class="muted" style="font-weight:600">' + accs.length + '</span></h3>' +
    '<div style="display:flex;gap:6px"><button class="btn btn-ghost btn-sm" data-act="acc-new">' + icon('plus', 'ic-sm') + '추가</button><a class="more" data-nav="accounts">전체' + icon('chevron-right', 'ic-sm') + '</a></div></div>' +
    (accs.length ? '<div class="list">' + accRows + '</div>' : '<div class="empty" style="padding:20px"><p style="margin:0">계좌를 추가해 보세요.</p></div>') + '</div>';

  // 종목 성적
  const rows = allHoldings().map(x => ({ a: x.a, h: x.h, v: hv(x.h) })).filter(x => x.v.cost > 0);
  const best = rows.slice().sort((p, q) => q.v.ret - p.v.ret);
  const pick = best.length > 4 ? best.slice(0, 2).concat(best.slice(-2)) : best;
  const perf = '<div class="card"><div class="card-head"><h3>' + icon('activity', 'ic-sm') + '내 종목 성적</h3>' +
      (best.length > 4 ? '<button class="btn btn-ghost btn-sm" data-act="perf-more">전체 ' + best.length + '개</button>' : '<span class="muted" style="font-size:.8rem">수익률 순</span>') + '</div>' +
    (pick.length ? '<div class="list" id="perfList">' + pick.map(x => holdRowHtml(x.a, x.h, x.v)).join('') + '</div>'
      : '<div class="empty" style="padding:24px 10px"><p style="margin:0">종목을 넣으면 수익률 순위가 보여요.</p></div>') + '</div>';

  const aiOn = AI_STATUS && AI_STATUS.on;
  const aiCard = '<div class="card">' +
    '<div class="card-head"><h3>' + icon('sparkles', 'ic-sm') + 'AI 비서</h3>' + (aiOn ? '<span class="badge green">연결됨</span>' : '<span class="badge orange">연결 전</span>') + '</div>' +
    (aiOn ? '<p class="note" style="margin:0 0 14px">' + esc(AI_STATUS.provider) + ' · ' + esc(AI_STATUS.model) + '</p>' +
      '<div class="stack" style="gap:8px"><button class="btn btn-soft btn-block" data-act="ai-brief-all">' + icon('clipboard') + '오늘의 전체 브리핑</button>' +
      '<button class="btn btn-gray btn-block" data-act="ai-chat">' + icon('message') + 'AI에게 물어보기</button></div>'
    : '<p class="note" style="margin:0 0 14px">무료 AI를 연결하면 내 종목 뉴스를 정리하고, 궁금한 걸 물어볼 수 있어요. 3분이면 끝나요.</p>' +
      '<button class="btn btn-primary btn-block" data-nav="settings" data-sec="ai">' + icon('key') + '무료 AI 연결하기</button>') + '</div>';

  el.innerHTML = fxMarqueeHtml() +
    '<div class="page-head"><div><h1>' + (P().name === '나' ? '내 자산' : esc(P().name) + '님의 자산') + '</h1><div class="desc">' + todayLong() + ' · ' + refreshed + '</div></div>' +
      '<div class="actions">' +
        (accs.length ? '<button class="btn btn-outline btn-hide-m" data-act="save-snap">' + icon('bookmark') + '오늘 기록 저장</button>' : '') +
        '<button class="btn btn-primary" data-act="refresh-all" data-refresh-btn>' + icon('refresh') + '시세 갱신</button></div></div>' +
    '<div class="grid g-12' + (re ? '' : ' fx-enter') + '">' + hero + today + strip + sbHome + promoSlot('home') + alloc + fxHeatmapCard() + accBox + '<div class="stack span-4">' + perf + '</div></div>';
  hydrateIcons(el); bindTips(el);
  if (hist.length >= 2) {
    const pts = hist.slice(-90).map(s => [s.date, s.totalAsset]);
    lineChart(document.getElementById('homeChart'), pts, {
      height: 110, yTicks: 3, color: '#fff', fmtX: d => dateLabel(d).slice(3), fmtAxis: v => compactKRW(v),
      fmtV: v => won(v), label: '총자산 변화',
      tip: (p, i, a) => '<span class="d">' + esc(dateLabel(p[0])) + '</span><br>' + esc(won(p[1])) + (i ? '<br><span class="' + cls(p[1] - a[i - 1][1]) + '">' + esc(wonS(p[1] - a[i - 1][1])) + '</span>' : ''),
    });
  }
  fxCountUp(document.getElementById('heroTotal'), Math.round(G.asset), { key: 'hero' });
  fxRenderHeatmap(!re);
  fxMarqueeSpeed(); fxStartLiveMarket();
  if (accs.length) fxRecordCheck(G.asset, hist);
  loadMarket(false).then(() => {
    const m = document.querySelector('#homeMarquee .fx-mq-track'); if (m && !m.querySelector('[data-mk]')) { m.innerHTML = fxMarqueeItems(); fxMarqueeSpeed(); }
  });
};

/* 홈 '오늘 확인할 것' — 시세 상태·오늘 크게 움직인 종목·건강검진 주의·큰 손실·AI 연결을 3~4줄로 */
function homeTodayCard() {
  const items = [], rows = allHoldings().map(x => ({ a: x.a, h: x.h, v: hv(x.h) }));
  const it = (ic, tone, html, act, btn) => items.push('<button class="td-i ' + tone + '" ' + act + '><span class="td-ico">' + icon(ic, 'ic-sm') + '</span><span class="td-t">' + html + '</span>' +
    (btn ? '<span class="td-b">' + btn + '</span>' : icon('chevron-right', 'ic-sm')) + '</button>');
  const stale = !UI.lastRefresh || Date.now() - UI.lastRefresh > 3 * 3600e3;
  if (stale) it('refresh', 'warn', UI.lastRefresh ? '시세가 <b>' + ago(UI.lastRefresh) + '</b> 기준이에요' : '아직 <b>시세를 불러오지 않았어요</b>', 'data-act="refresh-all"', '갱신');
  const moved = rows.filter(x => x.v.chg != null).sort((p, q) => q.v.chg - p.v.chg);
  if (moved.length) {
    const up = moved[0], dn = moved[moved.length - 1], nm = x => esc(dispName(x.h));
    if (up.v.chg > 0) it('trending-up', 'up', '오늘 가장 오른 종목 <b>' + nm(up) + ' <em class="up">' + pct(up.v.chg) + '</em></b>', 'data-act="open-h" data-a="' + up.a.id + '" data-h="' + up.h.id + '"');
    if (dn !== up && dn.v.chg < 0) it('trending-down', 'down', '오늘 가장 내린 종목 <b>' + nm(dn) + ' <em class="down">' + pct(dn.v.chg) + '</em></b>', 'data-act="open-h" data-a="' + dn.a.id + '" data-h="' + dn.h.id + '"');
  }
  const p = pol(), warnAcc = accounts().map(a => ({ a, n: a.holdings.length ? violCount(accCheck(a, accT(a)), p) : 0 })).filter(x => x.n > 0).sort((x, y) => y.n - x.n);
  if (warnAcc.length) it('shield', 'warn', '계좌 건강검진 주의 <b>' + esc(warnAcc[0].a.name) + ' ' + warnAcc[0].n + '개</b>' + (warnAcc.length > 1 ? ' 외 ' + (warnAcc.length - 1) + '계좌' : ''), 'data-act="open-acc" data-a="' + warnAcc[0].a.id + '"');
  const loss = rows.filter(x => x.v.cost > 0 && x.v.ret <= -15).sort((x, y) => x.v.ret - y.v.ret);
  if (loss.length) it('alert', 'down', '손실이 큰 종목 <b>' + esc(dispName(loss[0].h)) + ' <em class="down">' + pct(loss[0].v.ret, 1) + '</em></b>' + (loss.length > 1 ? ' 외 ' + (loss.length - 1) + '개' : '') + ' · AI 분석 받아 보기', 'data-act="open-h" data-a="' + loss[0].a.id + '" data-h="' + loss[0].h.id + '"');
  if (!sectors().length) it('target', 'info', '<b>관심 섹터</b>를 고르면 AI가 그 분야 위주로 종목을 찾아 줘요', 'data-act="pick-sectors"', '고르기');
  if (!(AI_STATUS && AI_STATUS.on)) it('sparkles', 'info', '무료 AI를 연결하면 <b>뉴스 영향·오를 확률</b>을 알려 줘요', 'data-nav="settings" data-sec="ai"', '연결');
  return '<div class="card span-4 td-card"><div class="card-head"><h3>' + icon('check', 'ic-sm') + '오늘 확인할 것</h3><span class="muted" style="font-size:.8rem">' + items.length + '개</span></div>' +
    (items.length ? '<div class="td-list">' + items.join('') + '</div>' : '<div class="td-ok">👍 오늘은 특별히 확인할 게 없어요</div>') + '</div>';
}

function holdRowHtml(a, h, v) {
  v = v || hv(h);
  return '<div class="li" data-act="open-h" data-a="' + a.id + '" data-h="' + h.id + '">' +
    '<div class="logo" style="background:' + hColor(h) + '">' + esc(logoTxt(h)) + '</div>' +
    '<div class="mid"><b>' + esc(dispName(h)) + '</b><span>' + esc(a.name) + '</span></div>' +
    '<div class="end"><b class="' + cls(v.ret) + '">' + pct(v.ret) + '</b><span class="' + cls(v.pl) + '">' + moneyS(v.pl, v.ccy) + '</span></div></div>';
}

/* ========================================================================
   시장 데이터 (홈 띠 + 시장 화면 공용)
   ======================================================================== */
let MK = { data: null, at: 0, sent: null, sentAt: 0, news: {}, loading: null };
try { const c = JSON.parse(localStorage.getItem('mk_cache_v1') || 'null'); if (c && c.data) { MK.data = c.data; MK.at = 0; } } catch (e) {}

function loadMarket(force) {
  if (MK.loading) return MK.loading;
  if (!force && MK.data && Date.now() - MK.at < 120000) return Promise.resolve(MK.data);
  MK.loading = api('/api/market', { timeout: 25000 }).then(d => {
    if (d && d.items && d.items.length) { MK.data = d; MK.at = Date.now(); MK.fail = 0; try { localStorage.setItem('mk_cache_v1', JSON.stringify({ data: d })); } catch (e) {} }
    else MK.fail = Date.now();
    return MK.data;
  }).catch(() => { MK.fail = Date.now(); return MK.data; }).finally(() => { MK.loading = null; });
  return MK.loading;
}
function mkItem(id) { return MK.data && MK.data.items ? MK.data.items.find(x => x.id === id) : null; }
function mkPrice(x) {
  if (!x) return '-';
  if (x.unit === '%') return x.price.toFixed(2) + '%';
  if (x.unit === '$') return '$' + nf(x.price, 2);
  if (x.unit === '원') return nf(x.price, x.price >= 1000 ? 0 : 2) + '원';
  return nf(x.price, 2);
}
function tickerStripHtml() {
  const ids = ['kospi', 'kosdaq', 'sp500', 'nasdaq', 'usdkrw', 'krw-btc'];
  if (!MK.data) return ids.map(() => '<div class="tick"><div class="skel" style="height:14px;width:60%"></div><div class="skel" style="height:20px;width:80%;margin-top:8px"></div><div class="skel" style="height:30px;margin-top:8px"></div></div>').join('');
  return ids.map(id => {
    const x = mkItem(id); if (!x) return '';
    return '<div class="tick" data-nav="market"><div class="nm">' + esc(x.name) + '</div><div class="px">' + mkPrice(x) + '</div>' +
      '<div class="ch ' + cls(x.change_pct) + '">' + (x.change_pct != null ? arrow(x.change_pct) + ' ' + pct(x.change_pct) : '-') + '</div>' +
      '<div class="spark">' + sparkline(x.spark, { h: 30 }) + '</div></div>';
  }).join('');
}

/* ========================================================================
   내 계좌
   ======================================================================== */
PAGES.accounts = function (params) {
  const el = pageEl('accounts');
  const accs = accounts();
  if (params && params.acc) { curAccId = params.acc; params.acc = null; }
  if (params && params.h) { selH = params.h; params.h = null; }
  if (!accs.length) {
    el.innerHTML = '<div class="page-head"><div><h1>내 계좌</h1><div class="desc">증권사 계좌별로 주식을 관리해요</div></div></div>' +
      '<div class="card"><div class="empty"><div class="ill">' + icon('wallet') + '</div><b>아직 계좌가 없어요</b>' +
      '<p>“키움증권”, “삼성증권”처럼 <b>증권사 이름</b>으로 계좌를 만들고, 가진 주식을 넣어 보세요.</p>' +
      '<button class="btn btn-primary btn-lg" data-act="acc-new">' + icon('plus') + '계좌 만들기</button></div></div>';
    hydrateIcons(el); return;
  }
  let a = findAcc(curAccId) || findAcc(UI.acc) || accs[0];
  curAccId = a.id; UI.acc = a.id; saveUI();
  const T = accT(a);
  const sortMode = UI.hSort || 'val';
  const list = a.holdings.slice().sort((x, y) => {
    if (sortMode === 'ret') return hv(y).ret - hv(x).ret;
    if (sortMode === 'name') return dispName(x).localeCompare(dispName(y), 'ko');
    return hv(y).valK - hv(x).valK;
  });
  if (!a.holdings.some(h => h.id === selH)) selH = list.length ? list[0].id : null;
  const wide = window.innerWidth > 1240;

  const tabs = '<div class="acc-tabs"><div class="chips scroll">' + accs.map(x =>
      '<button class="chip ' + (x.id === a.id ? 'on' : '') + '" data-act="sel-acc" data-a="' + x.id + '"><span style="width:8px;height:8px;border-radius:2px;background:' + aColor(x) + '"></span>' + esc(x.name) + '<span class="cnt">' + x.holdings.length + '</span></button>').join('') +
      '<button class="chip add" data-act="acc-new">' + icon('plus', 'ic-sm') + '계좌 추가</button></div></div>';

  const sum = '<div class="card cq">' +
    '<div class="card-head"><h2><span style="width:10px;height:10px;border-radius:3px;background:' + aColor(a) + '"></span>' + esc(a.name) + '</h2>' +
      '<div style="display:flex;gap:6px;flex-wrap:wrap">' +
        '<button class="btn btn-soft btn-sm" data-act="ai-brief-acc" data-a="' + a.id + '">' + icon('sparkles', 'ic-sm') + '이 계좌 AI 브리핑</button>' +
        '<button class="icon-btn" data-act="acc-menu" data-a="' + a.id + '" title="계좌 관리">' + icon('more') + '</button></div></div>' +
    '<div class="acc-sum">' +
      '<div><div class="k">계좌 자산</div><div class="v big">' + won(T.asset) + '</div><div class="s ' + cls(T.pl) + '">' + wonS(T.pl) + ' (' + pct(T.ret) + ')</div></div>' +
      '<div><div class="k">주식 평가금액</div><div class="v">' + won(T.stock) + '</div><div class="s muted">원금 ' + compactKRW(T.cost) + '원</div></div>' +
      '<div><div class="k">현금 ' + icon('pencil', 'ic-sm') + '</div><div class="v"><span class="editable-num" data-act="edit-cash" data-a="' + a.id + '">' + won(T.cash) + '</span></div><div class="s muted">눌러서 수정</div></div>' +
      '<div><div class="k">하루 변동</div><div class="v ' + (T.dayPct != null ? cls(T.day) : '') + '">' + (T.dayPct != null ? wonS(T.day) : '-') + '</div><div class="s ' + (T.dayPct != null ? cls(T.day) : 'muted') + '">' + (T.dayPct != null ? pct(T.dayPct) : '시세 갱신 후 표시') + '</div></div>' +
    '</div></div>';

  const check = a.holdings.length ? checkupHtml(a, T) : '';

  // 비중 막대(현재 / 목표)
  const segNow = list.map(h => { const v = hv(h); return { label: dispName(h), value: v.valK, color: hColor(h), amt: won(v.valK) }; });
  const fold = foldSegs(segNow, 7);
  if (T.cash > 0) fold.push({ label: '현금', value: T.cash, color: 'var(--c-other)', amt: won(T.cash) });
  const tgtSegs = list.filter(hasT).map(h => ({ label: dispName(h), value: num(h.target), color: hColor(h), amt: '목표 ' + num(h.target) + '%' }));
  if (T.sumT > 0 && T.sumT < 100) tgtSegs.push({ label: '현금·미지정', value: 100 - T.sumT, color: 'var(--c-other)' });

  const rowsHtml = list.map(h => holdingRow(a, h, T)).join('');
  const cardsHtml = list.map(h => {
    const v = hv(h);
    return '<div class="hcard" data-act="sel-h" data-a="' + a.id + '" data-h="' + h.id + '"><div class="logo" style="background:' + hColor(h) + '">' + esc(logoTxt(h)) + '</div>' +
      '<div class="mid"><b>' + esc(dispName(h)) + '</b><span>' + nf(v.qty) + '주 · ' + (T.asset > 0 ? (v.valK / T.asset * 100).toFixed(1) : '0') + '%</span></div>' +
      '<div class="end"><b>' + money(v.val, v.ccy) + '</b><span class="' + cls(v.ret) + '">' + pct(v.ret) + '</span></div></div>';
  }).join('');

  const holds = '<div class="card cq">' +
    '<div class="card-head"><h3>' + icon('layers', 'ic-sm') + '보유 종목 <span class="muted" style="font-weight:600">' + a.holdings.length + '</span></h3>' +
      '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">' +
        (a.holdings.length > 1 ? '<div class="seg"><button data-act="h-sort" data-v="val" class="' + (sortMode === 'val' ? 'on' : '') + '">금액순</button><button data-act="h-sort" data-v="ret" class="' + (sortMode === 'ret' ? 'on' : '') + '">수익률순</button><button data-act="h-sort" data-v="name" class="' + (sortMode === 'name' ? 'on' : '') + '">이름순</button></div>' : '') +
        '<button class="btn btn-outline btn-sm" data-act="refresh-acc" data-a="' + a.id + '" data-refresh-btn>' + icon('refresh', 'ic-sm') + '시세 갱신</button>' +
        '<button class="btn btn-primary btn-sm" data-act="h-new" data-a="' + a.id + '" id="btnAddHolding">' + icon('plus', 'ic-sm') + '종목 추가</button></div></div>' +
    (a.holdings.length ?
      '<div style="margin-bottom:18px"><div class="sb-cap"><span>지금 비중</span><span>' + (fold[0] ? esc(fold[0].label) + ' ' + (fold[0].value / Math.max(1, T.asset) * 100).toFixed(0) + '%' : '') + '</span></div>' + stackBar(fold, T.asset) +
        (tgtSegs.length ? '<div class="sb-cap" style="margin-top:10px"><span>목표 비중</span><span>내가 정한 값</span></div>' + stackBar(tgtSegs, 100) : '') + '</div>' +
      '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>종목</th><th>현재가 · 오늘</th><th class="c-avg">평단가 · 수량</th><th>평가금액</th><th>수익</th><th>비중 · 목표</th></tr></thead><tbody>' + rowsHtml + '</tbody></table></div>' +
      '<div class="hcards">' + cardsHtml + '</div>' +
      '<p class="note" style="margin:14px 2px 0">목표 비중을 정하면 <b class="gap-buy">더 사기</b> / <b class="gap-sell">덜기</b> 금액을 알려줘요. 종목을 누르면 차트·뉴스·AI 분석이 보여요.</p>'
    : '<div class="empty"><div class="ill">' + icon('layers') + '</div><b>이 계좌에 종목이 없어요</b><p>“삼성전자”, “애플”처럼 <b>이름으로 검색</b>해서 쉽게 넣을 수 있어요.</p>' +
      '<button class="btn btn-primary btn-lg" data-act="h-new" data-a="' + a.id + '">' + icon('plus') + '종목 추가</button></div>') + '</div>';

  const h = a.holdings.find(x => x.id === selH);
  el.innerHTML =
    '<div class="page-head"><div><h1>내 계좌</h1><div class="desc">' + (UI.lastRefresh ? '시세 ' + ago(UI.lastRefresh) + ' 갱신' : '시세 갱신을 누르면 현재가가 자동으로 채워져요') + '</div></div>' +
      '<div class="actions"><button class="btn btn-primary" data-act="h-new" data-a="' + a.id + '">' + icon('plus') + '종목 추가</button></div></div>' +
    tabs +
    '<div class="acc-layout ' + (a.holdings.length && wide ? '' : 'nodetail') + '">' +
      '<div class="stack">' + sum + check + holds + '</div>' +
      (a.holdings.length && wide ? '<div class="detail-col"><div class="card detail" id="detailCard">' + (h ? detailHtml(a, h) : '') + '</div></div>' : '') +
    '</div>';
  hydrateIcons(el); bindTips(el);
  if (h && wide) wireDetail(document.getElementById('detailCard'), a, h);
};

function holdingRow(a, h, T) {
  const v = hv(h);
  const w = T.asset > 0 ? v.valK / T.asset * 100 : 0;
  const tgt = hasT(h) ? '목표 ' + num(h.target) + '% · ' + gapHtml(v.valK - T.asset * num(h.target) / 100)
    : '<span class="muted" data-act="edit-target" data-a="' + a.id + '" data-h="' + h.id + '" style="cursor:pointer;text-decoration:underline dotted">목표 정하기</span>';
  return '<tr class="hrow ' + (h.id === selH ? 'sel' : '') + '" data-act="sel-h" data-a="' + a.id + '" data-h="' + h.id + '">' +
    '<td><div class="nmcell"><div class="logo" style="background:' + hColor(h) + '">' + esc(logoTxt(h)) + '</div><div style="min-width:0"><b>' + esc(dispName(h)) + '</b><span>' + esc(h.ticker || '코드 없음') + (v.ccy === 'USD' ? ' · 미국' : '') + '</span></div></div></td>' +
    '<td><div class="two"><b>' + priceTxt(v.cur, v.ccy) + '</b>' + (v.chg != null ? '<span class="' + cls(v.chg) + '">' + pct(v.chg) + '</span>' : '<span class="muted">-</span>') + '</div></td>' +
    '<td class="c-avg"><div class="two"><b>' + priceTxt(v.avg, v.ccy) + '</b><span class="muted">' + nf(v.qty, 4) + '주</span></div></td>' +
    '<td><div class="two"><b>' + money(v.val, v.ccy) + '</b>' + (v.ccy === 'USD' ? '<span class="muted">' + won(v.valK) + '</span>' : '<span class="muted">원금 ' + compactKRW(v.costK) + '</span>') + '</div></td>' +
    '<td><div class="two"><b class="' + cls(v.ret) + '">' + pct(v.ret) + '</b><span class="' + cls(v.pl) + '">' + moneyS(v.pl, v.ccy) + '</span></div></td>' +
    '<td><div class="two"><div class="wcell"><div class="mini"><i style="width:' + Math.min(100, w).toFixed(1) + '%;background:' + hColor(h) + '"></i></div><b>' + w.toFixed(1) + '%</b></div><span style="font-size:.76rem">' + tgt + '</span></div></td></tr>';
}
function gapHtml(g) {
  if (Math.abs(g) < 1000) return '<span class="gap-ok">목표 도달</span>';
  return g < 0 ? '<span class="gap-buy">더 사기 ' + compactKRW(-g) + '원</span>' : '<span class="gap-sell">덜기 ' + compactKRW(g) + '원</span>';
}

/* ---------- 계좌 점검 ---------- */
let _checkOpen = false;
function accCheck(a, T) {
  const asset = T.asset > 0 ? T.asset : 1;
  const rows = a.holdings.map(h => ({ name: dispName(h), val: hv(h).valK, per: num(h.per), perSet: String(h.per || '').trim() !== '', def: !!h.defensive }))
    .sort((x, y) => y.val - x.val);
  const top = rows[0] || null;
  const top3 = rows.slice(0, 3).reduce((s, r) => s + r.val, 0);
  const defVal = T.cash + rows.reduce((s, r) => s + (r.def ? r.val : 0), 0);
  const P_ = pol();
  const high = rows.filter(r => r.perSet && r.per >= P_.highPER), low = rows.filter(r => r.perSet && r.per > 0 && r.per <= LOW_PER);
  return { topName: top ? top.name : '-', topW: top ? top.val / asset * 100 : 0, top3W: top3 / asset * 100, cashW: T.cash / asset * 100, defW: defVal / asset * 100,
    highCount: high.length, lowCount: low.length, highNames: high.map(r => r.name), lowNames: low.map(r => r.name), perKnown: rows.filter(r => r.perSet).length, total: rows.length };
}
function violCount(c, p) { return (c.topW > p.single) + (c.top3W > p.top3) + (c.defW < p.defMin) + (c.cashW < p.cashMin); }
function checkupHtml(a, T) {
  const c = accCheck(a, T), p = pol(), warn = violCount(c, p);
  const sig = (st, k, v, r) => '<div class="sig ' + st + '"><div class="ico">' + icon(st === 'ok' ? 'check' : st === 'info' ? 'info' : 'alert', 'ic-sm') + '</div><div><div class="k">' + esc(k) + '</div><div class="v">' + esc(v) + '</div><div class="r">' + esc(r) + '</div></div></div>';
  const pols = Object.keys(POLICY).map(k => {
    const q = POLICY[k], vc = violCount(c, q);
    return '<button class="pol ' + (S.settings.policy === k ? 'on' : '') + '" data-act="set-policy" data-v="' + k + '"><div class="t">' + q.label + (vc ? '<span class="badge orange">주의 ' + vc + '</span>' : '<span class="badge green">통과</span>') + '</div><div class="d">' + q.desc + ' · 한 종목 ' + q.single + '% 이하</div></button>';
  }).join('');
  return '<div class="card tight">' +
    '<div class="check-head ' + (_checkOpen ? 'open' : '') + '" data-act="toggle-check"><h3>' + icon('shield', 'ic-sm') + '계좌 건강검진 <span class="muted" style="font-size:.82rem;font-weight:600">기준: ' + p.label + '</span></h3>' +
      (warn ? '<span class="badge orange">' + icon('alert', 'ic-sm') + '주의 ' + warn + '개</span>' : '<span class="badge green">' + icon('check', 'ic-sm') + '양호</span>') +
      '<span class="chev">' + icon('chevron-down', 'ic-sm') + '</span></div>' +
    '<div class="' + (_checkOpen ? '' : 'hide') + '" id="checkBody">' +
      '<div class="pol-cards">' + pols + '</div>' +
      '<div class="signals">' +
        sig(c.topW > p.single ? 'over' : 'ok', '가장 큰 종목 비중', c.topName + ' ' + c.topW.toFixed(0) + '%', '권장 ' + p.single + '% 이하 · 한 종목에 너무 몰리면 위험') +
        sig(c.top3W > p.top3 ? 'over' : 'ok', '상위 3종목 합계', c.top3W.toFixed(0) + '%', '권장 ' + p.top3 + '% 이하') +
        sig(c.defW < p.defMin ? 'under' : 'ok', '방어자산(현금·채권·배당)', c.defW.toFixed(0) + '%', '권장 ' + p.defMin + '% 이상 · 종목 수정에서 “방어자산” 표시') +
        sig(c.cashW < p.cashMin ? 'under' : 'ok', '현금 비중', c.cashW.toFixed(0) + '%', '권장 ' + p.cashMin + '% 이상 · 하락장 대비 여윳돈') +
        sig('info', '비싸 보이는 종목 (PER ' + p.highPER + '↑)', c.highCount + '개', c.highCount ? c.highNames.join(', ') : '없음') +
        sig('info', '싸 보이는 종목 (PER ' + LOW_PER + '↓)', c.lowCount + '개', c.lowCount ? c.lowNames.join(', ') : '없음') +
      '</div>' +
      (c.perKnown < c.total ? '<p class="note" style="margin:10px 2px 0">※ PER은 시세 갱신 때 자동으로 모여요 (' + c.perKnown + '/' + c.total + '개 수집됨).</p>' : '') +
      '<button class="ai-cta" data-act="ai-review" data-a="' + a.id + '"><div class="ico">' + icon('sparkles', 'ic-sm') + '</div><div style="flex:1"><b>AI 계좌 점수 받기</b><span>100점 만점 점수와 고칠 점을 쉽게 알려 드려요</span></div>' + icon('chevron-right', 'ic-sm') + '</button>' +
    '</div></div>';
}

/* ---------- 종목 상세 ---------- */
const CHART_CACHE = {};
let detailRange = '3m';
function detailHtml(a, h) {
  const v = hv(h), T = accT(a);
  const w = T.asset > 0 ? v.valK / T.asset * 100 : 0;
  let tgtRow;
  if (hasT(h)) {
    const g = v.valK - T.asset * num(h.target) / 100;
    tgtRow = '<div class="callout gray" style="align-items:center">' + icon('target', 'ic-sm') + '<div style="flex:1">목표 <b class="editable-num" data-act="edit-target" data-a="' + a.id + '" data-h="' + h.id + '">' + num(h.target) + '%</b> · 지금 ' + w.toFixed(1) + '%</div>' + gapHtml(g) + '</div>';
  } else {
    tgtRow = '<button class="btn btn-ghost btn-sm" data-act="edit-target" data-a="' + a.id + '" data-h="' + h.id + '">' + icon('target', 'ic-sm') + '목표 비중 정하기</button>';
  }
  const chgTxt = (h.sess ? '<span class="badge orange" style="margin-right:6px">' + esc(h.sess) + '</span>' : '') + (v.chg != null ? '<span class="' + cls(v.chg) + '">어제보다 ' + arrow(v.chg) + ' ' + pct(v.chg) + '</span>' : '<span class="muted">시세 갱신을 누르면 오늘 등락이 보여요</span>');
  return '<div class="dh"><div class="logo" style="background:' + hColor(h) + '">' + esc(logoTxt(h)) + '</div>' +
      '<div style="flex:1;min-width:0"><div class="nm">' + esc(dispName(h)) + '</div><div class="tk">' + esc(h.ticker || '코드 없음') + '<span class="badge gray">' + (v.ccy === 'USD' ? '미국' : '국내') + '</span>' + (h.defensive ? '<span class="badge green">방어자산</span>' : '') + '</div></div>' +
      '<button class="icon-btn" data-act="h-edit" data-a="' + a.id + '" data-h="' + h.id + '" title="종목 수정">' + icon('pencil', 'ic-sm') + '</button></div>' +
    '<div class="price">' + priceTxt(v.cur, v.ccy) + '</div><div class="price-ch">' + chgTxt + '</div>' +
    '<div class="rng" id="dRange">' + [['1d', '1일'], ['1w', '1주'], ['1m', '1달'], ['3m', '3달'], ['1y', '1년'], ['5y', '5년']].map(r => '<button data-act="d-range" data-v="' + r[0] + '" class="' + (detailRange === r[0] ? 'on' : '') + '">' + r[1] + '</button>').join('') + '</div>' +
    '<div class="chart-box" id="dChart"><div class="chart-msg" style="height:200px">' + (h.ticker ? '<div class="skel" style="width:100%;height:180px"></div>' : '종목코드가 있어야 차트를 볼 수 있어요') + '</div></div>' +
    (h.ticker ? '<p class="note" style="margin:4px 2px 0">📅 차트에서 날짜를 누르면 <b>그날 무슨 일이 있었는지</b>(뉴스·AI 정리)가 나와요 · ○ 크게 움직인 날</p>' : '') +
    '<div class="sect"><h4>내 보유 현황</h4><div class="kv">' +
      '<div><div class="k">평가금액</div><div class="v">' + money(v.val, v.ccy) + '</div>' + (v.ccy === 'USD' ? '<div class="s muted">' + won(v.valK) + '</div>' : '') + '</div>' +
      '<div><div class="k">수익</div><div class="v ' + cls(v.pl) + '">' + pct(v.ret) + '</div><div class="s ' + cls(v.pl) + '">' + moneyS(v.pl, v.ccy) + '</div></div>' +
      '<div><div class="k">평단가</div><div class="v">' + priceTxt(v.avg, v.ccy) + '</div></div>' +
      '<div><div class="k">보유 수량</div><div class="v">' + nf(v.qty, 4) + '주</div></div>' +
      '<div><div class="k">투자 원금</div><div class="v">' + money(v.cost, v.ccy) + '</div></div>' +
      '<div><div class="k">계좌 내 비중</div><div class="v">' + w.toFixed(1) + '%</div></div>' +
    '</div><div style="margin-top:10px">' + tgtRow + '</div></div>' +
    '<div class="act-grid">' +
      '<button class="btn btn-up" data-act="h-buy" data-a="' + a.id + '" data-h="' + h.id + '">더 사기</button>' +
      '<button class="btn btn-down" data-act="h-sell" data-a="' + a.id + '" data-h="' + h.id + '">팔기</button>' +
      '<button class="btn btn-gray" data-act="h-edit" data-a="' + a.id + '" data-h="' + h.id + '">수정</button></div>' +
    '<button class="ai-cta" data-act="ai-insight" data-a="' + a.id + '" data-h="' + h.id + '"><div class="ico">' + icon('sparkles', 'ic-sm') + '</div><div style="flex:1"><b>AI 분석 받기</b><span>뉴스 영향·오를 확률·매매 참고선</span></div>' + icon('chevron-right', 'ic-sm') + '</button>' +
    (h.ticker ? '<button class="ai-cta chart" data-act="ai-chart" data-t="' + esc(h.ticker) + '" data-m="' + mkt(h) + '" data-n="' + esc(dispName(h)) + '"><div class="ico">' + icon('activity', 'ic-sm') + '</div><div style="flex:1"><b>AI 차트 분석</b><span>추세·지지/저항·매수/손절/목표 참고선</span></div>' + icon('chevron-right', 'ic-sm') + '</button>' : '') +
    (h.rule ? '<div class="sect"><h4>나의 규칙</h4><div class="callout info">' + icon('bookmark', 'ic-sm') + '<div>' + esc(h.rule) + '</div></div></div>' : '') +
    '<div class="sect"><h4>기업 지표 <span class="badge blue">자동 수집</span></h4>' + fundHtml(h) + '</div>' +
    '<div class="sect"><h4>최근 뉴스 <span class="muted" style="font-size:.78rem;font-weight:600">7일 이내</span></h4><div class="news" id="dNews">' + (h.ticker ? '<div class="skel" style="height:16px;margin:10px 0"></div><div class="skel" style="height:16px;margin:10px 0;width:80%"></div>' : '<p class="note">종목코드가 없어 뉴스를 못 가져와요.</p>') + '</div></div>' +
    (h.ticker ? '<a class="btn btn-outline btn-block" style="margin-top:16px" href="' + esc(safeUrl(naverUrl(h))) + '" target="_blank" rel="noopener">' + icon('external', 'ic-sm') + '네이버 증권에서 더 보기</a>' : '');
}
function naverUrl(h) {
  if (h.naverUrl) return h.naverUrl;
  return mkt(h) === 'kr' ? 'https://finance.naver.com/item/main.naver?code=' + encodeURIComponent(h.ticker || '') : 'https://m.stock.naver.com/search/index?query=' + encodeURIComponent(h.ticker || '');
}
function fundHtml(h) {
  const ccy = h.mcapCcy || (ccyOf(h) === 'USD' ? 'USD' : 'KRW');
  const n2 = v => (v != null && v !== '') ? num(v).toFixed(2) : null;
  const p1 = v => (v != null && v !== '') ? num(v).toFixed(1) + '%' : null;
  // 쉬운 평가: [글자, 'good'|'mid'|'warn'] — 업종마다 다르므로 '일반적인 기준'으로만
  const lv = (v, f) => (v == null || v === '' || !isFinite(num(v))) ? null : f(num(v));
  const perLv = x => x <= 0 ? ['적자', 'warn'] : x < 10 ? ['싼 편', 'good'] : x <= 25 ? ['보통', 'mid'] : ['비싼 편', 'warn'];
  const capLv = x => (ccy === 'KRW' ? (x >= 1e13 ? '대형주' : x >= 1e12 ? '중형주' : '소형주') : (x >= 2e11 ? '초대형주' : x >= 1e10 ? '대형주' : x >= 2e9 ? '중형주' : '소형주'));
  const items = [
    ['PER', n2(h.per), '주가가 1년 이익의 몇 배인지. 낮을수록 싸다고 봐요 (보통 10~20배)', lv(h.per, perLv)],
    ['추정 PER', n2(h.fper), '내년 예상 이익으로 계산한 PER. 지금 PER보다 낮으면 이익이 늘 거란 기대', lv(h.fper, perLv)],
    ['PBR', n2(h.pbr), '주가가 회사 순재산의 몇 배인지. 1보다 낮으면 재산보다 싸게 거래되는 셈', lv(h.pbr, x => x < 1 ? ['싼 편', 'good'] : x <= 3 ? ['보통', 'mid'] : ['비싼 편', 'warn'])],
    ['PEG', n2(h.peg), 'PER을 이익 성장률로 나눈 값. 1보다 낮으면 성장에 비해 싸다고 봐요', lv(h.peg, x => x <= 0 ? null : x < 1 ? ['성장 대비 쌈', 'good'] : x <= 2 ? ['보통', 'mid'] : ['성장 대비 비쌈', 'warn'])],
    ['ROE', p1(h.roe), '회사가 주주 돈으로 1년에 몇 % 이익을 냈나. 15% 넘으면 잘 버는 편', lv(h.roe, x => x < 0 ? ['적자', 'warn'] : x >= 15 ? ['잘 버는 편', 'good'] : x >= 8 ? ['보통', 'mid'] : ['낮은 편', 'warn'])],
    ['영업이익률', p1(h.opMargin), '100원어치 팔아서 본업으로 남기는 돈. 높을수록 장사를 잘하는 것', lv(h.opMargin, x => x < 0 ? ['적자', 'warn'] : x >= 20 ? ['높은 편', 'good'] : x >= 8 ? ['보통', 'mid'] : ['낮은 편', 'warn'])],
    ['시가총액', bigMoney(h.marketCap, ccy), '회사 전체의 몸값 = 주가 × 주식 수', lv(h.marketCap, x => x > 0 ? [capLv(x), 'mid'] : null)],
    ['영업이익', bigMoney(h.opIncome, ccy), '본업으로 1년 동안 번 돈', lv(h.opIncome, x => x < 0 ? ['적자', 'warn'] : ['흑자', 'good'])],
    ['EPS', (h.eps != null && h.eps !== '') ? nf(num(h.eps), 2) : null, '1주당 이익 (회사 이익 ÷ 주식 수)', lv(h.eps, x => x < 0 ? ['적자', 'warn'] : null)]];
  const filled = items.filter(x => x[1] != null);
  if (!filled.length) return '<p class="note" style="margin:0">시세 갱신을 하면 PER·ROE·시가총액 같은 지표가 <b>자동으로</b> 채워져요.</p>';
  let out = '<div class="kv three">' + filled.map(x => '<div class="fund-cell" tabindex="0" data-tip="' + esc(x[0] + ': ' + x[2]) + '"><div class="k">' + x[0] + ' <span class="qm">?</span></div><div class="v">' + x[1] + '</div>' +
    (x[3] ? '<div class="lv ' + x[3][1] + '">' + x[3][0] + '</div>' : '') + '</div>').join('') + '</div>' +
    '<p class="note" style="margin:6px 2px 0">칸을 누르면 뜻이 나와요. 평가(싼 편·보통 등)는 일반적인 기준이라 업종마다 다를 수 있어요.</p>';
  if (h.epsRev != null && h.epsRev !== '') {
    const r = num(h.epsRev);
    out += '<div class="trend-line ' + (r > 1 ? 'up' : r < -1 ? 'down' : '') + '">예상 이익(EPS) 90일 변화 ' + pct(r, 1) + ' ' + (r > 1 ? '▲ 상향' : r < -1 ? '▼ 하향' : '– 보합') + '</div>';
  }
  if (h.opTrend && h.opTrend.length) {
    const pts = h.opTrend.filter(p => p && p[1] != null);
    if (pts.length >= 2) {
      const tc = String(h.trendClass || '');
      out += '<div class="trend-line ' + (/우상향/.test(tc) ? 'up' : /우하향/.test(tc) ? 'down' : '') + '"><b>영업이익 추세(전자공시)</b> ' + esc(pts.map(p => p[0] + ' ' + bigMoney(p[1], ccy)).join(' → ')) + (tc ? ' · ' + esc(tc) : '') + '</div>';
    }
  }
  if (h.valWarn && h.valWarn.length) out += '<div class="callout warn" style="margin-top:8px">' + icon('alert', 'ic-sm') + '<div>' + h.valWarn.map(esc).join('<br>') + '</div></div>';
  out += '<p class="note" style="margin:8px 2px 0">' + (h.valSrcs && h.valSrcs.length >= 2 ? h.valSrcs.length + '곳 교차확인 · ' : '') + '기준 ' + esc(h.asof || '시점 미상') + ' · 지표에 마우스를 올리면 뜻이 보여요</p>';
  return out;
}

function wireDetail(box, a, h) {
  if (!box) return;
  hydrateIcons(box); bindTips(box);
  loadDetailChart(box, h);
  const nbox = box.querySelector('#dNews');
  if (h.ticker && nbox) {
    api('/news?ticker=' + encodeURIComponent(h.ticker) + '&market=' + mkt(h) + '&name=' + encodeURIComponent(h.name || ''), { timeout: 20000 }).then(arr => {
      if (!box.isConnected) return;
      if (!arr || !arr.length) { nbox.innerHTML = '<p class="note">최근 7일 안에 나온 뉴스가 없어요.</p>'; return; }
      nbox.innerHTML = arr.slice(0, 8).map(it => '<a href="' + esc(safeUrl(it.url)) + '" target="_blank" rel="noopener"><b>' + esc(it.title) + '</b><span>' + esc(newsDate(it.date)) + '</span></a>').join('');
    }).catch(() => { if (box.isConnected) nbox.innerHTML = '<p class="note">' + SERVER_DOWN + '</p>'; });
  }
}
function newsDate(s) { const t = Date.parse(s); return isFinite(t) ? ago(t) : (s || ''); }

function loadDetailChart(box, h) {
  const cb = box.querySelector('#dChart'); if (!cb || !h.ticker) return;
  const key = h.ticker + ':' + mkt(h) + ':' + detailRange;
  cb._key = key;                                   // 늦게 온 예전 기간 응답이 새 기간 차트를 덮지 않게
  const draw = d => {
    if (!cb.isConnected) return;
    if (!d || !d.ok || !d.points || d.points.length < 2) { cb.innerHTML = '<div class="chart-msg" style="height:200px">차트를 불러오지 못했어요</div>'; return; }
    const ccy = ccyOf(h), avg = num(h.avg);
    const fmtX = detailRange === '1d' ? (t => { const d2 = new Date(t * 1000); return String(d2.getHours()).padStart(2, '0') + ':' + String(d2.getMinutes()).padStart(2, '0'); })
      : detailRange === '5y' || detailRange === '1y' ? (t => { const d2 = new Date(t * 1000); return String(d2.getFullYear()).slice(2) + '.' + (d2.getMonth() + 1); })
      : (t => { const d2 = new Date(t * 1000); return (d2.getMonth() + 1) + '/' + d2.getDate(); });
    const full = t => { const d2 = new Date(t * 1000); return d2.getFullYear() + '.' + (d2.getMonth() + 1) + '.' + d2.getDate() + (detailRange === '1d' || detailRange === '1w' ? ' ' + String(d2.getHours()).padStart(2, '0') + ':' + String(d2.getMinutes()).padStart(2, '0') : ''); };
    const first = d.points[0][1], P = d.points;
    // 크게 움직인 날(하루 기준 상위 몇 개) — 동그라미로 표시, 눌러서 이유 확인
    let marks = [];
    if (!/^1[dw]$/.test(detailRange)) {
      const lim = detailRange === '5y' ? 8 : 4;
      marks = P.map((p, i) => i ? { i, c: (p[1] - P[i - 1][1]) / P[i - 1][1] * 100 } : null).filter(x => x && Math.abs(x.c) >= lim)
        .sort((a, b) => Math.abs(b.c) - Math.abs(a.c)).slice(0, 6).map(x => ({ i: x.i, up: x.c > 0 }));
    }
    lineChart(cb, d.points, {
      marks, onPick: (p, i) => openDayNews(h, p[0], i ? P[i - 1][1] : null, p[1], detailRange),
      height: 210, fmtX, fmtV: v => priceTxt(v, ccy), fmtAxis: v => ccy === 'USD' ? '$' + nf(v, v >= 100 ? 0 : 2) : compactKRW(v),
      ref: avg > 0 ? { value: avg, label: '내 평단 ' + priceTxt(avg, ccy) } : null, label: dispName(h) + ' 주가',
      tip: p => '<span class="d">' + esc(full(p[0])) + '</span><br><b>' + esc(priceTxt(p[1], ccy)) + '</b>' +
        '<br><span class="d">기간 시작 대비</span> ' + esc(pct((p[1] - first) / first * 100)) + (avg > 0 ? '<br><span class="d">내 평단 대비</span> ' + esc(pct((p[1] - avg) / avg * 100)) : '') +
        '<br><span class="d">👆 누르면 그날 뉴스</span>',
    });
  };
  if (CHART_CACHE[key] && Date.now() - CHART_CACHE[key].at < 600000) { draw(CHART_CACHE[key].d); return; }
  cb.classList.add('stale');
  api('/api/chart?ticker=' + encodeURIComponent(h.ticker) + '&market=' + mkt(h) + '&range=' + detailRange, { timeout: 20000 })
    .then(d => { CHART_CACHE[key] = { d, at: Date.now() }; if (cb._key !== key) return; cb.classList.remove('stale'); draw(d); })
    .catch(() => { if (cb._key !== key) return; cb.classList.remove('stale'); if (cb.isConnected) cb.innerHTML = '<div class="chart-msg" style="height:200px">' + SERVER_DOWN + '</div>'; });
}

/* 📅 차트에서 누른 날, 무슨 일이 있었나 (v2.18) */
function dayKey(t) { const d = new Date(t * 1000); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function openDayNews(h, t, prev, close, rng) {
  const day = dayKey(t), ccy = ccyOf(h), dd = new Date(t * 1000);
  const label = dd.getFullYear() + '년 ' + (dd.getMonth() + 1) + '월 ' + dd.getDate() + '일';
  const chg = prev ? (close - prev) / prev * 100 : null;
  const unit = rng === '5y' ? '그 주' : '그날';
  const move = chg == null ? '' : unit + ' ' + (chg >= 0 ? '+' : '') + chg.toFixed(2) + '% (' + priceTxt(prev, ccy) + ' → ' + priceTxt(close, ccy) + ')';
  const m = openModal({ title: '📅 ' + esc(label) + ' · ' + esc(dispName(h)), size: 'wide', body:
    '<div class="dn-head">' + (chg != null ? '<div class="dn-move ' + (chg >= 0 ? 'up' : 'down') + '"><b>' + (chg >= 0 ? '▲ ' : '▼ ') + Math.abs(chg).toFixed(2) + '%</b><span>' + esc(move) + '</span></div>'
      : '<div class="dn-move"><b>' + esc(priceTxt(close, ccy)) + '</b><span>' + esc(label) + ' 가격</span></div>') + '</div>' +
    '<div id="dnBody"><div class="ai-loading" style="padding:26px 10px"><div class="orb"></div><div>' + esc(label) + ' 전후 뉴스를 찾는 중이에요…</div></div></div>' });
  const body = m.body.querySelector('#dnBody');
  api('/api/day-news?ticker=' + encodeURIComponent(h.ticker || '') + '&market=' + mkt(h) + '&name=' + encodeURIComponent(h.name || '') + '&date=' + day, { timeout: 30000 }).then(d => {
    if (m.closed) return;
    if (!d || !d.ok) { body.innerHTML = '<p class="note">' + esc((d && d.error) || '뉴스를 불러오지 못했어요') + '</p>'; return; }
    const row = it => '<a class="dn-item" href="' + esc(safeUrl(it.url)) + '" target="_blank" rel="noopener"><b>' + esc(it.title) + '</b><span>' +
      esc(it.day ? it.day.slice(5).replace('-', '/') : '') + (it.gap === 0 ? ' · 그날' : it.gap ? ' · ' + it.gap + '일 차이' : '') + '</span></a>';
    const same = d.items.filter(x => x.gap === 0).length;
    body.innerHTML =
      (d.items.length ? '<div class="dn-cap">' + icon('news', 'ic-sm') + '이 종목 뉴스 <span class="muted">' + (same ? '그날 ' + same + '건 · ' : '') + '앞뒤 ' + d.span + '일 안</span></div>' + d.items.map(row).join('')
        : '<div class="callout gray">' + icon('info', 'ic-sm') + '<div>이 무렵 이 종목 뉴스를 찾지 못했어요. 시장 전체 분위기 때문일 수 있어요.</div></div>') +
      (d.market && d.market.length ? '<div class="dn-cap" style="margin-top:14px">' + icon('globe', 'ic-sm') + '그날 시장 뉴스</div>' + d.market.map(row).join('') : '') +
      ((d.items.length || (d.market && d.market.length)) ? '<button class="btn btn-outline btn-block" style="margin-top:14px" data-why>' + icon('sparkles', 'ic-sm') + 'AI로 ' + unit + ' 움직인 이유 정리</button><div id="dnWhy"></div>' : '') +
      '<p class="note" style="margin-top:10px">구글 뉴스에서 날짜로 찾은 결과예요. 오래된 날짜는 뉴스가 적을 수 있어요. 제목을 누르면 기사 원문이 열려요.</p>';
    hydrateIcons(body);
    const btn = body.querySelector('[data-why]');
    if (btn) btn.onclick = () => {
      if (!(AI_STATUS && AI_STATUS.on)) { needAI(() => btn.onclick()); return; }
      btn.remove();
      const w = body.querySelector('#dnWhy'); w.innerHTML = aiLoading('뉴스와 주가 움직임을 맞춰 보는 중이에요…');
      const fmt = it => (it.day ? it.day + ' ' : '') + it.title;
      api('/api/day-why', { method: 'POST', timeout: 90000, body: { name: dispName(h), date: day, move: move || label, heads: d.items.map(fmt), market: (d.market || []).map(fmt) } })
        .then(r => { if (m.closed) return; w.innerHTML = r && r.status === 'ok' ? '<div style="margin-top:12px">' + renderAiText(r.text) + '</div>' : r && r.status === 'no_key' ? noKeyHtml() : '<p class="note">' + esc((r && r.text) || 'AI 답을 받지 못했어요') + '</p>'; hydrateIcons(w); })
        .catch(() => { if (!m.closed) w.innerHTML = '<p class="note">' + SERVER_DOWN + '</p>'; });
    };
  }).catch(() => { if (!m.closed) body.innerHTML = '<p class="note">' + SERVER_DOWN + '</p>'; });
}

function openHoldingModal(a, h) {
  const m = openModal({ title: '종목 상세', size: 'wide', body: '<div class="detail" style="position:static;max-height:none;overflow:visible">' + detailHtml(a, h) + '</div>' });
  m.el.dataset.detail = h.id;
  wireDetail(m.body, a, h);
  return m;
}

/* ========================================================================
   시장
   ======================================================================== */
const MK_HINT = {
  usdkrw: '환율이 오르면 내 미국 주식의 원화 가치가 올라가요',
  us10y: '금리가 오르면 성장주·기술주에 부담이 돼요',
  vix: '20을 넘으면 시장 불안이 커진 상태예요',
  sox: '반도체 업종 분위기를 보여줘요 (삼성·하이닉스와 연관)',
  gold: '불안할 때 사람들이 찾는 안전자산',
  wti: '유가가 오르면 물가·항공·화학 업종에 영향',
  dxy: '달러가 강해지면 원화가 약해지고 신흥국 증시엔 부담',
  kospi200: '국내 대형주 200개 — ETF가 많이 따라가는 지수',
};
const FG_KO = { 'extreme fear': '극단적 공포', fear: '공포', neutral: '중립', greed: '탐욕', 'extreme greed': '극단적 탐욕' };
let mkNewsLang = 'kr';

PAGES.market = function (params, isRe) {
  const el = pageEl('market');
  const groups = ['국내', '미국', '아시아', '금리·달러·심리', '원자재', '코인'];
  const items = MK.data ? MK.data.items : null;
  const sent = MK.sent;
  const sentCard = (title, d, src, help) => {
    if (!d) return '<div class="card span-6"><div class="card-head"><h3>' + title + '</h3></div>' + (MK.sentFail ? '<p class="note" style="margin:0">지금은 불러오지 못했어요. 잠시 뒤 새로고침해 주세요.</p>' : '<div class="skel" style="height:110px"></div>') + '</div>';
    const z = fgZone(d.score);
    return '<div class="card span-6"><div class="card-head"><h3>' + icon('gauge', 'ic-sm') + title + '</h3><span class="muted" style="font-size:.78rem">' + src + '</span></div>' +
      '<div class="gauge-card"><div data-tip-root>' + gauge(d.score, { w: 210 }) + '</div><div class="gtxt"><div class="score">' + d.score + '</div>' +
      '<div class="rating"><span style="display:inline-block;width:10px;height:10px;border-radius:3px;background:' + z.color + ';margin-right:6px"></span>' + (FG_KO[String(d.rating || '').toLowerCase()] || z.label) + '</div>' +
      '<div class="cmp">' + (d.prev != null ? '<span>어제 <b>' + d.prev + '</b></span>' : '') + (d.week != null ? '<span>1주 전 <b>' + d.week + '</b></span>' : '') + (d.month != null ? '<span>1달 전 <b>' + d.month + '</b></span>' : '') + '</div>' +
      '<p class="note" style="margin:10px 0 0">' + help + '</p></div></div></div>';
  };
  let body = '';
  if (!items && MK.fail && !MK.loading) {
    body = '<div class="card mk-fail" style="margin-bottom:26px">' + icon('wifi') + '<div><b>시세를 불러오지 못했어요</b><span>인터넷 연결을 확인하고 다시 시도해 주세요. (무료 공개 데이터라 가끔 늦거나 막힐 수 있어요)</span></div>' +
      '<button class="btn btn-primary btn-sm" data-act="mk-refresh" data-refresh-btn>' + icon('refresh', 'ic-sm') + '다시 시도</button></div>';
  } else if (!items) {
    body = groups.map(g => '<div class="mk-group"><h3>' + g + '</h3><div class="mk-grid">' + '<div class="mk-card"><div class="skel" style="height:90px"></div></div>'.repeat(4) + '</div></div>').join('');
  } else {
    body = groups.map(g => {
      const gi = items.filter(x => x.group === g); if (!gi.length) return '';
      return '<div class="mk-group"><h3>' + g + '</h3><div class="mk-grid">' + gi.map(x =>
        '<div class="mk-card"><div class="nm">' + esc(x.name) + '</div><div class="px">' + mkPrice(x) + '</div>' +
        '<div class="ch ' + cls(x.change_pct) + '">' + (x.change != null ? arrow(x.change) + ' ' + nf(Math.abs(x.change), 2) + ' (' + pct(x.change_pct) + ')' : '-') + '</div>' +
        '<div class="spark" data-tip="' + esc(x.name + ' 최근 한 달 흐름') + '">' + sparkline(x.spark, { h: 40 }) + '</div>' +
        (MK_HINT[x.id] ? '<div class="hint">' + MK_HINT[x.id] + '</div>' : '') + '</div>').join('') + '</div></div>';
    }).join('');
  }
  const news = MK.news[mkNewsLang];
  el.innerHTML =
    '<div class="page-head"><div><h1>시장</h1><div class="desc">지금 시장 분위기를 한눈에 · ' + (MK.data && MK.data.updated ? esc(MK.data.updated) + ' 기준' : '무료 공개 데이터') + '</div></div>' +
      '<div class="actions"><button class="btn btn-outline" data-act="mk-refresh" data-refresh-btn>' + icon('refresh') + '새로고침</button></div></div>' +
    '<div class="grid g-12" style="margin-bottom:26px">' +
      sentCard('주식시장 공포·탐욕 지수', sent && sent.stock, 'CNN', '0에 가까울수록 사람들이 겁먹어 팔고, 100에 가까울수록 너무 들떠 사고 있어요. “남들이 겁낼 때 기회, 들뜰 때 조심”의 참고용.') +
      sentCard('코인시장 공포·탐욕 지수', sent && sent.crypto, 'alternative.me', '비트코인 등 코인 시장의 분위기예요. 주식보다 변동이 훨씬 커요.') +
    '</div>' + body +
    '<div class="grid g-12">' +
      '<div class="card span-8"><div class="card-head"><h3>' + icon('news', 'ic-sm') + '경제 헤드라인</h3><div class="seg"><button data-act="mk-news" data-v="kr" class="' + (mkNewsLang === 'kr' ? 'on' : '') + '">국내</button><button data-act="mk-news" data-v="us" class="' + (mkNewsLang === 'us' ? 'on' : '') + '">해외</button></div></div>' +
        '<div class="headlines" id="mkNews">' + (news ? newsListHtml(news) : '<div class="skel" style="height:18px;margin:12px 0"></div>'.repeat(6)) + '</div></div>' +
      '<div class="card span-4"><div class="card-head"><h3>' + icon('globe', 'ic-sm') + '더 보기 (외부 사이트)</h3></div><div class="links" style="grid-template-columns:1fr">' +
        linkCard('https://finance.naver.com/sise/sise_group.naver?type=upjong', '네이버 업종별 시세', '국내 업종 등락') +
        linkCard('https://finviz.com/map.ashx', 'Finviz 히트맵', '미국 주식 지도') +
        linkCard('https://www.tradingview.com/heatmap/stock/', 'TradingView 히트맵', '세계 주식 지도') +
        linkCard('https://kr.investing.com/economic-calendar/', '경제 일정표', '금리·물가 발표일') +
      '</div><p class="note" style="margin:14px 2px 0">시세는 야후·업비트·CNN 등 무료 공개 데이터로, 15분 정도 늦을 수 있어요.</p></div>' +
    '</div>';
  hydrateIcons(el); bindTips(el);
  if (!isRe) {
    loadMarket(false).then(() => { if (route.page === 'market') PAGES.market({}, true); });
    if (!MK.sent || Date.now() - MK.sentAt > 600000) api('/api/sentiment', { timeout: 20000 }).then(d => { MK.sent = d; MK.sentAt = Date.now(); MK.sentFail = !(d && (d.stock || d.crypto)); if (route.page === 'market') PAGES.market({}, true); }).catch(() => { MK.sentFail = true; if (route.page === 'market') PAGES.market({}, true); });
    loadMkNews(mkNewsLang);
  }
};
function linkCard(u, t, s) { return '<a class="link-card" href="' + esc(u) + '" target="_blank" rel="noopener"><div><b>' + esc(t) + '</b><span>' + esc(s) + '</span></div>' + icon('external', 'ic-sm') + '</a>'; }
function newsListHtml(arr) {
  if (!arr.length) return '<p class="note">뉴스를 가져오지 못했어요.</p>';
  return arr.slice(0, 14).map(n => '<a href="' + esc(safeUrl(n.url)) + '" target="_blank" rel="noopener"><b>' + esc(n.title) + '</b><span>' + esc(n.source || '') + (n.ts ? ' · ' + ago(n.ts * 1000) : '') + '</span></a>').join('');
}
function loadMkNews(lang) {
  if (MK.news[lang] && MK.news[lang]._at && Date.now() - MK.news[lang]._at < 600000) return;
  api('/api/market/news?lang=' + lang, { timeout: 20000 }).then(arr => {
    arr = arr || []; arr._at = Date.now(); MK.news[lang] = arr;
    const box = document.getElementById('mkNews'); if (box && mkNewsLang === lang) box.innerHTML = newsListHtml(arr);
  }).catch(() => { const box = document.getElementById('mkNews'); if (box) box.innerHTML = '<p class="note">' + SERVER_DOWN + '</p>'; });
}

/* ========================================================================
   자산 기록
   ======================================================================== */
let histFrom = null, histTo = null;
function periodKey(d, u) {
  const y = d.slice(0, 4), m = parseInt(d.slice(5, 7), 10) || 1;
  if (u === 'month') return y + '-' + String(m).padStart(2, '0');
  if (u === 'quarter') return y + '-Q' + (Math.floor((m - 1) / 3) + 1);
  if (u === 'half') return y + '-H' + (m <= 6 ? 1 : 2);
  if (u === 'year') return y;
  return d;
}
function aggHist(all, u) { const b = {}, order = []; all.forEach(s => { const k = periodKey(s.date, u); if (!(k in b)) order.push(k); b[k] = s; }); return order.map(k => b[k]).slice(-60); }

PAGES.history = function () {
  const el = pageEl('history');
  const all = P().history.slice().sort((a, b) => a.date < b.date ? -1 : 1);
  const r = UI.histRange || 'day';
  let F = all;
  if (r === 'custom' && histFrom && histTo) F = all.filter(x => x.date >= histFrom && x.date <= histTo);
  else if (r !== 'all' && r !== 'custom') F = aggHist(all, r);
  const ranges = [['day', '일'], ['month', '월'], ['quarter', '분기'], ['half', '반기'], ['year', '년'], ['all', '전체'], ['custom', '직접 지정']];
  let top = '';
  if (all.length >= 1) {
    const last = all[all.length - 1], prev = all.length > 1 ? all[all.length - 2] : null;
    const src = F.length >= 1 ? F : all, b0 = src[0], b1 = src[src.length - 1];
    const dPrev = prev ? last.totalAsset - prev.totalAsset : 0, dR = b1.totalAsset - b0.totalAsset;
    top = '<div class="kpis">' +
      '<div class="kpi"><div class="k">최근 총자산 (' + dateLabel(last.date) + ')</div><div class="v">' + compactKRW(last.totalAsset) + '원</div><div class="s ' + cls(last.totalPL) + '">평가손익 ' + wonSC(last.totalPL || 0) + '</div></div>' +
      '<div class="kpi"><div class="k">직전 기록' + (prev ? '(' + dateLabel(prev.date) + ')' : '') + ' 대비</div><div class="v ' + cls(dPrev) + '">' + (prev ? wonSC(dPrev) : '-') + '</div><div class="s ' + cls(dPrev) + '">' + (prev && prev.totalAsset > 0 ? pct(dPrev / prev.totalAsset * 100) : '') + '</div></div>' +
      '<div class="kpi"><div class="k">선택 기간 시작(' + dateLabel(b0.date) + ') 대비</div><div class="v ' + cls(dR) + '">' + wonSC(dR) + '</div><div class="s ' + cls(dR) + '">' + (b0.totalAsset > 0 ? pct(dR / b0.totalAsset * 100) : '') + '</div></div></div>';
  }
  const listHtml = all.slice().reverse().map((s, i) => {
    const rows = (s.accounts || []).map(x => '<div class="r"><span>' + esc(x.name) + ' <span class="muted">' + (x.weight || 0).toFixed(0) + '%</span></span><span class="tnum">' + won(x.val || 0) + ' <b class="' + cls(x.ret) + '">' + pct(x.ret || 0) + '</b></span></div>').join('');
    return '<div class="snap' + (i >= 7 ? ' snap-more' : '') + '" data-date="' + s.date + '"><div class="sh" data-act="snap-toggle">' +
      '<div class="date">' + dateLabel(s.date) + (s.date === todayKey() ? ' <span class="badge blue">오늘</span>' : '') + '</div>' +
      '<div class="figs"><div class="fig"><div class="k">총자산</div><div class="v">' + won(s.totalAsset) + '</div></div>' +
      (s.totalCost != null ? '<div class="fig hide-m"><div class="k">투자원금</div><div class="v">' + won(s.totalCost) + '</div></div>' : '') +
      '<div class="fig"><div class="k">수익</div><div class="v ' + cls(s.totalPL) + '">' + pct(s.totalRet || 0) + '</div></div></div>' + icon('chevron-down', 'ic-sm') + '</div>' +
      '<div class="sd">' + rows + '<div style="text-align:right;margin-top:10px"><button class="btn btn-danger btn-sm" data-act="snap-del" data-date="' + s.date + '">' + icon('trash', 'ic-sm') + '이 기록 삭제</button></div></div></div>';
  }).join('');
  el.innerHTML =
    '<div class="page-head"><div><h1>자산 기록</h1><div class="desc">날짜별 총자산 변화 · 시세 갱신 때 자동 저장 ' + (S.settings.autoSnap ? '켜짐' : '꺼짐') + '</div></div>' +
      '<div class="actions"><button class="btn btn-primary" data-act="save-snap">' + icon('bookmark') + '오늘 기록 저장</button></div></div>' +
    (all.length ? top +
      '<div class="card" style="margin-bottom:18px"><div class="card-head"><h3>' + icon('trending-up', 'ic-sm') + '총자산 변화</h3>' +
        '<div class="seg" style="flex-wrap:wrap">' + ranges.map(x => '<button data-act="hist-range" data-v="' + x[0] + '" class="' + (r === x[0] ? 'on' : '') + '">' + x[1] + '</button>').join('') + '</div></div>' +
        (r === 'custom' ? '<div class="row" style="max-width:520px;margin-bottom:14px;align-items:center"><input type="date" class="input" id="hFrom" value="' + (histFrom || '') + '"><span style="flex:none">~</span><input type="date" class="input" id="hTo" value="' + (histTo || '') + '"><button class="btn btn-primary" style="flex:none" data-act="hist-apply">적용</button></div>' : '') +
        '<div id="histChart"></div></div>' +
      '<div class="card"><div class="card-head"><h3>' + icon('history', 'ic-sm') + '기록 목록 <span class="muted" style="font-weight:600">' + all.length + '</span></h3><span class="muted" style="font-size:.8rem">눌러서 계좌별 보기</span></div><div class="snap-list">' + listHtml + '</div>' +
        (all.length > 7 ? '<button class="btn btn-gray btn-block" style="margin-top:10px" onclick="this.previousElementSibling.classList.add(\'all\');this.remove()">이전 기록 ' + (all.length - 7) + '개 더 보기</button>' : '') + '</div>'
    : '<div class="card"><div class="empty"><div class="ill">' + icon('history') + '</div><b>아직 기록이 없어요</b><p>시세를 갱신하면 그날 총자산이 자동으로 쌓여요.<br>지금 바로 <b>오늘 기록 저장</b>을 눌러도 돼요.</p><button class="btn btn-primary btn-lg" data-act="save-snap">' + icon('bookmark') + '오늘 기록 저장</button></div></div>');
  hydrateIcons(el);
  const src = F.length >= 2 ? F : all;
  if (all.length) {
    lineChart(document.getElementById('histChart'), src.map(s => [s.date, s.totalAsset]), {
      height: 260, fmtX: d => dateLabel(d), fmtAxis: v => compactKRW(v), fmtV: v => won(v), label: '총자산 변화',
      empty: '기록이 2개 이상 쌓이면 그래프가 그려져요',
      tip: (p, i, a) => '<span class="d">' + esc(dateLabel(p[0])) + '</span><br><b>' + esc(won(p[1])) + '</b><br>' + esc(korUnit(p[1])) + (i ? '<br><span class="d">직전 대비</span> ' + esc(wonS(p[1] - a[i - 1][1])) : ''),
    });
  }
};

function snapObj() {
  if (!accounts().length) return null;
  const G = grand();
  if (!(G.asset > 0)) return null;
  return { date: todayKey(), totalAsset: G.asset, totalCost: G.cost, totalPL: G.pl, totalRet: G.ret,
    accounts: accounts().slice().sort((x, y) => accT(y).asset - accT(x).asset).map(a => { const t = accT(a); return { name: a.name, val: t.asset, weight: G.asset > 0 ? t.asset / G.asset * 100 : 0, pl: t.pl, ret: t.ret }; }) };
}
function saveSnapshot(silent) {
  if (!accounts().length) { if (!silent) toast('계좌가 없어요'); return; }
  const snap = snapObj();
  if (!snap) { if (!silent) toast('자산이 0원이라 기록하지 않았어요'); return; }
  const h = P().history, exists = h.some(x => x.date === snap.date);
  P().history = h.filter(x => x.date !== snap.date).concat([snap]);
  save();
  if (!silent) toast(exists ? '오늘 기록을 최신 값으로 바꿨어요' : '오늘 기록을 저장했어요');
}
