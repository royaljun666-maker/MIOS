/* ==========================================================================
   settings.js — AI 연결(회사·모델·키) · 투자 성향 · 계산 · 화면 · 가족 · 데이터 · 고급
   ========================================================================== */
'use strict';

let PROV = null, PROV_META = null, provSel = null, provShowKey = false;
const MODEL_CACHE = {};
const PROV_STYLE = {
  gemini: ['G', 'linear-gradient(135deg,#4285F4,#9B72CB)'], groq: ['Gq', '#F55036'], openrouter: ['OR', '#6467F2'],
  github: ['GH', '#24292F'], mistral: ['M', '#FA520F'], cerebras: ['C', '#E8522B'], ollama: ['OL', '#4A4A4A'],
  openai: ['AI', '#10A37F'], anthropic: ['A', '#C96442'],
};
const TIER_BADGE = { free: ['green', '무료'], local: ['blue', '내 PC · 무료'], paid: ['gray', '유료'] };

async function loadProviders() {
  try { const d = await api('/api/ai/providers', { timeout: 8000 }); PROV = d.providers; PROV_META = d; return d; }
  catch (e) { PROV = null; return null; }
}

const SET_SECS = [['ai', 'key', 'AI 연결'], ['license', 'lock', '이용권'], ['profile', 'user', '투자자 정보'], ['policy', 'shield', '투자 성향'], ['sector', 'target', '관심 섹터'], ['calc', 'coins', '계산·자동화'], ['view', 'sun', '화면'], ['people', 'users', '가족'], ['data', 'database', '데이터 백업'], ['legal', 'shield', '약관·고지'], ['adv', 'settings', '고급']];

PAGES.settings = function (params, isRe) {
  const el = pageEl('settings');
  const sec = params && params.sec;
  const wasOpen = isRe ? [...el.querySelectorAll('.set-sec.open')].map(x => x.id) : [];   // 화면·글자 크기를 바꿔도 펼친 칸 유지
  el.innerHTML =
    '<div class="page-head"><div><h1>설정</h1><div class="desc">AI 연결과 앱 사용 환경을 바꿀 수 있어요</div></div></div>' +
    '<div class="set-search"><input class="input" id="setQ" placeholder="🔍 설정 찾기 (예: 글자, 쿠폰, 수수료, 백업)" autocomplete="off"></div>' +
    '<div class="set-layout"><nav class="set-nav" id="setNav">' + SET_SECS.map(s => '<a data-sec-go="' + s[0] + '">' + icon(s[1], 'ic-sm') + s[2] + '</a>').join('') + '</nav>' +
    '<div>' +
      '<div class="card set-sec" id="sec-ai">' + aiSecHtml() + '</div>' +
      '<div class="card set-sec" id="sec-license">' + licenseSecHtml() + '</div>' +
      '<div class="card set-sec" id="sec-profile">' + profileSecHtml() + '</div>' +
      '<div class="card set-sec" id="sec-policy">' + policySecHtml() + '</div>' +
      '<div class="card set-sec" id="sec-sector">' + sectorSecHtml() + '</div>' +
      '<div class="card set-sec" id="sec-calc">' + calcSecHtml() + '</div>' +
      '<div class="card set-sec" id="sec-view">' + viewSecHtml() + '</div>' +
      '<div class="card set-sec" id="sec-people">' + peopleSecHtml() + '</div>' +
      '<div class="card set-sec" id="sec-data">' + dataSecHtml() + '</div>' +
      '<div class="card set-sec" id="sec-legal">' + legalSecHtml() + '</div>' +
      '<div class="card set-sec" id="sec-adv">' + advSecHtml() + '</div>' +
    '</div></div>';
  hydrateIcons(el);
  wireSettings(el);
  const q = el.querySelector('#setQ');            // 🔍 설정 찾기 (v3.2) — 글자가 들어간 칸만 펼쳐 보여 줌
  if (q) q.oninput = () => {
    const v = q.value.trim().toLowerCase();
    el.querySelectorAll('.set-sec').forEach(sec => {
      const hit = !v || sec.textContent.toLowerCase().includes(v);
      sec.style.display = hit ? '' : 'none';
      if (v && hit) sec.classList.add('open');
    });
  };
  wasOpen.forEach(id => { const t = document.getElementById(id); if (t) t.classList.add('open'); });
  if (sec) { const t = el.querySelector('#sec-' + sec); if (t) t.classList.add('open'); }
  if (!el._accWired) {                               // 폰: 제목을 누르면 펼치고 접기
    el._accWired = true;
    el.addEventListener('click', e => { const h = e.target.closest('.set-sec > h2'); if (!h) return; const c = h.parentElement, was = c.classList.contains('open');
      el.querySelectorAll('.set-sec.open').forEach(x => x.classList.remove('open')); if (!was) { c.classList.add('open'); setTimeout(() => c.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50); } });
  }
  if (sec) setTimeout(() => { const t = document.getElementById('sec-' + sec); if (t) t.scrollIntoView({ behavior: isRe ? 'auto' : 'smooth', block: 'start' }); }, 60);
  if (params) params.sec = null;
  if (!isRe || !PROV) loadProviders().then(() => { const s = document.getElementById('sec-ai'); if (s) { s.innerHTML = aiSecHtml(); hydrateIcons(s); wireAi(s); } });
  loadAdv();
};

/* ---------- AI 연결 ---------- */
function provLogo(id, size) {
  const st = PROV_STYLE[id] || ['?', '#888'];
  return '<div class="pl" style="background:' + st[1] + (size ? ';width:' + size + 'px;height:' + size + 'px' : '') + '">' + st[0] + '</div>';
}
function aiSecHtml() {
  let h = '<h2>AI 연결</h2><div class="desc">쓰고 싶은 AI 회사를 고르고, 키를 붙여넣고, 모델을 골라요. <b>무료</b>부터 쓸 수 있어요.</div>' +
    '<button class="wz-entry" data-act="ai-wizard"><span>🧓</span><div><b>어려우세요? 쉬운 도우미로 켜기</b><small>큰 글씨로 한 단계씩 · 복사만 하면 앱이 알아서 연결 · 가족에게 부탁하기</small></div></button>';
  if (!PROV) return h + '<div class="skel" style="height:200px"></div>';
  const st = PROV_META.status || {};
  const primary = PROV_META.primary;
  h += st.on ? '<div class="callout good" style="margin-bottom:16px">' + icon('check', 'ic-sm') + '<div><b>지금 사용 중: ' + esc(st.provider) + ' · ' + esc(st.model) + '</b>' + (st.count > 1 ? '<br>예비 AI ' + (st.count - 1) + '개가 준비돼 있어요 (한도 초과 시 자동 전환)' : '<br>예비 AI를 하나 더 연결해 두면 무료 한도가 끝나도 계속 쓸 수 있어요') + '</div></div>'
    : '<div class="callout info" style="margin-bottom:16px">' + icon('info', 'ic-sm') + '<div><b>처음이라면 Google Gemini가 쉬워요.</b> 구글 계정만 있으면 무료이고, 아래 카드를 누르면 순서대로 안내해 드려요.</div></div>';
  const card = p => {
    const tb = TIER_BADGE[p.tier] || TIER_BADGE.free;
    const usingEnv = !p.configured && p.env && st.on && st.provider_id === p.id && !primary;
    const state = (p.id === primary && p.configured) || usingEnv ? '<span class="badge blue">사용 중</span>' : p.configured || p.env ? '<span class="badge green">연결됨</span>' : '';
    return '<button class="prov ' + (provSel === p.id ? 'sel' : '') + '" data-prov="' + p.id + '"><span class="state">' + state + '</span>' +
      '<div class="pt">' + provLogo(p.id) + '<div><div class="pn">' + esc(p.name) + '</div><span class="badge ' + tb[0] + '">' + esc(p.badge || tb[1]) + '</span></div></div>' +
      '<div class="pd">' + esc(p.desc) + '</div></button>';
  };
  const free = PROV.filter(p => p.tier !== 'paid'), paid = PROV.filter(p => p.tier === 'paid');
  h += '<div class="label" style="font-size:.86rem;font-weight:700;color:var(--text-2);margin:4px 0 10px">무료로 쓸 수 있어요</div><div class="prov-grid">' + free.map(card).join('') + '</div>' +
    '<div class="label" style="font-size:.86rem;font-weight:700;color:var(--text-2);margin:18px 0 10px">유료 (선불 충전 필요 · ChatGPT/Claude 구독과는 별개)</div><div class="prov-grid">' + paid.map(card).join('') + '</div>' +
    '<div id="provEdit">' + (provSel ? provEditHtml(PROV.find(p => p.id === provSel)) : '') + '</div>' +
    '<div class="set-row" style="margin-top:14px;border-top:1px solid var(--line);padding-top:16px"><div class="t"><b>자동 대체</b><span>기본 AI가 한도 초과·오류일 때 연결해 둔 다른 AI로 자동으로 바꿔 답해요</span></div>' +
      '<label class="switch"><input type="checkbox" id="autoFb" ' + (PROV_META.auto_fallback ? 'checked' : '') + '><span></span></label></div>';
  return h;
}
function modelOptions(p) {
  const seen = new Set(), opts = [];
  const add = (id, d) => { if (!id || seen.has(id)) return; seen.add(id); opts.push([id, d || '']); };
  (p.models || []).forEach(m => add(m[0], m[1]));
  (MODEL_CACHE[p.id] || []).forEach(m => add(m[0], m[1]));
  if (p.model) add(p.model, '현재 설정');
  return opts;
}
function provEditHtml(p) {
  if (!p) return '';
  const tb = TIER_BADGE[p.tier] || TIER_BADGE.free;
  const opts = modelOptions(p);
  const curModel = p.model || (opts[0] && opts[0][0]) || '';
  return '<div class="prov-edit" id="pe" data-pid="' + p.id + '">' +
    '<div class="card-head" style="margin-bottom:8px"><h3>' + provLogo(p.id, 32) + esc(p.name) + ' <span class="badge ' + tb[0] + '">' + esc(p.badge) + '</span></h3>' +
      (p.configured ? '<button class="btn btn-ghost btn-sm" data-pe="remove" style="color:var(--bad)">' + icon('trash', 'ic-sm') + '연결 해제</button>' : '') + '</div>' +
    '<p class="note" style="margin:0">' + esc(p.desc) + '</p>' +
    (p.env && !p.configured ? '<div class="callout good" style="margin-top:12px">' + icon('check', 'ic-sm') + '<div>이 PC의 환경변수(<code>' + esc(p.env) + '</code>)에 있는 키로 이미 쓰고 있어요. 아래에 키를 넣으면 그 키가 먼저 쓰여요.</div></div>' : '') +
    '<ol class="steps">' + p.steps.map(s => '<li>' + esc(s) + '</li>').join('') + '</ol>' +
    '<a class="btn btn-soft" href="' + esc(safeUrl(p.key_url)) + '" target="_blank" rel="noopener" style="margin-bottom:18px">' + icon('external', 'ic-sm') + (p.no_key ? '설치 페이지 열기' : '키 발급 페이지 열기') + '</a>' +
    (p.no_key ?
      '<div class="field"><label>Ollama 주소</label><input class="input" id="peBase" value="' + esc(p.base_url || p.default_base || 'http://localhost:11434') + '"><div class="help">보통 그대로 두면 돼요</div></div>'
    : '<div class="field"><label>' + icon('key', 'ic-sm') + 'API 키 ' + (p.configured ? '<span class="badge green">저장됨 ' + esc(p.key_masked) + '</span>' : '') + '</label>' +
        '<div class="input-wrap"><input class="input" id="peKey" type="' + (provShowKey ? 'text' : 'password') + '" autocomplete="off" spellcheck="false" placeholder="' + (p.configured ? '바꾸려면 새 키를 붙여넣으세요 (비워 두면 기존 키 유지)' : esc(p.key_hint) + ' — 여기에 붙여넣기 (Ctrl+V)') + '" style="padding-right:96px">' +
        '<button class="inner-btn" data-pe="paste" style="right:46px" title="붙여넣기">' + icon('paste', 'ic-sm') + '</button>' +
        '<button class="inner-btn" data-pe="eye" title="보이기/숨기기">' + icon(provShowKey ? 'eye-off' : 'eye', 'ic-sm') + '</button></div>' +
        '<div class="help">키는 비밀번호처럼 소중해요. 이 기기에만 저장되고 다른 곳에 보내지 않아요.</div></div>') +
    '<div class="field"><label>' + icon('bot', 'ic-sm') + '모델</label><div class="model-row">' +
      '<select class="input" id="peModel">' + opts.map(o => '<option value="' + esc(o[0]) + '"' + (o[0] === curModel ? ' selected' : '') + '>' + esc(o[0]) + (o[1] ? ' — ' + esc(o[1]) : '') + '</option>').join('') + '<option value="__custom">직접 입력…</option></select>' +
      '<button class="btn btn-outline" data-pe="models" style="height:50px;flex:none">' + icon('refresh', 'ic-sm') + '목록 불러오기</button></div>' +
      '<input class="input hide" id="peModelCustom" placeholder="모델 이름을 정확히 적어 주세요" style="margin-top:8px">' +
      '<div class="help">' + (p.id === 'openrouter' ? '이름 끝이 <b>:free</b>인 무료 모델만 보여드려요. 무료 모델은 보낸 내용이 모델 개선에 쓰일 수 있어요(계좌번호 같은 정보는 보내지 않아요).' : '잘 모르겠으면 맨 위(추천)를 그대로 쓰세요. “목록 불러오기”로 최신 모델을 받을 수 있어요.') + '</div></div>' +
    '<div style="display:flex;gap:8px;flex-wrap:wrap">' +
      '<button class="btn btn-outline" data-pe="test">' + icon('zap', 'ic-sm') + '연결 테스트</button>' +
      '<button class="btn btn-primary" data-pe="save">' + icon('check', 'ic-sm') + (PROV_META.primary === p.id && p.configured ? '저장' : '저장하고 이 AI 쓰기') + '</button>' +
      (p.configured && PROV_META.primary !== p.id ? '<button class="btn btn-gray" data-pe="saveonly">예비로만 저장</button>' : '') +
    '</div><div class="test-result" id="peResult"></div></div>';
}
function wireAi(sec) {
  sec.querySelectorAll('[data-prov]').forEach(b => b.onclick = () => {
    provSel = provSel === b.dataset.prov ? null : b.dataset.prov; provShowKey = false;
    sec.innerHTML = aiSecHtml(); hydrateIcons(sec); wireAi(sec);
    const pe = document.getElementById('pe'); if (pe) pe.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    if (provSel === 'openrouter' && !MODEL_CACHE.openrouter) fetchModels(sec, 'openrouter', true);
  });
  const fb = sec.querySelector('#autoFb');
  if (fb) fb.onchange = async () => { try { await api('/api/ai/settings', { method: 'POST', body: { auto_fallback: fb.checked } }); toast(fb.checked ? '자동 대체를 켰어요' : '자동 대체를 껐어요'); } catch (e) { toast(SERVER_DOWN); } };
  const pe = sec.querySelector('#pe'); if (!pe) return;
  const pid = pe.dataset.pid;
  const sel = pe.querySelector('#peModel'), cust = pe.querySelector('#peModelCustom');
  sel.onchange = () => cust.classList.toggle('hide', sel.value !== '__custom');
  const res = pe.querySelector('#peResult');
  const vals = () => ({ provider: pid, key: (pe.querySelector('#peKey') || {}).value || '', model: sel.value === '__custom' ? cust.value.trim() : sel.value, base_url: (pe.querySelector('#peBase') || {}).value || '' });
  pe.addEventListener('click', async e => {
    const b = e.target.closest('[data-pe]'); if (!b) return;
    const act = b.dataset.pe;
    if (act === 'eye') { provShowKey = !provShowKey; const k = pe.querySelector('#peKey'); k.type = provShowKey ? 'text' : 'password'; b.innerHTML = icon(provShowKey ? 'eye-off' : 'eye', 'ic-sm'); }
    else if (act === 'paste') {
      try { const t = await navigator.clipboard.readText(); pe.querySelector('#peKey').value = t.trim(); toast('붙여넣었어요'); }
      catch (err) { pe.querySelector('#peKey').focus(); toast('키 칸을 누르고 Ctrl+V 를 눌러 붙여넣어 주세요', 3000); }
    }
    else if (act === 'models') fetchModels(sec, pid, false);
    else if (act === 'test') {
      const v = vals(); b.classList.add('loading'); b.disabled = true;
      res.innerHTML = '<div class="callout gray">' + icon('refresh', 'ic-sm') + '<div>AI에게 인사를 보내 보는 중…</div></div>';
      try {
        const d = await api('/api/ai/test', { method: 'POST', body: v, timeout: 70000 });
        res.innerHTML = d.ok ? '<div class="callout good">' + icon('check', 'ic-sm') + '<div><b>연결 성공! (' + (d.ms / 1000).toFixed(1) + '초)</b><br>AI의 답: “' + esc(d.reply) + '”<br><span style="opacity:.8">이제 “저장”을 눌러 주세요.</span></div></div>'
          : '<div class="callout warn">' + icon('alert', 'ic-sm') + '<div><b>' + esc(d.error) + '</b>' + (d.detail ? '<br><span style="opacity:.75;font-size:.8rem">' + esc(d.detail.slice(0, 160)) + '</span>' : '') + '</div></div>';
      } catch (err) { res.innerHTML = '<div class="callout warn">' + icon('alert', 'ic-sm') + '<div>' + SERVER_DOWN + '</div></div>'; }
      b.classList.remove('loading'); b.disabled = false; hydrateIcons(res);
    }
    else if (act === 'save' || act === 'saveonly') {
      const v = vals(); const p = PROV.find(x => x.id === pid);
      if (!p.no_key && !p.configured && !v.key.trim()) { toast('키를 먼저 붙여넣어 주세요'); pe.querySelector('#peKey').focus(); return; }
      if (!v.model) { toast('모델을 골라 주세요'); return; }
      // 새 키를 넣었거나 처음 연결이면, 저장 전에 한 번 확인해서 잘못된 키를 막아요
      if (v.key.trim() || !p.configured) {
        b.classList.add('loading'); b.disabled = true;
        res.innerHTML = '<div class="callout gray">' + icon('refresh', 'ic-sm') + '<div>저장하기 전에 키가 맞는지 확인하는 중…</div></div>';
        let t = null;
        try { t = await api('/api/ai/test', { method: 'POST', body: v, timeout: 70000 }); } catch (err) { t = { ok: false, error: SERVER_DOWN }; }
        b.classList.remove('loading'); b.disabled = false; res.innerHTML = '';
        if (!t.ok && !(await confirmBox({ title: '연결 확인 실패', msg: '<b>' + esc(t.error || '') + '</b><br><br>그래도 저장할까요? (키가 틀렸다면 “취소” 후 다시 붙여넣어 주세요)', ok: '그래도 저장', cancel: '취소' }))) return;
      }
      try {
        await api('/api/ai/settings', { method: 'POST', body: Object.assign(v, { make_primary: act === 'save' }) });
        await loadProviders(); await loadAIStatus();
        provShowKey = false;
        sec.innerHTML = aiSecHtml(); hydrateIcons(sec); wireAi(sec);
        toast(act === 'save' ? p.name + ' 연결 완료! 이제 AI 기능을 쓸 수 있어요' : '예비 AI로 저장했어요', 3000);
      } catch (err) { toast(SERVER_DOWN); }
    }
    else if (act === 'remove') {
      if (!(await confirmBox({ title: '연결 해제', msg: esc(PROV.find(x => x.id === pid).name) + ' 연결을 해제하고 저장된 키를 지울까요?', ok: '해제', danger: true }))) return;
      try { await api('/api/ai/settings', { method: 'POST', body: { provider: pid, remove: true } }); await loadProviders(); await loadAIStatus(); sec.innerHTML = aiSecHtml(); hydrateIcons(sec); wireAi(sec); toast('연결을 해제했어요'); }
      catch (err) { toast(SERVER_DOWN); }
    }
  });
}
async function fetchModels(sec, pid, quiet) {
  const pe = sec.querySelector('#pe');
  const key = pe && pe.querySelector('#peKey') ? pe.querySelector('#peKey').value : '';
  const base = pe && pe.querySelector('#peBase') ? pe.querySelector('#peBase').value : '';
  if (!quiet) toast('모델 목록을 불러오는 중…');
  try {
    const d = await api('/api/ai/models', { method: 'POST', body: { provider: pid, key, base_url: base }, timeout: 25000 });
    if (!d.ok) { if (!quiet) toast(d.error || '목록을 못 가져왔어요', 3200); return; }
    MODEL_CACHE[pid] = d.models || [];
    const keep = pe ? pe.querySelector('#peKey') && pe.querySelector('#peKey').value : '';
    sec.innerHTML = aiSecHtml(); hydrateIcons(sec); wireAi(sec);
    const k2 = sec.querySelector('#peKey'); if (k2 && keep) k2.value = keep;
    if (!quiet) toast('모델 ' + MODEL_CACHE[pid].length + '개를 찾았어요');
  } catch (e) { if (!quiet) toast(SERVER_DOWN); }
}

/* ---------- 투자 성향 ---------- */
function policySecHtml() {
  return '<h2>투자 성향</h2><div class="desc">계좌 건강검진과 AI 평가의 기준이 돼요. 정답은 없어요 — 나에게 맞는 걸 고르세요.<span class="set-more"> 매매 스타일·AI 설명 방식도 여기서 바꿔요.</span></div>' +
    '<div class="opt-cards">' + Object.keys(POLICY).map(k => { const p = POLICY[k]; return '<button class="opt ' + (S.settings.policy === k ? 'on' : '') + '" data-pol="' + k + '"><b>' + p.label + '</b><span>' + p.desc + '<br>한 종목 ' + p.single + '% 이하 · 현금 ' + p.cashMin + '% 이상 · 방어자산 ' + p.defMin + '% 이상</span></button>'; }).join('') + '</div>' +
    '<h2 style="margin-top:24px">매매 스타일</h2><div class="desc">AI가 종목을 짚어 줄 때 이 스타일에 맞춰 조언해요. (AI 탭의 아이디어 발굴에서도 바꿀 수 있어요)</div>' +
    '<div class="opt-cards">' + Object.values(TRADE_STYLES).map(s => '<button class="opt ' + (tradeStyle() === s.key ? 'on' : '') + '" data-style="' + s.key + '"><b>' + s.emoji + ' ' + s.label + '</b><span>' + s.desc + '</span></button>').join('') + '</div>' +
    '<h2 style="margin-top:24px">AI 설명 방식</h2><div class="desc">내 주식 실력에 맞춰 골라 주세요. AI의 모든 분석·브리핑·대화가 이 방식으로 <b>길이와 깊이, 내용</b>이 달라져요.</div>' +
    '<div class="opt-cards">' + Object.values(AI_DEPTHS).map(t => '<button class="opt ' + (aiDepth() === t.key ? 'on' : '') + '" data-depth="' + t.key + '"><b>' + t.emoji + ' ' + t.label + '</b><span>' + t.desc + '</span></button>').join('') + '</div>';
}
/* ---------- 투자자 정보 (설문) ---------- */
function profileSecHtml() {
  const p = profile(), n = PROFILE_Q.filter(x => p[x.k]).length;
  return '<h2>투자자 정보 <span class="muted" style="font-size:.82rem;font-weight:600">' + (n ? n + '/' + PROFILE_Q.length + ' 답함' : '아직 안 함') + '</span></h2>' +
    '<div class="desc">나이·직업·목적·경험을 알려 주면 AI가 <b>나에게 맞는</b> 위험 수준과 예시로 답해요. 이 기기에만 저장돼요.</div>' +
    '<div class="pf-list">' + PROFILE_Q.map(x => { const o = x.o.find(y => y[0] === p[x.k]); return '<div class="pf-row"><span>' + esc(x.q.replace(/\?$/, '')) + '</span><b>' + (o ? esc(o[1]) : '<em class="muted">—</em>') + '</b></div>'; }).join('') + '</div>' +
    '<button class="btn btn-soft btn-block" style="margin-top:12px" data-act="ai-setup">' + icon('pencil', 'ic-sm') + (n ? '설문 다시 하기' : '설문하기 (1분)') + '</button>' +
    (!feat('dna') ? '' : '<div class="dna-box"><b>🧬 내 투자 DNA</b><span>' + esc(dnaSummary()) + '</span><p>성격·투자금·버틸 수 있는 손실, 차트·뉴스·금리·환율을 얼마나 보는지, 소형/대형·국장/미장·ETF 선호까지 슬라이더로 조절해요. 여러 조합을 저장해 바꿔 쓸 수 있어요.</p>' +
      '<button class="btn btn-primary btn-block" data-act="dna">🧬 투자 DNA 조절하기</button></div>');
}
/* ---------- 관심 섹터 ---------- */
function sectorSecHtml() {
  const n = sectors().length;
  return '<h2>관심 섹터 <span class="muted" style="font-size:.82rem;font-weight:600">' + (n ? n + '개 고름' : '여러 개 가능') + '</span></h2>' +
    '<div class="desc">AI 종목 정리·시장 흐름·대화가 <b>고른 섹터를 중점</b>으로 봐요. 안 고르면 골고루 찾아요.</div>' +
    sectorChipsHtml(sectors()) + '<div class="sec-cnt">' + (n ? n + '개 골랐어요 · 누르면 바로 저장돼요' : '누르면 바로 저장돼요') + '</div>';
}
function wireSectorSec(s) {
  wireSectorChips(s, sectors().slice(), sel => {
    UI.sectors = sel.slice(); saveUI();
    const c = s.querySelector('.sec-cnt'); if (c) c.textContent = sel.length ? sel.length + '개 골랐어요 · 누르면 바로 저장돼요' : '누르면 바로 저장돼요';
    const h = s.querySelector('h2 .muted'); if (h) h.textContent = sel.length ? sel.length + '개 고름' : '여러 개 가능';
  });
}
/* ---------- 계산 · 자동화 ---------- */
function calcSecHtml() {
  return '<h2>계산 · 자동화</h2><div class="desc">수익률 계산에 쓰는 값과 자동 기능이에요.</div>' +
    '<div class="set-row"><div class="t"><b>달러 환율</b><span>시세 갱신 때 자동으로 최신 환율로 바뀌어요. 직접 고칠 수도 있어요.</span></div><div class="input-wrap"><input class="input tnum" data-set="fxRate" inputmode="decimal" value="' + esc(nf(fx(), 2)) + '"><span class="suffix">원</span></div></div>' +
    '<div class="set-row"><div class="t"><b>매매 수수료율</b><span>증권사마다 달라요 (보통 0.015% 안팎)</span></div><div class="input-wrap"><input class="input tnum" data-set="feeRate" inputmode="decimal" value="' + esc(S.settings.feeRate) + '"><span class="suffix">%</span></div></div>' +
    '<div class="set-row"><div class="t"><b>국내 주식 매도 거래세율</b><span>팔 때 자동으로 빼고 계산해요</span></div><div class="input-wrap"><input class="input tnum" data-set="taxRate" inputmode="decimal" value="' + esc(S.settings.taxRate) + '"><span class="suffix">%</span></div></div>' +
    '<div class="set-row"><div class="t"><b>앱을 열면 시세 자동 갱신</b><span>마지막 갱신 후 30분이 지났으면 켤 때 알아서 최신 시세를 가져와요</span></div><label class="switch"><input type="checkbox" data-sw="autoRefresh" ' + (S.settings.autoRefresh ? 'checked' : '') + '><span></span></label></div>' +
    '<div class="set-row"><div class="t"><b>시세 갱신 때 오늘 기록 자동 저장</b><span>매일 자산 변화가 자동으로 쌓여 그래프가 그려져요</span></div><label class="switch"><input type="checkbox" data-sw="autoSnap" ' + (S.settings.autoSnap ? 'checked' : '') + '><span></span></label></div>';
}
/* ---------- 화면 ---------- */
function viewSecHtml() {
  const seg = (k, opts, cur) => '<div class="seg lg">' + opts.map(o => '<button data-ui="' + k + '" data-v="' + o[0] + '" class="' + (cur === o[0] ? 'on' : '') + '">' + o[1] + '</button>').join('') + '</div>';
  return '<h2>화면</h2><div class="desc">눈이 편한 대로 바꿔 보세요.</div>' +
    '<div class="set-row"><div class="t"><b>화면 밝기</b><span>“자동”은 컴퓨터 설정을 따라가요</span></div>' + seg('theme', [['auto', '자동'], ['light', '밝게'], ['dark', '어둡게']], UI.theme) + '</div>' +
    '<div class="set-row"><div class="t"><b>글자 크기</b><span>글씨가 작게 느껴지면 키워 보세요</span></div>' + seg('fontScale', [['normal', '보통'], ['large', '크게'], ['xlarge', '아주 크게']], UI.fontScale) + '</div>' +
    '<div class="set-row"><div class="t"><b>오를 때 색</b><span>한국식은 빨강이 오름, 미국식은 초록이 오름</span></div>' + seg('upColor', [['red', '🔴 빨강 = 오름'], ['green', '🟢 초록 = 오름']], UI.upColor || 'red') + '</div>' +
    '<div class="set-row"><div class="t"><b>시작 애니메이션</b><span>앱을 켤 때 블록이 모여 아이콘이 되는 3초 화면 (누르면 건너뛰기)</span></div>' + seg('introOff', [['off', '🎬 켜기'], ['on', '끄기']], UI.introOff ? 'on' : 'off') + '</div>' +
    '<div class="set-row"><div class="t"><b>해외 뉴스 번역</b><span>영어 뉴스 제목을 한국어로 바꿔 보여 줘요 (원문은 아래 작게)</span></div>' + seg('trNews', [['on', '🌐 번역해서'], ['off', '원문 그대로']], UI.trNews === 'off' ? 'off' : 'on') + '</div>' +
    '<div class="set-row"><div class="t"><b>금액 숨기기</b><span>지하철 등 남이 볼 때 금액을 흐리게 (홈의 👁 버튼으로도 바꿀 수 있어요)</span></div>' + seg('hideAmt', [['off', '보이기'], ['on', '숨기기']], UI.hideAmt ? 'on' : 'off') + '</div>' +
    '<div class="set-row"><div class="t"><b>배경음</b><span>누르면 바로 들어 볼 수 있어요. 시끄러우면 끄세요. (기본 꺼짐)</span></div>' + seg('soundMode', [['off', '끄기'], ['calm', '🌙 잔잔하게'], ['upbeat', '🎵 경쾌하게']], soundMode()) + '</div>';
}
/* ---------- 가족 ---------- */
function peopleSecHtml() {
  return '<h2>가족</h2><div class="desc">가족 한 명 한 명의 자산을 따로 관리해요. 왼쪽 위 이름을 눌러 바꿔 볼 수 있어요.</div>' +
    '<div class="people">' + S.people.map(p => {
      let tot = 0; p.accounts.forEach(a => { tot += num(a.cash); a.holdings.forEach(h => { tot += hv(h).valK; }); });
      return '<div class="person-row"><span class="avatar">' + esc(p.name.slice(0, 1)) + '</span><div class="t"><b>' + esc(p.name) + (p.id === S.curPerson ? ' <span class="badge blue">보는 중</span>' : '') + '</b><span>계좌 ' + p.accounts.length + '개 · ' + korUnit(tot) + '</span></div>' +
        (p.id !== S.curPerson ? '<button class="btn btn-gray btn-sm" data-pp="view" data-id="' + p.id + '">보기</button>' : '') +
        '<button class="icon-btn" data-pp="edit" data-id="' + p.id + '" title="이름 바꾸기">' + icon('pencil', 'ic-sm') + '</button></div>';
    }).join('') + '</div><button class="btn btn-soft" style="margin-top:12px" data-pp="add">' + icon('plus', 'ic-sm') + '가족 추가</button>';
}
/* ---------- 데이터 ---------- */
function dataSecHtml() {
  return '<h2>데이터 백업</h2><div class="desc">내 자산 정보는 이 기기(폰·PC) 안에만 있어요. 가끔 백업 파일을 메일·클라우드에 보관해 두면 안심이에요.</div>' +
    '<div class="callout good" style="margin-bottom:6px">' + icon('shield', 'ic-sm') + '<div><b>자동 백업 켜짐</b> — ' + (IS_APP ? '바뀔 때마다 이 폰의 앱 안에 저장되고, 날짜별로 최근 14일치를 보관해요. 폰을 바꾸기 전에는 꼭 백업 파일을 받아 두세요.'
      : '바뀔 때마다 앱 폴더의 <code>userdata</code>에 저장되고, 날짜별로 최근 14일치를 보관해요. 브라우저 기록을 지워도 다시 불러와요.') + '</div></div>' +
    '<div class="set-row"><div class="t"><b>백업 파일 받기</b><span>모든 가족·계좌·기록을 파일 하나로 저장해요</span></div><button class="btn btn-outline" data-dt="export">' + icon('download', 'ic-sm') + '받기</button></div>' +
    '<div class="set-row"><div class="t"><b>백업 파일 불러오기</b><span>다른 PC에서 옮겨 오거나 예전 상태로 되돌려요</span></div><button class="btn btn-outline" data-dt="import">' + icon('upload', 'ic-sm') + '불러오기</button><input type="file" id="impFile" accept=".json,application/json" class="hide"></div>' +
    '<div class="set-row"><div class="t"><b>모든 데이터 지우기</b><span>처음 상태로 돌아가요. 되돌릴 수 없으니 먼저 백업하세요.</span></div><button class="btn btn-danger" data-dt="reset">' + icon('trash', 'ic-sm') + '지우기</button></div>';
}
/* ---------- 고급 ---------- */
function advSecHtml() {
  return '<h2>고급</h2><div class="desc">몰라도 괜찮은 설정이에요.</div>' +
    '<div class="set-row' + (IS_APP ? ' hide' : '') + '"><div class="t"><b>휴대폰에서도 보기 (같은 와이파이)</b><span>켜면 같은 집 와이파이의 휴대폰·태블릿에서 이 앱을 열 수 있어요. 바꾼 뒤 앱을 껐다 켜야 적용돼요.<br>카페 같은 공용 와이파이에서는 켜지 마세요.</span><div id="lanInfo" class="note" style="margin-top:6px"></div></div><label class="switch"><input type="checkbox" id="lanSw"><span></span></label></div>' +
    '<div class="set-row"><div class="t"><b>DART 전자공시 키 (선택)</b><span>넣으면 국내 기업의 공식 영업이익 추세(최근 몇 년)를 함께 보여줘요. <a href="https://opendart.fss.or.kr/uss/umt/EgovMberInsertView.do" target="_blank" rel="noopener" style="color:var(--brand-text);font-weight:700">무료 발급 ↗</a></span></div>' +
      '<input class="input" id="dartKey" placeholder="40자리 키" style="width:220px"><button class="btn btn-outline" data-adv="dart">저장</button></div>' +
    (REMOTE.charity ? '<div class="set-row"><div class="t"><b>💚 ' + esc(REMOTE.charity.name) + ' 기부하기</b><span>앱이 도움이 됐다면 아이들에게 나눠 주세요. 기부금은 전부 기부처로 가요.</span></div><button class="btn btn-soft btn-sm" data-act="support">기부하기</button></div>'
      : '<div class="set-row"><div class="t"><b>☕ 개발자 후원하기</b><span>앱이 도움이 됐다면 응원해 주세요. 후원해도 기능은 똑같아요.</span></div><button class="btn btn-soft btn-sm" data-act="support">후원하기</button></div>') +
    '<div class="set-row"><div class="t"><b>투자 유의 안내</b><span>' + DISCLAIMER.replace('⚠️ ', '') + '</span></div></div>' +
    '<div class="set-row" id="verRow"><div class="t"><b>앱 정보</b><span id="verInfo">확인 중…</span></div><a class="btn btn-ghost btn-sm hide" id="oldUiLink" href="/old" target="_blank" rel="noopener">예전 화면 열기</a></div>';
}
async function loadAdv() {
  try {
    const [st, lan] = await Promise.all([api('/api/status', { timeout: 6000 }), api('/api/settings/lan', { timeout: 6000 })]);
    const v = document.getElementById('verInfo'); if (v) v.textContent = '버전 ' + st.version + ' · DART ' + (st.dart ? '연결됨' : '없음');
    const ou = document.getElementById('oldUiLink'); if (ou) ou.classList.toggle('hide', !st.old_ui);   // 예전 화면이 있는 PC에서만
    const sw = document.getElementById('lanSw'); if (sw) sw.checked = !!lan.enabled;
    const li = document.getElementById('lanInfo');
    if (li) li.innerHTML = lan.enabled ? (lan.active ? '휴대폰 주소: ' + (lan.urls || []).map(u => '<b>' + esc(u) + '</b>').join(' 또는 ') : '앱을 껐다 켜면 휴대폰 주소가 여기 표시돼요') : '';
  } catch (e) { const v = document.getElementById('verInfo'); if (v) v.textContent = SERVER_DOWN; }
}

/* ---------- 이벤트 ---------- */
function wireSettings(el) {
  el.querySelectorAll('[data-sec-go]').forEach(a => a.onclick = () => { const t = document.getElementById('sec-' + a.dataset.secGo); if (t) t.scrollIntoView({ behavior: 'smooth', block: 'start' }); });
  const sa = el.querySelector('#sec-ai'); if (sa) wireAi(sa);
  el.querySelectorAll('[data-pol]').forEach(b => b.onclick = () => { S.settings.policy = b.dataset.pol; save(); const s = document.getElementById('sec-policy'); s.innerHTML = policySecHtml(); wireSettings_(s); toast(POLICY[b.dataset.pol].label + '으로 바꿨어요'); });
  el.querySelectorAll('[data-depth]').forEach(b => b.onclick = () => { UI.aiDepth = b.dataset.depth; saveUI(); const s = document.getElementById('sec-policy'); s.innerHTML = policySecHtml(); wireSettings_(s); toast('AI가 ' + AI_DEPTHS[b.dataset.depth].label + ' 설명해요'); });
  el.querySelectorAll('[data-style]').forEach(b => b.onclick = () => { UI.tradeStyle = b.dataset.style; saveUI(); const s = document.getElementById('sec-policy'); s.innerHTML = policySecHtml(); wireSettings_(s); toast(TRADE_STYLES[b.dataset.style].label + '으로 바꿨어요'); });
  const ss = el.querySelector('#sec-sector'); if (ss) wireSectorSec(ss);
  const sl = el.querySelector('#sec-license'); if (sl) wireLicenseSec(sl);
  el.querySelectorAll('[data-set]').forEach(inp => inp.addEventListener('change', () => {
    const k = inp.dataset.set, v = num(inp.value);
    if (k === 'fxRate' && !(v > 0)) { inp.value = nf(fx(), 2); return; }
    S.settings[k] = String(v); save(); toast('저장했어요');
  }));
  el.querySelectorAll('[data-sw]').forEach(sw => sw.onchange = () => { S.settings[sw.dataset.sw] = sw.checked; save(); toast(sw.checked ? '켰어요' : '껐어요'); });
  el.querySelectorAll('[data-ui]').forEach(b => b.onclick = () => {
    b.parentElement.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b));
    if (b.dataset.ui === 'soundMode') {            // 배경음: 누르면 바로 바뀌어 들려줌
      setSound(b.dataset.v);
      toast(b.dataset.v === 'off' ? '배경음을 껐어요' : (b.dataset.v === 'upbeat' ? '🎵 경쾌한 배경음' : '🌙 잔잔한 배경음') + '을 틀었어요');
      return;
    }
    UI[b.dataset.ui] = (b.dataset.ui === 'hideAmt' || b.dataset.ui === 'introOff') ? b.dataset.v === 'on' : b.dataset.v; saveUI(); applyView();
  });
  el.querySelectorAll('[data-pp]').forEach(b => b.onclick = () => {
    const a = b.dataset.pp;
    if (a === 'add') openPersonForm(null);
    else if (a === 'edit') openPersonForm(b.dataset.id);
    else if (a === 'view') { S.curPerson = b.dataset.id; curAccId = null; selH = null; save(); rerender(); toast(P().name + '님 자산으로 바꿨어요'); }
  });
  el.querySelectorAll('[data-dt]').forEach(b => b.onclick = () => dataAction(b.dataset.dt));
  const imp = el.querySelector('#impFile'); if (imp) imp.onchange = () => importFile(imp);
  const lan = el.querySelector('#lanSw');
  if (lan) lan.onchange = async () => {
    try { await api('/api/settings/lan', { method: 'POST', body: { enabled: lan.checked } }); toast(lan.checked ? '켰어요. 앱을 껐다 켜면 적용돼요' : '껐어요. 앱을 껐다 켜면 적용돼요', 3200); loadAdv(); }
    catch (e) { toast(SERVER_DOWN); lan.checked = !lan.checked; }
  };
  const dk = el.querySelector('[data-adv="dart"]');
  if (dk) dk.onclick = async () => {
    try { const d = await api('/api/settings/dart', { method: 'POST', body: { key: el.querySelector('#dartKey').value } }); toast(d.dart ? 'DART 키를 저장했어요' : 'DART 키를 지웠어요'); el.querySelector('#dartKey').value = ''; loadAdv(); }
    catch (e) { toast(SERVER_DOWN); }
  };
}
function wireSettings_(s) {
  s.querySelectorAll('[data-pol]').forEach(b => b.onclick = () => { S.settings.policy = b.dataset.pol; save(); s.innerHTML = policySecHtml(); wireSettings_(s); toast(POLICY[b.dataset.pol].label + '으로 바꿨어요'); });
  s.querySelectorAll('[data-style]').forEach(b => b.onclick = () => { UI.tradeStyle = b.dataset.style; saveUI(); s.innerHTML = policySecHtml(); wireSettings_(s); toast(TRADE_STYLES[b.dataset.style].label + '으로 바꿨어요'); });
  s.querySelectorAll('[data-depth]').forEach(b => b.onclick = () => { UI.aiDepth = b.dataset.depth; saveUI(); s.innerHTML = policySecHtml(); wireSettings_(s); toast('AI가 ' + AI_DEPTHS[b.dataset.depth].label + ' 설명해요'); });
}

function applyView() {
  let t = UI.theme || 'auto';
  if (t === 'auto') t = window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', t);
  document.querySelector('meta[name="theme-color"]').setAttribute('content', t === 'dark' ? '#0E0F12' : '#F2F4F6');
  document.documentElement.style.fontSize = { normal: '16px', large: '18px', xlarge: '20px' }[UI.fontScale] || '16px';
  document.documentElement.setAttribute('data-up', UI.upColor === 'green' ? 'green' : 'red');      // 오를 때 색 (v3.2)
  document.documentElement.classList.toggle('hide-amt', !!UI.hideAmt);                              // 금액 숨기기
  const ti = document.querySelector('[data-act="toggle-theme"] .ic'); if (ti) { ti.dataset.icon = t === 'dark' ? 'sun' : 'moon'; delete ti.dataset.iconDone; hydrateIcons(ti.parentElement); }
  // 차트는 색이 CSS 변수라 자동으로 바뀜. 크기가 바뀌면 다시 그림
  setTimeout(rerender, 30);
}

async function dataAction(k) {
  if (k === 'export' && IS_APP && window.AndroidBridge) {
    const ok = window.AndroidBridge.saveText('내자산_백업_' + todayKey() + '.json',
      JSON.stringify(Object.assign({ app: 'asset-assistant', exportedAt: new Date().toISOString() }, serial()), null, 2));
    toast(ok ? '폰의 “다운로드” 폴더에 백업 파일을 저장했어요' : '저장하지 못했어요. 다시 시도해 주세요', 3200);
  } else if (k === 'export') {
    const blob =new Blob([JSON.stringify(Object.assign({ app: 'asset-assistant', exportedAt: new Date().toISOString() }, serial()), null, 2)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = '내자산_백업_' + todayKey() + '.json';
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    toast('백업 파일을 “다운로드” 폴더에 저장했어요', 3000);
  } else if (k === 'import') document.getElementById('impFile').click();
  else if (k === 'reset') {
    if (!(await confirmBox({ title: '모든 데이터 지우기', msg: '모든 가족·계좌·종목·기록이 지워져요.<br><b>되돌릴 수 없어요.</b> 정말 지울까요?', ok: '모두 지우기', danger: true }))) return;
    if (!(await confirmBox({ title: '한 번 더 확인할게요', msg: '정말로 전부 지울까요? 백업 파일을 받아 두지 않았다면 “취소”를 누르세요.', ok: '네, 지울게요', danger: true }))) return;
    S = normalizeState({ people: [{ id: uid('p'), name: '나', accounts: [], history: [] }], settings: S.settings });
    curAccId = null; selH = null; save({ force: true }); UI.onboarded = false; saveUI(); go('home'); setTimeout(openOnboarding, 300);
  }
}
function importFile(inp) {
  const f = inp.files && inp.files[0]; if (!f) return;
  const r = new FileReader();
  r.onload = async () => {
    inp.value = '';                                  // 취소해도 같은 파일을 다시 고를 수 있게 먼저 비움
    try {
      const o = JSON.parse(r.result);
      if (!o.people || !Array.isArray(o.people) || !o.people.length) throw new Error('bad');
      const nAcc = o.people.reduce((s, p) => s + (p.accounts || []).length, 0);
      if (!(await confirmBox({ title: '백업 불러오기', msg: '가족 ' + o.people.length + '명 · 계좌 ' + nAcc + '개가 들어 있어요.<br>지금 데이터를 <b>이 백업으로 바꿀까요?</b>', ok: '불러오기' }))) return;
      S = normalizeState({ people: o.people, curPerson: o.curPerson, settings: Object.assign({}, S.settings, o.settings || {}) });
      curAccId = null; selH = null; save({ force: true }); go('home'); toast('백업을 불러왔어요');
    } catch (e) { toast('이 파일은 백업 파일이 아니에요'); }
    inp.value = '';
  };
  r.readAsText(f);
}
