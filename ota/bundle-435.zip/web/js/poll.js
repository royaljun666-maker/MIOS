/* ==========================================================================
   poll.js — 🗳 공개 투표 (텃밭투자집사 전용, v4.35)
   · 모든 사용자가 같은 질문을 보고 기기당 한 표 · 실시간 결과(항목별 표 수·%)
   · 질문은 update.json "tb".poll 에서, 집계는 쿠폰 서버(구글 시트)로. 기기 코드만 보냄(개인정보 없음).
   · 투표 정의가 없으면 카드가 아예 안 보여요.
   ========================================================================== */
'use strict';

let POLL = null;          // { poll:{id,q,options,until,closed}, counts:[], total, mine }
let _pollShowVote = false; // '다시 투표'로 선택지 다시 보기
let _pollBusy = false;

function homePollCard() {
  if (ED !== 'tb') return '';
  setTimeout(() => pollLoad(), 300);
  return '<div class="card poll-card span-8" id="homePoll" style="display:none"><div id="pollInner"></div></div>';
}

async function pollLoad(force) {
  const box = document.getElementById('homePoll');
  if (!box) return;
  let d = null;
  try { d = await api('/api/poll', { timeout: 12000 }); } catch (e) {}
  if (!d || !d.ok || !d.poll) { box.style.display = 'none'; return; }   // 투표 없음 → 숨김
  POLL = d; _pollShowVote = false;
  renderPoll();
  box.style.display = '';
}

function pollPct(n, total) { return total > 0 ? Math.round((n / total) * 100) : 0; }

function renderPoll() {
  const inner = document.getElementById('pollInner'); if (!inner || !POLL) return;
  const p = POLL.poll, opts = p.options || [], mine = (POLL.mine == null ? -1 : POLL.mine);
  const counts = POLL.counts || opts.map(() => 0), total = POLL.total || 0;
  const voted = mine >= 0, showResult = (voted || p.closed) && !_pollShowVote;
  let body;
  if (showResult) {
    body = '<div class="poll-bars">' + opts.map((o, i) => {
      const c = counts[i] || 0, pct = pollPct(c, total);
      return '<div class="poll-bar' + (i === mine ? ' mine' : '') + '"><div class="poll-bl"><span>' + esc(o) + (i === mine ? ' <b class="poll-you">내 선택</b>' : '') + '</span><b>' + pct + '%</b></div>' +
        '<div class="poll-track"><i style="width:' + pct + '%"></i></div><small>' + nf(c, 0) + '표</small></div>';
    }).join('') + '</div>' +
      '<div class="poll-foot"><span>' + (p.closed ? '🔒 마감됐어요' : '총 ' + nf(total, 0) + '명 참여') + '</span>' +
      (!p.closed && voted ? '<button class="btn btn-soft btn-sm" data-poll="revote">표 바꾸기</button>' : '') + '</div>';
  } else {
    body = '<div class="poll-opts">' + opts.map((o, i) =>
      '<button class="poll-opt' + (i === mine ? ' mine' : '') + '" data-pollv="' + i + '"' + (_pollBusy ? ' disabled' : '') + '>' + esc(o) + '</button>').join('') + '</div>' +
      '<div class="poll-note">기기당 한 표예요. 바꾸고 싶으면 다시 누르면 돼요. <b>기기 코드와 선택 항목만</b> 저장되고 이름·연락처는 저장하지 않아요.</div>';
  }
  inner.innerHTML = '<div class="poll-head"><span class="poll-badge">🗳 함께 정해요</span>' +
    (p.until && !p.closed ? '<small class="poll-until">~' + esc(p.until) + '</small>' : '') + '</div>' +
    '<h3 class="poll-q">' + esc(p.q) + '</h3>' + body;
}

async function pollVote(choice) {
  if (_pollBusy || !POLL) return;
  _pollBusy = true; renderPoll();
  let r = null;
  try { r = await api('/api/poll/vote', { method: 'POST', body: { choice: choice }, timeout: 15000 }); } catch (e) {}
  _pollBusy = false;
  if (!r || !r.ok) { toast((r && r.error) || SERVER_DOWN, 3500); renderPoll(); return; }
  POLL.counts = r.counts; POLL.total = r.total; POLL.mine = r.mine; _pollShowVote = false;
  renderPoll();
  try { fxConfetti(1200); } catch (e) {}
  toast('🗳 투표했어요! 결과를 함께 봐요', 2500);
}

document.addEventListener('click', e => {
  const v = e.target.closest('[data-pollv]');
  if (v) { pollVote(+v.dataset.pollv); return; }
  const b = e.target.closest('[data-poll]');
  if (b && b.dataset.poll === 'revote') { _pollShowVote = true; renderPoll(); }
});
