/* ==========================================================================
   dna.js — 🧬 내 투자 DNA (v2.21)
   투자에는 정답이 없어서, 사람마다 중요하게 보는 것을 슬라이더로 직접 조절.
   여러 조합을 이름 붙여 저장하고 바꿔 끼우면, 모든 AI 분석·대화가 그 조합대로 답함.
   서버로는 짧은 영문 키만 보냄 (X-AI-DNA: pat=7;cht=3;...) — 머리글에 한글 불가.
   ========================================================================== */
'use strict';

// 고르기 항목 [키, 제목, [[값, 보이는 글자], ...]]
const DNA_PICK = [
  ['gen', '성별', [['m', '남성'], ['f', '여성'], ['n', '밝히지 않음']]],
  ['per', '성격', [['care', '🐢 신중함'], ['bal', '⚖️ 균형'], ['bold', '🦁 과감함'], ['imp', '⚡ 즉흥적']]],
  ['port', '포트 구분', [['one', '한 계좌로 다'], ['cs', '핵심+위성(안전+공격)'], ['pen', '연금·ISA 중심'], ['trd', '매매 전용 계좌']]],
  ['cap', '투자금 규모', [['s', '500만 원 이하'], ['m', '500만~3천만'], ['l', '3천만~1억'], ['xl', '1억 이상']]],
  ['mon', '매달 넣는 돈', [['0', '없음'], ['s', '50만 원 이하'], ['m', '50만~200만'], ['l', '200만 원 이상']]],
  ['loss', '버틸 수 있는 손실', [['5', '-5%까지'], ['10', '-10%까지'], ['20', '-20%까지'], ['30', '-30%까지'], ['50', '-50%도 버팀']]],
];
// 슬라이더 [키, 제목, 왼쪽 0, 오른쪽 10] — 양쪽 글자가 있으면 '어느 쪽이냐', 없으면 '얼마나 중요하냐'
const DNA_SLIDE = [
  ['pat', '⏳ 인내심 (기다리기)', '금방 결과 보고 싶음', '몇 년도 기다림'],
  ['frq', '🔁 매매 빈도', '거의 안 사고팔기', '자주 사고팔기'],
  ['vol', '🎢 출렁임 견디기', '흔들리면 불안', '크게 흔들려도 괜찮음'],
  ['cht', '📈 차트 보는 정도', '', ''],
  ['fun', '📊 실적·재무 중시', '', ''],
  ['nws', '📰 뉴스·재료 중시', '', ''],
  ['flw', '🧲 수급(외국인·기관) 중시', '', ''],
  ['mac', '🏛 정치·매크로 중시', '', ''],
  ['rate', '🇺🇸 미국 금리·연준 중시', '', ''],
  ['fx', '💱 환율 중시', '', ''],
  ['size', '🏢 종목 크기', '소형주 좋아함', '대형주 좋아함'],
  ['ctry', '🌏 시장', '국내(국장)', '미국(미장)'],
  ['etf', '🧺 개별주 vs ETF', '개별 종목', 'ETF'],
  ['gv', '🌱 가치 vs 성장', '싼 가치주', '빠른 성장주'],
  ['div', '💰 배당 중시', '', ''],
  ['thm', '🔥 테마·유행 따라가기', '', ''],
  ['con', '🎯 분산 vs 집중', '넓게 분산', '몇 종목에 집중'],
  ['lev', '🚀 레버리지·고위험 허용', '', ''],
  ['warn', '🛑 위험 경고 강도', '짧게만', '꼼꼼하게 많이'],
];
// 빠른 조합
const DNA_PRESETS = [
  ['🧓 배당 노후형', { per: 'care', loss: '10', pat: 9, frq: 1, vol: 2, fun: 8, div: 10, size: 9, etf: 6, gv: 2, warn: 8, lev: 0, thm: 1 }],
  ['🚀 미장 성장 공격형', { per: 'bold', loss: '30', pat: 6, frq: 4, vol: 8, ctry: 9, gv: 9, rate: 8, fx: 6, nws: 6, lev: 5, thm: 6, size: 7 }],
  ['⚡ 국장 단타형', { per: 'imp', loss: '10', pat: 1, frq: 10, vol: 7, cht: 10, nws: 9, flw: 9, thm: 9, ctry: 1, size: 3, fun: 2 }],
  ['🧺 ETF 적립형', { per: 'bal', mon: 'm', loss: '20', pat: 10, frq: 0, etf: 10, con: 1, mac: 6, rate: 6, cht: 1, thm: 0 }],
  ['🔎 소형 가치 발굴형', { per: 'care', loss: '30', pat: 9, size: 1, gv: 1, fun: 10, nws: 5, con: 7, cht: 3 }],
];
function dnaNow() { return (UI.dna && typeof UI.dna === 'object') ? UI.dna : {}; }
function dnaSets() { return Array.isArray(UI.dnaSets) ? UI.dnaSets : []; }
function dnaHeader() {
  const d = dnaNow(), out = [];
  DNA_PICK.forEach(([k]) => { if (d[k]) out.push(k + '=' + d[k]); });
  DNA_SLIDE.forEach(([k]) => { if (d[k] != null && +d[k] !== 5) out.push(k + '=' + (+d[k])); });
  return out.join(';');
}
function dnaCount() { return dnaHeader() ? dnaHeader().split(';').length : 0; }
function dnaSummary() {
  const n = dnaCount(), nm = UI.dnaName;
  return n ? (nm ? '🧬 ' + nm + ' · ' : '🧬 ') + n + '개 항목 반영 중' : '🧬 아직 안 정함 (모두 보통)';
}
function openDna() {
  const d = Object.assign({}, dnaNow());
  const m = openModal({ title: '🧬 내 투자 DNA', size: 'wide', body: '' , foot: '<button class="btn btn-gray" data-reset>모두 보통으로</button><button class="btn btn-primary" data-ok>저장하고 AI에 반영</button>' });
  const draw = () => {
    const sets = dnaSets();
    m.setBody(
      '<p class="note" style="margin:0 0 10px">투자에는 정답이 없어요. <b>내가 중요하게 보는 것</b>을 직접 조절하면 모든 AI 분석·대화가 이 조합대로 답해요. 가운데(5)는 "보통"이라 반영하지 않아요.</p>' +
      '<div class="ah-sub" style="margin-top:0">빠른 조합</div><div class="chips" id="dnP">' + DNA_PRESETS.map((p, i) => '<button class="chip" data-p="' + i + '">' + esc(p[0]) + '</button>').join('') +
        sets.map((x, i) => '<button class="chip mine" data-s="' + i + '">⭐ ' + esc(x.name) + '<i data-del="' + i + '">✕</i></button>').join('') + '</div>' +
      DNA_PICK.map(([k, t, ops]) => '<div class="ah-sub">' + esc(t) + '</div><div class="chips" data-k="' + k + '">' + ops.map(([v, l]) => '<button class="chip' + (d[k] === v ? ' on' : '') + '" data-v="' + v + '">' + esc(l) + '</button>').join('') + '</div>').join('') +
      '<div class="ah-sub">얼마나 중요해요? / 어느 쪽이에요?</div>' +
      DNA_SLIDE.map(([k, t, l, r]) => {
        const v = d[k] != null ? +d[k] : 5;
        return '<div class="dn-sl"><div class="dn-t"><b>' + esc(t) + '</b><span id="dv-' + k + '">' + dnaWord(v, l, r) + '</span></div>' +
          '<input type="range" min="0" max="10" step="1" value="' + v + '" data-sl="' + k + '" class="' + (v !== 5 ? 'set' : '') + '">' +
          '<div class="dn-ends"><span>' + esc(l || '덜 중요') + '</span><span>' + esc(r || '아주 중요') + '</span></div></div>';
      }).join('') +
      '<button class="btn btn-ghost btn-sm" id="dnSave" style="margin-top:8px">' + icon('star', 'ic-sm') + '이 조합에 이름 붙여 저장 (여러 개 가능)</button>');
    hydrateIcons(m.body);
  };
  draw();
  m.body.addEventListener('input', e => {
    const k = e.target.dataset.sl; if (!k) return;
    d[k] = +e.target.value; e.target.classList.toggle('set', d[k] !== 5);
    const row = DNA_SLIDE.find(x => x[0] === k); document.getElementById('dv-' + k).textContent = dnaWord(d[k], row[2], row[3]);
  });
  m.body.addEventListener('click', e => {
    const del = e.target.closest('[data-del]');
    if (del) { e.stopPropagation(); UI.dnaSets = dnaSets().filter((_, i) => i !== +del.dataset.del); saveUI(); draw(); return; }
    const p = e.target.closest('[data-p]'), s = e.target.closest('[data-s]');
    if (p) { Object.keys(d).forEach(k => delete d[k]); Object.assign(d, DNA_PRESETS[+p.dataset.p][1]); d._name = DNA_PRESETS[+p.dataset.p][0]; draw(); toast(DNA_PRESETS[+p.dataset.p][0] + ' 불러왔어요 — 더 조절해도 돼요'); return; }
    if (s) { const x = dnaSets()[+s.dataset.s]; Object.keys(d).forEach(k => delete d[k]); Object.assign(d, x.v); d._name = x.name; draw(); return; }
    const v = e.target.closest('[data-v]'), grp = e.target.closest('[data-k]');
    if (v && grp) { const k = grp.dataset.k; d[k] = d[k] === v.dataset.v ? '' : v.dataset.v; draw(); return; }
    if (e.target.closest('#dnSave')) {
      const name = (prompt('이 조합의 이름 (예: 내 연금 계좌용)', d._name || '') || '').trim().slice(0, 16); if (!name) return;
      const v = Object.assign({}, d); delete v._name;
      UI.dnaSets = [{ name, v }].concat(dnaSets().filter(x => x.name !== name)).slice(0, 8); d._name = name; saveUI(); draw(); toast('⭐ "' + name + '" 저장했어요');
    }
  });
  m.foot.querySelector('[data-reset]').onclick = () => { Object.keys(d).forEach(k => delete d[k]); draw(); };
  m.foot.querySelector('[data-ok]').onclick = () => {
    const name = d._name || ''; delete d._name;
    UI.dna = d; UI.dnaName = name; saveUI(); m.close();
    toast('🧬 저장했어요 — 이제 AI가 이 조합대로 답해요');
    if (route.page === 'settings' || route.page === 'ai') go(route.page, route.params, true);
  };
}
function dnaWord(v, l, r) {
  if (v === 5) return '보통 (반영 안 함)';
  if (l) return (v < 5 ? l : r) + ' ' + (Math.abs(v - 5) >= 4 ? '(매우)' : Math.abs(v - 5) >= 2 ? '' : '(약간)');
  return ['전혀 안 봄', '거의 안 봄', '조금', '조금', '약간 덜', '보통', '약간 중요', '중요', '꽤 중요', '아주 중요', '가장 중요'][v];
}
