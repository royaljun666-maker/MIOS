/* ==========================================================================
   charts.js — 가벼운 SVG 차트 (외부 라이브러리 없음)
   원칙: 2px 선 · 10% 면 · 머리선(hairline) 격자 · 끝점 링 · 호버 십자선+툴팁
   ========================================================================== */
'use strict';

function _reduceMotion() { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } }

/* ---------- 툴팁 ---------- */
function showTip(html, x, y) {
  const t = document.getElementById('chartTip');
  t.innerHTML = html; t.style.left = '0px'; t.style.top = '0px'; t.classList.add('on');   // 왼쪽 끝에서 재야 폭이 줄지 않음
  const W = window.innerWidth, H = window.innerHeight, w = t.offsetWidth, h = t.offsetHeight;
  let left = x + 14, top = y - h - 12;
  if (left + w > W - 8) left = x - w - 14;
  if (left < 8) left = Math.min(Math.max(8, x - w / 2), W - w - 8);   // 양쪽 다 모자라면 손가락 위치 기준 가운데
  if (top < 8) top = y + 16;
  if (top + h > H - 8) top = Math.max(8, H - h - 8);
  t.style.left = Math.max(8, left) + 'px'; t.style.top = top + 'px';
}
function hideTip() { document.getElementById('chartTip').classList.remove('on'); }
function tipText(s) { return esc(s).replace(/\n/g, '<br>'); }
function bindTips(root) {
  if (!root || root._tips) return; root._tips = true;
  root.addEventListener('pointermove', e => {
    const t = e.target.closest && e.target.closest('[data-tip]');
    if (t && root.contains(t)) showTip(tipText(t.getAttribute('data-tip')), e.clientX, e.clientY); else if (!root._lineHover) hideTip();
  });
  root.addEventListener('pointerleave', hideTip);
}

/* ---------- 눈금 ---------- */
function niceNum(x) {
  const e = Math.floor(Math.log10(x)), f = x / Math.pow(10, e);
  const n = f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10;
  return n * Math.pow(10, e);
}
function niceTicks(min, max, count) {
  if (!(max > min)) return [min];
  const step = niceNum((max - min) / Math.max(1, count - 1));
  const out = [];
  for (let v = Math.ceil(min / step) * step; v <= max + step * 1e-6; v += step) out.push(+v.toFixed(10));
  return out;
}

/* ---------- 미니 추세선 ---------- */
function sparkline(vals, o) {
  o = o || {};
  vals = (vals || []).filter(v => v != null && isFinite(v));
  const w = o.w || 120, h = o.h || 32;
  if (vals.length < 2) return '<svg viewBox="0 0 ' + w + ' ' + h + '" width="100%" height="' + h + '"></svg>';
  const up = vals[vals.length - 1] >= vals[0];
  const color = o.color || (up ? 'var(--up)' : 'var(--down)');
  let min = Math.min.apply(null, vals), max = Math.max.apply(null, vals);
  if (max === min) { max += 1; min -= 1; }
  const n = vals.length;
  const pts = vals.map((v, i) => [(i / (n - 1)) * w, 2 + (h - 4) * (1 - (v - min) / (max - min))]);
  const line = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ',' + p[1].toFixed(1)).join('');
  const area = line + 'L' + w + ',' + h + 'L0,' + h + 'Z';
  return '<svg viewBox="0 0 ' + w + ' ' + h + '" preserveAspectRatio="none" width="100%" height="' + h + '" aria-hidden="true">' +
    '<path d="' + area + '" fill="' + color + '" fill-opacity=".1" stroke="none"/>' +
    '<path pathLength="1" d="' + line + '" fill="none" stroke="' + color + '" stroke-width="1.75" vector-effect="non-scaling-stroke" stroke-linejoin="round" stroke-linecap="round"/></svg>';
}

/* ---------- 선 차트 ---------- */
// pts: [[x(초 또는 순번), y], ...]
// o: { height, color, ref:{value,label}, fmtV(v), fmtX(x), tip(p,i,pts) }
function lineChart(el, pts, o) {
  el._chart = { pts: pts || [], o: Object.assign({ height: 220, yTicks: 4 }, o || {}) };
  drawLine(el);
  if (!el._ro && window.ResizeObserver) {
    let lastW = el.clientWidth;
    el._ro = new ResizeObserver(debounce(() => { if (el._chart && Math.abs(el.clientWidth - lastW) > 4) { lastW = el.clientWidth; drawLine(el); } }, 60));
    el._ro.observe(el);
  }
}
function drawLine(el) {
  const pts = el._chart.pts, o = el._chart.o;
  const W = Math.max(240, Math.round(el.clientWidth || 600)), H = o.height;
  if (!pts || pts.length < 2) { el.innerHTML = '<div class="chart-msg" style="height:' + H + 'px">' + (o.empty || '표시할 데이터가 아직 없어요') + '</div>'; return; }
  const padL = 2, padR = o.yAxis === false ? 6 : 62, padT = 16, padB = o.xAxis === false ? 8 : 28;
  const vals = pts.map(p => p[1]);
  let min = Math.min.apply(null, vals), max = Math.max.apply(null, vals);
  const ref = o.ref && isFinite(o.ref.value) && o.ref.value > 0 ? o.ref : null;
  if (ref) { min = Math.min(min, ref.value); max = Math.max(max, ref.value); }
  if (max === min) { max += Math.abs(max) * 0.01 || 1; min -= Math.abs(min) * 0.01 || 1; }
  const pad = (max - min) * 0.1; min -= pad; max += pad;
  const n = pts.length, pw = W - padL - padR, ph = H - padT - padB;
  const X = i => padL + pw * (i / (n - 1));
  const Y = v => padT + ph * (1 - (v - min) / (max - min));
  const up = vals[n - 1] >= vals[0];
  const color = o.color || (up ? 'var(--up)' : 'var(--down)');
  const fmtV = o.fmtV || (v => nf(v));
  let s = '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" width="100%" height="' + H + '" role="img" aria-label="' + esc(o.label || '추이 그래프') + '">';
  // 격자 + y축 글자(오른쪽)
  if (o.yAxis !== false) {
    niceTicks(min, max, o.yTicks).forEach(t => {
      const y = Y(t); if (y < padT - 2 || y > H - padB + 2) return;
      s += '<line x1="' + padL + '" x2="' + (W - padR) + '" y1="' + y.toFixed(1) + '" y2="' + y.toFixed(1) + '" stroke="var(--grid)" stroke-width="1"/>';
      s += '<text x="' + (W - padR + 10) + '" y="' + (y + 4).toFixed(1) + '">' + esc(o.fmtAxis ? o.fmtAxis(t) : fmtV(t)) + '</text>';
    });
  }
  // x축 글자
  if (o.xAxis !== false && o.fmtX) {
    const k = Math.min(4, n);
    for (let j = 0; j < k; j++) {
      const i = Math.round(j * (n - 1) / (k - 1 || 1));
      const anchor = j === 0 ? 'start' : j === k - 1 ? 'end' : 'middle';
      s += '<text x="' + X(i).toFixed(1) + '" y="' + (H - 8) + '" text-anchor="' + anchor + '">' + esc(o.fmtX(pts[i][0], i)) + '</text>';
    }
  }
  // 면 + 선
  const line = pts.map((p, i) => (i ? 'L' : 'M') + X(i).toFixed(1) + ',' + Y(p[1]).toFixed(1)).join('');
  const anim = o.animate !== false && !_reduceMotion();
  s += '<path class="' + (anim ? 'ch-area' : '') + '" d="' + line + 'L' + X(n - 1).toFixed(1) + ',' + (H - padB) + 'L' + X(0).toFixed(1) + ',' + (H - padB) + 'Z" fill="' + color + '" fill-opacity=".1"/>';
  s += '<path class="' + (anim ? 'ch-line' : '') + '" pathLength="1" d="' + line + '" fill="none" stroke="' + color + '" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>';
  // 기준선(내 평단 등) — 문턱값이라 점선
  if (ref) {
    const y = Y(ref.value).toFixed(1);
    s += '<line x1="' + padL + '" x2="' + (W - padR) + '" y1="' + y + '" y2="' + y + '" stroke="var(--text-3)" stroke-width="1" stroke-dasharray="4 4"/>';
    s += '<text x="' + (padL + 4) + '" y="' + (y - 6) + '" style="fill:var(--text-2)" paint-order="stroke" stroke="var(--surface)" stroke-width="4">' + esc(ref.label || '') + '</text>';
  }
  // 크게 움직인 날 표시 (눌러서 그날 뉴스 보기)
  (o.marks || []).forEach(m => {
    if (!(m.i >= 0 && m.i < n)) return;
    s += '<circle class="ch-mark" cx="' + X(m.i).toFixed(1) + '" cy="' + Y(vals[m.i]).toFixed(1) + '" r="4" fill="var(--surface)" stroke="' + (m.up ? 'var(--up)' : 'var(--down)') + '" stroke-width="2.2"/>';
  });
  // 끝점
  s += '<circle cx="' + X(n - 1).toFixed(1) + '" cy="' + Y(vals[n - 1]).toFixed(1) + '" r="4.5" fill="' + color + '" stroke="var(--surface)" stroke-width="2"/>';
  // 호버 레이어
  s += '<line class="xh" y1="' + padT + '" y2="' + (H - padB) + '" stroke="var(--text-4)" stroke-width="1" visibility="hidden"/>';
  s += '<circle class="hd" r="5" fill="' + color + '" stroke="var(--surface)" stroke-width="2" visibility="hidden"/>';
  s += '<rect class="hit" x="0" y="0" width="' + W + '" height="' + H + '" fill="transparent"/>';
  s += '</svg>';
  el.innerHTML = s;
  const svg = el.querySelector('svg'), xh = svg.querySelector('.xh'), hd = svg.querySelector('.hd');
  const move = e => {
    const r = svg.getBoundingClientRect();
    const px = (e.clientX - r.left) * (W / r.width);
    const i = Math.max(0, Math.min(n - 1, Math.round((px - padL) / pw * (n - 1))));
    const x = X(i), y = Y(pts[i][1]);
    xh.setAttribute('x1', x); xh.setAttribute('x2', x); xh.setAttribute('visibility', 'visible');
    hd.setAttribute('cx', x); hd.setAttribute('cy', y); hd.setAttribute('visibility', 'visible');
    const html = o.tip ? o.tip(pts[i], i, pts) : (o.fmtX ? '<span class="d">' + esc(o.fmtX(pts[i][0], i)) + '</span><br>' : '') + esc(fmtV(pts[i][1]));
    showTip(html, e.clientX, r.top + y * (r.height / H));
  };
  svg.addEventListener('pointermove', move);
  svg.addEventListener('pointerdown', move);
  if (o.onPick) {                                  // 날짜를 누르면 (v2.18 — 그날 뉴스)
    svg.style.cursor = 'pointer';
    svg.addEventListener('click', e => {
      const r = svg.getBoundingClientRect(), px = (e.clientX - r.left) * (W / r.width);
      const i = Math.max(0, Math.min(n - 1, Math.round((px - padL) / pw * (n - 1))));
      hideTip(); o.onPick(pts[i], i, pts);
    });
  }
  svg.addEventListener('pointerleave', () => { xh.setAttribute('visibility', 'hidden'); hd.setAttribute('visibility', 'hidden'); hideTip(); });
}

/* ---------- 도넛 ---------- */
// segs: [{label, value, color, amt}]  (최대 7 + 기타)
function donut(segs, o) {
  o = o || {};
  const S = o.size || 176, T = o.thick || 24, r = (S - T) / 2, C = 2 * Math.PI * r;
  const total = segs.reduce((s, x) => s + Math.max(0, x.value), 0);
  let s = '<svg viewBox="0 0 ' + S + ' ' + S + '" width="' + S + '" height="' + S + '" role="img" aria-label="' + esc(o.label || '비중 도넛') + '">';
  s += '<circle cx="' + S / 2 + '" cy="' + S / 2 + '" r="' + r + '" fill="none" stroke="var(--surface-3)" stroke-width="' + T + '"/>';
  if (total > 0) {
    const live = segs.filter(x => x.value > 0);
    const gap = live.length > 1 ? 2 : 0;
    let acc = 0;
    live.forEach(x => {
      const frac = x.value / total, len = Math.max(0.5, C * frac - gap);
      const tip = x.label + '  ' + (frac * 100).toFixed(1) + '%' + (x.amt ? '\n' + x.amt : '');
      s += '<circle cx="' + S / 2 + '" cy="' + S / 2 + '" r="' + r + '" fill="none" stroke="' + x.color + '" stroke-width="' + T + '"' +
        ' stroke-dasharray="' + len.toFixed(2) + ' ' + (C - len).toFixed(2) + '" stroke-dashoffset="' + (-acc).toFixed(2) + '"' +
        ' transform="rotate(-90 ' + S / 2 + ' ' + S / 2 + ')" data-tip="' + esc(tip) + '" style="cursor:default"/>';
      acc += C * frac;
    });
  }
  s += '</svg>';
  return '<div class="donut-wrap" style="width:' + S + 'px;height:' + S + 'px">' + s + '<div class="donut-center">' + (o.center || '') + '</div></div>';
}
// 범례(항상 이름+비율 표시 → 색만으로 구분하지 않음)
function legendHtml(segs, total, showAmt) {
  return '<div class="legend">' + segs.map(x => {
    const p = total > 0 ? x.value / total * 100 : 0;
    return '<div class="lg" data-tip="' + esc(x.label + '  ' + p.toFixed(1) + '%' + (x.amt ? '\n' + x.amt : '')) + '"><span class="sw" style="background:' + x.color + '"></span><span class="n">' + esc(x.label) + '</span>' +
      (showAmt && x.amt ? '<span class="a tnum">' + esc(x.amt) + '</span>' : '') + '<span class="p tnum">' + p.toFixed(1) + '%</span></div>';
  }).join('') + '</div>';
}
// 7개 넘으면 '기타'로 묶기
function foldSegs(segs, max) {
  max = max || 7;
  const sorted = segs.slice().sort((a, b) => b.value - a.value);
  if (sorted.length <= max) return sorted;
  const head = sorted.slice(0, max - 1), tail = sorted.slice(max - 1);
  const v = tail.reduce((s, x) => s + x.value, 0);
  head.push({ label: '기타 ' + tail.length + '개', value: v, color: 'var(--text-3)', amt: won(v) });
  return head;
}

/* ---------- 비중 막대 ---------- */
function stackBar(segs, total) {
  total = total || segs.reduce((s, x) => s + x.value, 0);
  if (!(total > 0)) return '<div class="stackbar"><i style="width:100%;background:var(--surface-3)"></i></div>';
  return '<div class="stackbar">' + segs.filter(x => x.value > 0).map(x => {
    const p = x.value / total * 100;
    return '<i style="width:' + p.toFixed(3) + '%;background:' + x.color + '" data-tip="' + esc(x.label + '  ' + p.toFixed(1) + '%' + (x.amt ? '\n' + x.amt : '')) + '"></i>';
  }).join('') + '</div>';
}

/* ---------- 공포·탐욕 게이지 ---------- */
const FG_ZONES = [
  { to: 25, label: '극단적 공포', color: '#2a78d6' },
  { to: 45, label: '공포', color: '#86b6ef' },
  { to: 55, label: '중립', color: '#b7bcc4' },
  { to: 75, label: '탐욕', color: '#f0a07c' },
  { to: 100, label: '극단적 탐욕', color: '#e34948' },
];
function fgZone(v) { return FG_ZONES.find(z => v <= z.to) || FG_ZONES[4]; }
function gauge(score, o) {
  o = o || {};
  const W = o.w || 200, H = W / 2 + 18, cx = W / 2, cy = W / 2 + 4, R = W / 2 - 14, T = 16;
  const ang = v => Math.PI * (1 - v / 100);
  const pt = (v, rr) => [cx + rr * Math.cos(ang(v)), cy - rr * Math.sin(ang(v))];
  let s = '<svg viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H + '" role="img" aria-label="공포 탐욕 지수 ' + score + '">';
  let from = 0;
  FG_ZONES.forEach(z => {
    const a = pt(from + 0.8, R), b = pt(z.to - 0.8, R);
    s += '<path d="M' + a[0].toFixed(1) + ',' + a[1].toFixed(1) + ' A' + R + ',' + R + ' 0 0 1 ' + b[0].toFixed(1) + ',' + b[1].toFixed(1) + '" fill="none" stroke="' + z.color + '" stroke-width="' + T + '" data-tip="' + esc(z.label + ' (' + from + '~' + z.to + ')') + '"/>';
    from = z.to;
  });
  if (score != null) {
    const tip = pt(score, R - T / 2 - 6);
    s += '<line class="g-needle" style="--r:' + (-(score / 100) * 180).toFixed(1) + 'deg;transform-origin:' + cx + 'px ' + cy + 'px" x1="' + cx + '" y1="' + cy + '" x2="' + tip[0].toFixed(1) + '" y2="' + tip[1].toFixed(1) + '" stroke="var(--text)" stroke-width="3" stroke-linecap="round"/>';
    s += '<circle cx="' + cx + '" cy="' + cy + '" r="6" fill="var(--text)" stroke="var(--surface)" stroke-width="2"/>';
  }
  return s + '</svg>';
}
