/* ==========================================================================
   flash.js — 📰 속보 (v2.20)
   최근 하루 속보·시장 뉴스를 트위터 카드처럼. 중요 속보는 색으로, 누르면 원래 기사로.
   ========================================================================== */
'use strict';

const FL = { data: null, busy: false, filter: 'all', timer: null };
const FL_LV = { red: ['🔴', '긴급'], orange: ['🟠', '중요'], normal: ['', ''] };
function flMine() {                                        // 내 종목·관심종목 이름 (카드에 '내 종목' 표시)
  const n = new Set();
  allHoldings().forEach(x => { const s = dispName(x.h); if (s && s.length >= 2) n.add(s); });
  watchlist().forEach(w => { const s = dispName(w); if (s && s.length >= 2) n.add(s); });
  return [...n];
}
function flCard(it, mine) {
  const hit = mine.find(n => it.title.includes(n));
  const lv = FL_LV[it.level] || FL_LV.normal, src = it.src || '뉴스';
  const hue = [...src].reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
  return '<a class="fl-card ' + it.level + (hit ? ' mine' : '') + '" href="' + esc(safeUrl(it.url)) + '" target="_blank" rel="noopener">' +
    '<div class="fl-av" style="background:hsl(' + hue + ',55%,48%)">' + esc(src.slice(0, 1)) + '</div>' +
    '<div class="fl-main"><div class="fl-top"><b>' + esc(src) + '</b><span>· ' + (it.ts ? esc(ago(it.ts * 1000)) : '') + '</span>' +
      (lv[1] ? '<i class="fl-tag ' + it.level + '">' + lv[0] + ' ' + lv[1] + '</i>' : '') + (hit ? '<i class="fl-tag mine">⭐ ' + esc(hit) + '</i>' : '') + '</div>' +
      '<div class="fl-title">' + esc(it.title) + '</div>' +
      '<div class="fl-foot">' + icon('link', 'ic-sm') + '<span>원문 기사 보기</span>' + (it.lang === 'en' ? '<span class="fl-en">해외</span>' : '') + '</div></div></a>';
}
function flLoad(fresh) {
  if (FL.busy) return;
  FL.busy = true;
  api('/api/flash' + (fresh ? '?fresh=1' : ''), { timeout: 30000 })
    .then(d => { if (d && d.ok) FL.data = d; })
    .catch(() => { if (!FL.data) FL.data = { err: 1, items: [] }; })
    .finally(() => { FL.busy = false; if (route.page === 'news') PAGES.news(null, true); });
}
PAGES.news = function (params, isRe) {
  const el = pageEl('news');
  const d = FL.data, mine = flMine();
  let items = (d && d.items) || [];
  const cnt = { red: items.filter(x => x.level === 'red').length, imp: items.filter(x => x.level !== 'normal').length, mine: items.filter(x => mine.some(n => x.title.includes(n))).length };
  if (FL.filter === 'imp') items = items.filter(x => x.level !== 'normal');
  if (FL.filter === 'mine') items = items.filter(x => mine.some(n => x.title.includes(n)));
  const chips = [['all', '전체 ' + ((d && d.items) || []).length], ['imp', '🔴🟠 중요 ' + cnt.imp], ['mine', '⭐ 내 종목 ' + cnt.mine]]
    .map(([k, l]) => '<button class="chip' + (FL.filter === k ? ' on' : '') + '" data-fl="' + k + '">' + l + '</button>').join('');
  el.innerHTML = '<div class="page-head"><div><h1>📰 속보</h1><div class="desc">최근 하루 증시·경제 속보 · 누르면 원래 기사로 가요' + (d && d.at ? ' · ' + esc(ago(d.at * 1000)) + ' 확인' : '') + '</div></div>' +
      '<div class="actions"><button class="btn btn-outline" id="flRe">' + icon('refresh', 'ic-sm') + '새로고침</button></div></div>' +
    '<div class="chips fl-chips" id="flF">' + chips + '</div>' +
    (cnt.red ? '<div class="fl-alert">🔴 긴급 속보 ' + cnt.red + '건 — 맨 위 빨간 카드부터 확인하세요</div>' : '') +
    '<div class="fl-list">' + (!d ? '<div class="ai-loading" style="padding:40px 10px"><div class="orb"></div><div>속보를 모으는 중이에요…</div></div>'
      : d.err ? '<p class="note">' + SERVER_DOWN + '</p>'
      : items.length ? items.map(x => flCard(x, mine)).join('') : '<p class="note" style="padding:20px 4px">' + (FL.filter === 'mine' ? '내 종목·관심종목 이름이 들어간 속보가 아직 없어요.' : '표시할 속보가 없어요.') + '</p>') + '</div>' +
    '<p class="note" style="margin:12px 2px 0">🔴 긴급(속보·폭락·전쟁 등) · 🟠 중요(단독·급등락·금리·환율 등)는 제목의 단어로 자동 표시돼요. 구글 뉴스에서 모아요.</p>';
  hydrateIcons(el);
  el.querySelector('#flF').onclick = e => { const b = e.target.closest('[data-fl]'); if (b) { FL.filter = b.dataset.fl; PAGES.news(null, true); } };
  el.querySelector('#flRe').onclick = () => { FL.data = null; PAGES.news(null, true); flLoad(true); };
  if (!isRe && !FL.busy && (!d || Date.now() / 1000 - d.at > 90)) flLoad(false);
  clearInterval(FL.timer);                                   // 이 화면에 있는 동안 2분마다 새로
  FL.timer = setInterval(() => { if (route.page !== 'news') { clearInterval(FL.timer); return; } flLoad(false); }, 120000);
};
