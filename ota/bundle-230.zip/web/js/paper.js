/* ==========================================================================
   paper.js — 🎮 포인트 모의투자 (v2.21)
   게임·출석으로 모은 포인트(1P = 1원)로 관심종목·AI 추천 종목을 사고팔아 보기.
   실제 돈·실제 주문과는 아무 관계 없음. 포인트는 현금으로 바꿀 수 없음.
   ========================================================================== */
'use strict';

const PAPER_FEE = 0.00015;                                 // 수수료 흉내 (0.015%)
function PP() {
  const s = S.settings;
  if (!s.paper || typeof s.paper !== 'object') s.paper = { pos: [], hist: [], realized: 0 };
  return s.paper;
}
function paperRate(ccy) { return ccy === 'USD' ? fx() : 1; }
function paperCur(t) {                                      // 앱이 아는 현재가 (관심·보유)
  const T = String(t || '').toUpperCase();
  const w = watchlist().find(x => String(x.ticker || '').toUpperCase() === T), h = allHoldings().find(x => String(x.h.ticker || '').toUpperCase() === T);
  return num((w && w.cur) || (h && h.h.cur) || 0);
}
function paperValue() {
  let v = 0, cost = 0;
  PP().pos.forEach(p => { const c = paperCur(p.t) || p.avg; v += c * p.qty * paperRate(p.ccy); cost += p.avg * p.qty * paperRate(p.ccy); });
  return { v, cost, pl: v - cost };
}
async function openPaperTrade(it) {
  const x = { t: String(it.ticker || '').toUpperCase(), n: it.name || it.ticker, mkt: it.market || (/^[A-Za-z]/.test(it.ticker || '') ? 'us' : 'kr') };
  x.ccy = it.ccy || (x.mkt === 'us' ? 'USD' : 'KRW');
  let cur = num(it.cur) || paperCur(x.t);
  const m = openModal({ title: '🎮 모의투자 · ' + esc(x.n), body: '<div class="ai-loading" style="padding:20px"><div class="orb"></div><div>현재가 확인 중…</div></div>' });
  try { const d = await api('/price?ticker=' + encodeURIComponent(x.t) + '&market=' + x.mkt, { timeout: 20000 }); if (d && d.price > 0) cur = d.price; } catch (e) {}
  if (m.closed) return;
  if (!(cur > 0)) { m.setBody('<p class="note">현재가를 받지 못해 모의투자를 할 수 없어요. 잠시 후 다시 해 주세요.</p>'); return; }
  const rate = paperRate(x.ccy);
  const draw = () => {
    const g = G(), pos = PP().pos.find(p => p.t === x.t), maxQ = Math.floor(g.pts / (cur * rate * (1 + PAPER_FEE)));
    const pl = pos ? (cur - pos.avg) * pos.qty * rate : 0;
    m.setBody('<div class="pp-head"><div><span>현재가</span><b>' + esc(priceTxt(cur, x.ccy)) + '</b>' + (rate > 1 ? '<em>1주 = ' + nf(Math.round(cur * rate), 0) + 'P</em>' : '') + '</div>' +
        '<div><span>내 포인트</span><b>💎 ' + nf(g.pts, 0) + 'P</b></div></div>' +
      (pos ? '<div class="pp-pos"><b>보유 ' + nf(pos.qty, 0) + '주 · 평균 ' + esc(priceTxt(pos.avg, x.ccy)) + '</b><span class="' + cls(pl) + '">' + (pl >= 0 ? '+' : '') + nf(Math.round(pl), 0) + 'P (' + pct((cur / pos.avg - 1) * 100) + ')</span></div>' : '') +
      '<div class="field" style="margin-top:12px"><label>수량 (주)</label><input class="input tnum lg" id="ppQ" inputmode="numeric" value="' + (pos ? '' : Math.min(1, maxQ) || '') + '" placeholder="몇 주?"></div>' +
      '<div class="chips" id="ppQuick">' + [['10%', .1], ['25%', .25], ['50%', .5], ['최대', 1]].map(([l, r]) => '<button class="chip" data-r="' + r + '">살 수 있는 ' + l + '</button>').join('') +
        (pos ? '<button class="chip" data-all>보유 전부</button>' : '') + '</div>' +
      '<div class="pp-sum" id="ppSum"></div>' +
      '<div class="row-btns" style="margin-top:12px"><button class="btn btn-primary btn-lg" style="flex:1" id="ppBuy">사기</button><button class="btn btn-outline btn-lg" style="flex:1" id="ppSell"' + (pos ? '' : ' disabled') + '>팔기</button></div>' +
      '<p class="note" style="margin-top:10px">게임·출석 포인트로 하는 <b>연습용 모의투자</b>예요 (1P = 1원). 실제 주문이 아니고, 포인트는 현금으로 바꿀 수 없어요. 시세는 15~20분 늦을 수 있어요.</p>');
    const q = m.body.querySelector('#ppQ'), sum = m.body.querySelector('#ppSum');
    const upd = () => { const n = Math.floor(num(q.value)); sum.textContent = n > 0 ? n + '주 ≈ ' + nf(Math.round(n * cur * rate), 0) + 'P (수수료 ' + nf(Math.ceil(n * cur * rate * PAPER_FEE), 0) + 'P)' : '살 수 있는 수량: 최대 ' + nf(maxQ, 0) + '주'; };
    q.oninput = upd; upd();
    m.body.querySelector('#ppQuick').onclick = e => { const b = e.target.closest('[data-r],[data-all]'); if (!b) return; q.value = b.dataset.all != null ? pos.qty : Math.max(0, Math.floor(maxQ * +b.dataset.r)); upd(); };
    m.body.querySelector('#ppBuy').onclick = () => {
      const n = Math.floor(num(q.value)), cost = Math.ceil(n * cur * rate * (1 + PAPER_FEE));
      if (!(n > 0)) { toast('수량을 넣어 주세요'); return; }
      if (cost > G().pts) { toast('포인트가 모자라요 — 게임 탭에서 출석 보너스를 받아 보세요'); return; }
      G().pts -= cost;
      const P = PP(); let p = P.pos.find(y => y.t === x.t);
      if (p) { p.avg = (p.avg * p.qty + cur * n) / (p.qty + n); p.qty += n; } else P.pos.push(p = { t: x.t, n: x.n, mkt: x.mkt, ccy: x.ccy, qty: n, avg: cur, at: Date.now() });
      P.hist.unshift({ k: 'buy', t: x.t, n: x.n, q: n, p: cur, ccy: x.ccy, at: Date.now() }); P.hist = P.hist.slice(0, 100);
      if (!inWatch(x.t, x.ccy)) watchlist().push({ ticker: x.t, name: x.n, market: x.mkt, ccy: x.ccy, cur, at: Date.now() });
      save(); toast('🎮 ' + x.n + ' ' + n + '주 모의 매수 (-' + nf(cost, 0) + 'P)'); draw(); paperRerender();
    };
    m.body.querySelector('#ppSell').onclick = () => {
      const P = PP(), p = P.pos.find(y => y.t === x.t); if (!p) return;
      const n = Math.min(p.qty, Math.floor(num(q.value)) || 0); if (!(n > 0)) { toast('팔 수량을 넣어 주세요'); return; }
      const get = Math.floor(n * cur * rate * (1 - PAPER_FEE)), gain = Math.round((cur - p.avg) * n * rate);
      G().pts += get; P.realized += gain; p.qty -= n; if (p.qty <= 0) P.pos = P.pos.filter(y => y !== p);
      P.hist.unshift({ k: 'sell', t: x.t, n: x.n, q: n, p: cur, ccy: x.ccy, gain, at: Date.now() }); P.hist = P.hist.slice(0, 100);
      save(); toast((gain >= 0 ? '🎉 ' : '') + x.n + ' ' + n + '주 모의 매도 (' + (gain >= 0 ? '+' : '') + nf(gain, 0) + 'P)'); draw(); paperRerender();
    };
  };
  draw();
}
function paperRerender() { if (route.page === 'watch') PAGES.watch({}, true); }
function paperCardHtml() {
  if (!feat('paper')) return '';
  const P = PP(), V = paperValue(), g = G(), w = watchlist();
  const rows = P.pos.map(p => {
    const c = paperCur(p.t) || p.avg, pl = (c - p.avg) * p.qty * paperRate(p.ccy);
    return '<button class="pp-row" data-act="paper" data-p="' + esc(JSON.stringify({ ticker: p.t, name: p.n, market: p.mkt, ccy: p.ccy })) + '"><div class="mid"><b>' + esc(p.n) + '</b><span>' + nf(p.qty, 0) + '주 · 평균 ' + esc(priceTxt(p.avg, p.ccy)) + ' → ' + esc(priceTxt(c, p.ccy)) + '</span></div>' +
      '<b class="' + cls(pl) + '">' + (pl >= 0 ? '+' : '') + nf(Math.round(pl), 0) + 'P<br><small>' + pct((c / p.avg - 1) * 100) + '</small></b></button>';
  }).join('');
  return '<div class="card pp-card" style="margin-bottom:16px"><div class="card-head"><h3>🎮 포인트 모의투자</h3><span class="muted" style="font-size:.78rem">1P = 1원 · 연습용</span></div>' +
    '<div class="pp-kpi"><div><span>남은 포인트</span><b>💎 ' + nf(g.pts, 0) + '</b></div><div><span>모의 주식 평가</span><b>' + nf(Math.round(V.v), 0) + '</b></div>' +
      '<div><span>평가 손익</span><b class="' + cls(V.pl) + '">' + (V.pl >= 0 ? '+' : '') + nf(Math.round(V.pl), 0) + '</b></div><div><span>실현 손익</span><b class="' + cls(P.realized) + '">' + (P.realized >= 0 ? '+' : '') + nf(Math.round(P.realized), 0) + '</b></div></div>' +
    (rows ? '<div class="pp-list">' + rows + '</div>' : '<p class="note" style="margin:6px 0">아직 모의로 산 종목이 없어요. 아래 관심종목을 눌러 포인트로 사 보세요.</p>') +
    (w.length ? '<div class="ah-sub">관심종목으로 모의투자</div><div class="chips">' + w.slice(0, 16).map(x => '<button class="chip" data-act="paper" data-p="' + esc(JSON.stringify({ ticker: x.ticker, name: dispName(x), market: x.market, ccy: x.ccy, cur: x.cur })) + '">🎮 ' + esc(dispName(x)) + '</button>').join('') + '</div>' : '') +
    (g.pts < 10000 ? '<p class="note" style="margin:8px 0 0">포인트가 부족하면 <a class="lnk" data-nav="game">게임 탭</a>에서 매일 출석 보너스를 받으세요.</p>' : '') + '</div>';
}

// 관심종목 카드에 '포인트로 산 것' 표시 — 실제 보유와 헷갈리지 않게
function paperBadge(t) {
  if (!feat('paper')) return '';
  const p = PP().pos.find(x => x.t === String(t || '').toUpperCase());
  return p ? '<em class="pp-badge">🎮 모의 보유 ' + nf(p.qty, 0) + '주 · 포인트</em>' : '';
}
