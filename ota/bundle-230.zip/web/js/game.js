/* ==========================================================================
   game.js — 🚀 크래시 게임 (재미용 포인트 · 현금/상품 교환 없음)
   · 하루 1회 접속 보너스 100,000P · 한 판 10,000~100,000P · 하루 100판
   · 1.01배(+1%)부터 주가 차트처럼 출렁이며 지수함수로 상승, 상한 없이 1000배까지 (닿으면 자동 수령)
   · 폭발 지점: 1배대 60% · 2배대 28% · 3배대 8% · 그 뒤로 점점 작게 (화면에 실제 확률 그대로 표시)
   · 폭발·수령은 화면에 보이는(출렁이는) 배율이 그 값에 처음 닿는 순간 기준
   ========================================================================== */
'use strict';

const GAME = { MIN: 10000, MAX: 100000, STEP: 10000, DAILY: 1000000, PLAYS: 100, CAP: 1000, START: 1.01, RATE: Math.log(11 / 1.01) / 30, WIN_LIMIT: 100000000,
  ODDS: [[1, 1], [2, .40], [3, .12], [4, .04]], TAIL: 1.5 };   // 11배까지 약 30초. 상한 사실상 없음(1000배)
/* 폭발 분포: [배율, 그 배율 이상 갈 확률]. 구간 사이는 부드럽게 이어 붙이고, 4배 뒤로는 점점 작아짐(x^-TAIL)
   → 1배대(+0~99%)에서 폭발 60% · 2배대 28% · 3배대 8% · 4배 이상 4% (10배 이상 약 1%, 100배 이상 약 0.03%) */
function reachProb(x) {                                          // x배 이상 갈 확률
  const O = GAME.ODDS; if (x <= 1) return 1;
  for (let i = 1; i < O.length; i++) {
    const [a, sa] = O[i - 1], [b, sb] = O[i];
    if (x <= b) return sa * Math.pow(x / a, Math.log(sb / sa) / Math.log(b / a));
  }
  const [a, sa] = O[O.length - 1]; return sa * Math.pow(x / a, -GAME.TAIL);
}
const ret = x => '+' + Math.floor((x - 1) * 100 + 1e-9) + '%';                 // 배율 → 수익률 표시 (2.87 → +187%)

function G() {
  const s = S.settings;
  if (!s.game || typeof s.game !== 'object') s.game = { pts: 0, day: '', plays: 0, bonusDay: '', hist: [], best: 0, todayNet: 0, bet: 20000, auto: 0 };
  return s.game;
}
function gameDayRoll() {
  const g = G(), t = todayKey();
  if (g.day !== t) { g.day = t; g.plays = 0; g.todayNet = 0; }
}
/* 📅 출석 체크 (v2.30) — 하루 한 번 [출석] 버튼으로 100만P · 연속 출석하면 더 많이
   연속 n일째: 100만 + (n-1)×10만 (최대 10일째 190만) · 7일 +300만 · 30일 +1,000만 · 100일 +3,000만 보너스 */
const CHECKIN_MILE = { 7: 3000000, 30: 10000000, 100: 30000000 };
function checkinAmount(streak) { return GAME.DAILY + Math.min(streak - 1, 9) * 100000 + (CHECKIN_MILE[streak] || 0); }
function checkedToday() { return G().bonusDay === todayKey(); }
function checkinNextStreak() {
  const g = G(), y = todayKey(new Date(Date.now() - 86400000));
  return g.bonusDay === y ? (g.streak || 1) + 1 : 1;
}
function grantDailyBonus() {                           // 앱을 켰을 때: 자동 지급 대신 출석하라고 알려 줌
  gameDayRoll();
  if (checkedToday()) return;
  setTimeout(() => toast('📅 오늘 출석하고 ' + nf(checkinAmount(checkinNextStreak()), 0) + 'P 받으세요! (홈의 출석 버튼)', 4500), 1800);
}
function doCheckin() {
  const g = G(); gameDayRoll();
  if (checkedToday()) { toast('오늘은 이미 출석했어요 ✅ 내일 또 오세요 (연속 ' + (g.streak || 1) + '일째)'); return; }
  const st = checkinNextStreak(), amt = checkinAmount(st);
  g.streak = st; g.bestStreak = Math.max(g.bestStreak || 0, st); g.bonusDay = todayKey(); g.pts += amt; save();
  const next = checkinAmount(st + 1), mile = Object.keys(CHECKIN_MILE).map(Number).find(d => d > st);
  openModal({ title: '📅 출석 완료!', body:
    '<div class="ci-box"><div class="ci-amt">+' + nf(amt, 0) + 'P</div><div class="ci-st">🔥 연속 <b>' + st + '일</b> 출석' + (CHECKIN_MILE[st] ? ' · 🎉 ' + st + '일 달성 보너스 +' + nf(CHECKIN_MILE[st], 0) + 'P' : '') + '</div>' +
      '<div class="ci-week">' + Array.from({ length: 7 }, (_, i) => { const d = ((st - 1) % 7) + 1; return '<i class="' + (i < d ? 'on' : '') + '">' + (i + 1) + '</i>'; }).join('') + '</div>' +
      '<div class="ci-pts">내 포인트 <b>💎 ' + nf(g.pts, 0) + 'P</b></div>' +
      '<p class="note">내일 출석하면 <b>' + nf(next, 0) + 'P</b>' + (mile ? ' · ' + mile + '일 연속이면 보너스 +' + nf(CHECKIN_MILE[mile], 0) + 'P' : '') + '<br>하루라도 빠지면 연속 기록이 1일부터 다시 시작해요. 포인트는 게임·모의투자용이며 현금으로 바꿀 수 없어요.</p></div>' });
  if (typeof fxConfetti === 'function') fxConfetti(CHECKIN_MILE[st] ? 4000 : 1800);
  if (route.page && PAGES[route.page]) go(route.page, route.params, true);
}
function checkinBtnHtml(cls) {
  return checkedToday() ? '<button class="btn btn-gray ' + (cls || '') + '" data-act="checkin">✅ 출석 완료 · 연속 ' + (((S.settings.game || {}).streak) || 1) + '일</button>'
    : '<button class="btn btn-primary ' + (cls || '') + '" data-act="checkin">📅 출석하고 ' + nf(checkinAmount(checkinNextStreak()), 0) + 'P 받기</button>';
}
/* 폭발 배율: 암호학적 난수 U 로 reachProb(x) = U 인 x 를 거꾸로 구함 (판마다 완전히 독립) · 소수 둘째 자리 내림 */
function crashPoint() {
  const a = new Uint32Array(1); crypto.getRandomValues(a);
  const u = 1 - a[0] / 4294967296, O = GAME.ODDS;             // (0, 1]
  let raw = 0;
  for (let i = 1; i < O.length && !raw; i++) {
    const [a0, sa] = O[i - 1], [b, sb] = O[i];
    if (u >= sb) raw = a0 * Math.pow(u / sa, Math.log(b / a0) / Math.log(sb / sa));
  }
  if (!raw) { const [a0, sa] = O[O.length - 1]; raw = a0 * Math.pow(u / sa, -1 / GAME.TAIL); }
  if (raw < 1.02) return 1;                                  // 출발하자마자 폭발 (약 2.6%)
  return Math.min(Math.floor(raw * 100) / 100, GAME.CAP);
}
const baseAt = t => GAME.START * Math.exp(GAME.RATE * t);  // 출렁임 없는 기본 곡선
/* 이번 판의 출렁임 (주가처럼 여러 주기의 물결을 겹침) */
function makeWaves() {
  const r = () => { const a = new Uint32Array(1); crypto.getRandomValues(a); return a[0] / 4294967296; };
  return [[0.9, .024], [2.1, .018], [3.9, .011], [7.1, .006]].map(([f, a]) => ({ f: f * (.8 + r() * .4), a: a * (.7 + r() * .6), p: r() * 6.283 }));
}
function multAt(t, R) {
  R = R || RUN; const base = baseAt(t);
  if (!R || !R.waves) return base;
  let n = 0; for (const w of R.waves) n += w.a * (Math.sin(w.f * t + w.p) - Math.sin(w.p));
  return Math.max(1, base * Math.exp(n * Math.min(1, t / 2.5)));
}

/* 효과음 (배경음이 켜져 있을 때만) */
const GSFX = (function () {
  let ctx = null;
  const ok = () => { if (soundModeSafe() === 'off') return false; try { ctx = ctx || new (window.AudioContext || window.webkitAudioContext)(); if (ctx.state === 'suspended') ctx.resume(); return true; } catch (e) { return false; } };
  function tone(f, d, type, vol, slide) {
    const o = ctx.createOscillator(), g = ctx.createGain(), t = ctx.currentTime;
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t); if (slide) o.frequency.exponentialRampToValueAtTime(slide, t + d);
    g.gain.setValueAtTime(vol || .15, t); g.gain.exponentialRampToValueAtTime(.0001, t + d);
    o.connect(g); g.connect(ctx.destination); o.start(t); o.stop(t + d + .02);
  }
  function noise(d, vol, freq) {
    const b = ctx.createBuffer(1, ctx.sampleRate * d, ctx.sampleRate), x = b.getChannelData(0);
    for (let i = 0; i < x.length; i++) x[i] = (Math.random() * 2 - 1) * (1 - i / x.length);
    const s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    s.buffer = b; f.type = 'lowpass'; f.frequency.value = freq || 900; g.gain.value = vol || .5;
    s.connect(f); f.connect(g); g.connect(ctx.destination); s.start();
  }
  return {
    launch() { if (ok()) { noise(1.2, .25, 500); tone(120, 1.2, 'sawtooth', .05, 420); } },
    tick() { if (ok()) tone(880, .06, 'square', .03); },
    cash() { if (ok()) { tone(880, .12, 'sine', .18); setTimeout(() => tone(1320, .25, 'sine', .18), 110); } },
    boom() { if (ok()) { noise(1.1, .9, 700); tone(90, .8, 'sine', .4, 30); } },
  };
})();
function soundModeSafe() { try { return soundMode(); } catch (e) { return 'off'; } }

/* ── 한 판 진행 (화면을 떠나도 계속 돌아감) ─────────────────────────── */
let RUN = null;          // { phase: 'count'|'fly'|'end', bet, auto, crash, t0, cashedAt, win, startAt }
let _gTimer = null;

function gameStart() {
  const g = G(); gameDayRoll();
  if (RUN && RUN.phase !== 'end') return;
  const bet = Math.min(GAME.MAX, Math.max(GAME.MIN, Math.round((g.bet || GAME.MIN) / GAME.STEP) * GAME.STEP));
  if (g.plays >= GAME.PLAYS) { toast('오늘 ' + GAME.PLAYS + '판을 다 했어요. 내일 다시 도전해요!'); return; }
  if (g.pts < bet) { toast('포인트가 모자라요. 금액을 줄이거나 내일 출석 보너스를 받으세요'); return; }
  g.pts -= bet; g.plays += 1; g.todayNet -= bet;
  RUN = { phase: 'count', bet, auto: +g.auto || 0, crash: crashPoint(), t0: performance.now() + 3000, cashedAt: 0, cashT: 0, endT: 0, win: 0, startAt: Date.now(), waves: makeWaves() };
  g.live = { bet, auto: RUN.auto, crash: RUN.crash, at: Date.now() };   // 앱이 꺼져도 정산할 수 있게
  save({ noSync: true });
  GSFX.launch();
  clearInterval(_gTimer); _gTimer = setInterval(gameStep, 40);
  gameRenderControls();
}
function gameStep() {
  if (!RUN) return;
  const now = performance.now();
  if (RUN.phase === 'count') { if (now >= RUN.t0) { RUN.phase = 'fly'; gameRenderControls(); } else return; }   // 출발하는 순간 버튼을 '수령'으로
  if (RUN.phase !== 'fly') return;
  const t = (now - RUN.t0) / 1000, m = multAt(t);
  if (!RUN.cashedAt && RUN.auto >= 1.01 && m >= RUN.auto && RUN.auto < RUN.crash) gameCash(RUN.auto, t);
  if (m >= RUN.crash) {
    if (RUN.crash >= GAME.CAP && !RUN.cashedAt) gameCash(GAME.CAP, t);        // 1000배 도달 → 자동 수령
    RUN.endT = t;
    gameEnd();
  }
}
function gameCash(at, tt) {
  if (!RUN || RUN.phase !== 'fly' || RUN.cashedAt) return;
  const t = tt != null ? tt : (performance.now() - RUN.t0) / 1000, cur = Math.floor(multAt(t) * 100) / 100;
  at = Math.min(at || cur, RUN.crash, GAME.CAP);
  const g = G();
  RUN.cashedAt = at; RUN.cashT = t; RUN.win = Math.min(Math.floor(RUN.bet * at), GAME.WIN_LIMIT);
  g.pts += RUN.win; g.todayNet += RUN.win; if (at > (g.best || 0)) g.best = at;
  delete g.live; save({ noSync: true });
  GSFX.cash();
  gameBurst('cash');
  gameWinPop(RUN.win, at);
  gameRenderControls();
}
function gameEnd() {
  if (!RUN || RUN.phase === 'end') return;                   // 한 판은 한 번만 정산
  const g = G();
  RUN.phase = 'end'; clearInterval(_gTimer);
  g.hist = [RUN.crash].concat(g.hist || []).slice(0, 20);
  delete g.live; save();
  if (!RUN.cashedAt) GSFX.boom();
  gameBurst('boom');
  gameRenderControls(); gameRenderSide();
}
/* 앱이 꺼진 사이 끝난 판 정산: 자동 수령이 폭발보다 낮았으면 수령, 아니면 잃음 */
function gameSettleLive() {
  if (RUN && RUN.phase !== 'end') return;                    // 지금 날고 있는 판은 건드리지 않음
  const g = G(); if (!g.live) return;
  const L = g.live;
  if (L.auto >= 1.01 && L.auto < L.crash) { const w = Math.min(Math.floor(L.bet * L.auto), GAME.WIN_LIMIT); g.pts += w; g.todayNet += w; if (L.auto > (g.best || 0)) g.best = L.auto; }
  g.hist = [L.crash].concat(g.hist || []).slice(0, 20);
  delete g.live; save();
}

/* ── 화면 ─────────────────────────────────────────────────────────── */
PAGES.game = function (params, re) {
  const el = pageEl('game'), g = G(); gameDayRoll(); gameSettleLive();
  if (re && document.getElementById('gmCanvas')) { gameRenderControls(); gameRenderSide(); return; }   // 다시 그리기: 진행 화면 유지
  const autos = [[0, '끄기'], [1.2, '+20%'], [1.5, '+50%'], [2, '+100%'], [3, '+200%'], [5, '+400%']];
  el.innerHTML =
    '<div class="page-head"><div><h1>🚀 크래시</h1><div class="desc">폭발하기 전에 수령하세요! 하루 ' + GAME.PLAYS + '판 · 재미용 포인트</div></div>' +
      '<div class="actions"><button class="btn btn-outline" data-nav="lotto">🎱 로또</button></div></div>' +
    '<div class="gm-wrap">' +
      '<div class="card gm-main">' +
        '<div class="gm-stage" id="gmStage"><canvas id="gmCanvas"></canvas>' +
          '<div class="gm-mult" id="gmMult">+1%</div><div class="gm-pct" id="gmPct">1.01배</div><div class="gm-msg" id="gmMsg">금액을 정하고 출발을 눌러요</div>' +
          '<div class="gm-pts-mini" id="gmPtsMini"></div><div class="gm-flash" id="gmFlash"></div>' +
          '<button class="btn btn-lg btn-block gm-go" id="gmGo"></button></div>' +
        '<div class="gm-hist" id="gmHist"></div>' +
        '<div class="gm-ctrl">' +
          '<div class="gm-row"><b>참여 금액</b><div class="gm-bets" id="gmBets">' +
            Array.from({ length: 10 }, (_, i) => (i + 1) * GAME.STEP).map(v => '<button data-bet="' + v + '">' + (v / 10000) + '만</button>').join('') + '</div></div>' +
          '<div class="gm-row"><b>자동 수령</b><div class="seg gm-auto" id="gmAuto">' + autos.map(a => '<button data-auto="' + a[0] + '">' + a[1] + '</button>').join('') + '</div></div>' +
        '</div>' +
      '</div>' +
      '<div class="stack gm-side" id="gmSide"></div>' +
    '</div>';
  el.querySelector('#gmBets').onclick = e => { const b = e.target.closest('[data-bet]'); if (!b || (RUN && RUN.phase !== 'end')) return; G().bet = +b.dataset.bet; save({ noSync: true }); gameRenderControls(); };
  el.querySelector('#gmAuto').onclick = e => { const b = e.target.closest('[data-auto]'); if (!b || (RUN && RUN.phase !== 'end')) return; G().auto = +b.dataset.auto; save({ noSync: true }); gameRenderControls(); };
  el.querySelector('#gmGo').onclick = () => { if (RUN && RUN.phase === 'fly' && !RUN.cashedAt) gameCash(); else if (!RUN || RUN.phase === 'end') gameStart(); };
  gameRenderControls(); gameRenderSide(); gameCanvasLoop();
};
function gameRenderSide() {
  const box = document.getElementById('gmSide'); if (!box) return;
  const g = G(), left = Math.max(0, GAME.PLAYS - g.plays);
  box.innerHTML =
    '<div class="card gm-stats">' +
      '<div class="gm-pts"><span>내 포인트</span><b id="gmPts">' + nf(g.pts, 0) + 'P</b></div>' +
      '<div class="gm-grid"><div><span>오늘 남은 판</span><b>' + left + ' / ' + GAME.PLAYS + '</b></div>' +
      '<div><span>오늘 손익</span><b class="' + cls(g.todayNet) + '">' + (g.todayNet > 0 ? '+' : '') + nf(g.todayNet, 0) + 'P</b></div>' +
      '<div><span>최고 수령</span><b>' + (g.best ? ret(g.best) : '-') + '</b></div>' +
      '<div><span>연속 출석</span><b>' + (checkedToday() ? '🔥 ' + (g.streak || 1) + '일 ✅' : '오늘 아직') + '</b></div></div>' + checkinBtnHtml('btn-block ci-btn') +
      '<div class="gm-dots"><i style="width:' + (left / GAME.PLAYS * 100).toFixed(1) + '%"></i></div></div>' +
    '<div class="card"><div class="card-head"><h3>' + icon('info', 'ic-sm') + '게임 방법</h3></div>' +
      '<ol class="gm-rules"><li><b>금액</b>(1만~10만P)을 정하고 <b>출발</b>을 눌러요.</li>' +
      '<li>로켓이 오르는 동안 배율이 <b>점점 빨라지며</b> 올라가요. <b>폭발 전에 수령</b>을 누르세요.</li>' +
      '<li><b>자동 수령</b>을 정해 두면 그 배율에서 알아서 받아요. 먼저 폭발하면 참여 포인트를 잃어요.</li>' +
      '<li><b>+1%</b>에서 출발해 주가처럼 <b>출렁이며</b> 올라가요. 상한 없이 <b>+1000%</b>, <b>+10000%</b>도 갈 수 있어요(아주 드물게).</li>' +
      '<li>받는 포인트 = 참여 금액 × (1 + 수익률). 예) 1만P를 +150%에 수령 → 2만 5천P(순수익 +1만 5천P)</li></ol>' +
      '<div class="gm-odds"><b>실제 확률</b> (그 수익률 이상 날아갈 확률)<br>' + [1.5, 2, 3, 4, 11, 101].map(x => ret(x) + ' ' + (reachProb(x) * 100).toFixed(reachProb(x) < .01 ? 2 : 1) + '%').join(' · ') +
        '<br>운이 크게 작용하는 게임이에요. 포인트는 재미용이에요.</div>' +
      '<p class="note" style="margin:10px 0 0">포인트는 이 앱 안에서만 쓰는 <b>재미용</b>이에요. 현금·상품으로 바꿀 수 없고, 사고팔 수 없어요.</p></div>' + promoSlot('game');
}
function gameRenderControls() {
  const el = pageEl('game'); if (!el || !document.getElementById('gmGo')) return;
  const g = G(), go = document.getElementById('gmGo');
  el.querySelectorAll('[data-bet]').forEach(b => b.classList.toggle('on', +b.dataset.bet === g.bet));
  el.querySelectorAll('[data-auto]').forEach(b => b.classList.toggle('on', +b.dataset.auto === (+g.auto || 0)));
  const busy = RUN && RUN.phase !== 'end';
  el.querySelector('.gm-ctrl').classList.toggle('gm-busy', !!busy);
  go.className = 'btn btn-lg btn-block gm-go';
  if (!busy) {
    const done = g.plays >= GAME.PLAYS, poor = g.pts < g.bet;
    go.disabled = done || poor;
    go.innerHTML = done ? '오늘 ' + GAME.PLAYS + '판 끝! 내일 또 만나요' : poor ? '포인트가 모자라요' : '🚀 출발 (' + nf(g.bet, 0) + 'P)';
  } else if (RUN.phase === 'count') { go.disabled = true; go.innerHTML = '곧 출발해요…'; }
  else if (RUN.cashedAt) { go.disabled = true; go.classList.add('cashed'); go.innerHTML = '✅ ' + ret(RUN.cashedAt) + ' 수령 · +' + nf(RUN.win, 0) + 'P'; }
  else { go.disabled = false; go.classList.add('cash'); go.innerHTML = '💰 수령'; }
  const pts = document.getElementById('gmPts'); if (pts) pts.textContent = nf(g.pts, 0) + 'P';
  const pm = document.getElementById('gmPtsMini'); if (pm) pm.innerHTML = '💎 ' + nf(g.pts, 0) + 'P · 남은 판 ' + Math.max(0, GAME.PLAYS - g.plays);
  const h = document.getElementById('gmHist');
  if (h) h.innerHTML = (g.hist || []).slice(0, 12).map(x => '<span class="' + (x < 2 ? 'lo' : x < 5 ? 'mid' : 'hi') + '">' + ret(x) + '</span>').join('') || '<span class="none">최근 결과(폭발 지점)가 여기 쌓여요</span>';
}

/* ── 캔버스: 우주·곡선·로켓·폭발 ──────────────────────────────────── */
let _gRaf = 0, _gStars = null, _gParts = [], _gShake = 0;
function gameBurst(kind) {
  const n = kind === 'boom' ? 70 : 34;
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2, sp = (kind === 'boom' ? 3 : 2) + Math.random() * (kind === 'boom' ? 7 : 4);
    _gParts.push({ kind, x: null, y: null, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - (kind === 'cash' ? 2 : 0), life: 1,
      c: kind === 'boom' ? ['#FFB020', '#FF5A36', '#FFE08A', '#ffffff'][i % 4] : ['#FFD54A', '#FFE9A3', '#1BAF7A'][i % 3], s: 2 + Math.random() * 4 });
  }
  if (kind === 'boom') _gShake = 14;
}
function gameCanvasLoop() {
  cancelAnimationFrame(_gRaf);
  const cv = document.getElementById('gmCanvas'); if (!cv) return;
  const stage = cv.parentElement, dpr = Math.min(2, window.devicePixelRatio || 1);
  let W = 0, H = 0;
  const fit = () => { W = stage.clientWidth; H = stage.clientHeight; cv.width = W * dpr; cv.height = H * dpr; cv.style.width = W + 'px'; cv.style.height = H + 'px'; };
  fit();
  if (!_gStars) _gStars = Array.from({ length: 70 }, () => ({ x: Math.random(), y: Math.random(), z: .3 + Math.random() * .7 }));
  const ctx = cv.getContext('2d');
  const multEl = document.getElementById('gmMult'), msgEl = document.getElementById('gmMsg');
  let lastTick = 0;
  (function frame() {
    if (!cv.isConnected || route.page !== 'game') { _gRaf = 0; return; }   // 다른 화면이면 그리기 멈춤 (배터리 절약 · 판은 타이머로 계속 진행)
    if (stage.clientWidth !== W || stage.clientHeight !== H) fit();
    const now = performance.now();
    let m = 1, t = 0, phase = RUN ? RUN.phase : 'idle';
    if (RUN && phase !== 'count') { t = phase === 'end' ? RUN.endT : Math.max(0, (now - RUN.t0) / 1000); m = phase === 'end' ? RUN.crash : multAt(t); }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const sx = _gShake > 0 ? (Math.random() - .5) * _gShake : 0, sy = _gShake > 0 ? (Math.random() - .5) * _gShake : 0; _gShake *= .9; if (_gShake < .3) _gShake = 0;
    ctx.translate(sx, sy);
    // 하늘 → 우주 (배율이 클수록 깊은 우주색)
    const k = Math.min(1, Math.log10(Math.max(1, m)) / 2);
    const grd = ctx.createLinearGradient(0, 0, 0, H);
    grd.addColorStop(0, 'hsl(' + (230 + 40 * k) + ',55%,' + (16 - 9 * k) + '%)'); grd.addColorStop(1, 'hsl(' + (220 + 50 * k) + ',60%,' + (30 - 20 * k) + '%)');
    ctx.fillStyle = grd; ctx.fillRect(-20, -20, W + 40, H + 40);
    // 별 (속도 = 상승 속도)
    const spd = phase === 'fly' ? .0006 + .002 * Math.min(1, (m - 1) / 20) : .00015;
    _gStars.forEach(s => { s.x -= spd * s.z * 16; s.y += spd * s.z * 10; if (s.x < 0) s.x += 1; if (s.y > 1) s.y -= 1;
      ctx.globalAlpha = .35 + .65 * s.z; ctx.fillStyle = '#fff'; ctx.fillRect(s.x * W, s.y * H, s.z * 2, s.z * 2); });
    ctx.globalAlpha = 1;
    // 곡선 (시간축은 넉넉히, 배율축은 자동 확대)
    const pad = 28, tMax = Math.max(6, t * 1.12), mMax = Math.max(1.6, m * 1.22);
    const X = tt => pad + (W - pad * 2) * (tt / tMax), Y = mm => H - pad - (H - pad * 2) * ((mm - 1) / (mMax - 1));
    ctx.strokeStyle = 'rgba(255,255,255,.08)'; ctx.lineWidth = 1; ctx.font = '600 11px Pretendard, sans-serif'; ctx.fillStyle = 'rgba(255,255,255,.45)';
    [1.5, 2, 3, 5, 10, 20, 50, 100, 200, 500].filter(v => v <= mMax).slice(-3).forEach(v => { ctx.beginPath(); ctx.moveTo(pad, Y(v)); ctx.lineTo(W - pad, Y(v)); ctx.stroke(); ctx.fillText(ret(v), 4, Y(v) - 3); });
    let hx = X(0), hy = Y(1);
    if (RUN && phase !== 'count') {
      const g2 = ctx.createLinearGradient(0, H, W, 0); g2.addColorStop(0, '#22B8CF'); g2.addColorStop(1, phase === 'end' && !RUN.cashedAt ? '#F04452' : '#7C5CFF');
      ctx.beginPath(); const N = Math.max(40, Math.min(240, Math.round(t * 16)));
      for (let i = 0; i <= N; i++) { const tt = t * i / N, x = X(tt), y = Y(multAt(tt)); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
      ctx.lineWidth = 4; ctx.strokeStyle = g2; ctx.shadowColor = '#7C9CFF'; ctx.shadowBlur = 12; ctx.stroke(); ctx.shadowBlur = 0;
      ctx.lineTo(X(t), H - pad); ctx.lineTo(X(0), H - pad); ctx.closePath();
      const fill = ctx.createLinearGradient(0, 0, 0, H); fill.addColorStop(0, 'rgba(124,92,255,.28)'); fill.addColorStop(1, 'rgba(34,184,207,0)'); ctx.fillStyle = fill; ctx.fill();
      hx = X(t); hy = Y(m);
      if (RUN.cashedAt) { const cx = X(RUN.cashT), cy = Y(RUN.cashedAt); ctx.fillStyle = '#1BAF7A'; ctx.beginPath(); ctx.arc(cx, cy, 6, 0, 7); ctx.fill(); ctx.fillStyle = '#fff'; ctx.font = '800 12px Pretendard, sans-serif'; ctx.fillText('수령 ' + ret(RUN.cashedAt), cx + 8, cy + 4); }
    }
    // 로켓 (폭발 전) / 폭발
    if (phase !== 'end') {
      // 로켓: 기본 곡선 방향 + 흔들림 + 둥실 + 깜빡이는 불꽃 + 연기 꼬리
      const dt = .25, slope = RUN && phase === 'fly' ? Math.atan2(Y(baseAt(t)) - Y(baseAt(Math.max(0, t - dt))), X(t) - X(Math.max(0, t - dt))) : -Math.PI / 4;
      const wob = Math.sin(now / 110) * .13 + Math.sin(now / 47) * .05, bob = Math.sin(now / 90) * 3;
      if (phase === 'fly' && Math.random() < .8) _gParts.push({ kind: 'smoke', x: hx - 10, y: hy + 10, vx: -1 - Math.random(), vy: .6 + Math.random() * .6, life: .8, c: 'rgba(200,210,255,.5)', s: 3 + Math.random() * 3 });
      ctx.save(); ctx.translate(hx, hy + bob - (phase === 'count' ? 4 + Math.sin(now / 40) * 2 : 0)); ctx.rotate(slope + Math.PI / 4 + wob);
      const fl = 14 + Math.random() * 12;
      const fg = ctx.createRadialGradient(-12, 12, 1, -12, 12, fl);
      fg.addColorStop(0, 'rgba(255,255,255,.95)'); fg.addColorStop(.35, 'rgba(255,200,60,.9)'); fg.addColorStop(1, 'rgba(255,70,40,0)');
      ctx.fillStyle = fg; ctx.beginPath(); ctx.ellipse(-12 - fl * .35, 12 + fl * .35, fl * .55, fl * .3, -Math.PI / 4, 0, 7); ctx.fill();
      ctx.shadowColor = 'rgba(160,190,255,.9)'; ctx.shadowBlur = 16;
      ctx.font = '38px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('🚀', 0, 0); ctx.shadowBlur = 0; ctx.restore();
      if (phase === 'fly') { ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = 1.5;          // 속도선
        for (let i = 0; i < 4; i++) { const yy = (now / 3 + i * 80) % H; ctx.beginPath(); ctx.moveTo(W - ((now / 2 + i * 137) % W), yy); ctx.lineTo(W - ((now / 2 + i * 137) % W) + 30, yy - 18); ctx.stroke(); } }
    } else if (phase === 'end') {
      ctx.font = '54px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('💥', hx, hy); ctx.textAlign = 'start'; ctx.textBaseline = 'alphabetic';
    }
    // 파편·코인
    _gParts = _gParts.filter(p => p.life > 0);
    _gParts.forEach(p => { if (p.x == null) { p.x = hx; p.y = hy; } p.x += p.vx; p.y += p.vy;
      if (p.kind === 'smoke') { p.s += .35; p.life -= .03; } else { p.vy += .15; p.life -= .018; }
      ctx.globalAlpha = Math.max(0, p.life); ctx.fillStyle = p.c; ctx.beginPath(); ctx.arc(p.x, p.y, p.s, 0, 7); ctx.fill(); });
    ctx.globalAlpha = 1;
    // 숫자·안내
    const pctEl = document.getElementById('gmPct');
    if (pctEl) { const mm = phase === 'idle' || phase === 'count' ? GAME.START : m; const up = mm >= (pctEl._last || 0); pctEl._last = mm;
      pctEl.textContent = (Math.floor(mm * 100) / 100).toFixed(2) + '배'; pctEl.className = 'gm-pct' + (phase === 'fly' ? (up ? ' up' : ' dn') : ''); }
    if (multEl) {
      if (phase === 'count') { const c = Math.ceil((RUN.t0 - now) / 1000); multEl.textContent = c > 0 ? c : '🚀'; multEl.className = 'gm-mult count'; msgEl.textContent = '발사 준비…'; }
      else if (phase === 'fly') { multEl.textContent = ret(m); multEl.className = 'gm-mult fly' + (m >= 5 ? ' hot' : m >= 2 ? ' warm' : '');
        msgEl.textContent = RUN.cashedAt ? '수령 완료! 로켓은 계속 날아가요…' : '지금 수령하면 +' + nf(Math.min(Math.floor(RUN.bet * m), GAME.WIN_LIMIT), 0) + 'P';
        if (now - lastTick > 1000 / Math.min(8, 1 + m)) { lastTick = now; if (m > 1.5 && !RUN.cashedAt) GSFX.tick(); }
        const ms = [1.5, 2, 3, 5, 7, 10, 20, 50, 100].find(x => m >= x && !(RUN.miles || (RUN.miles = {}))[x]);
        if (ms) { RUN.miles[ms] = 1; const f = document.getElementById('gmFlash'); if (f) { f.textContent = '🔥 ' + ret(ms) + ' 돌파!'; f.classList.remove('on'); void f.offsetWidth; f.classList.add('on'); } GSFX.cash(); } }
      else if (phase === 'end') { multEl.textContent = RUN.cashedAt ? ret(RUN.cashedAt) : '💥 ' + ret(RUN.crash); multEl.className = 'gm-mult end' + (RUN.cashedAt ? ' won' : ' lost');
        msgEl.textContent = RUN.cashedAt ? '🎉 수령 성공 · +' + nf(RUN.win, 0) + 'P (순수익 ' + (RUN.win - RUN.bet >= 0 ? '+' : '') + nf(RUN.win - RUN.bet, 0) + 'P) · 로켓은 ' + ret(RUN.crash) + '에서 폭발' : ret(RUN.crash) + '에서 폭발 · -' + nf(RUN.bet, 0) + 'P'; }
      else { multEl.textContent = '+1%'; multEl.className = 'gm-mult'; msgEl.textContent = '금액을 정하고 출발을 눌러요'; }
    }
    _gRaf = requestAnimationFrame(frame);
  })();
}

/* 숨은 테스트 모드: 설정 → '앱 정보'를 7번 연속 누르면 오늘 판수 0 + 100,000P 충전 (날짜 바뀌길 기다리지 않고 시험용) */
(function () {
  let n = 0, t = 0;
  document.addEventListener('click', e => {
    if (!e.target.closest || !e.target.closest('#verRow')) return;
    const now = Date.now(); n = now - t < 1500 ? n + 1 : 1; t = now;
    if (n >= 3 && n < 7) toast('테스트 모드까지 ' + (7 - n) + '번', 800);
    if (n >= 7) {
      n = 0; const g = G(); gameDayRoll();
      g.plays = 0; g.todayNet = 0; g.pts += GAME.DAILY; delete g.live; save();
      toast('🧪 테스트 모드: 오늘 판수 초기화 + ' + nf(GAME.DAILY, 0) + 'P 충전', 3000);
    }
  });
})();

/* 수령 순간: '+15,400P' 숫자가 튀어 오르고, +100% 이상이면 꽃가루 */
function gameWinPop(win, at) {
  const st = document.getElementById('gmStage'); if (!st) return;
  const e = document.createElement('div'); e.className = 'gm-winpop' + (at >= 2 ? ' big' : '');
  e.textContent = '+' + nf(win, 0) + 'P';
  st.appendChild(e); setTimeout(() => e.remove(), 1700);
  if (at >= 2 && typeof fxConfetti === 'function') fxConfetti(at >= 5 ? 3200 : 2000);
}
