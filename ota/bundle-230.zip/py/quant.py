"""
Quant Lab 엔진 (quant.py) — 일봉 기반 · 결정론적 계산
=====================================================
역할 분리
  · 데이터: market_data.chart_rows (야후 파이낸스 일봉, 15분 캐시) — 못 받으면 '데이터 없음' (가짜 데이터 절대 안 만듦)
  · 퀀트 엔진(이 파일): 지표·매매 규칙·백테스트·시장 국면·섹터 강도·판단 가이드를 '숫자로' 계산
  · AI: 이 결과(JSON)만 받아 쉬운 말로 해설 (엔진에 없는 숫자를 만들지 못하게 지시)

원칙
  · 미래 데이터 참조 금지: t일 '종가까지'로 신호를 정하고, 매매는 t+1일 '시가'에 체결
  · 거래비용: 수수료(양쪽)·매도세(국내)·슬리피지를 모두 빼고 계산
  · 개발 구간(앞 70%)과 검증 구간(뒤 30%) 성과를 따로 보여 줌 — 뒤 구간이 크게 나쁘면 과최적화 의심
  · 전략은 모두 공개 규칙(이동평균·모멘텀·RSI·볼린저·돌파 등의 교과서적 정의). 특정인의 비공개 매매법이 아님
  · 결과는 과거 성과일 뿐, 미래 수익을 보장하지 않음 — 화면에 항상 표시
"""
import math
import time
from concurrent.futures import ThreadPoolExecutor

from flask import Blueprint, jsonify, request

ENGINE_VERSION = "1.0"
bp = Blueprint("quant", __name__)


# ─────────────────────────── 지표 (모두 순수 함수) ───────────────────────────
def sma(xs, n):
    out, s = [None] * len(xs), 0.0
    for i, x in enumerate(xs):
        s += x
        if i >= n:
            s -= xs[i - n]
        if i >= n - 1:
            out[i] = s / n
    return out


def ema(xs, n):
    out, k, e = [None] * len(xs), 2 / (n + 1), None
    for i, x in enumerate(xs):
        e = x if e is None else x * k + e * (1 - k)
        out[i] = e if i >= n - 1 else None
    return out


def rsi(c, n=14):
    out = [None] * len(c)
    if len(c) <= n:
        return out
    g = [max(0.0, c[i] - c[i - 1]) for i in range(1, len(c))]
    l_ = [max(0.0, c[i - 1] - c[i]) for i in range(1, len(c))]
    ag, al = sum(g[:n]) / n, sum(l_[:n]) / n
    out[n] = 100.0 if al == 0 else 100 - 100 / (1 + ag / al)
    for i in range(n, len(g)):
        ag, al = (ag * (n - 1) + g[i]) / n, (al * (n - 1) + l_[i]) / n
        out[i + 1] = 100.0 if al == 0 else 100 - 100 / (1 + ag / al)
    return out


def stdev(xs, n):
    out = [None] * len(xs)
    for i in range(n - 1, len(xs)):
        w = xs[i - n + 1:i + 1]
        m = sum(w) / n
        out[i] = math.sqrt(sum((x - m) ** 2 for x in w) / n)
    return out


def roll_max(xs, n, shift=0):
    """i일 기준 '그 전' n일 최고 (shift=1 이면 오늘 제외)."""
    out = [None] * len(xs)
    for i in range(len(xs)):
        a, b = i - n + 1 - shift, i + 1 - shift
        if a >= 0:
            out[i] = max(xs[a:b])
    return out


def roll_min(xs, n, shift=0):
    out = [None] * len(xs)
    for i in range(len(xs)):
        a, b = i - n + 1 - shift, i + 1 - shift
        if a >= 0:
            out[i] = min(xs[a:b])
    return out


def pct_change(c, n):
    return [None if i < n or not c[i - n] else (c[i] / c[i - n] - 1) * 100 for i in range(len(c))]


def series(rows):
    c = [r["c"] for r in rows]
    s = {"o": [r["o"] for r in rows], "h": [r["h"] for r in rows], "l": [r["l"] for r in rows], "c": c,
         "v": [r.get("v") or 0 for r in rows], "t": [r["t"] for r in rows]}
    for n in (5, 20, 50, 60, 120, 200):
        s["ma%d" % n] = sma(c, n)
    s["rsi"] = rsi(c, 14)
    sd = stdev(c, 20)
    s["bb_mid"] = s["ma20"]
    s["bb_up"] = [None if m is None else m + 2 * d for m, d in zip(s["ma20"], sd)]
    s["bb_lo"] = [None if m is None else m - 2 * d for m, d in zip(s["ma20"], sd)]
    s["vma20"] = sma(s["v"], 20)
    s["ret20"], s["ret60"], s["ret120"] = pct_change(c, 20), pct_change(c, 60), pct_change(c, 120)
    s["hh20"], s["ll10"] = roll_max(s["h"], 20, 1), roll_min(s["l"], 10, 1)
    dr = [None] + [(c[i] / c[i - 1] - 1) for i in range(1, len(c))]
    s["vol20"] = [None] * len(c)
    for i in range(21, len(c)):
        w = dr[i - 19:i + 1]
        m = sum(w) / 20
        s["vol20"][i] = math.sqrt(sum((x - m) ** 2 for x in w) / 19) * math.sqrt(252) * 100
    return s


# ─────────────────────────── 전략 (공개된 교과서 규칙) ───────────────────────────
# 각 전략: want(s, i, p, holding) → (사고 싶음/들고 싶음 bool, [(조건, 충족)], [(매도 조건, 충족)])
def _ok(*xs):
    return all(x is not None for x in xs)


def st_trend(s, i, p, holding):
    a, b, c = s["ma%d" % p["short"]][i], s["ma%d" % p["long"]][i], s["c"][i]
    if not _ok(a, b):
        return None
    buy = [(f"{p['short']}일선이 {p['long']}일선 위 (상승 추세)", a > b), (f"종가가 {p['long']}일선 위", c > b)]
    sell = [(f"{p['short']}일선이 {p['long']}일선 아래로 (데드크로스)", a < b)]
    return (not sell[0][1]) if holding else all(x for _, x in buy), buy, sell


def st_momentum(s, i, p, holding):
    r, m, c = s["ret%d" % p["lookback"]][i], s["ma%d" % p["lookback"]][i], s["c"][i]
    if not _ok(r, m):
        return None
    buy = [(f"{p['lookback']}일 수익률 +{p['min_ret']}% 이상 (현재 {r:+.1f}%)", r >= p["min_ret"]), (f"종가가 {p['lookback']}일선 위", c > m)]
    sell = [(f"{p['lookback']}일 수익률이 0% 아래로", r < 0), (f"종가가 {p['lookback']}일선 아래로", c < m)]
    return (not any(x for _, x in sell)) if holding else all(x for _, x in buy), buy, sell


def st_rsi(s, i, p, holding):
    r, m200 = s["rsi"][i], s["ma120"][i]
    if not _ok(r, m200):
        return None
    buy = [(f"RSI {p['buy']} 아래 (과매도, 현재 {r:.0f})", r < p["buy"]), ("종가가 120일선 위 (큰 추세는 살아 있음)", s["c"][i] > m200)]
    sell = [(f"RSI {p['sell']} 위로 회복", r > p["sell"])]
    return (not sell[0][1]) if holding else all(x for _, x in buy), buy, sell


def st_bollinger(s, i, p, holding):
    lo, mid, c = s["bb_lo"][i], s["bb_mid"][i], s["c"][i]
    if not _ok(lo, mid):
        return None
    buy = [("종가가 볼린저 하단 아래 (20일·2표준편차)", c < lo)]
    sell = [("종가가 볼린저 중심선(20일선) 위로", c > mid)]
    return (not sell[0][1]) if holding else buy[0][1], buy, sell


def st_breakout(s, i, p, holding):
    hh, ll, c = s["hh20"][i], s["ll10"][i], s["c"][i]
    if not _ok(hh, ll):
        return None
    buy = [("종가가 직전 20일 최고가 돌파", c > hh)]
    sell = [("종가가 직전 10일 최저가 아래로", c < ll)]
    return (not sell[0][1]) if holding else buy[0][1], buy, sell


def st_volume(s, i, p, holding):
    m20, v, vm, c = s["ma20"][i], s["v"][i], s["vma20"][i], s["c"][i]
    if not _ok(m20, vm) or i < 1:
        return None
    buy = [(f"거래량이 20일 평균의 {p['mult']}배 이상", vm > 0 and v >= vm * p["mult"]), ("양봉 (전일보다 상승)", c > s["c"][i - 1]), ("종가가 20일선 위", c > m20)]
    sell = [("종가가 20일선 아래로", c < m20)]
    return (not sell[0][1]) if holding else all(x for _, x in buy), buy, sell


def st_composite(s, i, p, holding):
    m60, m120, r60, r, c = s["ma60"][i], s["ma120"][i], s["ret60"][i], s["rsi"][i], s["c"][i]
    if not _ok(m60, m120, r60, r):
        return None
    conds = [("중기 추세: 종가 > 60일선", c > m60), ("장기 추세: 60일선 > 120일선", m60 > m120), (f"모멘텀: 60일 수익률 > 0 (현재 {r60:+.1f}%)", r60 > 0),
             (f"과열 아님: RSI < 70 (현재 {r:.0f})", r < 70)]
    score = sum(1 for _, x in conds if x)
    sell = [("점수 2점 이하로 하락", score <= 2)]
    return (score >= 3) if holding else score == 4, conds, sell


STRATEGIES = {
    "trend": {"name": "추세 추종 (이동평균)", "fn": st_trend, "params": {"short": 20, "long": 60},
              "buy": "단기 이동평균이 장기 이동평균 위에 있고 종가도 장기선 위", "sell": "단기선이 장기선 아래로 내려가면(데드크로스)",
              "kind": "추세", "fit": "스윙·장기"},
    "momentum": {"name": "모멘텀", "fn": st_momentum, "params": {"lookback": 60, "min_ret": 5},
                 "buy": "최근 60일 수익률이 +5% 이상이고 60일선 위", "sell": "60일 수익률이 마이너스이거나 60일선 아래로", "kind": "모멘텀", "fit": "스윙"},
    "rsi": {"name": "평균회귀 (RSI 과매도)", "fn": st_rsi, "params": {"buy": 30, "sell": 55},
            "buy": "RSI 30 아래(과매도)인데 120일선 위(큰 추세 유지)", "sell": "RSI 55 위로 회복", "kind": "평균회귀", "fit": "단타·스윙"},
    "bollinger": {"name": "볼린저 밴드 반등", "fn": st_bollinger, "params": {},
                  "buy": "종가가 볼린저 하단(20일·2σ) 아래", "sell": "종가가 중심선(20일선) 위로", "kind": "평균회귀", "fit": "단타·스윙"},
    "breakout": {"name": "신고가 돌파 (돈키언)", "fn": st_breakout, "params": {},
                 "buy": "종가가 직전 20일 최고가를 돌파", "sell": "종가가 직전 10일 최저가 아래로", "kind": "추세", "fit": "스윙"},
    "volume": {"name": "거래량 급증", "fn": st_volume, "params": {"mult": 2.0},
               "buy": "거래량이 20일 평균의 2배 이상 + 양봉 + 20일선 위", "sell": "종가가 20일선 아래로", "kind": "거래량", "fit": "단타·스윙"},
    "composite": {"name": "복합 점수 (추세+모멘텀+과열)", "fn": st_composite, "params": {},
                  "buy": "4개 조건(60일선 위·60>120일선·60일 수익률>0·RSI<70) 모두 충족", "sell": "충족 조건이 2개 이하로", "kind": "복합", "fit": "장기·스윙"},
}


def strategy_meta():
    return [{"id": k, "name": v["name"], "buy": v["buy"], "sell": v["sell"], "params": v["params"], "kind": v["kind"], "fit": v["fit"],
             "version": ENGINE_VERSION, "status": "연구용 (공개 규칙 · 과거 검증만)"} for k, v in STRATEGIES.items()]


# ─────────────────────────── 백테스트 ───────────────────────────
def _metrics(eq, t, trades, days_in):
    if len(eq) < 2:
        return {}
    years = max(1e-9, (t[-1] - t[0]) / 86400 / 365.25)
    total = eq[-1] / eq[0] - 1
    cagr = (eq[-1] / eq[0]) ** (1 / years) - 1 if eq[-1] > 0 else -1
    peak, mdd = eq[0], 0.0
    for x in eq:
        peak = max(peak, x)
        mdd = min(mdd, x / peak - 1)
    dr = [eq[i] / eq[i - 1] - 1 for i in range(1, len(eq))]
    m = sum(dr) / len(dr)
    sd = math.sqrt(sum((x - m) ** 2 for x in dr) / max(1, len(dr) - 1))
    vol = sd * math.sqrt(252)
    wins = [x for x in trades if x["ret"] > 0]
    gp, gl = sum(x["ret"] for x in wins), -sum(x["ret"] for x in trades if x["ret"] <= 0)
    return {"total": total * 100, "cagr": cagr * 100, "mdd": mdd * 100, "vol": vol * 100,
            "sharpe": (m * 252) / vol if vol > 0 else None, "trades": len(trades),
            "win": len(wins) / len(trades) * 100 if trades else None, "pf": gp / gl if gl > 0 else (None if not gp else 99),
            "avg_hold": sum(x["days"] for x in trades) / len(trades) if trades else None,
            "exposure": days_in / max(1, len(eq) - 1) * 100}


def backtest(rows, sid, params=None, costs=None, warmup=None):
    """t일 종가로 신호 → t+1일 시가 체결. 비용 반영. 손절·익절(선택)은 장중 저가·고가로 확인."""
    st = STRATEGIES[sid]
    p = dict(st["params"], **(params or {}))
    cst = {"fee": 0.015, "tax": 0.18, "slip": 0.05}
    cst.update(costs or {})
    fee, tax, slip = cst["fee"] / 100, cst["tax"] / 100, cst["slip"] / 100
    stop, take = float(p.get("stop") or 0) / 100, float(p.get("take") or 0) / 100
    s = series(rows)
    n = len(rows)
    start = warmup if warmup is not None else 130
    if n < start + 30:
        return {"error": "데이터가 부족해요 (최소 %d거래일 필요, 받은 데이터 %d일)" % (start + 30, n)}
    cash, sh, entry, entry_i, blocked = 1.0, 0.0, 0.0, 0, False
    eq, ts, trades, days_in, marks = [], [], [], 0, []
    for j in range(start, n):
        # ① 어제(j-1) 종가까지의 신호로 오늘 시가 체결
        if j > start:
            w = st["fn"](s, j - 1, p, sh > 0)
            want = bool(w and w[0])
            if not want:
                blocked = False
            if want and sh == 0 and not blocked:
                px = s["o"][j] * (1 + slip)
                sh, cash, entry, entry_i = cash * (1 - fee) / px, 0.0, px, j
                marks.append({"i": j, "type": "buy", "px": px})
            elif not want and sh > 0:
                px = s["o"][j] * (1 - slip)
                cash = sh * px * (1 - fee - tax)
                trades.append({"in": s["t"][entry_i], "out": s["t"][j], "ret": (px * (1 - fee - tax) / (entry / (1 - fee)) - 1) * 100, "days": j - entry_i, "why": "신호"})
                marks.append({"i": j, "type": "sell", "px": px})
                sh = 0.0
        # ② 손절·익절 (장중)
        if sh > 0 and (stop or take):
            hit = None
            if stop and s["l"][j] <= entry * (1 - stop):
                hit = (min(s["o"][j], entry * (1 - stop)), "손절")
            elif take and s["h"][j] >= entry * (1 + take):
                hit = (max(s["o"][j], entry * (1 + take)), "익절")
            if hit:
                px = hit[0] * (1 - slip)
                cash = sh * px * (1 - fee - tax)
                trades.append({"in": s["t"][entry_i], "out": s["t"][j], "ret": (px * (1 - fee - tax) / (entry / (1 - fee)) - 1) * 100, "days": j - entry_i, "why": hit[1]})
                marks.append({"i": j, "type": "sell", "px": px})
                sh, blocked = 0.0, True                 # 신호가 한 번 꺼질 때까지 다시 안 삼
        if sh > 0:
            days_in += 1
        eq.append(cash + sh * s["c"][j])
        ts.append(s["t"][j])
    if sh > 0:                                   # 끝날 때 들고 있으면 마지막 종가로 평가해 거래 기록에 넣음 (미청산)
        px = s["c"][n - 1] * (1 - slip)
        trades.append({"in": s["t"][entry_i], "out": s["t"][n - 1], "ret": (px * (1 - fee - tax) / (entry / (1 - fee)) - 1) * 100,
                       "days": n - 1 - entry_i, "why": "미청산(마지막 종가 평가)"})
    # 벤치마크: 같은 기간 그냥 사서 들고 있기 (비용 포함)
    b0 = s["o"][start] * (1 + slip) / (1 - fee)
    bench = [1.0] + [s["c"][j] / b0 for j in range(start + 1, n)]   # 첫날은 투자금 1 (매수 비용이 수익률에 반영되게)
    cut = int(len(eq) * 0.7)
    def seg(a, b):
        return _metrics(eq[a:b], ts[a:b], [x for x in trades if ts[a] <= x["in"] <= ts[b - 1]], 0)
    res = {
        "strategy": sid, "name": st["name"], "params": p, "costs": cst, "version": ENGINE_VERSION,
        "all": _metrics(eq, ts, trades, days_in), "bench": _metrics(bench, ts, [], len(bench) - 1),
        "dev": seg(0, cut), "test": seg(cut, len(eq)),
        "split": {"dev_from": ts[0], "dev_to": ts[cut - 1], "test_from": ts[cut], "test_to": ts[-1]},
        "trades": trades[-30:], "open": sh > 0,
        "curve": _down([(ts[k], eq[k], bench[k]) for k in range(len(eq))], 160),
    }
    for k in ("dev", "test"):
        res[k].pop("exposure", None)
    return res


def _down(pts, n):
    if len(pts) <= n:
        return pts
    step = len(pts) / n
    return [pts[int(i * step)] for i in range(n)] + [pts[-1]]


def current_signal(rows, sid, params=None):
    """마지막 종가 기준: 오늘 새 매수 신호인지 / 전략상 보유 구간인지 / 신호 없음 + 조건별 충족 여부."""
    st = STRATEGIES[sid]
    fn = st["fn"]
    p = dict(st["params"], **(params or {}))
    s = series(rows)
    i = len(rows) - 1
    holding = False
    for j in range(130, i + 1):              # 백테스트와 같은 흐름으로 지금 상태를 재현
        w = fn(s, j, p, holding)
        holding = bool(w and w[0])
    entry, prev, ex = fn(s, i, p, False), fn(s, i - 1, p, False), fn(s, i, p, True)
    if not entry or not ex:
        return {"state": "데이터 부족", "want": False, "new": False, "buy": [], "sell": []}
    new = bool(entry[0]) and not bool(prev and prev[0])
    state = "오늘 새 매수 신호" if new else ("전략상 보유 구간" if holding else "신호 없음")
    return {"state": state, "want": bool(new or holding), "new": new,
            "buy": [{"t": a, "ok": bool(b)} for a, b in entry[1]], "sell": [{"t": a, "ok": bool(b)} for a, b in ex[2]]}


# ─────────────────────────── 시장 국면 · 섹터 강도 ───────────────────────────
def regime(rows):
    s = series(rows)
    i = len(rows) - 1
    c, m50, m200 = s["c"][i], s["ma50"][i], s["ma200"][i] or s["ma120"][i]
    m50p = s["ma50"][i - 20] if i >= 20 else None
    if not _ok(c, m50, m200, m50p):
        return {"state": "데이터 부족"}
    hi = max(s["h"][-250:])
    dd = (c / hi - 1) * 100
    up50 = m50 > m50p
    if c > m200 and up50 and dd > -8:
        st, tone = "상승 추세", "up"
    elif c > m200:
        st, tone = "상승 중 조정", "warn"
    elif c < m200 and not up50:
        st, tone = "하락 추세", "down"
    else:
        st, tone = "바닥 다지기·전환 시도", "warn"
    return {"state": st, "tone": tone, "close": c, "ma50": m50, "ma200": m200, "ma50_up": up50, "from_high": dd,
            "ret20": s["ret20"][i], "ret60": s["ret60"][i], "vol20": s["vol20"][i], "rsi": s["rsi"][i],
            "why": [("종가 > 200일선(장기 추세)", c > m200), ("50일선이 한 달 전보다 위(중기 추세 상승)", up50), (f"52주 고점 대비 {dd:+.1f}% (−8% 이내면 강함)", dd > -8)]}


SECTORS = {
    "kr": [("091160", "반도체"), ("305720", "2차전지"), ("266420", "헬스케어"), ("091180", "자동차"), ("091170", "은행"),
           ("117460", "에너지화학"), ("117680", "철강"), ("117700", "건설"), ("139260", "IT(코스피200)"), ("228810", "미디어·콘텐츠"),
           ("140710", "운송"), ("266410", "필수소비재")],
    "us": [("XLK", "기술"), ("SMH", "반도체"), ("XLC", "통신·미디어"), ("XLY", "임의소비재"), ("XLF", "금융"), ("XLV", "헬스케어"),
           ("XLE", "에너지"), ("XLI", "산업재"), ("XLB", "소재"), ("XLP", "필수소비재"), ("XLU", "유틸리티"), ("XLRE", "부동산")],
}
BENCH = {"kr": ("^KS11", "코스피"), "us": ("^GSPC", "S&P 500")}
UNIVERSE = {
    "kr_large": [("005930", "삼성전자"), ("000660", "SK하이닉스"), ("373220", "LG에너지솔루션"), ("207940", "삼성바이오로직스"), ("005380", "현대차"),
                 ("000270", "기아"), ("068270", "셀트리온"), ("005490", "POSCO홀딩스"), ("035420", "NAVER"), ("035720", "카카오"), ("051910", "LG화학"),
                 ("006400", "삼성SDI"), ("105560", "KB금융"), ("055550", "신한지주"), ("012330", "현대모비스"), ("028260", "삼성물산"), ("066570", "LG전자"),
                 ("086790", "하나금융지주"), ("015760", "한국전력"), ("034020", "두산에너빌리티"), ("012450", "한화에어로스페이스"), ("009540", "HD한국조선해양"),
                 ("329180", "HD현대중공업"), ("042700", "한미반도체"), ("247540", "에코프로비엠"), ("010130", "고려아연"), ("011200", "HMM"),
                 ("003670", "포스코퓨처엠"), ("018260", "삼성에스디에스"), ("259960", "크래프톤")],
    "us_large": [("AAPL", "애플"), ("MSFT", "마이크로소프트"), ("NVDA", "엔비디아"), ("GOOGL", "알파벳"), ("AMZN", "아마존"), ("META", "메타"),
                 ("TSLA", "테슬라"), ("AVGO", "브로드컴"), ("JPM", "JP모건"), ("V", "비자"), ("UNH", "유나이티드헬스"), ("XOM", "엑슨모빌"), ("LLY", "일라이릴리"),
                 ("JNJ", "존슨앤존슨"), ("WMT", "월마트"), ("MA", "마스터카드"), ("PG", "P&G"), ("HD", "홈디포"), ("COST", "코스트코"), ("ORCL", "오라클"),
                 ("AMD", "AMD"), ("NFLX", "넷플릭스"), ("CRM", "세일즈포스"), ("ADBE", "어도비"), ("KO", "코카콜라"), ("TSM", "TSMC"), ("ASML", "ASML"),
                 ("PLTR", "팔란티어"), ("QCOM", "퀄컴"), ("MU", "마이크론")],
    # v2.21 — 코스닥 대표·ETF (조건 검색기 범위 확장)
    "kr_kosdaq": [("247540", "에코프로비엠"), ("086520", "에코프로"), ("196170", "알테오젠"), ("028300", "HLB"), ("263750", "펄어비스"),
                  ("293490", "카카오게임즈"), ("068760", "셀트리온제약"), ("357780", "솔브레인"), ("039030", "이오테크닉스"), ("145020", "휴젤"),
                  ("214150", "클래시스"), ("277810", "레인보우로보틱스"), ("058470", "리노공업"), ("095340", "ISC"), ("240810", "원익IPS"),
                  ("403870", "HPSP"), ("112040", "위메이드"), ("041510", "에스엠"), ("035900", "JYP Ent."), ("253450", "스튜디오드래곤")],
    "kr_etf": [("069500", "KODEX 200"), ("229200", "KODEX 코스닥150"), ("122630", "KODEX 레버리지"), ("114800", "KODEX 인버스"),
               ("360750", "TIGER 미국S&P500"), ("133690", "TIGER 미국나스닥100"), ("381170", "TIGER 미국테크TOP10"), ("305720", "KODEX 2차전지산업"),
               ("091160", "KODEX 반도체"), ("091170", "KODEX 은행"), ("148070", "KOSEF 국고채10년"), ("132030", "KODEX 골드선물(H)"),
               ("261220", "KODEX WTI원유선물(H)")],
    "us_etf": [("SPY", "S&P500 ETF"), ("QQQ", "나스닥100 ETF"), ("DIA", "다우 ETF"), ("IWM", "러셀2000 ETF"), ("VTI", "미국 전체 ETF"),
               ("SCHD", "미국 배당 ETF"), ("VYM", "고배당 ETF"), ("TLT", "미국 장기국채 ETF"), ("GLD", "금 ETF"), ("XLK", "기술주 ETF"),
               ("XLE", "에너지 ETF"), ("XLF", "금융 ETF"), ("SOXX", "반도체 ETF"), ("SMH", "반도체 ETF(VanEck)"), ("ARKK", "혁신 성장 ETF")],
}


# ─────────────────────────── 보유·관심 종목 판단 가이드 ───────────────────────────
VERDICTS = ["신규 매수 검토", "추가 매수 검토", "보유", "비중 축소 검토", "매도 조건 충족", "관망", "데이터 부족으로 판단 보류"]


def guide(rows, held=False, weight=None, target=None, single_max=None, style="long", mkt=None):
    s = series(rows)
    i = len(rows) - 1
    if len(rows) < 130:
        return {"verdict": VERDICTS[6], "why": ["일봉이 130일보다 적어요 (받은 데이터 %d일)" % len(rows)]}
    c, m20, m60, m120 = s["c"][i], s["ma20"][i], s["ma60"][i], s["ma120"][i]
    r60, r, vol = s["ret60"][i], s["rsi"][i], s["vol20"][i]
    hi = max(s["h"][-250:])
    dd = (c / hi - 1) * 100
    short = style in ("day", "scalp")
    fast, slow, fl, sl = (m20, m60, "20일선", "60일선") if short else (m60, m120, "60일선", "120일선")
    conds = [
        (f"종가가 {sl} 위 (큰 추세 살아 있음)", c > slow),
        (f"{fl}이 {sl} 위 (추세 정배열)", fast > slow),
        (f"60일 수익률 플러스 (현재 {r60:+.1f}%)", r60 > 0),
        (f"과열 아님: RSI 70 미만 (현재 {r:.0f})", r < 70),
    ]
    score = sum(1 for _, x in conds if x)
    sell_cond = c < slow * 0.97 and (fast < slow or r60 < -10)
    mkt_down = bool(mkt and mkt.get("state") == "하락 추세")
    notes = []
    if held:
        over = weight is not None and single_max and weight > single_max
        if sell_cond:
            v = VERDICTS[4]
        elif over or (r >= 75 and dd > -3):
            v = VERDICTS[3]
            notes.append("한 종목 비중이 권장(%s%%)보다 커요" % single_max if over else "단기 과열(RSI 75↑, 고점 근처)")
        elif score == 4 and (target is None or weight is None or weight < target):
            v = VERDICTS[1] if not mkt_down else VERDICTS[2]
        else:
            v = VERDICTS[2]
    else:
        if score == 4:
            v = VERDICTS[0]
        elif c > slow and r < 35:
            v = VERDICTS[0]
            notes.append("큰 추세 위에서의 눌림(RSI 35 미만)")
        else:
            v = VERDICTS[5]
        if mkt_down and v == VERDICTS[0]:
            v = VERDICTS[5]
            notes.append("시장 전체가 하락 추세라 신규 매수는 한 단계 낮춰 '관망'")
    if vol and vol > 60:
        notes.append(f"변동성이 커요 (연환산 {vol:.0f}%) — 비중을 작게")
    return {
        "verdict": v, "score": score, "conds": [{"t": a, "ok": bool(b)} for a, b in conds],
        "sell_rule": {"t": f"종가가 {sl}의 97%({slow * 0.97:,.2f}) 아래 + 추세 꺾임", "ok": bool(sell_cond)},
        "invalid": [f"종가가 {sl}({slow:,.2f}) 아래로 내려가면 상승 판단 무효", "RSI 70 이상에서 추격 매수는 위험"],
        "obs": {"close": c, "ma20": m20, "ma60": m60, "ma120": m120, "rsi": r, "ret60": r60, "from_high": dd, "vol20": vol},
        "notes": notes, "basis": "단기 매매 기준(20·60일선)" if short else "중장기 기준(60·120일선)",
    }


# ─────────────────────────── 데이터 연결 · API ───────────────────────────
def _rows(ticker, market, rng="1y"):
    import market_data
    d = market_data.chart_rows(ticker, market, rng, "1d")
    if not d or len(d.get("rows") or []) < 30:
        return None, None
    rows = d["rows"]
    last = rows[-1]["t"]
    info = {"source": "Yahoo Finance 일봉", "symbol": d.get("symbol"), "bars": len(rows), "first": rows[0]["t"], "last": last,
            "fetched": int(time.time()), "stale_days": round((time.time() - last) / 86400, 1), "currency": d.get("currency")}
    return rows, info


def _mkt(t):
    t = (t or "").upper()
    return "kr" if (len(t) == 6 and t[0].isdigit()) else "us"


@bp.get("/api/quant/strategies")
def api_strategies():
    return jsonify({"strategies": strategy_meta(), "conds": cond_meta(), "version": ENGINE_VERSION})


@bp.post("/api/quant/backtest")
def api_backtest():
    q = request.get_json(force=True, silent=True) or {}
    sid = q.get("strategy") if q.get("strategy") in STRATEGIES else "trend"
    t = str(q.get("ticker") or "").strip().upper()
    m = q.get("market") or _mkt(t)
    yrs = {"1y": "2y", "3y": "5y", "5y": "10y"}.get(q.get("period"), "5y")        # 지표 준비 기간(130일)까지 넉넉히
    rows, info = _rows(t, m, yrs)
    if not rows:
        return jsonify({"ok": False, "error": "이 종목의 일봉 데이터를 받지 못했어요 (데이터 없음)"})
    want_days = {"1y": 252, "3y": 756, "5y": 1260}.get(q.get("period"), 756)
    rows = rows[-(want_days + 130):]
    params = {k: float(v) for k, v in (q.get("params") or {}).items() if str(v).replace(".", "", 1).isdigit()}
    costs = {k: float(v) for k, v in (q.get("costs") or {}).items() if str(v).replace(".", "", 1).isdigit()}
    if m != "kr":
        costs.setdefault("tax", 0.0)
    res = backtest(rows, sid, params, costs)
    if res.get("error"):
        return jsonify({"ok": False, "error": res["error"], "data": info})
    res["signal"] = current_signal(rows, sid, params)
    return jsonify({"ok": True, "ticker": t, "market": m, "data": info, "result": res})


def _regime_of(key):
    sym, name = BENCH[key]
    import market_data
    d = None
    try:
        meta, rows = market_data.yahoo_ohlcv(sym, "2y", "1d")
        d = rows if len(rows) >= 210 else None
    except Exception:
        d = None
    if not d:
        return {"name": name, "state": "데이터 없음"}
    out = regime(d)
    out.update(name=name, asof=d[-1]["t"])
    return out


def _sector_list(key):
    bsym, bname = BENCH[key]
    import market_data
    try:
        _, brows = market_data.yahoo_ohlcv(bsym, "6mo", "1d")
    except Exception:
        brows = []

    def ret(rows, n):
        return (rows[-1]["c"] / rows[-n - 1]["c"] - 1) * 100 if len(rows) > n else None
    b20, b60 = ret(brows, 20), ret(brows, 60)

    def one(item):
        t, nm = item
        rows, info = _rows(t, key, "6mo")
        if not rows:
            return {"ticker": t, "name": nm, "ok": False}
        r20, r60 = ret(rows, 20), ret(rows, 60)
        rel20 = r20 - b20 if (r20 is not None and b20 is not None) else None
        rel60 = r60 - b60 if (r60 is not None and b60 is not None) else None
        score = None if rel20 is None or rel60 is None else 0.5 * rel20 + 0.5 * rel60
        return {"ticker": t, "name": nm, "ok": True, "r20": r20, "r60": r60, "rel20": rel20, "rel60": rel60, "score": score, "asof": rows[-1]["t"]}
    with ThreadPoolExecutor(max_workers=6) as ex:
        out = list(ex.map(one, SECTORS[key]))
    good = sorted([x for x in out if x.get("score") is not None], key=lambda x: -x["score"])
    return {"bench": bname, "b20": b20, "b60": b60, "items": good + [x for x in out if x.get("score") is None]}


@bp.get("/api/quant/market")
def api_market_q():
    with ThreadPoolExecutor(max_workers=4) as ex:
        fk, fu, sk, su = ex.submit(_regime_of, "kr"), ex.submit(_regime_of, "us"), ex.submit(_sector_list, "kr"), ex.submit(_sector_list, "us")
        res = {"regime": {"kr": fk.result(), "us": fu.result()}, "sectors": {"kr": sk.result(), "us": su.result()}}
    res["breadth"] = "데이터 없음 (상승·하락 종목 비율은 시장 전체 종목 데이터가 필요해 아직 계산하지 않아요)"
    res["at"] = int(time.time())
    return jsonify(res)


@bp.post("/api/quant/signals")
def api_signals():
    """보유·관심 종목별 판단 가이드 (+ 시장 국면 반영)."""
    q = request.get_json(force=True, silent=True) or {}
    items = (q.get("items") or [])[:40]
    style = q.get("style") or "long"
    with ThreadPoolExecutor(max_workers=4) as ex:
        regs = {"kr": ex.submit(_regime_of, "kr"), "us": ex.submit(_regime_of, "us")}
        regs = {k: v.result() for k, v in regs.items()}

    def one(it):
        t = str(it.get("ticker") or "").upper()
        m = it.get("market") or _mkt(t)
        rows, info = _rows(t, m, "1y")
        base = {"ticker": t, "name": it.get("name") or t, "market": m, "held": bool(it.get("held"))}
        if not rows:
            return dict(base, verdict="데이터 부족으로 판단 보류", why=["일봉 데이터를 받지 못했어요 (데이터 없음)"])
        g = guide(rows, held=bool(it.get("held")), weight=it.get("weight"), target=it.get("target"), single_max=it.get("single_max"),
                  style=style, mkt=regs.get(m))
        g.update(base, data=info)
        return g
    with ThreadPoolExecutor(max_workers=6) as ex:
        out = list(ex.map(one, items))
    return jsonify({"items": out, "regime": regs, "style": style, "version": ENGINE_VERSION, "at": int(time.time())})


# ─────────────────────────── 내 조건 검색 (v2.19) ───────────────────────────
# 사용자가 고른 숫자 조건으로만 거름 (AI 없음). id: (설명, 판정 함수(s, i, 값) → (충족, 관측값 글자))
def _f(x, d=1):
    return "-" if x is None else ("%." + str(d) + "f") % x


def _hi250(s, i):
    w = [x for x in s["h"][max(0, i - 249):i + 1] if x]
    return max(w) if w else None


def _vol_spike(s, i, v):
    """최근 3일 중 가장 큰 '그날 거래량 ÷ 전날까지 20일 평균'."""
    xs = [s["v"][j] / s["vma20"][j - 1] for j in range(i - 2, i + 1) if s["vma20"][j - 1]]
    m = max(xs) if xs else None
    return (m is not None and m >= v, "최대 " + _f(m) + "배")


COND = {
    "above20": ("종가가 20일선 위", lambda s, i, v: (_ok(s["ma20"][i]) and s["c"][i] > s["ma20"][i], "20일선 " + _f(s["ma20"][i], 0))),
    "above60": ("종가가 60일선 위", lambda s, i, v: (_ok(s["ma60"][i]) and s["c"][i] > s["ma60"][i], "60일선 " + _f(s["ma60"][i], 0))),
    "above120": ("종가가 120일선 위", lambda s, i, v: (_ok(s["ma120"][i]) and s["c"][i] > s["ma120"][i], "120일선 " + _f(s["ma120"][i], 0))),
    "aligned": ("이동평균 정배열 (20 > 60 > 120일선)", lambda s, i, v: (_ok(s["ma20"][i], s["ma60"][i], s["ma120"][i]) and s["ma20"][i] > s["ma60"][i] > s["ma120"][i], "정배열" if _ok(s["ma20"][i], s["ma60"][i], s["ma120"][i]) and s["ma20"][i] > s["ma60"][i] > s["ma120"][i] else "아님")),
    "rsi_min": ("RSI ≥ 값", lambda s, i, v: (_ok(s["rsi"][i]) and s["rsi"][i] >= v, "RSI " + _f(s["rsi"][i], 0))),
    "rsi_max": ("RSI ≤ 값", lambda s, i, v: (_ok(s["rsi"][i]) and s["rsi"][i] <= v, "RSI " + _f(s["rsi"][i], 0))),
    "ret20_min": ("20일 수익률 ≥ 값%", lambda s, i, v: (_ok(s["ret20"][i]) and s["ret20"][i] >= v, "20일 " + _f(s["ret20"][i]) + "%")),
    "ret60_min": ("60일 수익률 ≥ 값%", lambda s, i, v: (_ok(s["ret60"][i]) and s["ret60"][i] >= v, "60일 " + _f(s["ret60"][i]) + "%")),
    "ret60_max": ("60일 수익률 ≤ 값% (많이 빠진 종목)", lambda s, i, v: (_ok(s["ret60"][i]) and s["ret60"][i] <= v, "60일 " + _f(s["ret60"][i]) + "%")),
    "near_high": ("52주 최고가 대비 -값% 이내", lambda s, i, v: ((lambda h: (h is not None and (s["c"][i] / h - 1) * 100 >= -v, "고점 대비 " + _f(None if h is None else (s["c"][i] / h - 1) * 100) + "%"))(_hi250(s, i)))),
    "far_high": ("52주 최고가 대비 -값% 이상 하락", lambda s, i, v: ((lambda h: (h is not None and (s["c"][i] / h - 1) * 100 <= -v, "고점 대비 " + _f(None if h is None else (s["c"][i] / h - 1) * 100) + "%"))(_hi250(s, i)))),
    "vol_spike": ("거래량이 20일 평균의 값배 이상 (최근 3일 중)", lambda s, i, v: _vol_spike(s, i, v)),
    "vol_max": ("변동성(연환산) ≤ 값% (덜 출렁이는 종목)", lambda s, i, v: (_ok(s["vol20"][i]) and s["vol20"][i] <= v, "변동성 " + _f(s["vol20"][i], 0) + "%")),
    # v2.21 추가 조건
    "above200": ("종가가 200일선 위 (장기 추세)", lambda s, i, v: (_ok(s["ma200"][i]) and s["c"][i] > s["ma200"][i], "200일선 " + _f(s["ma200"][i], 0))),
    "golden": ("최근 값일 안에 20일선이 60일선 위로 돌파 (골든크로스)", lambda s, i, v: _cross(s, i, int(v or 10), up=True)),
    "dead": ("최근 값일 안에 20일선이 60일선 아래로 (데드크로스)", lambda s, i, v: _cross(s, i, int(v or 10), up=False)),
    "macd_up": ("MACD가 시그널 위 (상승 힘)", lambda s, i, v: _macd_up(s, i)),
    "bb_low": ("볼린저 밴드 하단 근처 (하단 +값% 이내)", lambda s, i, v: (_ok(s["bb_lo"][i]) and s["c"][i] <= s["bb_lo"][i] * (1 + v / 100), "하단 " + _f(s["bb_lo"][i], 0))),
    "bb_high": ("볼린저 밴드 상단 돌파", lambda s, i, v: (_ok(s["bb_up"][i]) and s["c"][i] >= s["bb_up"][i], "상단 " + _f(s["bb_up"][i], 0))),
    "up_days": ("값일 연속 상승", lambda s, i, v: _streak(s, i, int(v or 3))),
    "gap_up": ("오늘 시가가 어제 종가보다 값% 이상 높게 출발 (갭상승)", lambda s, i, v: ((s["o"][i] / s["c"][i - 1] - 1) * 100 >= v, "갭 " + _f((s["o"][i] / s["c"][i - 1] - 1) * 100) + "%")),
    "near_low": ("52주 최저가 대비 +값% 이내 (바닥권)", lambda s, i, v: _near_low(s, i, v)),
    "ret5_min": ("5일 수익률 ≥ 값%", lambda s, i, v: _ret(s, i, 5, v, True)),
    "ret5_max": ("5일 수익률 ≤ 값% (최근 급락)", lambda s, i, v: _ret(s, i, 5, v, False)),
    "ma20_gap": ("20일선보다 값% 이상 아래 (과하게 빠짐)", lambda s, i, v: (_ok(s["ma20"][i]) and (s["c"][i] / s["ma20"][i] - 1) * 100 <= -v, "20일선 대비 " + _f(None if not s["ma20"][i] else (s["c"][i] / s["ma20"][i] - 1) * 100) + "%")),
    "price_min": ("주가 ≥ 값 (원/달러)", lambda s, i, v: (s["c"][i] >= v, "주가 " + _f(s["c"][i], 2))),
    "price_max": ("주가 ≤ 값 (원/달러)", lambda s, i, v: (s["c"][i] <= v, "주가 " + _f(s["c"][i], 2))),
}


def _cross(s, i, n, up=True):
    for j in range(max(1, i - n + 1), i + 1):
        a, b, pa, pb = s["ma20"][j], s["ma60"][j], s["ma20"][j - 1], s["ma60"][j - 1]
        if _ok(a, b, pa, pb) and ((pa <= pb and a > b) if up else (pa >= pb and a < b)):
            return True, "%d일 전" % (i - j)
    return False, "없음"


def _macd_up(s, i):
    c = s["c"][:i + 1]
    e12, e26 = ema(c, 12), ema(c, 26)
    m = [None if a is None or b is None else a - b for a, b in zip(e12, e26)]
    vals = [x for x in m if x is not None]
    if len(vals) < 10:
        return False, "계산 불가"
    sig = ema(vals, 9)[-1]
    return (sig is not None and vals[-1] > sig), ("MACD %.2f / 시그널 %.2f" % (vals[-1], sig or 0))


def _streak(s, i, n):
    k = 0
    while k < 30 and i - k - 1 >= 0 and s["c"][i - k] > s["c"][i - k - 1]:
        k += 1
    return k >= n, "%d일 연속" % k


def _near_low(s, i, v):
    w = [x for x in s["l"][max(0, i - 249):i + 1] if x]
    lo = min(w) if w else None
    if not lo:
        return False, "계산 불가"
    g = (s["c"][i] / lo - 1) * 100
    return g <= v, "저점 대비 +" + _f(g) + "%"


def _ret(s, i, n, v, ge):
    if i - n < 0:
        return False, "계산 불가"
    r = (s["c"][i] / s["c"][i - n] - 1) * 100
    return (r >= v if ge else r <= v), "%d일 %s%%" % (n, _f(r))


def cond_meta():
    return [{"id": k, "t": v[0]} for k, v in COND.items()]


def check_conds(rows, conds):
    s = series(rows)
    i = len(rows) - 1
    out = []
    for c in conds:
        k = c.get("id")
        if k not in COND:
            continue
        try:
            val = float(c.get("v") or 0)
        except (TypeError, ValueError):
            val = 0.0
        try:
            ok, obs = COND[k][1](s, i, val)
        except Exception:
            ok, obs = False, "계산 불가"
        out.append({"id": k, "t": COND[k][0].replace("값", ("%g" % val)), "ok": bool(ok), "obs": obs})
    return out


@bp.post("/api/quant/scan")
def api_scan():
    q = request.get_json(force=True, silent=True) or {}
    sid = q.get("strategy") if q.get("strategy") in STRATEGIES else "composite"
    uni = q.get("universe") or "kr_large"
    custom = [c for c in (q.get("custom") or []) if isinstance(c, dict) and c.get("id") in COND][:10]
    try:
        need = max(1, min(len(custom), int(q.get("need") or len(custom)))) if custom else 0
    except (TypeError, ValueError):
        need = len(custom)
    if uni == "mine":
        items = [(str(x.get("ticker") or "").upper(), x.get("name") or "") for x in (q.get("items") or [])][:40]
    else:
        items = UNIVERSE.get(uni, UNIVERSE["kr_large"])

    def one(it):
        t, nm = it
        m = _mkt(t)
        rows, info = _rows(t, m, "1y")
        if not rows or len(rows) < 140:
            return {"ticker": t, "name": nm, "ok": False}
        s = series(rows)
        i = len(rows) - 1
        base = {"ticker": t, "name": nm, "market": m, "ok": True, "close": s["c"][i], "rsi": s["rsi"][i],
                "ret20": s["ret20"][i], "ret60": s["ret60"][i], "asof": rows[-1]["t"], "stale_days": info["stale_days"]}
        if custom:
            res = check_conds(rows, custom)
            n = sum(1 for r in res if r["ok"])
            return dict(base, conds=res, met=n, total=len(res), signal={"want": n >= need, "new": n == len(res), "state": "%d/%d 충족" % (n, len(res))})
        return dict(base, signal=current_signal(rows, sid))
    with ThreadPoolExecutor(max_workers=8) as ex:
        out = list(ex.map(one, items))
    ok = [x for x in out if x.get("ok")]
    if custom:
        sort = q.get("sort") or "met"
        keyf = {"ret60": lambda x: -(x.get("ret60") or -999), "ret20": lambda x: -(x.get("ret20") or -999),
                "rsi_low": lambda x: (x.get("rsi") if x.get("rsi") is not None else 999), "met": lambda x: (-x["met"], -(x.get("ret60") or 0))}.get(sort)
        hit = sorted([x for x in ok if x["signal"].get("want")], key=keyf or (lambda x: (-x["met"], -(x.get("ret60") or 0))))
    else:
        hit = sorted([x for x in ok if x["signal"].get("want")], key=lambda x: (not x["signal"].get("new"), -(x.get("ret60") or 0)))
    return jsonify({"strategy": "custom" if custom else sid, "custom": bool(custom), "need": need, "universe": uni, "hits": hit, "checked": len(ok), "failed": [x["name"] or x["ticker"] for x in out if not x.get("ok")],
                    "at": int(time.time()), "version": ENGINE_VERSION})
