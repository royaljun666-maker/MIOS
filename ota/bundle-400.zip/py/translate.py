"""
translate.py — 해외(영어) 뉴스 제목을 한국어로 (v3.7)

1순위: 구글 번역 공개 주소 (키 없음 · 무료)  →  2순위: MyMemory (키 없음 · 무료, 하루 한도 있음)
→  3순위: 사용자가 연결한 AI (있을 때만). 막힌 곳은 5분 쉬었다가 다시 씀.
번역한 제목은 메모리 + 파일에 기억해 두어 같은 제목은 다시 번역하지 않음.
번역이 안 되면 원문 그대로 둠 (화면이 깨지지 않게).
"""
import json
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import requests

_HANGUL = re.compile(r"[가-힣]")
_LATIN = re.compile(r"[A-Za-z]{3,}")
_LOCK = threading.Lock()
_MEM = {}
_MAX = 4000
_DIRTY = [0.0]


def _path():
    base = os.environ.get("ASSET_DATA_DIR") or os.path.join(os.path.dirname(os.path.abspath(__file__)), "userdata")
    return os.path.join(base, "tr_cache.json")


def _load():
    try:
        with open(_path(), encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict):
            _MEM.update(d)
    except Exception:
        pass


def _save():
    with _LOCK:
        if not _DIRTY[0] or time.time() - _DIRTY[0] < 5:
            return
        _DIRTY[0] = 0.0
        if len(_MEM) > _MAX:                       # 오래된 것부터 버림 (dict 는 넣은 순서 유지)
            for k in list(_MEM)[: len(_MEM) - _MAX]:
                _MEM.pop(k, None)
        data = dict(_MEM)
    try:
        p = _path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, p)
    except Exception:
        pass


_load()


def is_foreign(t):
    """한글이 없고 영어 단어가 있는 제목만 번역 대상."""
    t = t or ""
    return bool(t) and not _HANGUL.search(t) and bool(_LATIN.search(t))


_COOL = {}                                        # 엔진 → 다시 써 볼 시각 (429 등으로 막혔을 때)


def _ok(engine):
    return time.time() >= _COOL.get(engine, 0)


def _cool(engine, sec=300):
    _COOL[engine] = time.time() + sec


def _google(text):
    r = requests.get("https://translate.googleapis.com/translate_a/single",
                     params={"client": "gtx", "sl": "auto", "tl": "ko", "dt": "t", "q": text},
                     timeout=6)
    r.raise_for_status()
    d = r.json()
    return "".join(seg[0] for seg in (d[0] or []) if seg and seg[0])


def _google_batch(titles):
    """여러 제목을 줄바꿈으로 묶어 한 번에. 줄 수가 안 맞으면 하나씩."""
    out = {}
    if not _ok("google"):
        return out
    chunks, cur, size = [], [], 0
    for t in titles:
        if cur and (size + len(t) > 1800 or len(cur) >= 25):
            chunks.append(cur)
            cur, size = [], 0
        cur.append(t)
        size += len(t) + 1

    if cur:
        chunks.append(cur)

    def one(ch):
        res = {}
        if not _ok("google"):
            return res
        try:
            lines = _google("\n".join(ch)).split("\n")
            if len(lines) == len(ch):
                return {a: b.strip() for a, b in zip(ch, lines) if b.strip()}
        except Exception:
            _cool("google")                         # 막힘(429)·끊김 — 잠시 다른 방법으로
            return res
        for t in ch:                                # 묶음이 어긋나면 하나씩
            try:
                k = _google(t).strip()
                if k:
                    res[t] = k
            except Exception:
                _cool("google")
                break
        return res
    with ThreadPoolExecutor(max_workers=4) as ex:
        for r in ex.map(one, chunks):
            out.update(r)
    return out


def _mymemory_batch(titles):
    """MyMemory 무료 번역 (키 없음). 제목 하나씩, 최대 15개."""
    out = {}
    for t in titles[:15]:
        if not _ok("mymemory"):
            break
        try:
            r = requests.get("https://api.mymemory.translated.net/get", params={"q": t[:450], "langpair": "en|ko"}, timeout=6)
            d = r.json()
            k = ((d.get("responseData") or {}).get("translatedText") or "").strip()
            if r.status_code != 200 or d.get("responseStatus") not in (200, "200") or not k or "MYMEMORY WARNING" in k.upper():
                _cool("mymemory", 1800)
                break
            out[t] = k
        except Exception:
            _cool("mymemory")
            break
    return out


def _ai_batch(titles):
    """구글 번역이 막혔을 때 — 사용자가 AI를 연결해 둔 경우에만."""
    try:
        import ai_engine
    except Exception:
        return {}
    titles = titles[:30]
    prompt = ("아래 영어 뉴스 제목을 자연스러운 한국어 뉴스 제목으로 번역하세요. 회사·지수 이름은 한국에서 흔히 쓰는 이름으로"
              "(예: Nvidia→엔비디아, S&P 500→S&P500, Fed→연준). 번호를 그대로 붙여 한 줄에 하나씩, 번역만 쓰세요.\n\n"
              + "\n".join(f"{i+1}. {t}" for i, t in enumerate(titles)))
    try:
        text, _p, _m, err = ai_engine.complete(prompt=prompt, max_out=1500, temperature=0.2,
                                               system="당신은 경제 뉴스 번역가입니다. 번역만 출력합니다.")
    except Exception:
        return {}
    if err or not text:
        return {}
    out = {}
    for line in text.splitlines():
        m = re.match(r"\s*(\d+)[.)]\s*(.+)", line)
        if m and 1 <= int(m.group(1)) <= len(titles):
            out[titles[int(m.group(1)) - 1]] = m.group(2).strip()
    return out


def translate_titles(titles):
    """{원문: 번역} — 번역 못 한 제목은 빠짐."""
    want = []
    res = {}
    for t in dict.fromkeys(x.strip() for x in titles if x and is_foreign(x)):
        if t in _MEM:
            res[t] = _MEM[t]
        else:
            want.append(t)
    if want:
        got = _google_batch(want)
        miss = [t for t in want if t not in got]
        if miss:
            got.update(_mymemory_batch(miss))
            miss = [t for t in miss if t not in got]
        if miss and _ok("ai"):
            a = _ai_batch(miss)
            if not a:
                _cool("ai", 600)                    # AI 미연결·실패 — 매번 기다리지 않게
            got.update(a)
        if got:
            with _LOCK:
                _MEM.update(got)
                _DIRTY[0] = _DIRTY[0] or time.time() - 10
            _save()
        res.update(got)
    return res


def cached(titles):
    """이미 번역해 둔 것만 바로 돌려줌 (기다리지 않음)."""
    return {t: _MEM[t] for t in (x.strip() for x in titles if x) if t in _MEM}


_BG = {"busy": False, "q": []}


def _bg_run():
    try:
        while True:
            with _LOCK:
                todo, _BG["q"] = _BG["q"][:60], _BG["q"][60:]
                if not todo:
                    _BG["busy"] = False
                    return
            try:
                translate_titles(todo)
            except Exception:
                pass
    except Exception:
        _BG["busy"] = False


def warm(titles):
    """번역 안 된 제목을 뒤에서 번역해 둠 (다음에 바로 나오게). 화면은 기다리지 않음."""
    miss = [t for t in dict.fromkeys(x.strip() for x in titles if x and is_foreign(x)) if t not in _MEM]
    if not miss:
        return
    with _LOCK:
        _BG["q"].extend(t for t in miss if t not in _BG["q"])
        _BG["q"] = _BG["q"][-300:]
        if _BG["busy"]:
            return
        _BG["busy"] = True
    threading.Thread(target=_bg_run, daemon=True).start()


def add_ko(items, key="title", nested=("more",), wait=False):
    """뉴스 목록(dict)에 'title_ko' 를 붙임. 하위 목록(비슷한 기사)도 함께. 원본 목록을 바꾸고 그대로 돌려줌.
    wait=False(기본): 번역해 둔 것만 바로 붙이고, 나머지는 뒤에서 번역 (화면이 느려지지 않게 · v3.8)."""
    if not items:
        return items
    flat = []
    for it in items:
        if isinstance(it, dict):
            flat.append(it)
            for n in nested:
                flat.extend(x for x in (it.get(n) or []) if isinstance(x, dict))
    titles = [str(x.get(key) or "") for x in flat]
    try:
        tr = translate_titles(titles) if wait else cached(titles)
        if not wait:
            warm(titles)
    except Exception:
        tr = {}
    for x in flat:
        k = tr.get(str(x.get(key) or "").strip())
        if k:
            x[key + "_ko"] = k
    return items
