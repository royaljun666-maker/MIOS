"""
council.py — 🏛 AI 위원회 토론 (v4.0)

한 명의 AI가 한 번 답하는 대신, 관점이 다른 여섯 명의 '패널'이 같은 자료를 따로 읽고(1라운드),
서로의 주장을 보고 질문·반박한 뒤(2라운드), 의장이 합의·쟁점·시나리오·미리 볼 신호로 정리한다.

정보 제공 한정 원칙(COMPLIANCE)을 그대로 따른다:
  · 사라·팔라 같은 행동 지시, 확률 예측 없음 — '어느 쪽 근거가 많고 강한지'만
  · '선제 대응'은 행동이 아니라 '먼저 보일 신호'를 숫자 조건으로 정해 두고 앱이 지켜보는 것

숫자는 앱이 모은 자료(지표·뉴스 제목·일봉 계산값)만 쓰게 하고,
의장이 낸 감시 신호는 앱이 다시 검사해(지표 이름·현재값과의 거리) 엉뚱한 것은 버린다.
"""
import json
import math
import re
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

ps = None                     # price_server 모듈 (register 때 넣음)
md = None                     # market_data 모듈

PANEL = [
    {"id": "macro", "name": "거시 경제학자", "emoji": "🌍",
     "focus": "금리·환율·달러·경기·중앙은행·원자재 흐름이 시장 전체(와 이 종목)에 주는 영향",
     "how": "지표 숫자의 방향과 크기로 말하세요. 금리·환율·달러 인덱스·유가가 어느 쪽 근거인지 분명히."},
    {"id": "tech", "name": "차트 분석가", "emoji": "📈",
     "focus": "추세(이동평균), 최근 고점·저점, 한 달 흐름, 평소보다 큰 움직임, RSI·MACD 같은 기술 지표",
     "how": "자료의 계산값(평균 대비 위치, 한 달 변화, 이상 움직임 z값 등)만 근거로. 차트 모양을 상상해서 말하지 마세요."},
    {"id": "fund", "name": "실적 분석가", "emoji": "🏭",
     "focus": "기업 실적·밸류에이션(PER·PBR·ROE)·업종 흐름, 시장이면 업종별 이익 기대와 주도 업종",
     "how": "실적·지표 숫자가 없으면 '자료 없음'이라고 말하고 뉴스 제목에서 확인되는 실적 이야기만 쓰세요."},
    {"id": "flow", "name": "수급·심리 분석가", "emoji": "💸",
     "focus": "공포·탐욕 지수, VIX, 뉴스 제목의 분위기, 외국인·기관 수급 이야기, 쏠림·과열",
     "how": "심리 지표 숫자와 뉴스 제목의 톤을 근거로. 과열·공포가 극단이면 그 자체도 근거로 다루세요."},
    {"id": "risk", "name": "리스크 감시자", "emoji": "🛡",
     "focus": "다들 놓치기 쉬운 위험, 한쪽으로 쏠린 해석의 허점, 꼬리 위험(드물지만 크게 아픈 일)",
     "how": "일부러 반대편에 서서 '이게 틀린다면 왜일까'를 찾는 역할입니다. 근거 없이 겁주지는 마세요."},
    {"id": "hist", "name": "역사 연구가", "emoji": "📚",
     "focus": "지금과 비슷했던 과거 국면(금리·환율·지수 흐름·뉴스 주제가 닮은 때)과 그 뒤에 흔히 나타난 흐름",
     "how": "과거 이야기는 기억에 기댄 것이니 '과거 비슷한 때에는 ~한 경우가 많았다' 정도로만, 구체적 수익률 숫자는 쓰지 마세요."},
]
PIDS = [p["id"] for p in PANEL]
PBY = {p["id"]: p for p in PANEL}

# 앱이 지켜볼 수 있는 지표 (의장이 고르는 '먼저 보일 신호'는 이 안에서만)
METRICS = {
    "kospi": ("코스피", ""), "kosdaq": ("코스닥", ""), "sp500": ("S&P 500", ""), "nasdaq": ("나스닥", ""),
    "sox": ("필라델피아 반도체", ""), "usdkrw": ("원/달러 환율", "원"), "us10y": ("미국 10년 국채금리", "%"),
    "dxy": ("달러 인덱스", ""), "vix": ("VIX 공포지수", ""), "wti": ("WTI 유가", "$"), "gold": ("금", "$"),
    "krw-btc": ("비트코인", "원"), "fg": ("공포·탐욕 지수", "점"), "stock": ("이 종목 주가", ""),
}
WIDE = {"vix": 0.8, "fg": 1.5, "us10y": 0.35, "krw-btc": 0.4}   # 지표마다 '말이 되는' 거리 (현재값 대비)

_PACKS = {}
_PLOCK = threading.Lock()


# ── 자료 묶음 ─────────────────────────────────────────────────────────────
def _mkt_items():
    c = md._cget("market", 300)
    if c and c.get("items"):
        return c["items"]
    with ThreadPoolExecutor(max_workers=10) as ex:
        items = [x for x in ex.map(md._one_market, md.MARKET_ITEMS) if x]
        up = ex.submit(md._upbit).result()
    data = {"items": items + up, "updated": time.strftime("%Y-%m-%d %H:%M")}
    if items:
        md._cset("market", data)
    return data["items"]


def _fg():
    c = md._cget("sent", 1800)
    if c and c.get("stock"):
        return c["stock"]
    try:
        with ps.app.test_request_context():
            r = md.api_sentiment()
        d = r.get_json() if hasattr(r, "get_json") else None
        return (d or {}).get("stock")
    except Exception:
        return None


def _stats(x):
    """22일 스파크라인으로 계산: 하루·한 달 변화, 20일 평균 대비, 한 달 고저, 오늘 움직임의 크기(z)."""
    sp = [v for v in (x.get("spark") or []) if isinstance(v, (int, float))]
    last = x.get("price")
    out = {"last": last, "d1": x.get("change_pct")}
    if len(sp) >= 5 and last:
        out["m1"] = (last / sp[0] - 1) * 100 if sp[0] else None
        base = sp[-20:]
        avg = sum(base) / len(base)
        out["avg20"] = avg
        out["vs_avg"] = (last / avg - 1) * 100 if avg else None
        out["hi"], out["lo"] = max(sp), min(sp)
        rets = [(sp[i] / sp[i - 1] - 1) * 100 for i in range(1, len(sp)) if sp[i - 1]]
        if len(rets) >= 5 and out["d1"] is not None:
            mu = sum(rets) / len(rets)
            sd = math.sqrt(sum((r - mu) ** 2 for r in rets) / len(rets)) or None
            out["z"] = (out["d1"] - mu) / sd if sd else None
        out["prev_vs_avg"] = (sp[-2] / avg - 1) * 100 if len(sp) >= 2 and avg else None
    return out


def _f(v, nd=2):
    if v is None:
        return "?"
    s = format(v, ",.%df" % nd)
    return s.rstrip("0").rstrip(".") if "." in s else s


def market_alerts(by, fg):
    """AI 없이 숫자로 잡는 '시장 이상 신호' — 홈 경보와 위원회 자료에 같이 씀."""
    al = []

    def add(level, key, text):
        al.append({"level": level, "key": key, "text": text})
    v = by.get("vix")
    if v and v.get("last"):
        if v["last"] >= 30:
            add("red", "vix30", "VIX 공포지수 %s — 30 이상(시장 불안이 큰 구간)" % _f(v["last"], 1))
        elif v["last"] >= 22:
            add("orange", "vix22", "VIX 공포지수 %s — 평소(15~20)보다 높음" % _f(v["last"], 1))
        if (v.get("d1") or 0) >= 15:
            add("orange", "vixjump", "VIX 하루 %+.1f%% 급등" % v["d1"])
    for k, nm in (("kospi", "코스피"), ("kosdaq", "코스닥"), ("sp500", "S&P 500"), ("nasdaq", "나스닥"), ("sox", "반도체 지수")):
        x = by.get(k)
        if not x or x.get("d1") is None:
            continue
        if x["d1"] <= -2.5:
            add("red", k + "drop", "%s 하루 %+.2f%% 큰 하락" % (nm, x["d1"]))
        elif x["d1"] >= 2.5:
            add("orange", k + "jump", "%s 하루 %+.2f%% 큰 상승" % (nm, x["d1"]))
        elif x.get("z") is not None and abs(x["z"]) >= 2.2:
            add("orange", k + "z", "%s 오늘 움직임(%+.2f%%)이 한 달 평소보다 큼" % (nm, x["d1"]))
        if x.get("prev_vs_avg") is not None and x.get("vs_avg") is not None and k in ("kospi", "sp500", "nasdaq"):
            if x["prev_vs_avg"] >= 0 > x["vs_avg"]:
                add("orange", k + "ma", "%s가 20일 평균 아래로 내려옴" % nm)
            elif x["prev_vs_avg"] <= 0 < x["vs_avg"]:
                add("normal", k + "ma_up", "%s가 20일 평균 위로 올라섬" % nm)
    u = by.get("usdkrw")
    if u and u.get("last") and u.get("hi"):
        if u["last"] >= u["hi"] * 0.999:
            add("orange", "krwhi", "원/달러 %s원 — 한 달 중 가장 높은 수준" % _f(u["last"], 1))
        if abs(u.get("d1") or 0) >= 1.0:
            add("orange", "krwmove", "원/달러 하루 %+.2f%% 크게 움직임" % u["d1"])
    t = by.get("us10y")
    if t and t.get("last") and t.get("m1") is not None and abs(t["m1"]) >= 7:
        add("orange", "tnx", "미국 10년 금리 %s%% — 한 달 %+.1f%% 변화" % (_f(t["last"]), t["m1"]))
    w = by.get("wti")
    if w and abs(w.get("d1") or 0) >= 4:
        add("orange", "wti", "WTI 유가 하루 %+.1f%%" % w["d1"])
    if fg and fg.get("score") is not None:
        if fg["score"] <= 25:
            add("orange", "fglow", "공포·탐욕 지수 %d — 극단적 공포" % fg["score"])
        elif fg["score"] >= 75:
            add("orange", "fghigh", "공포·탐욕 지수 %d — 극단적 탐욕(과열)" % fg["score"])
    rank = {"red": 0, "orange": 1, "normal": 2}
    return sorted(al, key=lambda a: rank[a["level"]])


def levels(stocks=()):
    """감시 신호 확인용 현재값 + 시장 이상 신호."""
    items = _mkt_items()
    by = {x["id"]: _stats(x) for x in items}
    fg = _fg()
    cur = {k: v["last"] for k, v in by.items() if k in METRICS and v.get("last") is not None}
    if fg and fg.get("score") is not None:
        cur["fg"] = fg["score"]
    st = {}
    for s in list(stocks)[:20]:
        t, _, m = s.partition(":")
        try:
            p = ps.get_price(t, m or "kr") if hasattr(ps, "get_price") else None
        except Exception:
            p = None
        if isinstance(p, dict) and p.get("price"):
            st[s] = p["price"]
    return {"cur": cur, "stocks": st, "alerts": market_alerts(by, fg), "at": int(time.time())}


def _market_block(kind):
    items = _mkt_items()
    by = {x["id"]: _stats(x) for x in items}
    names = {x["id"]: (x["name"], x.get("unit") or "") for x in items}
    order = (["kospi", "kosdaq", "usdkrw", "sp500", "nasdaq", "sox", "us10y", "dxy", "vix", "wti", "gold", "krw-btc"]
             if kind == "kr" else
             ["sp500", "nasdaq", "dow", "sox", "us10y", "dxy", "vix", "wti", "gold", "kospi", "usdkrw", "krw-btc"])
    lines = []
    for k in order:
        x = by.get(k)
        if not x or x.get("last") is None:
            continue
        nm, unit = names.get(k, (k, ""))
        bits = ["지금 %s%s" % (_f(x["last"]), unit)]
        if x.get("d1") is not None:
            bits.append("전일 %+.2f%%" % x["d1"])
        if x.get("m1") is not None:
            bits.append("한 달 %+.1f%%" % x["m1"])
        if x.get("vs_avg") is not None:
            bits.append("20일 평균 대비 %+.1f%%" % x["vs_avg"])
        if x.get("hi") and x.get("lo"):
            bits.append("한 달 범위 %s~%s" % (_f(x["lo"]), _f(x["hi"])))
        if x.get("z") is not None and abs(x["z"]) >= 1.5:
            bits.append("오늘 움직임 평소의 %.1f배" % abs(x["z"]))
        lines.append("- [%s] %s: %s" % (k, nm, " · ".join(bits)))
    fg = _fg()
    if fg and fg.get("score") is not None:
        lines.append("- [fg] 공포·탐욕 지수(미국 주식): %d점 (%s) · 1주 전 %s · 1달 전 %s" % (
            fg["score"], fg.get("rating") or "", fg.get("week", "?"), fg.get("month", "?")))
    cur = {k: v["last"] for k, v in by.items() if v.get("last") is not None}
    if fg and fg.get("score") is not None:
        cur["fg"] = fg["score"]
    return lines, market_alerts(by, fg), cur


def build_pack(target, mine=(), past=""):
    kind = target.get("kind") or "market"
    mk = "us" if target.get("mkt") == "us" else "kr"
    lines, alerts, cur = _market_block(mk if kind == "market" else ("kr" if target.get("market") != "us" else "us"))
    try:
        heads = ps.get_market_headlines(days=2, limit_per=6)[:14]
    except Exception:
        heads = []
    title = "한국 시장" if (kind == "market" and mk == "kr") else "미국 시장" if kind == "market" else (target.get("name") or target.get("ticker") or "종목")
    stock_lines, stock_heads, lv = [], [], None
    if kind == "stock":
        t = str(target.get("ticker") or "").strip()
        m = "us" if target.get("market") == "us" else "kr"
        name = target.get("name") or t
        try:
            d = md.chart_rows(t, m, "1y", "1d")
            rows = (d or {}).get("rows") or []
        except Exception:
            rows = []
        ccy = "USD" if m == "us" else "KRW"
        if len(rows) >= 60:
            ind = md.tech_indicators(rows)
            cur["stock"] = ind["last"]
            r = ind["ret"]
            stock_lines += [
                "- [stock] 지금 주가 %s · 1주 %s · 1달 %s · 3달 %s · 1년 %s" % (
                    ps._fmt_px(ind["last"], ccy), *[("%+.1f%%" % r[k]) if r.get(k) is not None else "?" for k in ("1주", "1달", "3달", "1년")]),
                "- 이동평균: 5일 %s · 20일 %s · 60일 %s · 120일 %s" % tuple(ps._fmt_px(ind["ma"][n], ccy) if ind["ma"].get(n) else "?" for n in (5, 20, 60, 120)),
                "- RSI(14) %.0f · MACD 히스토그램 %s(이전 %s) · 거래량 5일/20일 %.2f배 · 하루 평균 변동폭(ATR) %s" % (
                    ind["rsi"], _f(ind["macd_hist"], 3), _f(ind.get("macd_hist_prev"), 3), ind.get("vol_ratio") or 0,
                    ("%.1f%%" % ind["atr_pct"]) if ind.get("atr_pct") else "?"),
                "- 52주 고점 대비 %+.1f%% · 저점 대비 %+.1f%% · 최근 20일 저점 %s / 고점 %s · 60일 저점 %s / 고점 %s%s" % (
                    ind["from_hi"], ind["from_lo"], ps._fmt_px(ind["sup20"], ccy), ps._fmt_px(ind["res20"], ccy),
                    ps._fmt_px(ind["sup60"], ccy), ps._fmt_px(ind["res60"], ccy), (" · " + ind["cross"]) if ind.get("cross") else ""),
            ]
            try:
                lv = ps.ref_levels(rows, "", ind["last"], ccy)
            except Exception:
                lv = None
        try:
            fb = ps._fund_bundle(t, m)
            bits = []
            for k, lab in (("per", "PER"), ("fper", "예상 PER"), ("pbr", "PBR"), ("roe", "ROE"), ("op_margin", "영업이익률"), ("peg", "PEG")):
                if fb.get(k) is not None:
                    bits.append("%s %s" % (lab, _f(fb[k])))
            if fb.get("op_trend"):
                bits.append("영업이익 추세 " + str(fb["op_trend"])[:60])
            if bits:
                stock_lines.append("- 실적·가치 지표: " + " · ".join(bits) + (" (기준 %s)" % fb["asof"] if fb.get("asof") else ""))
        except Exception:
            pass
        try:
            news = ps.get_news(t, m, name)
            stock_heads = [n["title"] for n in news if n.get("title")][:12]
        except Exception:
            stock_heads = []
    now = ps._kst_now().strftime("%Y-%m-%d %H:%M (%a) KST")
    txt = ["[지금 시각] " + now, "[주제] " + title + (" (" + str(target.get("ticker")) + ")" if kind == "stock" else "")]
    if stock_lines:
        txt += ["", "[이 종목 숫자 — 앱이 일봉으로 계산]"] + stock_lines
        if lv:
            txt += ["", ps.levels_block(lv)]
    txt += ["", "[시장 지표 — 대괄호 안은 지표 이름표]"] + (lines or ["- (지표를 못 가져옴)"])
    if alerts:
        txt += ["", "[앱이 숫자로 잡은 이상 신호]"] + ["- " + a["text"] for a in alerts[:8]]
    if stock_heads:
        txt += ["", "[이 종목 최근 뉴스 제목]"] + ["- " + h for h in stock_heads]
    txt += ["", "[시장 뉴스 제목 (최근 이틀)]"] + (["- " + h for h in heads] or ["- (없음)"])
    if mine:
        txt += ["", "[사용자가 보유·관심 중인 종목 이름]", ", ".join(str(x)[:20] for x in list(mine)[:20])]
    if past:
        txt += ["", "[지난 위원회 결론과 그 뒤 실제 움직임 — 맞고 틀린 이유를 짚고 같은 실수를 반복하지 마세요]", str(past)[:900]]
    return {"title": title, "kind": kind, "text": "\n".join(txt), "alerts": alerts, "cur": cur, "levels": lv,
            "news": len(heads) + len(stock_heads), "target": target}


# ── AI 호출 ───────────────────────────────────────────────────────────────
def _sys(extra):
    return (ps.COMPLIANCE +
            "[위원회 규칙]\n"
            "- 숫자는 [자료]에 있는 것만 쓰세요. 자료에 없는 가격·지표·실적을 만들지 마세요. 없으면 '자료 없음'.\n"
            "- 확률·퍼센트 예측(오를 확률 등)은 쓰지 마세요. 근거마다 세기(강·중·약)만 붙이세요.\n"
            "- 쉬운 한국어로 짧게. 답은 지정한 JSON 하나만 출력하세요(설명·코드블록 표시 없이).\n" + extra)


def _call(prompt, system, max_out=1400, temp=0.6):
    text, prov, mdl, err = ps.ai_engine.complete(prompt=prompt, max_out=max_out, system=system, temperature=temp)
    return text, prov, mdl, err


def _json(text):
    if not text:
        return None
    t = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    for pat in (r"\{.*\}", r"\[.*\]"):
        m = re.search(pat, t, re.S)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                s = re.sub(r",\s*([}\]])", r"\1", m.group(0))          # 끝 쉼표 같은 흔한 실수
                try:
                    return json.loads(s)
                except Exception:
                    pass
    return None


_GRADES = {"강": 3, "중": 2, "약": 1}


def _claims(arr):
    out = []
    for c in (arr or [])[:5]:
        if isinstance(c, str):
            c = {"t": c}
        if not isinstance(c, dict) or not str(c.get("t") or "").strip():
            continue
        g = str(c.get("g") or "중")[:1]
        out.append({"t": str(c["t"])[:160], "g": g if g in _GRADES else "중", "src": str(c.get("src") or "")[:60]})
    return out


def _stance(v):
    v = str(v or "")
    return "긍정" if "긍정" in v else "부정" if "부정" in v else "중립"


def _strength(v):
    try:
        return max(0, min(100, int(float(v))))
    except (TypeError, ValueError):
        return 50


R1_FORMAT = """{"stance":"긍정|중립|부정","strength":0~100(내 근거의 강도, 확률 아님),"headline":"내 관점 한 줄 요약",
"up":[{"t":"오를 수 있는 근거","g":"강|중|약","src":"근거가 된 자료(지표 이름표나 뉴스 제목 일부)"}],
"down":[{"t":"내릴 수 있는 근거","g":"강|중|약","src":"..."}],
"watch":[{"metric":"지표 이름표","op":">=|<=","value":숫자,"why":"이 선을 넘으면 어떤 근거가 강해지는지"}],
"ask":{"to":"질문할 패널 id","q":"그 패널에게 묻고 싶은 한 문장"}}"""


def speak_r1(pack, pid):
    p = PBY[pid]
    others = ", ".join("%s(%s)" % (x["id"], x["name"]) for x in PANEL if x["id"] != pid)
    prompt = f"""당신은 'AI 위원회'의 {p['emoji']} {p['name']}입니다.
맡은 관점: {p['focus']}
말하는 법: {p['how']}

아래 [자료]를 당신의 관점에서만 읽고, '{pack['title']}'에 대해 오를 수 있는 근거와 내릴 수 있는 근거를 각각 0~4개 고르세요.
- 관점 밖의 이야기는 다른 패널이 합니다. 겹치지 않게 당신 관점에 집중하세요.
- watch: 앞으로 먼저 보일 신호 1~2개. metric 은 [자료]의 대괄호 이름표 중 하나({", ".join(k for k in METRICS)}), value 는 지금 값 근처의 현실적인 숫자.
- ask: 다른 패널({others}) 중 한 명에게 진짜 궁금한 것 하나 (다음 라운드에 그 패널이 답합니다).

[자료]
{pack['text']}

[출력 — 이 JSON 하나만]
{R1_FORMAT}"""
    text, prov, mdl, err = _call(prompt, _sys("- 당신은 위원회의 한 사람일 뿐입니다. 결론을 내리지 말고 당신 관점의 근거만.\n"), 1300)
    j = _json(text) if text else None
    if not isinstance(j, dict):
        return {"ok": False, "id": pid, "error": "NO_KEY" if err == "NO_KEY" else (str(err or "형식이 맞지 않은 답")[:120])}
    ask = j.get("ask") if isinstance(j.get("ask"), dict) else {}
    return {"ok": True, "id": pid, "stance": _stance(j.get("stance")), "strength": _strength(j.get("strength")),
            "headline": str(j.get("headline") or "")[:140], "up": _claims(j.get("up")), "down": _claims(j.get("down")),
            "watch": [w for w in (j.get("watch") or [])[:3] if isinstance(w, dict)],
            "ask": {"to": ask.get("to") if ask.get("to") in PIDS and ask.get("to") != pid else "", "q": str(ask.get("q") or "")[:160]},
            "provider": prov, "model": mdl}


def _r1_digest(r1, skip=None):
    out = []
    for pid in PIDS:
        r = r1.get(pid)
        if not r or not r.get("ok") or pid == skip:
            continue
        p = PBY[pid]
        up = "; ".join("[%s] %s" % (c["g"], c["t"]) for c in r["up"]) or "-"
        dn = "; ".join("[%s] %s" % (c["g"], c["t"]) for c in r["down"]) or "-"
        out.append(f"■ {p['emoji']} {p['name']}({pid}) — {r['stance']} · 근거 강도 {r['strength']}\n  한 줄: {r['headline']}\n  오를 근거: {up}\n  내릴 근거: {dn}" +
                   (f"\n  → {r['ask']['to']}에게 질문: {r['ask']['q']}" if r.get("ask", {}).get("q") else ""))
    return "\n".join(out)


R2_FORMAT = """{"reply":"나에게 온 질문에 대한 답(질문이 없으면 빈 문자열)",
"rebut":[{"to":"패널 id","kind":"반박|보완|동의","t":"그 패널 주장에 대한 한두 문장"}],
"changed":"토론을 듣고 생각이 바뀐 점(없으면 빈 문자열)",
"stance":"긍정|중립|부정","strength":0~100,"headline":"토론 뒤 내 관점 한 줄"}"""


def speak_r2(pack, pid, r1):
    p = PBY[pid]
    mine = r1.get(pid) or {}
    asked = [(q, r1[q]["ask"]["q"]) for q in PIDS if r1.get(q, {}).get("ok") and r1[q].get("ask", {}).get("to") == pid]
    qtxt = "\n".join(f"- {PBY[q]['name']}({q}): {t}" for q, t in asked) or "(없음)"
    prompt = f"""당신은 'AI 위원회'의 {p['emoji']} {p['name']}입니다 (맡은 관점: {p['focus']}).
1라운드에서 당신은 '{mine.get('stance', '중립')}'(근거 강도 {mine.get('strength', 50)}) — "{mine.get('headline', '')}" 라고 했습니다.

[다른 패널들의 1라운드 의견]
{_r1_digest(r1, skip=pid)}

[당신에게 온 질문]
{qtxt}

이번 라운드에서 쓸 것:
1) 질문이 있으면 [자료]의 숫자·뉴스로 답하세요.
2) 다른 패널 주장 1~3개에 반박·보완·동의하세요. 근거가 약하거나 자료와 다른 주장은 분명히 짚으세요.
3) 설득력 있는 반박을 들었으면 입장을 바꿔도 됩니다(바꾼 이유를 changed 에). 고집도, 쉽게 따라가기도 하지 마세요.

[자료]
{pack['text']}

[출력 — 이 JSON 하나만]
{R2_FORMAT}"""
    text, prov, mdl, err = _call(prompt, _sys(""), 1100)
    j = _json(text) if text else None
    if not isinstance(j, dict):
        return {"ok": False, "id": pid, "error": "NO_KEY" if err == "NO_KEY" else (str(err or "형식이 맞지 않은 답")[:120])}
    reb = []
    for r in (j.get("rebut") or [])[:3]:
        if isinstance(r, dict) and r.get("to") in PIDS and r.get("to") != pid and str(r.get("t") or "").strip():
            k = str(r.get("kind") or "")
            reb.append({"to": r["to"], "kind": k if k in ("반박", "보완", "동의") else "반박", "t": str(r["t"])[:220]})
    return {"ok": True, "id": pid, "reply": str(j.get("reply") or "")[:300], "asked": [{"from": q, "q": t} for q, t in asked],
            "rebut": reb, "changed": str(j.get("changed") or "")[:200],
            "stance": _stance(j.get("stance") or mine.get("stance")), "strength": _strength(j.get("strength", mine.get("strength"))),
            "headline": str(j.get("headline") or mine.get("headline") or "")[:140]}


FINAL_FORMAT = """{"summary":"3초 요약 — 지금 상황을 한두 문장(행동 지시 없이)",
"consensus":["패널 대부분이 동의한 점 2~4개"],
"disputes":[{"topic":"의견이 갈린 주제","a":"한쪽 주장(누가)","b":"다른 쪽 주장(누가)","key":"무엇을 보면 판가름 나는지"}],
"scenarios":[{"name":"좋게 풀리면","when":"어떤 조건에서","then":"그때 일어날 수 있는 흐름","sign":"먼저 보일 신호"},
             {"name":"지금 흐름대로면","when":"...","then":"...","sign":"..."},
             {"name":"나쁘게 풀리면","when":"...","then":"...","sign":"..."}],
"signals":[{"metric":"지표 이름표","op":">=|<=","value":숫자,"why":"이 선을 넘으면 무엇이 달라지는지","side":"up|down"}],
"check":["앞으로 며칠 함께 볼 일정·지표 2~4개 (행동 지시 없이)"],
"mine":[{"name":"사용자 종목 이름","why":"이번 토론 내용이 그 종목과 닿는 지점"}],
"blind":["이번 토론에서 자료가 부족했거나 확인이 필요한 부분 1~3개"]}"""


def chair(pack, r1, r2):
    def last(pid):
        a, b = r1.get(pid) or {}, (r2 or {}).get(pid) or {}
        return b if b.get("ok") else a
    debate = []
    for pid in PIDS:
        b = (r2 or {}).get(pid)
        if b and b.get("ok"):
            p = PBY[pid]
            seg = f"■ {p['name']}({pid}) 2라운드 — {b['stance']} · 근거 강도 {b['strength']} · {b['headline']}"
            if b.get("reply"):
                seg += f"\n  질문에 답: {b['reply']}"
            for r in b.get("rebut") or []:
                seg += f"\n  {r['kind']} → {PBY[r['to']]['name']}: {r['t']}"
            if b.get("changed"):
                seg += f"\n  생각이 바뀐 점: {b['changed']}"
            debate.append(seg)
    finals = ", ".join(f"{PBY[p]['name']} {last(p).get('stance', '?')}({last(p).get('strength', '?')})" for p in PIDS if last(p).get("ok"))
    prompt = f"""당신은 'AI 위원회'의 🧑‍⚖️ 의장입니다. 여섯 패널의 토론을 '{pack['title']}'에 대해 공정하게 정리하세요.
- 다수결로 결론 내지 말고, 근거의 양과 세기, 그리고 반박을 견딘 근거인지를 따지세요.
- 사라·팔라 같은 행동 지시, 확률 예측은 절대 쓰지 마세요. '무엇을 보면 판가름 나는지'를 알려 주는 것이 당신의 일입니다.
- signals: 앱이 자동으로 지켜볼 '먼저 보일 신호' 2~5개. metric 은 반드시 이 중 하나: {", ".join(METRICS)} (stock 은 종목 토론일 때만).
  value 는 지금 값 근처의 현실적인 선(이미 넘은 선 말고 앞으로 넘을 수 있는 선), side 는 그 선을 넘으면 강해지는 쪽(up=오를 근거, down=내릴 근거).
- mine: 사용자 종목 중 이번 토론 내용과 실제로 닿는 것만(없으면 빈 배열). 그 종목을 어떻게 하라는 말은 하지 마세요.

[1라운드 — 각자 의견]
{_r1_digest(r1)}

[2라운드 — 질문·반박]
{chr(10).join(debate) or "(이번엔 1라운드만 진행)"}

[최종 입장] {finals}

[자료]
{pack['text']}

[출력 — 이 JSON 하나만]
{FINAL_FORMAT}"""
    text, prov, mdl, err = _call(prompt, _sys("- 당신은 결론을 강요하지 않는 진행자입니다.\n"), 2200, 0.4)
    j = _json(text) if text else None
    if not isinstance(j, dict):
        return {"ok": False, "error": "NO_KEY" if err == "NO_KEY" else (str(err or "형식이 맞지 않은 답")[:120])}
    return finalize(pack, r1, r2, j, prov, mdl)


def _num(v):
    try:
        return float(str(v).replace(",", ""))
    except (TypeError, ValueError):
        return None


def clean_signals(raw, cur, kind):
    """의장·패널이 낸 신호를 앱이 다시 검사 — 모르는 지표, 지금 값과 너무 먼 선, 이미 넘은 선은 버림."""
    out, seen = [], set()
    for s in raw or []:
        if not isinstance(s, dict):
            continue
        m = str(s.get("metric") or "").strip().lower()
        op = str(s.get("op") or "").strip()
        v = _num(s.get("value"))
        if m not in METRICS or op not in (">=", "<=") or v is None or (m == "stock" and kind != "stock"):
            continue
        now = cur.get(m)
        if now is None or now == 0:
            continue
        gap = abs(v / now - 1)
        if gap > WIDE.get(m, 0.15) or gap < 0.002:
            continue
        if (op == ">=" and now >= v) or (op == "<=" and now <= v):
            continue                                       # 이미 넘은 선은 '먼저 보일 신호'가 아님
        k = (m, op)
        if k in seen:
            continue
        seen.add(k)
        side = "up" if str(s.get("side") or "") == "up" else "down" if str(s.get("side") or "") == "down" else ""
        out.append({"metric": m, "label": METRICS[m][0], "unit": METRICS[m][1], "op": op, "value": v, "now": now,
                    "gap": round((v / now - 1) * 100, 2), "why": str(s.get("why") or "")[:160], "side": side})
    return out[:6]


def finalize(pack, r1, r2, j, prov=None, mdl=None):
    def last(pid):
        a, b = r1.get(pid) or {}, (r2 or {}).get(pid) or {}
        return b if b.get("ok") else a
    up = [c for p in PIDS if (r1.get(p) or {}).get("ok") for c in r1[p]["up"]]
    dn = [c for p in PIDS if (r1.get(p) or {}).get("ok") for c in r1[p]["down"]]
    up_pts, dn_pts = sum(_GRADES[c["g"]] for c in up), sum(_GRADES[c["g"]] for c in dn)
    tally = {"긍정": 0, "중립": 0, "부정": 0}
    for p in PIDS:
        if last(p).get("ok"):
            tally[last(p)["stance"]] += 1
    side = "오를 근거 쪽이 더 많음" if up_pts > dn_pts * 1.15 else "내릴 근거 쪽이 더 많음" if dn_pts > up_pts * 1.15 else "비슷함"
    raw = list(j.get("signals") or [])
    for p in PIDS:                                          # 패널이 낸 신호도 후보로 (의장 것이 먼저)
        for w in (r1.get(p) or {}).get("watch") or []:
            raw.append(dict(w, side=w.get("side") or ""))
    sc = []
    for s in (j.get("scenarios") or [])[:3]:
        if isinstance(s, dict):
            sc.append({k: str(s.get(k) or "")[:220] for k in ("name", "when", "then", "sign")})
    disp = []
    for d in (j.get("disputes") or [])[:4]:
        if isinstance(d, dict) and d.get("topic"):
            disp.append({k: str(d.get(k) or "")[:220] for k in ("topic", "a", "b", "key")})
    strs = lambda arr, n, ln=200: [str(x)[:ln] for x in (arr or [])[:n] if str(x).strip()]
    return {"ok": True, "summary": str(j.get("summary") or "")[:300],
            "balance": {"up": len(up), "down": len(dn), "up_pts": up_pts, "down_pts": dn_pts, "side": side},
            "tally": tally, "consensus": strs(j.get("consensus"), 5), "disputes": disp, "scenarios": sc,
            "signals": clean_signals(raw, pack["cur"], pack["kind"]), "check": strs(j.get("check"), 5),
            "mine": [{"name": str(x.get("name") or "")[:30], "why": str(x.get("why") or "")[:180]} for x in (j.get("mine") or [])[:5] if isinstance(x, dict) and x.get("name")],
            "blind": strs(j.get("blind"), 3), "provider": prov, "model": mdl}


QUICK_FORMAT = """{"panel":[{"id":"macro|tech|fund|flow|risk|hist","stance":"긍정|중립|부정","strength":0~100,"headline":"한 줄",
"up":[{"t":"근거","g":"강|중|약","src":"자료"}],"down":[{"t":"근거","g":"강|중|약","src":"자료"}],
"rebut":{"to":"다른 패널 id","kind":"반박|보완|동의","t":"한 문장"}}],
"final": """ + FINAL_FORMAT + "}"


def quick(pack):
    """AI 한 번으로 위원회를 흉내 (빠르게) — 같은 결과 모양."""
    roles = "\n".join(f"- {p['id']}: {p['emoji']} {p['name']} — {p['focus']}" for p in PANEL)
    prompt = f"""'AI 위원회'를 진행하세요. 아래 여섯 패널이 [자료]를 각자 관점에서 읽고 근거를 낸 뒤, 서로 한 번씩 반박·보완하고,
의장이 정리합니다. 패널끼리 의견이 다를 수 있게 각 관점에 충실하세요.
{roles}
- signals metric 은 반드시 이 중 하나: {", ".join(METRICS)}. 이미 넘은 선 말고 앞으로 넘을 수 있는 선.

[자료]
{pack['text']}

[출력 — 이 JSON 하나만]
{QUICK_FORMAT}"""
    text, prov, mdl, err = _call(prompt, _sys(""), 3600, 0.5)
    j = _json(text) if text else None
    if not isinstance(j, dict) or not isinstance(j.get("panel"), list):
        return {"ok": False, "error": "NO_KEY" if err == "NO_KEY" else (str(err or "형식이 맞지 않은 답")[:120])}
    r1, r2 = {}, {}
    for x in j["panel"]:
        if not isinstance(x, dict) or x.get("id") not in PIDS:
            continue
        pid = x["id"]
        r1[pid] = {"ok": True, "id": pid, "stance": _stance(x.get("stance")), "strength": _strength(x.get("strength")),
                   "headline": str(x.get("headline") or "")[:140], "up": _claims(x.get("up")), "down": _claims(x.get("down")),
                   "watch": [], "ask": {"to": "", "q": ""}}
        rb = x.get("rebut") if isinstance(x.get("rebut"), dict) else None
        if rb and rb.get("to") in PIDS and rb.get("to") != pid and rb.get("t"):
            k = str(rb.get("kind") or "")
            r2[pid] = {"ok": True, "id": pid, "reply": "", "asked": [], "changed": "",
                       "rebut": [{"to": rb["to"], "kind": k if k in ("반박", "보완", "동의") else "반박", "t": str(rb["t"])[:220]}],
                       "stance": r1[pid]["stance"], "strength": r1[pid]["strength"], "headline": r1[pid]["headline"]}
    fin = finalize(pack, r1, r2, j.get("final") if isinstance(j.get("final"), dict) else {}, prov, mdl)
    return {"ok": True, "r1": r1, "r2": r2, "final": fin}


# ── 저장소 (진행 중인 토론) ─────────────────────────────────────────────────
def _put(pack):
    cid = uuid.uuid4().hex[:12]
    with _PLOCK:
        for k in [k for k, v in _PACKS.items() if time.time() - v["at"] > 3600]:
            _PACKS.pop(k, None)
        while len(_PACKS) >= 20:
            _PACKS.pop(next(iter(_PACKS)))
        _PACKS[cid] = {"at": time.time(), "pack": pack, "r1": {}, "r2": {}}
    return cid


def _get(cid):
    with _PLOCK:
        return _PACKS.get(str(cid or ""))


# ── 경로 ─────────────────────────────────────────────────────────────────
def register(server):
    global ps, md
    ps, md = server, server.market_data
    app = server.app
    from flask import request, jsonify

    def _target(q):
        t = q.get("target") if isinstance(q.get("target"), dict) else {}
        if t.get("kind") == "stock" and str(t.get("ticker") or "").strip():
            return {"kind": "stock", "ticker": str(t["ticker"]).strip()[:20], "market": "us" if t.get("market") == "us" else "kr",
                    "name": str(t.get("name") or "")[:40]}
        return {"kind": "market", "mkt": "us" if t.get("mkt") == "us" else "kr"}

    @app.post("/api/council/start")
    def route_council_start():
        q = request.get_json(force=True, silent=True) or {}
        if not ps.ai_engine.candidates():
            return jsonify({"ok": False, "status": "no_key"})
        pack = build_pack(_target(q), [str(x) for x in (q.get("mine") or [])][:20], str(q.get("past") or "")[:900])
        cid = _put(pack)
        return jsonify({"ok": True, "id": cid, "title": pack["title"], "kind": pack["kind"], "alerts": pack["alerts"],
                        "levels": pack["levels"], "news": pack["news"], "cur": pack["cur"],
                        "panel": [{k: p[k] for k in ("id", "name", "emoji", "focus")} for p in PANEL]})

    @app.post("/api/council/speak")
    def route_council_speak():
        q = request.get_json(force=True, silent=True) or {}
        st, pid, rnd = _get(q.get("id")), q.get("who"), int(q.get("round") or 1)
        if not st:
            return jsonify({"ok": False, "error": "토론이 끝났거나 오래됐어요. 다시 시작해 주세요"})
        if pid not in PIDS:
            return jsonify({"ok": False, "error": "패널을 찾지 못했어요"})
        if rnd == 1:
            r = speak_r1(st["pack"], pid)
            if r.get("ok"):
                st["r1"][pid] = r
        else:
            if not st["r1"].get(pid, {}).get("ok"):
                return jsonify({"ok": False, "id": pid, "error": "1라운드 의견이 없어요"})
            r = speak_r2(st["pack"], pid, st["r1"])
            if r.get("ok"):
                st["r2"][pid] = r
        return jsonify(r)

    @app.post("/api/council/final")
    def route_council_final():
        q = request.get_json(force=True, silent=True) or {}
        st = _get(q.get("id"))
        if not st:
            return jsonify({"ok": False, "error": "토론이 끝났거나 오래됐어요. 다시 시작해 주세요"})
        if sum(1 for r in st["r1"].values() if r.get("ok")) < 2:
            return jsonify({"ok": False, "error": "의견을 낸 패널이 너무 적어요 (AI 한도·연결을 확인해 주세요)"})
        return jsonify(chair(st["pack"], st["r1"], st["r2"]))

    @app.post("/api/council/quick")
    def route_council_quick():
        q = request.get_json(force=True, silent=True) or {}
        if not ps.ai_engine.candidates():
            return jsonify({"ok": False, "status": "no_key"})
        pack = build_pack(_target(q), [str(x) for x in (q.get("mine") or [])][:20], str(q.get("past") or "")[:900])
        res = quick(pack)
        res.update(title=pack["title"], kind=pack["kind"], alerts=pack["alerts"], levels=pack["levels"], cur=pack["cur"],
                   panel=[{k: p[k] for k in ("id", "name", "emoji", "focus")} for p in PANEL])
        return jsonify(res)

    @app.get("/api/council/levels")
    def route_council_levels():
        stocks = [s for s in (request.args.get("stocks") or "").split(",") if s][:20]
        try:
            return jsonify(dict(levels(stocks), ok=True))
        except Exception as e:
            return jsonify({"ok": False, "error": type(e).__name__, "cur": {}, "alerts": []})
