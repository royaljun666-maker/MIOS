/* ==========================================================================
   license.js — 🎟 이용권(쿠폰)
   · 관리 파일(update.json)의 "license.required" 가 켜져 있으면, 쿠폰을 등록해 기간이 남아 있을 때만 앱을 씀
   · 쿠폰: 무료 체험 7일 / 1개월 / 3개월 / 6개월 … (주인 PC의 쿠폰 생성기로만 만듦)
   · 남은 기간이 있으면 새 쿠폰은 그 뒤에 이어 붙음 · 기간 3일 이하면 미리 알려 줌
   ========================================================================== */
'use strict';

let LIC = null;
const licDate = ms => { const d = new Date(ms); return d.getFullYear() + '.' + (d.getMonth() + 1) + '.' + d.getDate(); };
function fmtCoupon(v) {
  const s = String(v || '').toUpperCase().replace(/[^0-9A-Z]/g, '').slice(0, 16);
  return s.match(/.{1,4}/g) ? s.match(/.{1,4}/g).join('-') : '';
}

async function licenseCheck() {
  try { LIC = await api('/api/license', { timeout: 20000 }); } catch (e) { return; }
  if (!LIC) return;
  if (LIC.required && !LIC.active) { licenseLock(); return; }
  licenseUnlock();
  const once = (k, msg, ms) => { try { if (!localStorage.getItem(k)) { localStorage.setItem(k, '1'); setTimeout(() => toast(msg, ms || 5000), 2500); } } catch (e) {} };
  if (LIC.free) once('lic_free_' + LIC.free_until, '🎉 무료 오픈! ' + licDate(LIC.free_until - 1) + '까지 쿠폰 없이 모든 기능을 쓸 수 있어요', 6000);
  if (LIC.bonus_days > 0 && LIC.coupon_active) once('lic_bonus_' + LIC.bonus_days, '🎁 무료 오픈 기념 · 내 이용 기간이 ' + LIC.bonus_days + '일 늘었어요 (' + licDate(LIC.until) + '까지)', 6000);
  if (LIC.coupon_active && LIC.days_left <= 3 && !(LIC.free && LIC.free_until >= LIC.until)) {
    const k = 'lic_warn_' + todayKey();
    try { if (!localStorage.getItem(k)) { localStorage.setItem(k, '1'); setTimeout(() => toast('🎟 이용 기간이 ' + LIC.days_left + '일 남았어요 · 설정 → 이용권에서 쿠폰을 등록해 주세요', 5000), 2500); } } catch (e) {}
  }
  if (route && route.page === 'settings') { const s = document.getElementById('sec-license'); if (s) { s.innerHTML = licenseSecHtml(); wireLicenseSec(s); } }
}

function licPlansHtml(st) {
  const plans = (st && st.plans) || [];
  if (!plans.length) return '';
  return '<div class="lic-plans">' + plans.map(p => '<div class="lic-plan"><b>' + esc(p.name || '') + '</b><span>' + esc(p.price || '문의') + '</span></div>').join('') + '</div>';
}

/* 잠금 화면 — 쿠폰을 넣어야 열림 */
function licenseLock() {
  if (document.getElementById('licLock')) return;
  const st = LIC || {};
  const expired = st.count > 0 && !st.capped;
  const el = document.createElement('div');
  el.id = 'licLock'; el.className = 'lic-lock';
  el.innerHTML = '<div class="lic-box">' +
    '<div class="lic-ico">🎟</div>' +
    '<h2>' + (st.capped ? '지금은 정원이 다 찼어요' : expired ? '이용 기간이 끝났어요' : '쿠폰을 등록해 주세요') + '</h2>' +
    '<p>' + (expired ? '계속 쓰려면 새 쿠폰을 등록해 주세요. 내 계좌·기록은 그대로 남아 있어요.' : '내 투자 비서는 <b>쿠폰 번호</b>를 등록하면 쓸 수 있어요. 무료 체험 쿠폰도 있어요.') + '<br><span style="font-size:.8rem;color:var(--text-3)">이용권은 정보 정리·계산 도구를 쓰는 기간이에요. 투자 조언·종목 추천을 파는 것이 아니에요.</span></p>' +
    (st.capped ? '<div class="lic-notice">👥 ' + esc(st.cap_msg || '자리가 나면 다시 열려요') + (st.visitor && st.visitor.cap ? ' (정원 ' + st.visitor.cap + '명 · 내 순번 ' + st.visitor.rank + '번)' : '') + '<br><small>쿠폰이 있으면 정원과 상관없이 바로 쓸 수 있어요</small></div>' : '') +
    (st.notice ? '<div class="lic-notice">' + esc(st.notice) + '</div>' : '') +
    '<div class="lic-in"><input class="input tnum" id="licCode" placeholder="쿠폰 번호 입력" autocomplete="off" autocapitalize="characters" spellcheck="false">' +
    '<button class="btn btn-primary" id="licGo">등록</button></div>' +
    '<div class="lic-msg" id="licMsg"></div>' +
    licPlansHtml(st) +
    (st.contact ? '<button class="btn btn-soft btn-block" id="licBuy" style="margin-top:12px">💬 ' + esc(st.contact_label || '쿠폰 구매·문의하기') + '</button>' : '') +
    '<button class="btn btn-ghost btn-block" id="licQuit" style="margin-top:6px">앱 끄기</button></div>';
  document.body.appendChild(el);
  wireCouponInput(el, () => { el.classList.add('out'); setTimeout(() => el.remove(), 400); });
  const buy = el.querySelector('#licBuy'); if (buy) buy.onclick = () => openExt(st.contact);
  el.querySelector('#licQuit').onclick = () => { try { if (window.AndroidBridge && AndroidBridge.exitApp) AndroidBridge.exitApp(); else quitApp(); } catch (e) {} };
}
function licenseUnlock() { const l = document.getElementById('licLock'); if (l) l.remove(); }

/* 쿠폰 입력칸 + 등록 버튼 (잠금 화면·설정 공용) */
function wireCouponInput(box, onOk) {
  const inp = box.querySelector('#licCode'), go = box.querySelector('#licGo'), msg = box.querySelector('#licMsg');
  inp.addEventListener('input', () => { const p = inp.selectionStart === inp.value.length; inp.value = fmtCoupon(inp.value); if (p) inp.selectionStart = inp.selectionEnd = inp.value.length; });
  const redeem = async () => {
    const code = inp.value.trim(); if (!code) { inp.focus(); return; }
    go.disabled = true; msg.className = 'lic-msg'; msg.textContent = '확인 중…';
    let r = null; try { r = await api('/api/license/redeem', { method: 'POST', body: { code }, timeout: 30000 }); } catch (e) {}
    go.disabled = false;
    if (!r || !r.ok) { msg.className = 'lic-msg bad'; msg.textContent = (r && r.error) || SERVER_DOWN; return; }
    LIC = r; inp.value = '';
    msg.className = 'lic-msg good';
    msg.textContent = r.again ? '이 기기에 등록했던 쿠폰이라 남은 기간을 되살렸어요 (' + licDate(r.until) + '까지)' : '🎉 ' + r.name + ' 등록 완료! ' + licDate(r.until) + '까지 쓸 수 있어요';
    toast('🎉 ' + r.name + ' 이용권 등록 · ' + licDate(r.until) + '까지', 4000);
    try { fxConfetti(2400); } catch (e) {}
    if (onOk) setTimeout(onOk, 900);
  };
  go.onclick = redeem;
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); redeem(); } });
}

/* 설정 → 이용권 */
function licenseSecHtml() {
  const st = LIC || {};
  const free = st.free ? '<div class="lic-free">🎉 <b>무료 오픈 중</b> · ' + licDate(st.free_until - 1) + '까지 쿠폰 없이 모든 기능을 쓸 수 있어요</div>' : '';
  const bonus = st.bonus_days > 0 && st.coupon_active ? ' · 🎁 무료 오픈 기념 +' + st.bonus_days + '일 포함' : '';
  const line = st.coupon_active ? '<b class="up">' + esc(st.plan || '이용권') + ' 사용 중</b> · <b>' + licDate(st.until) + '</b>까지 (' + st.days_left + '일 남음)' + bonus
    : st.free ? '무료 오픈 기간이라 쿠폰 없이 쓰는 중이에요' : st.count ? '<b class="down">기간이 끝났어요</b>' : (st.required ? '<b class="down">등록된 쿠폰이 없어요</b>' : '지금은 쿠폰 없이 쓸 수 있어요');
  return '<h2>이용권</h2><div class="desc">쿠폰을 등록하면 그 기간만큼 쓸 수 있어요. 남은 기간이 있으면 새 쿠폰은 <b>그 뒤에 이어서</b> 붙어요.</div>' +
    free + (st.visitor && st.visitor.n ? '<div class="note" style="margin:0 0 6px">👥 이 앱 사용자 ' + nf(st.visitor.n, 0) + '명 중 ' + nf(st.visitor.rank, 0) + '번째로 접속한 기기예요' + (st.visitor.cap ? ' · 정원 ' + st.visitor.cap + '명' : '') + '</div>' : '') + '<div class="lic-status">🎟 ' + line + (st.device ? '<div class="lic-dev">이 기기 코드: <b>' + esc(st.device) + '</b> · 폰을 바꿨다면 이 코드를 판매자에게 알려 주세요</div>' : '') + '</div>' +
    '<div class="lic-in"><input class="input tnum" id="licCode" placeholder="쿠폰 번호 입력" autocomplete="off" autocapitalize="characters" spellcheck="false">' +
    '<button class="btn btn-primary" id="licGo">등록</button></div><div class="lic-msg" id="licMsg"></div>' +
    licPlansHtml(st) +
    (st.contact ? '<button class="btn btn-soft btn-block" data-lic-buy style="margin-top:12px">💬 ' + esc(st.contact_label || '쿠폰 구매·문의하기') + '</button>' : '');
}
function wireLicenseSec(s) {
  wireCouponInput(s, () => { s.innerHTML = licenseSecHtml(); wireLicenseSec(s); });
  const b = s.querySelector('[data-lic-buy]'); if (b) b.onclick = () => openExt((LIC || {}).contact);
}
