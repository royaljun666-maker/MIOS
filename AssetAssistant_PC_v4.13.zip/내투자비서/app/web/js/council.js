/* ==========================================================================
   council.js — 🏛 AI 위원회 토론 (v4.0)
   관점이 다른 7명의 AI 패널이 같은 자료를 각자 읽고(1라운드) → 서로 묻고 반박하고(2라운드)
   → 의장이 합의·쟁점·시나리오·'먼저 보일 신호'로 정리. 신호는 앱이 계속 지켜보다가 넘으면 알려 줌.
   정보 제공 한정: 사라·팔라·확률 없음. '무엇을 보면 판가름 나는지'를 미리 정해 두는 기능.
   ========================================================================== */
'use strict';

const CW_KEY = 'council_watch_v1', CH_KEY = 'council_hist_v1';
const CW = { cur: {}, stocks: {}, alerts: [], at: 0, busy: false };
const CN_DEPTH = {
  quick: { label: '⚡ 빠르게', calls: 1, desc: 'AI 한 번으로 위원회를 압축 진행 (가장 빠름)' },
  solo: { label: '👥 각자 의견', calls: 8, desc: '7명이 따로 의견 → 의장 정리 (AI 8번)' },
  debate: { label: '🗣 토론까지', calls: 15, desc: '7명이 따로 의견 → 서로 질문·반박 → 의장 정리 (AI 15번 · 가장 깊음)' },
};
const STANCE_CLS = { 긍정: 'up', 중립: 'flat', 부정: 'down' };
const cnLoad = k => { try { const v = JSON.parse(localStorage.getItem(k) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } };
const cnSave = (k, v, n) => { try { localStorage.setItem(k, JSON.stringify(v.slice(-(n || 30)))); } catch (e) {} };
function cnTargetKey(t) { return t.kind === 'stock' ? 'stock:' + String(t.ticker).toUpperCase() : 'mkt:' + (t.mkt || 'kr'); }
function cnRefMetric(t) { return t.kind === 'stock' ? 'stock' : t.mkt === 'us' ? 'sp500' : 'kospi'; }
function cnFmt(v, unit) { return (Math.abs(v) >= 100 ? nf(Math.round(v * 100) / 100, Math.abs(v) >= 1000 ? 0 : 1) : nf(v, 2)) + (unit || ''); }

/* 지난 위원회 → 그 뒤 실제 움직임 (다음 토론에 넘겨 같은 실수를 줄이게) */
function cnPast(t) {
  const key = cnTargetKey(t), m = cnRefMetric(t);
  const now = m === 'stock' ? CW.stocks[String(t.ticker).toUpperCase() + ':' + (t.market || 'kr')] : CW.cur[m];
  return cnLoad(CH_KEY).filter(h => h.tkey === key && Date.now() - h.at > 12 * 3600000).slice(-2).map(h => {
    const d = new Date(h.at), was = h.ref;
    const after = was && now ? ' → 그 뒤 ' + (m === 'stock' ? '주가' : m === 'sp500' ? 'S&P 500' : '코스피') + ' ' + cnFmt(was) + ' → ' + cnFmt(now) + ' (' + pct((now / was - 1) * 100) + ')' : '';
    return (d.getMonth() + 1) + '/' + d.getDate() + ' 위원회: ' + h.side + ' (오를 근거 ' + h.up_pts + '점 · 내릴 근거 ' + h.down_pts + '점) · "' + String(h.summary || '').slice(0, 80) + '"' + after;
  }).join('\n');
}

/* ── 열기: 무엇을, 얼마나 깊게 ── */
function openCouncil(preset) {
  if (!(AI_STATUS && AI_STATUS.on)) { needAI(() => openCouncil(preset)); return; }
  const stocks = [];
  allHoldings().forEach(x => { if (x.h.ticker && !stocks.some(s => s.ticker === x.h.ticker)) stocks.push({ ticker: x.h.ticker, name: dispName(x.h), market: mkt(x.h), held: 1 }); });
  watchlist().forEach(w => { if (w.ticker && !stocks.some(s => s.ticker === w.ticker)) stocks.push({ ticker: w.ticker, name: dispName(w), market: w.market || 'kr' }); });
  let tgt = preset || { kind: 'market', mkt: 'kr' }, depth = UI.cnDepth || 'debate';
  const chip = (t, label) => '<button class="chip' + (cnTargetKey(t) === cnTargetKey(tgt) ? ' on' : '') + '" data-t="' + esc(JSON.stringify(t)) + '">' + label + '</button>';
  const m = openModal({ title: '🏛 AI 위원회 토론', size: 'wide', body: '' });
  const draw = () => {
    m.setBody(aiStyleBar() +
      '<div class="cn-intro"><b>관점이 다른 일곱 AI가 같은 자료를 따로 읽고, 서로 묻고 반박한 뒤 의장이 정리해요.</b>' +
        '<div class="cn-faces">' + ['🌍 거시', '📈 차트', '🏭 실적', '💸 수급·심리', '🛡 리스크', '📚 역사', '🦉 역발상'].map(x => '<span>' + x + '</span>').join('') + '<span class="chair">🧑‍⚖️ 의장</span></div>' +
        '<p>결론을 정해 주는 게 아니라 <b>근거가 어느 쪽에 많은지, 무엇을 보면 판가름 나는지</b>를 보여 주고, 그 신호를 앱이 지켜보다 넘으면 알려 드려요.</p></div>' +
      '<div class="ah-sub">무엇을 토론할까요?</div><div class="chips" id="cnT">' + chip({ kind: 'market', mkt: 'kr' }, '🇰🇷 한국 시장') + chip({ kind: 'market', mkt: 'us' }, '🇺🇸 미국 시장') +
        stocks.slice(0, 14).map(s => chip({ kind: 'stock', ticker: s.ticker, market: s.market, name: s.name }, (s.held ? '💼 ' : '⭐ ') + esc(s.name))).join('') + '</div>' +
      '<div class="ah-sub">얼마나 깊게?</div><div class="cn-depth" id="cnD">' + Object.entries(CN_DEPTH).map(([k, d]) =>
        '<button class="' + (k === depth ? 'on' : '') + '" data-d="' + k + '"><b>' + d.label + '</b><span>' + d.desc + '</span></button>').join('') + '</div>' +
      '<button class="btn btn-primary btn-lg btn-block" id="cnGo" style="margin-top:14px">' + icon('sparkles') + '위원회 열기</button>' +
      '<p class="note" style="margin-top:8px">AI를 여러 번 부르니 1~3분 걸릴 수 있어요. 무료 AI는 한도 때문에 일부 패널이 빠질 수 있어요(빠진 채로 정리해요). 정보 제공 · 투자 권유 아님.</p>');
    m.body.querySelector('#cnT').onclick = e => { const b = e.target.closest('[data-t]'); if (b) { tgt = JSON.parse(b.dataset.t); draw(); } };
    m.body.querySelector('#cnD').onclick = e => { const b = e.target.closest('[data-d]'); if (b) { depth = b.dataset.d; UI.cnDepth = depth; saveUI(); draw(); } };
    m.body.querySelector('#cnGo').onclick = () => runCouncil(m, tgt, depth);
    hydrateIcons(m.body);
  };
  draw();
}

/* ── 진행 화면 ── */
function cnPanelCard(p) {
  return '<div class="cn-p" id="cnp-' + p.id + '"><div class="cn-ph"><span class="cn-em">' + p.emoji + '</span><div><b>' + esc(p.name) + '</b><small>' + esc(p.focus.split('·').slice(0, 3).join('·')) + '</small></div>' +
    '<i class="cn-st wait">생각 중…</i></div><div class="cn-pb"><div class="cn-dots"><i></i><i></i><i></i></div></div></div>';
}
function cnClaims(arr, k) {
  return (arr || []).map(c => '<li class="' + k + '"><span class="sg sg-' + ({ 강: 's', 중: 'm', 약: 'w' })[c.g] + '">' + c.g + '</span>' + esc(c.t) + (c.src ? ' <em>' + esc(c.src) + '</em>' : '') + '</li>').join('');
}
function cnFillPanel(box, r, r2) {
  const el = box.querySelector('#cnp-' + r.id); if (!el) return;
  const st = el.querySelector('.cn-st'), body = el.querySelector('.cn-pb');
  if (!r.ok) { st.className = 'cn-st off'; st.textContent = '빠짐'; body.innerHTML = '<p class="note" style="margin:0">' + esc(r.error === 'NO_KEY' ? 'AI 연결이 필요해요' : 'AI 답을 받지 못했어요 (' + (r.error || '') + ')') + '</p>'; return; }
  const fin = r2 && r2.ok ? r2 : r, moved = r2 && r2.ok && r2.stance !== r.stance;
  st.className = 'cn-st ' + STANCE_CLS[fin.stance];
  st.innerHTML = (moved ? '<s>' + esc(r.stance) + '</s> → ' : '') + esc(fin.stance);
  body.innerHTML = '<div class="cn-str"><i style="width:' + fin.strength + '%"></i><span>근거 강도 ' + fin.strength + '</span></div>' +
    '<p class="cn-hl">' + esc(fin.headline || r.headline) + '</p>' +
    '<details><summary>근거 보기 (오를 ' + r.up.length + ' · 내릴 ' + r.down.length + ')</summary><ul class="cn-cl">' + cnClaims(r.up, 'u') + cnClaims(r.down, 'd') + '</ul></details>' +
    (moved && r2.changed ? '<div class="cn-moved">🔄 ' + esc(r2.changed) + '</div>' : '');
}
function cnDebateItem(r, P) {
  const nm = id => (P[id] ? P[id].emoji + ' ' + P[id].name : id);
  let h = '';
  (r.asked || []).forEach(a => { h += '<div class="cn-msg q"><b>' + nm(a.from) + ' → ' + nm(r.id) + '</b><span>❓ ' + esc(a.q) + '</span></div>'; });
  if (r.reply) h += '<div class="cn-msg a"><b>' + nm(r.id) + '</b><span>💬 ' + esc(r.reply) + '</span></div>';
  (r.rebut || []).forEach(x => { h += '<div class="cn-msg ' + (x.kind === '동의' ? 'ok' : x.kind === '보완' ? 'add' : 'no') + '"><b>' + nm(r.id) + ' → ' + nm(x.to) + ' · ' + esc(x.kind) + '</b><span>' + esc(x.t) + '</span></div>'; });
  return h;
}
function cnFoldFeed(feed) {                               // 토론이 길면 8개만 보이고 나머지는 접기
  const msgs = [...feed.children]; if (msgs.length <= 8) return;
  msgs.slice(8).forEach(x => x.classList.add('cn-hide'));
  const b = document.createElement('button'); b.className = 'btn btn-ghost btn-sm'; b.textContent = '토론 ' + (msgs.length - 8) + '개 더 보기';
  b.onclick = () => { msgs.forEach(x => x.classList.remove('cn-hide')); b.remove(); };
  feed.appendChild(b);
}
async function cnPool(tasks, n) {                         // 무료 AI 한도를 생각해 동시에 n개씩
  const out = []; let i = 0;
  await Promise.all(Array.from({ length: n }, async () => { while (i < tasks.length) { const k = i++; out[k] = await tasks[k](); } }));
  return out;
}
async function runCouncil(m, tgt, depth) {
  const mine = [...new Set(allHoldings().map(x => dispName(x.h)).concat(watchlist().map(w => dispName(w))))].slice(0, 20);
  m.setBody('<div class="cn-run"><div class="cn-top" id="cnTop"><div class="ai-loading" style="padding:14px"><div class="orb"></div><div>지표·뉴스·차트 자료를 모으는 중…</div></div></div>' +
    '<div class="cn-sec-h">👥 패널 의견</div><div class="cn-grid" id="cnGrid"></div><div id="cnDeb"></div><div id="cnFin"></div></div>');
  const top = m.body.querySelector('#cnTop'), grid = m.body.querySelector('#cnGrid'), deb = m.body.querySelector('#cnDeb'), fin = m.body.querySelector('#cnFin');
  const body = { target: tgt, mine, past: cnPast(tgt) };
  const head = d => '<div class="cn-title"><b>🏛 ' + esc(d.title) + ' 위원회</b><span>' + CN_DEPTH[depth].label + ' · 자료: 지표 ' + Object.keys(d.cur || {}).length + '개 · 뉴스 ' + (d.news != null ? d.news : '') + '건</span></div>' +
    (d.alerts && d.alerts.length ? '<div class="cn-alerts">' + d.alerts.slice(0, 5).map(a => '<span class="' + a.level + '">' + (a.level === 'red' ? '🔴 ' : a.level === 'orange' ? '🟠 ' : '🟢 ') + esc(a.text) + '</span>').join('') + '</div>' : '');
  try {
    if (depth === 'quick') {
      top.innerHTML = '<div class="ai-loading" style="padding:14px"><div class="orb"></div><div>위원회가 압축 토론 중… (AI 1번)</div></div>';
      const d = await api('/api/council/quick', { method: 'POST', body, timeout: 180000 });
      if (m.closed) return;
      if (!d || !d.ok) { top.innerHTML = d && d.status === 'no_key' ? noKeyHtml() : '<p class="note">' + esc((d && d.error) || 'AI 답을 받지 못했어요') + '</p>'; return; }
      top.innerHTML = head(d);
      const P = Object.fromEntries(d.panel.map(p => [p.id, p]));
      grid.innerHTML = d.panel.map(cnPanelCard).join('');
      d.panel.forEach(p => cnFillPanel(grid, d.r1[p.id] || { ok: false, id: p.id, error: '이번엔 빠졌어요' }, d.r2[p.id]));
      const items = d.panel.map(p => d.r2[p.id] ? cnDebateItem(d.r2[p.id], P) : '').join('');
      if (items) { deb.innerHTML = '<div class="cn-sec-h">🗣 토론</div><div class="cn-feed">' + items + '</div>'; cnFoldFeed(deb.querySelector('.cn-feed')); }
      cnRenderFinal(fin, d.final, tgt, d.title, d.cur);
      return;
    }
    const s = await api('/api/council/start', { method: 'POST', body, timeout: 90000 });
    if (m.closed) return;
    if (!s || !s.ok) { top.innerHTML = s && s.status === 'no_key' ? noKeyHtml() : '<p class="note">' + esc((s && s.error) || SERVER_DOWN) + '</p>'; return; }
    top.innerHTML = head(s);
    const P = Object.fromEntries(s.panel.map(p => [p.id, p]));
    grid.innerHTML = s.panel.map(cnPanelCard).join('');
    const r1 = {}, r2 = {};
    await cnPool(s.panel.map(p => async () => {
      let r; try { r = await api('/api/council/speak', { method: 'POST', body: { id: s.id, who: p.id, round: 1 }, timeout: 150000 }); } catch (e) { r = { ok: false, id: p.id, error: '연결 끊김' }; }
      r1[p.id] = r || { ok: false, id: p.id }; if (!m.closed) cnFillPanel(grid, r1[p.id]);
    }), 3);
    if (m.closed) return;
    const okN = Object.values(r1).filter(r => r.ok).length;
    if (okN < 2) { fin.innerHTML = '<div class="callout warn">' + icon('alert', 'ic-sm') + '<div>의견을 낸 패널이 ' + okN + '명뿐이에요. AI 한도나 연결을 확인하고 잠시 후 다시 열어 주세요. (⚡ 빠르게는 AI를 한 번만 불러요)</div></div>'; hydrateIcons(fin); return; }
    if (depth === 'debate') {
      deb.innerHTML = '<div class="cn-sec-h">🗣 2라운드 — 서로 묻고 반박하는 중…</div><div class="cn-feed" id="cnFeed"></div>';
      const feed = deb.querySelector('#cnFeed');
      await cnPool(s.panel.filter(p => r1[p.id].ok).map(p => async () => {
        let r; try { r = await api('/api/council/speak', { method: 'POST', body: { id: s.id, who: p.id, round: 2 }, timeout: 150000 }); } catch (e) { r = null; }
        if (r && r.ok) { r2[p.id] = r; if (!m.closed) { feed.insertAdjacentHTML('beforeend', cnDebateItem(r, P)); cnFillPanel(grid, r1[p.id], r); } }
      }), 3);
      if (m.closed) return;
      deb.querySelector('.cn-sec-h').textContent = '🗣 2라운드 — 질문·반박 ' + Object.keys(r2).length + '명';
      if (!feed.innerHTML) deb.innerHTML = ''; else cnFoldFeed(feed);
    }
    fin.innerHTML = '<div class="ai-loading" style="padding:18px"><div class="orb"></div><div>🧑‍⚖️ 의장이 합의·쟁점·신호를 정리하는 중…</div></div>';
    const f = await api('/api/council/final', { method: 'POST', body: { id: s.id }, timeout: 180000 });
    if (m.closed) return;
    if (!f || !f.ok) { fin.innerHTML = '<p class="note">' + esc((f && f.error) || '의장 정리를 받지 못했어요') + '</p>'; return; }
    cnRenderFinal(fin, f, tgt, s.title, s.cur);
  } catch (e) { if (!m.closed) top.innerHTML = '<p class="note">' + SERVER_DOWN + '</p>'; }
}

/* ── 의장 정리 ── */
function cnRenderFinal(box, f, tgt, title, cur) {
  const b = f.balance || {}, tot = Math.max(1, (b.up_pts || 0) + (b.down_pts || 0)), us = Math.round((b.up_pts || 0) / tot * 100), t = f.tally || {};
  const sid = Date.now().toString(36);
  const sig = (f.signals || []).map((x, i) => '<label class="cn-sig ' + (x.side || '') + '"><input type="checkbox" data-sig="' + i + '" checked><div><b>' + esc(x.label) + ' ' + (x.op === '>=' ? '↑ ' : '↓ ') + cnFmt(x.value, x.unit) + (x.op === '>=' ? ' 넘으면' : ' 밑돌면') + '</b>' +
    '<span>지금 ' + cnFmt(x.now, x.unit) + ' · ' + (x.gap >= 0 ? '+' : '') + x.gap + '% 거리' + (x.side ? ' · ' + (x.side === 'up' ? '오를 근거가 강해지는 신호' : '내릴 근거가 강해지는 신호') : '') + '</span>' + (x.why ? '<em>' + esc(x.why) + '</em>' : '') + '</div></label>').join('');
  const scIc = ['🌤', '⛅', '🌧'];
  box.innerHTML = '<div class="cn-chair"><div class="cn-sec-h">🧑‍⚖️ 의장 정리</div>' +
    (f.summary ? '<div class="cn-sum">' + esc(f.summary) + '</div>' : '') +
    '<div class="op-card" style="margin:10px 0"><div class="op-two"><div class="ot up"><span>📈 오를 근거 <b>' + (b.up || 0) + '개</b></span><em>세기 ' + (b.up_pts || 0) + '점</em></div>' +
      '<div class="ot dn"><span>📉 내릴 근거 <b>' + (b.down || 0) + '개</b></span><em>세기 ' + (b.down_pts || 0) + '점</em></div></div>' +
      '<div class="op-bal-t">⚖️ 근거 균형 — <b>' + esc(b.side || '') + '</b></div><div class="op-bar bal"><i class="u" style="width:' + us + '%"></i><i class="d" style="width:' + (100 - us) + '%"></i></div>' +
      '<div class="cn-tally">패널 최종 입장 · <span class="up">긍정 ' + (t['긍정'] || 0) + '</span> · <span class="flat">중립 ' + (t['중립'] || 0) + '</span> · <span class="down">부정 ' + (t['부정'] || 0) + '</span></div>' +
      '<div class="op-note">일곱 패널이 낸 근거의 개수와 세기(강 3·중 2·약 1점)를 센 것 · 예측이 아니에요</div></div>' +
    (f.consensus && f.consensus.length ? '<div class="cn-block"><h4>🤝 대부분 동의한 점</h4><ul>' + f.consensus.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul></div>' : '') +
    (f.disputes && f.disputes.length ? '<div class="cn-block"><h4>⚔️ 의견이 갈린 점</h4>' + f.disputes.map(d => '<div class="cn-disp"><b>' + esc(d.topic) + '</b><div class="vs"><span>' + esc(d.a) + '</span><i>vs</i><span>' + esc(d.b) + '</span></div>' + (d.key ? '<small>🔑 판가름: ' + esc(d.key) + '</small>' : '') + '</div>').join('') + '</div>' : '') +
    (f.scenarios && f.scenarios.length ? '<div class="cn-block"><h4>🧭 이렇게 갈 수 있어요 (조건별)</h4><div class="cn-scs">' + f.scenarios.map((s, i) => '<div class="cn-sc s' + i + '"><b>' + (scIc[i] || '•') + ' ' + esc(s.name) + '</b>' + (s.when ? '<span><i>조건</i>' + esc(s.when) + '</span>' : '') + (s.then ? '<span><i>흐름</i>' + esc(s.then) + '</span>' : '') + (s.sign ? '<span><i>먼저 보일 신호</i>' + esc(s.sign) + '</span>' : '') + '</div>').join('') + '</div></div>' : '') +
    (sig ? '<div class="cn-block"><h4>🔔 먼저 보일 신호 — 앱이 지켜볼게요</h4><p class="note" style="margin:0 0 8px">체크한 신호는 앱이 시세를 받을 때마다 확인해서, 선을 넘으면 알려 드려요 (14일 동안).</p><div id="cnSigs">' + sig + '</div>' +
      '<button class="btn btn-soft btn-block" id="cnWatch" style="margin-top:8px">🔔 체크한 신호 지켜보기</button></div>' : '') +
    (f.check && f.check.length ? '<div class="cn-block"><h4>📅 앞으로 함께 볼 것</h4><ul>' + f.check.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul></div>' : '') +
    (f.mine && f.mine.length ? '<div class="cn-block"><h4>💼 내 종목과 닿는 점</h4><ul>' + f.mine.map(x => '<li><b>' + esc(x.name) + '</b> — ' + esc(x.why) + '</li>').join('') + '</ul></div>' : '') +
    (f.blind && f.blind.length ? '<div class="cn-block muted-b"><h4>🙈 이번 토론의 빈 곳</h4><ul>' + f.blind.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul></div>' : '') +
    '<p class="note" style="margin-top:12px">' + (f.provider ? esc(f.provider) + (f.model ? ' · ' + esc(f.model) : '') + ' · ' : '') + 'AI 위원회의 토론은 정보 정리예요. 사거나 팔라는 뜻이 아니고, 판단과 결과의 책임은 본인에게 있어요.</p></div>';
  // 기록 (다음 위원회에 '지난 결론 → 실제'로 넘김)
  const m = cnRefMetric(tgt), ref = (cur || {})[m];
  const h = cnLoad(CH_KEY); h.push({ at: Date.now(), tkey: cnTargetKey(tgt), title, side: b.side || '', up_pts: b.up_pts || 0, down_pts: b.down_pts || 0, summary: f.summary || '', ref: ref || null });
  cnSave(CH_KEY, h, 40);
  const w = box.querySelector('#cnWatch');
  if (w) w.onclick = () => {
    const picks = [...box.querySelectorAll('[data-sig]')].filter(x => x.checked).map(x => f.signals[+x.dataset.sig]);
    const list = cnLoad(CW_KEY).filter(x => !(x.tkey === cnTargetKey(tgt) && !x.fired));     // 같은 주제의 지난 신호는 새 것으로 바꿈
    picks.forEach((x, i) => list.push({ id: sid + i, tkey: cnTargetKey(tgt), title, target: tgt, metric: x.metric, label: x.label, unit: x.unit, op: x.op, value: x.value, base: x.now, why: x.why, side: x.side,
      stock: x.metric === 'stock' ? String(tgt.ticker).toUpperCase() + ':' + (tgt.market || 'kr') : '', at: Date.now() }));
    cnSave(CW_KEY, list, 40);
    w.disabled = true; w.textContent = '✅ ' + picks.length + '개 신호를 지켜보는 중 (홈에서 확인)';
    toast('🔔 ' + picks.length + '개 신호를 지켜볼게요 — 넘으면 알려 드려요');
  };
  hydrateIcons(box);
}

/* ── 감시: 시세를 받을 때마다 신호 확인 ── */
function cnActive() { const now = Date.now(); return cnLoad(CW_KEY).filter(x => !x.fired && now - x.at < 14 * 86400000); }
async function councilTick(force) {
  if (CW.busy || (!force && Date.now() - CW.at < 8 * 60000)) return;
  CW.busy = true;
  try {
    const act = cnActive(), stocks = [...new Set(act.filter(x => x.stock).map(x => x.stock))];
    const d = await api('/api/council/levels' + (stocks.length ? '?stocks=' + encodeURIComponent(stocks.join(',')) : ''), { timeout: 60000 });
    if (!d || !d.ok) return;
    CW.cur = d.cur || {}; CW.stocks = d.stocks || {}; CW.alerts = d.alerts || []; CW.at = Date.now();
    const all = cnLoad(CW_KEY); let fired = [];
    all.forEach(x => {
      if (x.fired || Date.now() - x.at > 14 * 86400000) return;
      const v = x.metric === 'stock' ? CW.stocks[x.stock] : CW.cur[x.metric];
      if (v == null) return;
      if ((x.op === '>=' && v >= x.value) || (x.op === '<=' && v <= x.value)) { x.fired = Date.now(); x.hit = v; fired.push(x); }
    });
    if (fired.length) {
      cnSave(CW_KEY, all, 40);
      fired.forEach((x, i) => setTimeout(() => toast('🔔 위원회 신호: ' + x.title + ' · ' + x.label + ' ' + cnFmt(x.value, x.unit) + (x.op === '>=' ? ' 넘음' : ' 밑돎') + ' (지금 ' + cnFmt(x.hit, x.unit) + ')', 6000), i * 1500));
    }
    if (route.page === 'home') { const c = document.getElementById('cnHome'); if (c) c.outerHTML = councilHomeCard(); }
    if (route.page === 'market' && !document.querySelector('.mk-alerts') && CW.alerts.length) PAGES.market({}, true);
  } catch (e) { /* 서버 꺼짐 등 */ } finally { CW.busy = false; }
}

/* 홈 카드: 넘은 신호 · 지켜보는 신호 · 시장 이상 신호 */
function councilHomeCard() {
  const all = cnLoad(CW_KEY), now = Date.now();
  const hits = all.filter(x => x.fired && !x.seen && now - x.fired < 3 * 86400000), act = cnActive();
  const al = (CW.alerts || []).filter(a => a.level !== 'normal').slice(0, 3);
  if (!hits.length && !act.length && !al.length) return '<div id="cnHome"></div>';
  const nearest = act.map(x => { const v = x.metric === 'stock' ? CW.stocks[x.stock] : CW.cur[x.metric]; return Object.assign({}, x, { now: v, dist: v ? Math.abs(x.value / v - 1) * 100 : 99 }); }).sort((a, b) => a.dist - b.dist).slice(0, 3);
  return '<div class="card span-12 cn-home" id="cnHome"><div class="card-head"><h3>🏛 위원회가 지켜보는 신호</h3><button class="btn btn-ghost btn-sm" data-act="council">위원회 열기 ›</button></div>' +
    hits.map(x => '<div class="cn-hit ' + (x.side || '') + '"><b>🔔 ' + esc(x.label) + ' ' + cnFmt(x.value, x.unit) + (x.op === '>=' ? ' 넘음' : ' 밑돎') + '</b><span>' + esc(x.title) + ' 위원회 · ' + esc(x.why || '') + '</span>' +
      '<div class="row-btns"><button class="btn btn-soft btn-sm" data-act="council-again" data-t="' + esc(JSON.stringify(x.target || {})) + '">다시 토론</button><button class="btn btn-ghost btn-sm" data-act="council-seen" data-id="' + esc(x.id) + '">확인</button></div></div>').join('') +
    nearest.map(x => '<div class="cn-near"><span>' + esc(x.label) + ' ' + (x.op === '>=' ? '↑' : '↓') + ' ' + cnFmt(x.value, x.unit) + '</span><em>' + (x.now != null ? '지금 ' + cnFmt(x.now, x.unit) + ' · ' + x.dist.toFixed(1) + '% 남음' : '확인 대기') + '</em></div>').join('') +
    (act.length > 3 ? '<div class="cn-near muted"><span>그 밖에 ' + (act.length - 3) + '개 지켜보는 중</span></div>' : '') +
    (al.length ? '<div class="cn-al">' + al.map(a => '<span class="' + a.level + '">' + (a.level === 'red' ? '🔴 ' : '🟠 ') + esc(a.text) + '</span>').join('') + '</div>' : '') + '</div>';
}
