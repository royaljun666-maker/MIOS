/* ==========================================================================
   lotto.js — 🎱 로또 추첨기 (재미용 포인트 · 실제 로또와 무관 · 현금/상품 교환 없음)
   · 내가 직접 추첨기를 돌려 1~45 중 공 6개 + 보너스 1개를 뽑아요
     (암호학적 난수로 섞기 → 실제 로또 6/45 와 똑같은 확률, 1등 1/8,145,060)
   · 번호만 뽑기(무료, 몇 번이든) / 포인트 도전(한 게임 1,000P, 한 번에 최대 5게임)
   · 결과는 출발 순간 정해져 저장돼요 (추첨 중 화면을 떠나도 그대로 반영)
   ========================================================================== */
'use strict';

const LOTTO = { PRICE: 1000, MAX_GAMES: 5,
  PRIZE: { 1: 2000000000, 2: 50000000, 3: 1500000, 4: 50000, 5: 5000 },
  RULE: { 1: '6개 모두', 2: '5개 + 보너스', 3: '5개', 4: '4개', 5: '3개' },
  ODDS: { 1: '8,145,060', 2: '1,357,510', 3: '35,724', 4: '733', 5: '45' } };

function LT() {
  const s = S.settings;
  if (!s.lotto || typeof s.lotto !== 'object') s.lotto = { mode: 'play', games: [], hist: [], fast: false, best: 0, spent: 0, won: 0 };
  return s.lotto;
}
/* 0..n-1 균등 난수 (나머지 치우침 없게 거절 표본) */
function lottoRand(n) {
  const a = new Uint32Array(1), lim = Math.floor(4294967296 / n) * n;
  do crypto.getRandomValues(a); while (a[0] >= lim);
  return a[0] % n;
}
/* 1~45 를 섞어 앞에서 k개 (뽑힌 순서 그대로) */
function lottoPick(k) {
  const p = Array.from({ length: 45 }, (_, i) => i + 1);
  for (let i = 0; i < k; i++) { const j = i + lottoRand(45 - i); [p[i], p[j]] = [p[j], p[i]]; }
  return p.slice(0, k);
}
const lottoSort = a => a.slice().sort((x, y) => x - y);
function lottoRank(nums, win, bonus) {
  const hit = nums.filter(n => win.includes(n)).length;
  return hit === 6 ? 1 : hit === 5 && nums.includes(bonus) ? 2 : hit === 5 ? 3 : hit === 4 ? 4 : hit === 3 ? 5 : 0;
}
/* 실제 로또 공 색 (1~10 노랑 · 11~20 파랑 · 21~30 빨강 · 31~40 회색 · 41~45 초록) */
const LT_COL = [['#FBC400', '#B98F00'], ['#69C8F2', '#2B86B8'], ['#FF7272', '#C83B3B'], ['#AAAAAA', '#6E6E6E'], ['#B0D840', '#76A11A']];
const lottoCol = n => LT_COL[Math.min(4, Math.floor((n - 1) / 10))];
const ltBall = (n, cls) => '<span class="lt-ball ' + (cls || '') + '" style="--bc:' + lottoCol(n)[0] + '">' + n + '</span>';
const ltPrizeTxt = p => p >= 100000000 ? nf(p / 100000000, 1) + '억P' : p >= 10000 ? nf(p / 10000, 1) + '만P' : nf(p, 0) + 'P';

/* 효과음 */
const LSFX = (function () {
  let ctx = null;
  const ok = () => { if (soundModeSafe() === 'off') return false; try { ctx = ctx || new (window.AudioContext || window.webkitAudioContext)(); if (ctx.state === 'suspended') ctx.resume(); return true; } catch (e) { return false; } };
  function tone(f, d, type, vol, at) {
    const o = ctx.createOscillator(), g = ctx.createGain(), t = ctx.currentTime + (at || 0);
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t);
    g.gain.setValueAtTime(vol || .15, t); g.gain.exponentialRampToValueAtTime(.0001, t + d);
    o.connect(g); g.connect(ctx.destination); o.start(t); o.stop(t + d + .02);
  }
  function air(d, vol) {
    const b = ctx.createBuffer(1, ctx.sampleRate * d, ctx.sampleRate), x = b.getChannelData(0);
    for (let i = 0; i < x.length; i++) x[i] = (Math.random() * 2 - 1) * Math.sin(Math.PI * i / x.length);
    const s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    s.buffer = b; f.type = 'bandpass'; f.frequency.value = 1400; g.gain.value = vol || .12;
    s.connect(f); f.connect(g); g.connect(ctx.destination); s.start();
  }
  return {
    whir(d) { if (ok()) { air(d, .14); for (let i = 0; i < d * 6; i++) tone(500 + Math.random() * 900, .04, 'triangle', .025, i / 6 + Math.random() * .1); } },
    pop(bonus) { if (ok()) { tone(bonus ? 784 : 660, .1, 'sine', .2); tone(bonus ? 1175 : 990, .22, 'sine', .18, .09); } },
    win(big) { if (ok()) [523, 659, 784, 1047].concat(big ? [1319, 1568] : []).forEach((f, i) => tone(f, .3, 'triangle', .16, i * .11)); },
    lose() { if (ok()) { tone(330, .25, 'sine', .12); tone(262, .4, 'sine', .12, .2); } },
  };
})();

/* ── 추첨 진행 ─────────────────────────────────────────────────────────── */
let LRUN = null;   // { phase: 'run'|'end', order[7], win[6], bonus, res[], prize, cost, play, ptsBefore, revealed, t0, fast }
function lottoTimes(R) {
  const mix = R.fast ? 1.2 : 3.2, step = R.fast ? .75 : 2.1, lead = R.fast ? .45 : .95;
  const T = R.order.map((_, i) => mix + i * step + (i === 6 ? (R.fast ? .4 : 1.2) : 0));
  return { T, lead, mix, hold: R.fast ? .5 : 1.0, end: T[6] + (R.fast ? .8 : 1.6) };
}
function lottoStart() {
  if (LRUN && LRUN.phase !== 'end') return;
  const l = LT(), g = G(), play = l.mode === 'play';
  const games = play ? l.games.filter(x => x && x.length === 6) : [];
  if (play && !games.length) { toast('번호를 먼저 골라 주세요 (자동 버튼을 눌러도 돼요)'); return; }
  const cost = games.length * LOTTO.PRICE;
  if (play && g.pts < cost) { toast('포인트가 모자라요. 내일 출석 보너스를 받아 보세요!'); return; }
  const order = lottoPick(7), win = order.slice(0, 6), bonus = order[6];
  const res = games.map(n => { const r = lottoRank(n, win, bonus); return { nums: n, rank: r, prize: r ? LOTTO.PRIZE[r] : 0 }; });
  const prize = res.reduce((s, r) => s + r.prize, 0), ptsBefore = g.pts;
  if (play) {
    g.pts += prize - cost; l.spent = (l.spent || 0) + cost; l.won = (l.won || 0) + prize;
    const best = Math.min(9, ...res.map(r => r.rank || 9));
    if (best < 9 && (!l.best || best < l.best)) l.best = best;
  }
  l.hist.unshift({ at: Date.now(), win: lottoSort(win), bonus, play, cost, prize, ranks: res.map(r => r.rank) });
  l.hist = l.hist.slice(0, 20);
  save();
  if (_ltBalls) _ltBalls.forEach(b => { b.cap = null; });
  LRUN = { phase: 'run', order, win, bonus, res, prize, cost, play, ptsBefore, revealed: 0, t0: performance.now(), fast: !!l.fast };
  LSFX.whir(lottoTimes(LRUN).mix + .3);
  lottoRenderCtrl(); lottoRenderDrawn(); lottoRenderSide(); lottoLoop();
  const st = document.getElementById('ltStage');                   // 추첨기가 화면에 보이게 끌어올림
  if (st) { const top = st.getBoundingClientRect().top + window.scrollY - 70; if (Math.abs(window.scrollY - top) > 40) window.scrollTo({ top: Math.max(0, top), behavior: 'smooth' }); }
}
function lottoFinish() {
  const R = LRUN; if (!R || R.phase === 'end') return;
  R.phase = 'end';
  lottoRenderCtrl(); lottoRenderSide();
  const msg = document.getElementById('ltMsg');
  if (!R.play) { if (msg) msg.textContent = '행운의 번호가 나왔어요! 🍀'; LSFX.win(false); return; }
  const best = Math.min(9, ...R.res.map(r => r.rank || 9));
  if (R.prize > 0) {
    if (msg) msg.textContent = best + '등 당첨! +' + nf(R.prize, 0) + 'P';
    const st = document.getElementById('ltStage');
    if (st) { const d = document.createElement('div'); d.className = 'gm-winpop lt-pop' + (best <= 3 ? ' big' : ''); d.textContent = '🎉 ' + best + '등 +' + ltPrizeTxt(R.prize); st.appendChild(d); setTimeout(() => d.remove(), 1700); }
    LSFX.win(best <= 4);
    if (best <= 4 && typeof fxConfetti === 'function') fxConfetti(best <= 2 ? 5000 : 3000);
  } else {
    if (msg) msg.textContent = '아쉽게도 꽝… 다음엔 꼭!';
    LSFX.lose();
  }
}

/* ── 화면 ─────────────────────────────────────────────────────────────── */
PAGES.lotto = function (params, re) {
  const el = pageEl('lotto');
  if (re && document.getElementById('ltCanvas')) { lottoRenderCtrl(); lottoRenderSide(); return; }
  el.innerHTML =
    '<div class="page-head"><div><h1>🎱 로또 추첨기</h1><div class="desc">내가 직접 돌리는 6/45 추첨 · 재미용 포인트</div></div>' +
      '<div class="actions"><button class="btn btn-outline" data-nav="game">🚀 크래시</button></div></div>' +
    '<div class="gm-wrap">' +
      '<div class="card gm-main">' +
        '<div class="lt-stage" id="ltStage"><canvas id="ltCanvas"></canvas>' +
          '<div class="gm-pts-mini" id="ltPtsMini"></div><div class="lt-msg" id="ltMsg"></div></div>' +
        '<div class="lt-drawn" id="ltDrawn"></div>' +
        '<div id="ltCtrl"></div>' +
      '</div>' +
      '<div id="ltSide"></div>' +
    '</div>';
  hydrateIcons(el);
  el.onclick = lottoClick;
  lottoRenderCtrl(); lottoRenderDrawn(); lottoRenderSide(); lottoLoop();
};

function lottoRenderDrawn() {
  const box = document.getElementById('ltDrawn'); if (!box) return;
  const R = LRUN, n = R ? R.revealed : 0;
  let h = '';
  for (let i = 0; i < 6; i++) h += i < n ? ltBall(R.order[i], 'big') : '<span class="lt-ball big lt-e">?</span>';
  h += '<span class="lt-plus">+</span>' + (n >= 7 ? ltBall(R.order[6], 'big bonus') : '<span class="lt-ball big lt-e">B</span>');
  box.innerHTML = h;
}
function lottoAddDrawn(i) {
  const box = document.getElementById('ltDrawn'), R = LRUN; if (!box || !R) return;
  const slots = box.querySelectorAll('.lt-ball'); const s = slots[i]; if (!s) return;
  const tmp = document.createElement('span'); tmp.innerHTML = ltBall(R.order[i], 'big pop' + (i === 6 ? ' bonus' : ''));
  s.replaceWith(tmp.firstChild);
}

function lottoRenderCtrl() {
  const box = document.getElementById('ltCtrl'); if (!box) return;
  const l = LT(), g = G(), R = LRUN, run = R && R.phase === 'run', done = R && R.phase === 'end';
  const play = l.mode === 'play';
  const games = l.games.filter(x => x && x.length === 6).length, cost = games * LOTTO.PRICE;
  let h = '<div class="seg lt-mode">' +
    '<button class="' + (!play ? 'on' : '') + '" data-lt="mode" data-v="free"' + (run ? ' disabled' : '') + '>🍀 번호만 뽑기 (무료)</button>' +
    '<button class="' + (play ? 'on' : '') + '" data-lt="mode" data-v="play"' + (run ? ' disabled' : '') + '>💎 포인트 도전</button></div>';
  if (play) {
    const showRes = done && R.play;
    h += '<div class="lt-games">' + (l.games.length ? l.games.map((nums, i) => {
      const r = showRes && R.res.find(x => x.nums.join() === (nums || []).join());
      const balls = nums && nums.length === 6 ? nums.map(n => ltBall(n, 'sm' + (showRes ? (R.win.includes(n) ? ' hit' : n === R.bonus ? ' hit-b' : ' miss') : ''))).join('')
        : '<span class="lt-empty-txt">번호 6개를 골라 주세요</span>';
      return '<div class="lt-game"><b class="lt-gl">' + 'ABCDE'[i] + '</b><div class="lt-nums">' + balls + '</div>' +
        (r ? '<span class="lt-rank ' + (r.rank ? 'r' + r.rank : 'r0') + '">' + (r.rank ? r.rank + '등 +' + ltPrizeTxt(r.prize) : '꽝') + '</span>'
          : '<div class="lt-gbtn"><button data-lt="auto" data-i="' + i + '"' + (run ? ' disabled' : '') + '>자동</button><button data-lt="pick" data-i="' + i + '"' + (run ? ' disabled' : '') + '>고르기</button>' +
            '<button class="x" data-lt="del" data-i="' + i + '" aria-label="이 게임 지우기"' + (run ? ' disabled' : '') + '>✕</button></div>') +
        '</div>';
    }).join('') : '<div class="lt-empty-txt" style="padding:10px 4px">아래 <b>+ 게임 추가</b>를 눌러 번호를 골라요. (한 게임 1,000P)</div>') + '</div>' +
      '<div class="lt-row">' +
        (done && R.play ? '<button class="btn btn-soft" data-lt="clear">새 번호로 하기</button>' : '') +
        (l.games.length < LOTTO.MAX_GAMES ? '<button class="btn btn-soft" data-lt="add"' + (run ? ' disabled' : '') + '>+ 게임 추가</button>' : '') +
        '<button class="btn btn-soft" data-lt="allauto"' + (run || !l.games.length ? ' disabled' : '') + '>모두 자동</button></div>';
  } else if (done && !R.play) {
    h += '<div class="lt-row"><button class="btn btn-soft" data-lt="copy">📋 번호 복사</button><button class="btn btn-soft" data-lt="use">💎 이 번호로 도전</button></div>';
  }
  h += '<label class="lt-fast"><input type="checkbox" data-lt="fast"' + (l.fast ? ' checked' : '') + (run ? ' disabled' : '') + '> 빠르게 추첨</label>';
  const poor = play && cost > g.pts;
  const label = run ? '추첨 중…' : play ? (games ? (poor ? '포인트가 모자라요' : '🎱 추첨 시작 · ' + games + '게임 ' + nf(cost, 0) + 'P') : '🎱 번호를 골라 주세요')
    : '🎱 추첨기 돌리기' + (done ? ' (한 번 더)' : '');
  h += '<button class="btn btn-lg btn-block lt-go" id="ltGo"' + (run || (play && (!games || poor)) ? ' disabled' : '') + '>' + label + '</button>';
  box.innerHTML = h;
  const pm = document.getElementById('ltPtsMini');
  if (pm) pm.textContent = '💎 ' + nf(run && R.play ? R.ptsBefore - R.cost : g.pts, 0) + 'P';
  const msg = document.getElementById('ltMsg');
  if (msg && !R) msg.textContent = play ? '번호를 고르고 추첨을 시작하세요' : '추첨기를 돌려 행운의 번호를 뽑아요';
}

function lottoRenderSide() {
  const box = document.getElementById('ltSide'); if (!box) return;
  const l = LT(), g = G(), R = LRUN, run = R && R.phase === 'run';
  const hist = l.hist.filter((h, i) => !(run && i === 0)).slice(0, 6);   // 추첨 중인 판은 끝난 뒤에 보여 줌
  box.innerHTML =
    '<div class="card gm-stats">' +
      '<div class="gm-pts"><span>내 포인트</span><b>' + nf(run && R.play ? R.ptsBefore - R.cost : g.pts, 0) + 'P</b></div>' +
      '<div class="gm-grid"><div><span>지금까지 쓴 포인트</span><b>' + nf(l.spent || 0, 0) + 'P</b></div>' +
      '<div><span>지금까지 당첨</span><b class="' + ((l.won || 0) > 0 ? 'up' : '') + '">' + nf(l.won || 0, 0) + 'P</b></div>' +
      '<div><span>최고 당첨</span><b>' + (l.best ? l.best + '등' : '-') + '</b></div>' +
      '<div><span>출석 보너스</span><b>' + (g.bonusDay === todayKey() ? '오늘 받음 ✅' : '앱 켜면 지급') + '</b></div></div></div>' +
    '<div class="card"><div class="card-head"><h3>' + icon('star', 'ic-sm') + '당첨표 (한 게임 1,000P)</h3></div>' +
      '<table class="lt-table"><tr><th>등수</th><th>맞힌 개수</th><th>포인트</th><th>확률</th></tr>' +
      [1, 2, 3, 4, 5].map(r => '<tr><td><b>' + r + '등</b></td><td>' + LOTTO.RULE[r] + '</td><td class="up">' + ltPrizeTxt(LOTTO.PRIZE[r]) + '</td><td>1/' + LOTTO.ODDS[r] + '</td></tr>').join('') +
      '</table><div class="gm-odds">실제 로또 6/45와 <b>같은 확률</b>로 뽑아요. 포인트는 재미용이며 현금·상품으로 바꿀 수 없어요. 실제 로또(동행복권)와는 관계없어요.</div></div>' +
    '<div class="card"><div class="card-head"><h3>' + icon('history', 'ic-sm') + '최근 추첨</h3></div>' +
      (hist.length ? '<div class="lt-hist">' + hist.map(h => {
        const d = new Date(h.at), best = h.play ? Math.min(9, ...h.ranks.map(r => r || 9)) : 0;
        return '<div class="lt-h"><span class="lt-ht">' + String(d.getMonth() + 1) + '/' + d.getDate() + ' ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0') + '</span>' +
          '<span class="lt-hn">' + h.win.map(n => ltBall(n, 'xs')).join('') + '<i>+</i>' + ltBall(h.bonus, 'xs') + '</span>' +
          '<span class="lt-hr ' + (!h.play ? '' : best < 9 ? 'up' : 'muted') + '">' + (!h.play ? '뽑기' : best < 9 ? best + '등 +' + ltPrizeTxt(h.prize) : '꽝 -' + nf(h.cost, 0) + 'P') + '</span></div>';
      }).join('') + '</div>' : '<div class="muted" style="padding:6px 2px;font-size:.9rem">아직 추첨 기록이 없어요.</div>') + '</div>' + promoSlot('game');
  hydrateIcons(box);
}

function lottoClick(e) {
  if (e.target.closest('#ltGo')) { lottoStart(); return; }
  const b = e.target.closest('[data-lt]'); if (!b || b.disabled) return;
  const l = LT(), a = b.dataset.lt, i = +b.dataset.i;
  if (a === 'fast') { l.fast = b.checked; save(); return; }
  if (LRUN && LRUN.phase === 'run') return;
  const after = () => { if (LRUN && LRUN.phase === 'end' && LRUN.play) { LRUN = null; lottoRenderDrawn(); } save(); lottoRenderCtrl(); };
  if (a === 'mode') { l.mode = b.dataset.v; if (LRUN && LRUN.phase === 'end') LRUN = null; save(); lottoRenderDrawn(); lottoRenderCtrl(); return; }
  if (a === 'add') { if (l.games.length < LOTTO.MAX_GAMES) l.games.push(lottoSort(lottoPick(6))); after(); }
  if (a === 'auto') { l.games[i] = lottoSort(lottoPick(6)); after(); }
  if (a === 'allauto') { l.games = l.games.map(() => lottoSort(lottoPick(6))); after(); }
  if (a === 'del') { l.games.splice(i, 1); after(); }
  if (a === 'clear') { LRUN = null; lottoRenderDrawn(); lottoRenderCtrl(); const m = document.getElementById('ltMsg'); if (m) m.textContent = '번호를 고르고 추첨을 시작하세요'; }
  if (a === 'pick') lottoPickModal(i);
  if (a === 'copy' && LRUN) {
    const t = lottoSort(LRUN.win).join(', ') + ' + 보너스 ' + LRUN.bonus;
    copyText(t).then(ok => toast(ok ? '복사했어요: ' + t : t, ok ? 2400 : 6000));
  }
  if (a === 'use' && LRUN) {
    const w = lottoSort(LRUN.win); l.mode = 'play';
    if (l.games.length < LOTTO.MAX_GAMES) l.games.push(w); else l.games[l.games.length - 1] = w;
    LRUN = null; save(); lottoRenderDrawn(); lottoRenderCtrl(); toast('도전 번호에 넣었어요. 추첨 시작을 눌러 보세요!');
  }
}

/* 번호 직접 고르기 (6개) */
function lottoPickModal(i) {
  const l = LT(); let sel = (l.games[i] || []).slice();
  const m = openModal({ title: '번호 고르기 · ' + 'ABCDE'[i] + ' 게임', body: '<div class="lt-grid" id="ltGrid"></div><div class="muted" id="ltCnt" style="margin-top:10px;text-align:center;font-weight:700"></div>',
    foot: '<button class="btn btn-soft" data-k="auto">나머지 자동</button><button class="btn btn-soft" data-k="reset">초기화</button><button class="btn btn-primary" data-k="ok">확인</button>' });
  const draw = () => {
    m.body.querySelector('#ltGrid').innerHTML = Array.from({ length: 45 }, (_, k) => k + 1).map(n =>
      '<button class="lt-pk' + (sel.includes(n) ? ' on' : '') + '" data-n="' + n + '" style="--bc:' + lottoCol(n)[0] + '">' + n + '</button>').join('');
    m.body.querySelector('#ltCnt').textContent = sel.length + ' / 6개 골랐어요';
    const ok = m.foot.querySelector('[data-k="ok"]'); ok.disabled = sel.length !== 6;
  };
  m.body.addEventListener('click', e => {
    const b = e.target.closest('[data-n]'); if (!b) return;
    const n = +b.dataset.n;
    if (sel.includes(n)) sel = sel.filter(x => x !== n); else if (sel.length < 6) sel.push(n); else { toast('6개까지 고를 수 있어요'); return; }
    draw();
  });
  m.foot.addEventListener('click', e => {
    const k = e.target.closest('[data-k]'); if (!k) return;
    if (k.dataset.k === 'auto') { while (sel.length < 6) { const n = 1 + lottoRand(45); if (!sel.includes(n)) sel.push(n); } draw(); }
    if (k.dataset.k === 'reset') { sel = []; draw(); }
    if (k.dataset.k === 'ok' && sel.length === 6) {
      l.games[i] = lottoSort(sel); if (LRUN && LRUN.phase === 'end' && LRUN.play) { LRUN = null; lottoRenderDrawn(); }
      save(); m.close(); lottoRenderCtrl();
    }
  });
  draw();
}

/* ── 추첨기 그림 (유리 구슬통 안에서 공 45개가 바람에 날림) ─────────── */
let _ltRaf = 0, _ltBalls = null, _ltLast = 0;
function ltInitBalls() {
  _ltBalls = Array.from({ length: 45 }, (_, i) => {
    const a = Math.random() * Math.PI, d = .3 + Math.random() * .55;
    return { n: i + 1, x: Math.cos(a) * d * .9, y: Math.sin(a) * d * .9, vx: 0, vy: 0, out: false };
  });
}
function ltPhysics(blow, dt) {
  const r = .095, B = _ltBalls.filter(b => !b.out);
  B.forEach(b => {
    b.vy += .0028 * dt;
    if (blow) {
      b.vx += (Math.random() - .5) * .014 * dt; b.vy += (Math.random() - .5) * .012 * dt;
      if (b.y > .3) b.vy -= (.012 + Math.random() * .026) * dt;     // 아래에서 바람이 불어 올림
    }
    const damp = blow ? .996 : .97; b.vx *= damp; b.vy *= damp;
    const sp = Math.hypot(b.vx, b.vy); if (sp > .09) { b.vx *= .09 / sp; b.vy *= .09 / sp; }
    b.x += b.vx * dt; b.y += b.vy * dt;
    const d = Math.hypot(b.x, b.y), lim = 1 - r;
    if (d > lim) {
      const nx = b.x / d, ny = b.y / d; b.x = nx * lim; b.y = ny * lim;
      const vn = b.vx * nx + b.vy * ny; if (vn > 0) { b.vx -= 1.6 * vn * nx; b.vy -= 1.6 * vn * ny; }
    }
  });
  for (let i = 0; i < B.length; i++) for (let j = i + 1; j < B.length; j++) {
    const p = B[i], q = B[j], dx = q.x - p.x, dy = q.y - p.y, d2 = dx * dx + dy * dy;
    if (d2 >= 4 * r * r || d2 === 0) continue;
    const d = Math.sqrt(d2), nx = dx / d, ny = dy / d, ov = (2 * r - d) / 2;
    p.x -= nx * ov; p.y -= ny * ov; q.x += nx * ov; q.y += ny * ov;
    const rv = (q.vx - p.vx) * nx + (q.vy - p.vy) * ny;
    if (rv < 0) { const k = -rv * .9; p.vx -= k * nx; p.vy -= k * ny; q.vx += k * nx; q.vy += k * ny; }
  }
}
function ltDrawBall(ctx, x, y, r, n, alpha) {
  const [c, dk] = lottoCol(n);
  ctx.globalAlpha = alpha == null ? 1 : alpha;
  const g = ctx.createRadialGradient(x - r * .35, y - r * .4, r * .08, x, y, r);
  g.addColorStop(0, '#fff'); g.addColorStop(.3, c); g.addColorStop(1, dk);
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, 6.2832); ctx.fill();
  if (r >= 7) {
    ctx.fillStyle = 'rgba(255,255,255,.92)'; ctx.beginPath(); ctx.arc(x, y + r * .04, r * .56, 0, 6.2832); ctx.fill();
    ctx.fillStyle = '#222'; ctx.font = '800 ' + Math.round(r * .78) + 'px Pretendard, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(String(n), x, y + r * .07);
  }
  ctx.globalAlpha = 1;
}
function lottoLoop() {
  cancelAnimationFrame(_ltRaf);
  const cv = document.getElementById('ltCanvas'); if (!cv) return;
  const ctx = cv.getContext('2d');
  if (!_ltBalls) ltInitBalls();
  _ltLast = performance.now();
  const frame = now => {
    if (!cv.isConnected || route.page !== 'lotto') { _ltRaf = 0; return; }
    const dpr = Math.min(2, window.devicePixelRatio || 1), W = cv.clientWidth, H = cv.clientHeight;
    if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, W, H);
    const dt = Math.min(2.5, (now - _ltLast) / 16.67); _ltLast = now;
    const R = LRUN, t = R ? (now - R.t0) / 1000 : 0, TM = R ? lottoTimes(R) : null;
    const running = R && R.phase === 'run';
    const GR = Math.min(W * .34, H * .36), cx = W / 2, cy = H * .44, br = GR * .095;
    const P = (x, y) => [cx + x * GR, cy + y * GR];

    // 뽑혀 나간 공 정리 (화면을 떠났다 와도 시간 기준으로 맞춤)
    _ltBalls.forEach(b => { b.out = false; });
    if (R) R.order.forEach((n, i) => { if (t >= TM.T[i] - TM.lead || R.phase === 'end') { const b = _ltBalls[n - 1]; if (!b.out) { b.out = true; if (!b.cap) b.cap = { x: b.x, y: b.y }; } } });
    if (!R) _ltBalls.forEach(b => { b.cap = null; });
    const blow = running && t < TM.end - .3;
    ltPhysics(blow, dt); if (dt > 1.5) ltPhysics(blow, dt / 2);

    // 받침대
    const sg = ctx.createLinearGradient(0, cy + GR, 0, H);
    sg.addColorStop(0, '#3a3f63'); sg.addColorStop(1, '#1c1f38');
    ctx.fillStyle = sg; ctx.beginPath();
    ctx.moveTo(cx - GR * .42, cy + GR * .9); ctx.lineTo(cx + GR * .42, cy + GR * .9); ctx.lineTo(cx + GR * .8, H - 6); ctx.lineTo(cx - GR * .8, H - 6); ctx.closePath(); ctx.fill();
    // 바람 불빛
    if (blow) { const a = .25 + .2 * Math.sin(now / 90); const bg = ctx.createRadialGradient(cx, cy + GR * .85, 2, cx, cy + GR * .85, GR * .9);
      bg.addColorStop(0, 'rgba(120,200,255,' + a + ')'); bg.addColorStop(1, 'rgba(120,200,255,0)'); ctx.fillStyle = bg; ctx.fillRect(cx - GR, cy, GR * 2, GR * 1.2); }
    // 위쪽 배출구
    ctx.fillStyle = 'rgba(255,255,255,.10)'; ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.rect(cx - br * 1.35, cy - GR - br * 2.6, br * 2.7, br * 2.8); ctx.fill(); ctx.stroke();
    // 유리 구슬통
    const gg = ctx.createRadialGradient(cx - GR * .3, cy - GR * .35, GR * .1, cx, cy, GR);
    gg.addColorStop(0, 'rgba(255,255,255,.10)'); gg.addColorStop(.85, 'rgba(160,190,255,.07)'); gg.addColorStop(1, 'rgba(200,220,255,.22)');
    ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(cx, cy, GR, 0, 6.2832); ctx.fill();
    _ltBalls.forEach(b => { if (!b.out) { const [x, y] = P(b.x, b.y); ltDrawBall(ctx, x, y, br, b.n); } });
    ctx.strokeStyle = 'rgba(255,255,255,.45)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx, cy, GR, 0, 6.2832); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 4; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.arc(cx, cy, GR * .86, Math.PI * 1.08, Math.PI * 1.42); ctx.stroke();

    // 뽑히는 공: 배출구로 올라감 → 앞으로 크게 나와 번호 공개 → 아래 줄로
    if (R && R.phase === 'run') R.order.forEach((n, i) => {
      const T = TM.T[i], s = T - TM.lead, b = _ltBalls[n - 1];
      if (t < s || t > T + TM.hold) return;
      if (t < T) {
        const u = (t - s) / TM.lead, c = b.cap || { x: 0, y: .6 };
        let x, y, rr = br;
        if (u < .55) { const k = u / .55, e = k * k * (3 - 2 * k); x = c.x + (0 - c.x) * e; y = c.y + (-1.2 - c.y) * e; }
        else { const k = (u - .55) / .45, e = 1 - Math.pow(1 - k, 3); x = 0; y = -1.2 + 1.05 * e; rr = br * (1 + 1.6 * e); }
        const [px, py] = P(x, y); ltDrawBall(ctx, px, py, rr, n);
      } else {
        const v = (t - T) / TM.hold, pop = 2.6 + .5 * Math.sin(Math.min(1, v * 2.5) * Math.PI);
        const drop = v > .65 ? (v - .65) / .35 : 0;
        const [px, py] = P(0, -.15 + drop * 1.6);
        const glow = ctx.createRadialGradient(px, py, 2, px, py, br * pop * 2);
        glow.addColorStop(0, 'rgba(255,230,140,.55)'); glow.addColorStop(1, 'rgba(255,230,140,0)');
        ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(px, py, br * pop * 2, 0, 6.2832); ctx.fill();
        ltDrawBall(ctx, px, py, br * pop * (1 - drop * .5), n, 1 - drop * .8);
        if (i === 6 && v < .65) { ctx.fillStyle = '#FFD54A'; ctx.font = '900 15px Pretendard, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('보너스!', px, py - br * pop - 10); }
      }
    });

    // 진행 상황 → 아래 줄 · 문구
    if (R && R.phase === 'run') {
      const rev = TM.T.filter(x => t >= x).length;
      if (rev > R.revealed) {
        for (let i = R.revealed; i < rev; i++) lottoAddDrawn(i);
        if (rev - R.revealed === 1) LSFX.pop(rev === 7);
        R.revealed = rev;
      }
      const msg = document.getElementById('ltMsg');
      if (msg) msg.textContent = t < TM.mix ? '공이 섞이는 중…' : rev < 6 ? (rev + 1) + '번째 공을 뽑아요' : rev < 7 ? '마지막! 보너스 공' : '결과 확인 중…';
      if (t >= TM.end) lottoFinish();
    }
    _ltRaf = requestAnimationFrame(frame);
  };
  _ltRaf = requestAnimationFrame(frame);
}
