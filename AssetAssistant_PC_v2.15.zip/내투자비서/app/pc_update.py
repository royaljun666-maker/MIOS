"""
PC판 자동 업데이트 (pc_update.py)
================================
폰 앱처럼, 관리 파일(update.json)의 'ota' 묶음을 받아 서명을 확인한 뒤 앱 폴더의 파일을 바꿉니다.
  1) 켜고 몇 초 뒤 새 묶음이 있는지 확인 → 받기 → 해시·Ed25519 서명 확인 (폰과 같은 공개키)
  2) 따로 떨어진 프로세스에서 새 코드를 한 번 불러와 봄(시험) — 실패하면 설치 안 함
  3) 지금 파일을 _backup/pre_<버전> 에 보관 → 새 파일로 교체
  4) 화면이 /api/ota/apply 를 부르면 그 자리에서 새 코드로 갈아 끼움 (다시 켤 필요 없음)
  · 설치된 PC 앱(app/runtime 폴더가 있는 곳)에서만 동작 — 개발용 폴더에서는 꺼져 있음
  · 새 파이썬 패키지가 필요한 큰 변경은 이 방식으로 안 되고, PC 압축 파일을 새로 받아야 함
"""
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import zipfile

OTA_PUBKEY = "9b8e517f1a10994645cd73d47ba05b554772cd220a7970b36905a82c9bad50d3"
STATE = {"ready": 0, "applied": 0, "error": "", "checking": False}


# ── Ed25519 서명 확인 (RFC 8032, 순수 파이썬 · 확인 전용) ─────────────────────
_P = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _P - 2, _P) % _P
_I = pow(2, (_P - 1) // 4, _P)


def _xrecover(y, sign):
    xx = (y * y - 1) * pow(_D * y * y + 1, _P - 2, _P) % _P
    x = pow(xx, (_P + 3) // 8, _P)
    if (x * x - xx) % _P:
        x = x * _I % _P
    if (x * x - xx) % _P:
        return None
    if x & 1 != sign:
        x = _P - x
    return x


_BY = 4 * pow(5, _P - 2, _P) % _P
_B = (_xrecover(_BY, 0), _BY, 1, _xrecover(_BY, 0) * _BY % _P)


def _add(p, q):
    a = (p[1] - p[0]) * (q[1] - q[0]) % _P
    b = (p[1] + p[0]) * (q[1] + q[0]) % _P
    c = 2 * p[3] * q[3] * _D % _P
    d = 2 * p[2] * q[2] % _P
    e, f, g, h = b - a, d - c, d + c, b + a
    return (e * f % _P, g * h % _P, f * g % _P, e * h % _P)


def _mul(s, p):
    q = (0, 1, 1, 0)
    while s:
        if s & 1:
            q = _add(q, p)
        p = _add(p, p)
        s >>= 1
    return q


def _enc(p):
    zi = pow(p[2], _P - 2, _P)
    x, y = p[0] * zi % _P, p[1] * zi % _P
    return (y | ((x & 1) << 255)).to_bytes(32, "little")


def _dec(b):
    y = int.from_bytes(b, "little")
    sign, y = y >> 255, y & ((1 << 255) - 1)
    if y >= _P:
        return None
    x = _xrecover(y, sign)
    return None if x is None else (x, y, 1, x * y % _P)


def ed25519_verify(pub, msg, sig):
    try:
        if len(pub) != 32 or len(sig) != 64:
            return False
        A, R = _dec(pub), _dec(sig[:32])
        s = int.from_bytes(sig[32:], "little")
        if A is None or R is None or s >= _L:
            return False
        h = int.from_bytes(hashlib.sha512(sig[:32] + pub + msg).digest(), "little") % _L
        return _enc(_mul(s, _B)) == _enc(_add(R, _mul(h, A)))
    except Exception:
        return False



def enabled(here):
    if os.environ.get("ASSET_PLATFORM") == "android":
        return False
    if os.environ.get("ASSET_PC_AUTOUPDATE") == "0":
        return False
    return os.environ.get("ASSET_PC_AUTOUPDATE") == "1" or os.path.isdir(os.path.join(here, "runtime"))


def status():
    return {k: STATE[k] for k in ("ready", "applied", "error")}


def _state_path(here):
    return os.path.join(here, "_update", "state.json")


def _read_state(here):
    try:
        with open(_state_path(here), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _write_state(here, st):
    os.makedirs(os.path.dirname(_state_path(here)), exist_ok=True)
    with open(_state_path(here), "w", encoding="utf-8") as f:
        json.dump(st, f)


def _trial_import(py_dir, web_dir):
    """새 코드를 다른 프로세스에서 불러와 봄. 문법·불러오기 오류가 있으면 False."""
    tmp = tempfile.mkdtemp(prefix="asset_try_")
    env = dict(os.environ, ASSET_DATA_DIR=tmp, ASSET_WEB_DIR=web_dir, ASSET_PC_AUTOUPDATE="0", PYTHONDONTWRITEBYTECODE="1")
    exe = sys.executable
    if exe.lower().endswith("pythonw.exe") and os.path.exists(exe[:-5] + ".exe"):
        exe = exe[:-5] + ".exe"
    flags = 0x08000000 if os.name == "nt" else 0          # 창 안 뜨게
    try:
        r = subprocess.run([exe, "-c", "import sys; sys.path.insert(0, sys.argv[1]); import price_server, ai_engine, market_data", py_dir],
                           cwd=py_dir, env=env, timeout=180, capture_output=True, creationflags=flags)
        return r.returncode == 0, (r.stderr or b"")[-300:].decode("utf-8", "ignore")
    except Exception as e:
        return False, type(e).__name__
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _install(here, code, blob):
    z = zipfile.ZipFile(io.BytesIO(blob))
    names = z.namelist()
    if any(n.startswith("/") or ".." in n.split("/") for n in names):
        raise ValueError("묶음 경로 이상")
    if "py/price_server.py" not in names or "web/index.html" not in names:
        raise ValueError("묶음 내용 부족")
    root = os.path.join(here, "_update")
    stage = os.path.join(root, "stage_%d" % code)
    shutil.rmtree(stage, ignore_errors=True)
    os.makedirs(stage)
    z.extractall(stage)
    ok, err = _trial_import(os.path.join(stage, "py"), os.path.join(stage, "web"))
    if not ok:
        raise ValueError("새 코드 시험 실패: " + err)
    # 지금 것 보관 (최근 2개만)
    bdir = os.path.join(here, "_backup")
    keep = os.path.join(bdir, "pre_%d" % code)
    shutil.rmtree(keep, ignore_errors=True)
    os.makedirs(keep, exist_ok=True)
    for n in os.listdir(os.path.join(stage, "py")):
        if os.path.exists(os.path.join(here, n)):
            shutil.copy2(os.path.join(here, n), os.path.join(keep, n))
    if os.path.isdir(os.path.join(here, "web")):
        shutil.copytree(os.path.join(here, "web"), os.path.join(keep, "web"))
    olds = sorted(d for d in os.listdir(bdir) if d.startswith("pre_"))
    for d in olds[:-2]:
        shutil.rmtree(os.path.join(bdir, d), ignore_errors=True)
    # 교체 (파이썬 파일은 실행 중이어도 바꿀 수 있음)
    for n in os.listdir(os.path.join(stage, "py")):
        shutil.copy2(os.path.join(stage, "py", n), os.path.join(here, n))
    shutil.copytree(os.path.join(stage, "web"), os.path.join(here, "web"), dirs_exist_ok=True)
    shutil.rmtree(stage, ignore_errors=True)


def _run(here, cur_code, update_url):
    import requests
    time.sleep(4)
    STATE["checking"] = True
    try:
        m = requests.get(update_url, timeout=10, headers={"Cache-Control": "no-cache"}).json()
        o = m.get("ota") or {}
        code = int(o.get("code") or 0)
        st = _read_state(here)
        if code <= cur_code or code in st.get("bad", []):
            return
        r = requests.get(str(o["url"]), timeout=90)
        r.raise_for_status()
        blob = r.content
        digest = hashlib.sha256(blob).hexdigest()
        if digest != str(o.get("sha256", "")).lower():
            raise ValueError("묶음 해시 불일치")
        msg = ("asset-ota:%d:%s" % (code, digest)).encode()
        if not ed25519_verify(bytes.fromhex(OTA_PUBKEY), msg, bytes.fromhex(str(o.get("sig", "")))):
            raise ValueError("묶음 서명 불일치")
        try:
            _install(here, code, blob)
        except ValueError:
            st.setdefault("bad", []).append(code)
            _write_state(here, st)
            raise
        st.update(current=code, prev=cur_code, at=time.time())
        _write_state(here, st)
        STATE["ready"] = code
    except Exception as e:
        STATE["error"] = (type(e).__name__ + ": " + str(e))[:160]
    finally:
        STATE["checking"] = False


def start(here, cur_code, update_url):
    if not update_url or not enabled(here):
        return
    threading.Thread(target=_run, args=(here, cur_code, update_url), name="pc-update", daemon=True).start()
