/* ==========================================================================
   game.js — 🧠 투자 퀴즈 (v4.49 · 크래시 게임을 대신함) + 📅 출석 체크 + 포인트 지갑
   · 하루 3문제 · 4지선다 · 모든 사용자가 같은 날 같은 문제 (서버가 문제 묶음에서 날짜로 골라 줌)
   · 정답 하나에 300,000P · 세 문제 다 맞히면 +100,000P · 틀려도 포인트를 잃지 않음 (거는 것이 없음)
   · 문제마다 '투자 원칙 열 가지' 가운데 하나와 이어지고, 답을 고르면 바로 해설을 보여 줌
   · 포인트는 재미·모의투자 연습용 — 현금/상품으로 바꿀 수 없음
   ========================================================================== */
'use strict';

const GAME = { DAILY: 1000000 };
const QUIZ = { PER_DAY: 3, PT: 300000, BONUS: 100000 };
// 다섯 단계 (v4.54) — 본인이 고르고, 같은 단계끼리 같은 문제. 포인트는 모든 단계가 같음(높은 단계를 찍는 게 이득이 되지 않게).
const QUIZ_LV = [[1, '진짜 초보', '🌱', '투자가 처음이에요'], [2, '초보', '🌿', '기본 용어는 들어 봤어요'], [3, '일반', '🌳', '지표와 재무제표를 어느 정도 봐요'],
  [4, '전문가 수준', '🎓', '가치 평가 · 채권 · 파생상품 기초'], [5, '실무·자격시험 수준', '🏛', '이론 · 계산 방법 · 채권 중심']];

function G() {
  const s = S.settings;
  if (!s.game || typeof s.game !== 'object') s.game = { pts: 0, day: '', plays: 0, bonusDay: '', hist: [], best: 0, todayNet: 0, bet: 20000, auto: 0 };
  return s.game;
}
function gameDayRoll() {
  const g = G(), t = todayKey();
  if (g.day !== t) { g.day = t; g.plays = 0; g.todayNet = 0; }
}
/* 📅 출석 체크 (v2.30) — 하루 한 번 [출석] 버튼으로 100만P · 연속 출석하면 더 많이
   연속 n일째: 100만 + (n-1)×10만 (최대 10일째 190만) · 7일 +300만 · 30일 +1,000만 · 100일 +3,000만 보너스 */
const CHECKIN_MILE = { 7: 3000000, 30: 10000000, 100: 30000000 };
function checkinAmount(streak) { return GAME.DAILY + Math.min(streak - 1, 9) * 100000 + (CHECKIN_MILE[streak] || 0); }
function checkedToday() { return G().bonusDay === todayKey(); }
function checkinNextStreak() {
  const g = G(), y = todayKey(new Date(Date.now() - 86400000));
  return g.bonusDay === y ? (g.streak || 1) + 1 : 1;
}
function grantDailyBonus() {                           // 앱을 켰을 때: 자동 지급 대신 출석하라고 알려 줌
  gameDayRoll();
  if (checkedToday()) return;
  setTimeout(() => toast('📅 오늘 출석하고 ' + nf(checkinAmount(checkinNextStreak()), 0) + 'P 받으세요! (홈의 출석 버튼)', 4500), 1800);
}
function doCheckin() {
  const g = G(); gameDayRoll();
  if (checkedToday()) { toast('오늘은 이미 출석했어요 ✅ 내일 또 오세요 (연속 ' + (g.streak || 1) + '일째)'); return; }
  const st = checkinNextStreak(), amt = checkinAmount(st);
  g.streak = st; g.bestStreak = Math.max(g.bestStreak || 0, st); g.bonusDay = todayKey(); g.pts += amt; save();
  const next = checkinAmount(st + 1), mile = Object.keys(CHECKIN_MILE).map(Number).find(d => d > st);
  openModal({ title: '📅 출석 완료!', body:
    '<div class="ci-box"><div class="ci-amt">+' + nf(amt, 0) + 'P</div><div class="ci-st">🔥 연속 <b>' + st + '일</b> 출석' + (CHECKIN_MILE[st] ? ' · 🎉 ' + st + '일 달성 보너스 +' + nf(CHECKIN_MILE[st], 0) + 'P' : '') + '</div>' +
      '<div class="ci-week">' + Array.from({ length: 7 }, (_, i) => { const d = ((st - 1) % 7) + 1; return '<i class="' + (i < d ? 'on' : '') + '">' + (i + 1) + '</i>'; }).join('') + '</div>' +
      '<div class="ci-pts">내 포인트 <b>💎 ' + nf(g.pts, 0) + 'P</b></div>' +
      '<p class="note">내일 출석하면 <b>' + nf(next, 0) + 'P</b>' + (mile ? ' · ' + mile + '일 연속이면 보너스 +' + nf(CHECKIN_MILE[mile], 0) + 'P' : '') + '<br>하루라도 빠지면 연속 기록이 1일부터 다시 시작해요. 포인트는 게임·모의투자용이며 현금으로 바꿀 수 없어요.</p></div>' });
  if (typeof fxConfetti === 'function') fxConfetti(CHECKIN_MILE[st] ? 4000 : 1800);
  if (route.page && PAGES[route.page]) go(route.page, route.params, true);
}
function checkinBtnHtml(cls) {
  return checkedToday() ? '<button class="btn btn-gray ' + (cls || '') + '" data-act="checkin">✅ 출석 완료 · 연속 ' + (((S.settings.game || {}).streak) || 1) + '일</button>'
    : '<button class="btn btn-primary ' + (cls || '') + '" data-act="checkin">📅 출석하고 ' + nf(checkinAmount(checkinNextStreak()), 0) + 'P 받기</button>';
}

function soundModeSafe() { try { return soundMode(); } catch (e) { return 'off'; } }

/* ── 🧠 오늘의 퀴즈 ─────────────────────────────────────────────────────── */
let _qzBusy = false, _qzErr = '', _qzShow = -1;           // _qzShow: 방금 답한 문제(해설을 보는 중)
function qzLv() { const v = +G().qlv; return v >= 1 && v <= 5 ? v : 1; }                 // 내가 고른 단계
function qzLvName(lv, short) { const x = QUIZ_LV[(+lv || 1) - 1] || QUIZ_LV[0]; return x[2] + ' ' + x[0] + '단계' + (short ? '' : ' · ' + x[1]); }
function QZ() {                                            // 오늘 문제와 내 답
  const g = G();
  if (!g.quiz || typeof g.quiz !== 'object' || g.quiz.day !== todayKey()) g.quiz = { day: todayKey(), lv: qzLv(), items: [], picks: [], bonus: false };
  return g.quiz;
}
function QZS() { const g = G(); if (!g.qzs || typeof g.qzs !== 'object') g.qzs = { n: 0, ok: 0, days: 0, last: '', streak: 0, by: {} }; return g.qzs; }
function quizDone(q) { q = q || QZ(); return q.items.length > 0 && q.items.every((_, i) => q.picks[i] != null); }
function quizRight(q) { q = q || QZ(); return q.items.filter((it, i) => q.picks[i] === it.a).length; }
async function quizLoad(force) {
  const q = QZ();
  if (q.items.length && !force) return;
  if (_qzBusy) return;
  _qzBusy = true; _qzErr = '';
  let d = null;
  try { d = await api('/api/quiz?d=' + encodeURIComponent(todayKey()) + '&lv=' + (q.lv || qzLv()), { timeout: 15000 }); } catch (e) {}
  _qzBusy = false;
  const ok = d && d.ok && Array.isArray(d.items) && d.items.length && d.items.every(x => x && Array.isArray(x.o) && x.o.length === 4 && x.a >= 0 && x.a <= 3);
  if (ok) { const z = QZ(); if (!z.items.length) { z.items = d.items.slice(0, QUIZ.PER_DAY); z.picks = z.items.map(() => null); z.no = d.no || 0; z.lv = +d.lv || z.lv || 1; if (d.counts) _qzCounts = d.counts; save({ noSync: true }); } }
  else _qzErr = (d && d.error) || SERVER_DOWN;
  if (route.page === 'game') quizRender();
}
let _qzCounts = null;                                     // 단계별 문제 수 (서버가 알려 줌)
function quizSetLevel(lv) {
  lv = +lv; if (!(lv >= 1 && lv <= 5)) return;
  const g = G(), q = QZ(), st = QZS(), started = q.picks.some(x => x != null);
  g.qlv = lv; g.qlvSet = true; g.qlvAsk = '';
  if (st.recLv !== lv) { st.rec = []; st.recLv = lv; }
  if (!started && q.lv !== lv) { q.lv = lv; q.items = []; q.picks = []; q.bonus = false; _qzErr = ''; _qzShow = -1; }
  save(); quizRender();
  if (!q.items.length) quizLoad(true);
  toast(started && q.lv !== lv ? '오늘은 이미 풀기 시작해서, ' + qzLvName(lv, true) + ' 문제는 내일부터 나와요' : qzLvName(lv) + ' 문제로 바꿨어요', 3000);
}
function openQuizLevel(first) {
  const cur = qzLv(), g = G();
  const m = openModal({ title: '🧠 내 퀴즈 단계', body:
    '<div class="ru-lead">' + (first ? '먼저 <b>내 단계</b>를 골라 주세요. ' : '') + '언제든 바꿀 수 있어요.<br>포인트는 모든 단계가 같아요. 내 수준에 맞는 단계가 가장 많이 남아요.</div>' +
    QUIZ_LV.map(x => '<button class="qz-lvopt' + (x[0] === cur && g.qlvSet ? ' on' : '') + '" data-lv="' + x[0] + '"><span>' + x[2] + '</span><div><b>' + x[0] + '단계 · ' + esc(x[1]) + '</b><small>' + esc(x[3]) +
      (_qzCounts && _qzCounts[x[0]] ? ' · 문제 ' + _qzCounts[x[0]] + '개' : '') + '</small></div>' + (x[0] === cur && g.qlvSet ? '<i>지금</i>' : '') + '</button>').join('') +
    '<p class="note" style="margin:12px 2px 0">5단계는 이론·계산·채권 중심의 공부용 문제예요. 이 퀴즈를 푼다고 자격이 생기지는 않아요.</p>',
    onClose: () => { if (!G().qlvSet) { G().qlvSet = true; save({ noSync: true }); } } });
  m.body.addEventListener('click', e => { const b = e.target.closest('[data-lv]'); if (!b) return; m.close(); quizSetLevel(+b.dataset.lv); });
}
function qzSuggest() {                                     // 요즘 9문제 넘게 풀었고 정답률이 아주 높거나 낮으면 단계를 권함 (하루 한 번)
  const st = QZS(), g = G(), lv = qzLv(), rec = st.recLv === lv && Array.isArray(st.rec) ? st.rec : [];
  if (rec.length < 9 || g.qlvAsk === todayKey() || (+QZ().lv || 1) !== lv) return null;
  const rate = rec.reduce((a, b) => a + b, 0) / rec.length;
  if (rate >= .8 && lv < 5) return { to: lv + 1, up: true, rate };
  if (rate <= .34 && lv > 1) return { to: lv - 1, up: false, rate };
  return null;
}
function qzSuggestHtml() {
  const s = qzSuggest(); if (!s) return '';
  return '<div class="qz-sg"><b>' + (s.up ? '👏 요즘 정답률이 ' + Math.round(s.rate * 100) + '%예요. 다음 단계를 풀어 볼까요?' : '조금 어려웠나요? 한 단계 내려서 다져 보는 것도 좋아요.') + '</b>' +
    '<div class="row-btns pp-btns"><button class="btn btn-soft btn-sm" style="flex:1" data-qz-setlv="' + s.to + '">' + esc(qzLvName(s.to)) + '(으)로</button><button class="btn btn-ghost btn-sm" style="flex:1" data-qz-keep>지금 단계 그대로</button></div></div>';
}
function quizPick(i, k) {
  const q = QZ(), it = q.items[i]; if (!it || q.picks[i] != null) return;
  const g = G(), st = QZS(), right = k === it.a;
  q.picks[i] = k; st.n++; if (right) { st.ok++; g.pts += QUIZ.PT; }
  const by = st.by[it.r] || (st.by[it.r] = { n: 0, ok: 0 }); by.n++; if (right) by.ok++;
  const lv = +q.lv || 1;                                   // 단계별 기록 + 요즘 15문제(단계를 올리거나 내릴지 권할 때 씀)
  if (!st.lvs || typeof st.lvs !== 'object') st.lvs = {};
  const bl = st.lvs[lv] || (st.lvs[lv] = { n: 0, ok: 0 }); bl.n++; if (right) bl.ok++;
  if (st.recLv !== lv || !Array.isArray(st.rec)) { st.rec = []; st.recLv = lv; }
  st.rec.push(right ? 1 : 0); st.rec = st.rec.slice(-15);
  let bonus = false;
  if (quizDone(q)) {
    const y = todayKey(new Date(Date.now() - 86400000));
    st.streak = st.last === y ? (st.streak || 0) + 1 : 1; st.last = todayKey(); st.days++;
    if (quizRight(q) === q.items.length && !q.bonus) { q.bonus = true; g.pts += QUIZ.BONUS; bonus = true; }
  }
  save(); _qzShow = i; quizRender();
  if (bonus && typeof fxConfetti === 'function') fxConfetti(1600);
}
function quizItemHtml(it, i, pick, review) {
  const done = pick != null, right = pick === it.a;
  return '<div class="qz-q' + (review ? ' rv' : '') + '">' +
    '<div class="qz-tag"><a data-qz-rule="' + (+it.r || 0) + '">' + esc(ruleTag(it.r, it.lv)) + '</a></div>' +
    '<div class="qz-text">' + (review ? '<i>' + (i + 1) + '</i>' : '') + esc(it.q) + '</div>' +
    '<div class="qz-opts">' + it.o.map((o, k) => '<button class="qz-opt' + (done ? (k === it.a ? ' ok' : k === pick ? ' no' : ' off') : '') + '"' + (done ? ' disabled' : ' data-qz-pick="' + i + ':' + k + '"') + '>' +
      '<i>' + 'ABCD'[k] + '</i><span>' + esc(o) + '</span>' + (done && k === it.a ? '<em>정답</em>' : done && k === pick ? '<em>내 답</em>' : '') + '</button>').join('') + '</div>' +
    (done ? '<div class="qz-x ' + (right ? 'ok' : 'no') + '"><b>' + (right ? '✅ 맞았어요! +' + nf(QUIZ.PT, 0) + 'P' : '❌ 아쉬워요. 잃는 포인트는 없어요') + '</b><p>' + esc(it.x) + '</p>' +
      '<a class="lnk" data-qz-ai="' + i + '">🤖 AI에게 더 쉽게 설명해 달라고 하기</a></div>' : '') + '</div>';
}
function quizRender() {
  const main = document.getElementById('qzMain'), side = document.getElementById('qzSide'); if (!main) return;
  const q = QZ(), g = G(), st = QZS(), n = q.items.length;
  const lvNow = +q.lv || 1, lvNext = qzLv();
  const lvBar = '<button class="qz-lv" data-qz-level><b>' + esc(qzLvName(lvNow)) + '</b>' + (lvNext !== lvNow ? '<small>내일부터 ' + esc(qzLvName(lvNext, true)) + '</small>' : '') + '<i>단계 바꾸기</i></button>';
  if (!n) {
    main.innerHTML = lvBar + (_qzErr ? '<p class="note" style="margin:0">😥 ' + esc(_qzErr) + '</p><button class="btn btn-soft btn-sm" style="margin-top:10px" data-qz-reload>다시 불러오기</button>'
      : '<div class="skel" style="height:26px;width:60%;margin-bottom:14px"></div><div class="skel" style="height:54px;margin-bottom:8px"></div><div class="skel" style="height:54px;margin-bottom:8px"></div><div class="skel" style="height:54px"></div>');
  } else {
    const done = quizDone(q), right = quizRight(q);
    let cur = _qzShow >= 0 && _qzShow < n ? _qzShow : q.picks.findIndex(x => x == null);
    const dots = '<div class="qz-dots">' + q.items.map((it, i) => '<i class="' + (q.picks[i] == null ? (i === cur ? 'cur' : '') : q.picks[i] === it.a ? 'ok' : 'no') + '">' + (i + 1) + '</i>').join('') +
      '<span>오늘의 문제 ' + Math.min(n, q.picks.filter(x => x != null).length + (cur >= 0 && q.picks[cur] == null ? 1 : 0)) + ' / ' + n + '</span></div>';
    if (done && cur < 0) {
      const earned = right * QUIZ.PT + (q.bonus ? QUIZ.BONUS : 0);
      main.innerHTML = lvBar + dots +
        '<div class="qz-res"><div class="qz-res-n">' + right + '<small> / ' + n + '</small></div><b>' + (right === n ? '🎉 오늘 문제를 모두 맞혔어요!' : right ? '오늘 ' + n + '문제 가운데 ' + right + '개를 맞혔어요' : '오늘은 아쉬웠어요. 해설을 한 번 읽어 보세요') + '</b>' +
          '<span>받은 포인트 <b>+' + nf(earned, 0) + 'P</b>' + (q.bonus ? ' (모두 정답 보너스 +' + nf(QUIZ.BONUS, 0) + 'P 포함)' : '') + '</span>' +
          '<p>내일 새 문제 3개가 나와요. 같은 단계 분들은 모두 같은 문제를 풀어요.</p>' + qzSuggestHtml() +
          '<div class="row-btns pp-btns"><button class="btn btn-primary" style="flex:1" data-act="go-paper">🎮 모의투자 하러 가기</button><button class="btn btn-outline" style="flex:1" data-qz-rule="0">🌱 ' + RULES_NAME + '</button></div></div>' +
        '<div class="ah-sub" style="margin-top:16px">오늘 푼 문제 다시 보기</div>' + q.items.map((it, i) => quizItemHtml(it, i, q.picks[i], true)).join('');
    } else {
      const answered = q.picks[cur] != null, last = q.picks.every(x => x != null);
      main.innerHTML = lvBar + dots + quizItemHtml(q.items[cur], cur, q.picks[cur], false) +
        (answered ? '<button class="btn btn-primary btn-block btn-lg" style="margin-top:14px" data-qz-next>' + (last ? '오늘 결과 보기' : '다음 문제') + '</button>' : '');
    }
  }
  if (side) {
    const rate = st.n ? Math.round(st.ok / st.n * 100) : null;
    const weak = Object.keys(st.by).map(k => [+k, st.by[k]]).filter(x => x[0] >= 1 && x[1].n >= 3 && x[1].ok / x[1].n < .6).sort((a, b) => a[1].ok / a[1].n - b[1].ok / b[1].n)[0];
    side.innerHTML =
      '<div class="card"><div class="qz-pts"><span>내 포인트</span><b>💎 ' + nf(g.pts, 0) + 'P</b></div>' + checkinBtnHtml('btn-block') +
        '<p class="note" style="margin:10px 0 0">포인트는 <a class="lnk" data-act="go-paper">모의투자</a> 연습에 써요. 현금으로 바꿀 수 없어요.</p></div>' +
      '<div class="card"><div class="ah-sub" style="margin-top:0">내 기록</div><div class="qz-stat"><div><span>푼 문제</span><b>' + nf(st.n, 0) + '</b></div><div><span>정답률</span><b>' + (rate == null ? '-' : rate + '%') + '</b></div><div><span>연속 참여</span><b>' + (st.last === todayKey() || st.last === todayKey(new Date(Date.now() - 86400000)) ? (st.streak || 0) : 0) + '일</b></div></div>' +
        (weak ? '<p class="note" style="margin:10px 0 0">더 익히면 좋은 ' + RULES_ONE + ': <a class="lnk" data-qz-rule="' + weak[0] + '">' + esc(ruleTag(weak[0])) + '</a></p>' : '') + '</div>' +
      '<div class="card qz-how"><div class="ah-sub" style="margin-top:0">이렇게 해요</div><ul><li>하루 <b>3문제</b>, 네 개 가운데 하나를 골라요.</li><li>단계는 <b>다섯 가지</b>예요. 내 수준에 맞게 골라요. 포인트는 모든 단계가 같아요.</li><li>맞히면 한 문제에 <b>' + nf(QUIZ.PT, 0) + 'P</b>, 모두 맞히면 <b>+' + nf(QUIZ.BONUS, 0) + 'P</b>를 더 받아요.</li><li>틀려도 포인트를 <b>잃지 않아요</b>.</li><li>투자 공부용 문제예요. 특정 종목을 권하지 않아요.</li></ul></div>';
  }
}
/* 🧠🎱 퀴즈·로또를 한 탭으로 (v4.55) — 두 화면 맨 위에 같은 전환 버튼을 둠. 왼쪽 메뉴·아래 탭은 하나만 있고 여기서 오감 */
function gameTabs(cur) {
  return '<div class="seg lg gm-tabs" role="tablist">' +
    [['game', '🧠 투자 퀴즈'], ['lotto', '🎱 로또']].map(([pg, t]) =>
      '<button role="tab" data-nav="' + pg + '"' + (pg === cur ? ' class="on" aria-selected="true"' : ' aria-selected="false"') + '>' + t + '</button>').join('') + '</div>';
}
PAGES.game = function (params, re) {
  const el = pageEl('game'); if (!el) return; gameDayRoll();
  if (!(re && document.getElementById('qzMain'))) {
    el.innerHTML = gameTabs('game') +
      '<div class="page-head"><div><h1>🧠 투자 퀴즈</h1><div class="desc">하루 3문제 · 맞히면 포인트 · 틀려도 잃지 않아요</div></div></div>' +
      '<div class="qz-wrap"><div class="card qz-main" id="qzMain"></div><div class="stack qz-side" id="qzSide"></div></div>';
    el.onclick = e => {
      const pk = e.target.closest('[data-qz-pick]'); if (pk) { const [i, k] = pk.dataset.qzPick.split(':').map(Number); quizPick(i, k); return; }
      if (e.target.closest('[data-qz-next]')) { _qzShow = -1; quizRender(); const m = document.getElementById('qzMain'); if (m && m.scrollIntoView) m.scrollIntoView({ block: 'start' }); return; }
      if (e.target.closest('[data-qz-reload]')) { _qzErr = ''; quizRender(); quizLoad(true); return; }
      if (e.target.closest('[data-qz-level]')) { openQuizLevel(); return; }
      const sg = e.target.closest('[data-qz-setlv]'); if (sg) { quizSetLevel(+sg.dataset.qzSetlv); return; }
      if (e.target.closest('[data-qz-keep]')) { G().qlvAsk = todayKey(); save({ noSync: true }); quizRender(); return; }
      const ru = e.target.closest('[data-qz-rule]'); if (ru) { openRules10(+ru.dataset.qzRule); return; }
      const gg = e.target.closest('[data-qz-go]'); if (gg) { go(gg.dataset.qzGo); return; }
      const ai = e.target.closest('[data-qz-ai]');
      if (ai) { const it = QZ().items[+ai.dataset.qzAi]; if (it) openChat('투자 공부 문제예요(' + QUIZ_LV[(+it.lv || 1) - 1][1] + ' 단계). ' + (+it.lv >= 4 ? '풀이 과정과 공식을 차근차근' : '처음 배우는 사람도 알기 쉽게') + ' 설명해 주세요.\n\n문제: ' + it.q + '\n정답: ' + it.o[it.a] + '\n해설: ' + it.x); }
    };
    _qzShow = -1;
    if (!G().qlvSet && !QZ().picks.some(x => x != null)) setTimeout(() => { if (route.page === 'game' && !G().qlvSet) openQuizLevel(true); }, 500);   // 처음 한 번: 내 단계 고르기
  }
  quizRender(); quizLoad(false);
};
