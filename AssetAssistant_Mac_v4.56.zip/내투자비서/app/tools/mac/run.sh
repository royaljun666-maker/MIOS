#!/bin/bash
# ==========================================================================
#  앱 켜기 (맥) — 아이콘과 "… 실행.command" 가 이 파일을 부릅니다.
#    run.sh           뒤에서 조용히 켜고 인터넷 창을 엽니다. (이미 켜져 있으면 창만 엽니다)
#    run.sh --debug   이 창에 진행 내용을 그대로 보여 줍니다. (문제 해결용)
# ==========================================================================
APP="$(cd "$(dirname "$0")/../.." && pwd)"           # …/app
PORT=8000
URL="http://localhost:$PORT/app"

note() {       # 아이콘으로 켰을 땐 보이는 창이 없으니 알림 창으로, 터미널이면 글자로
    if [ -t 1 ] || [ "$(uname -s)" != "Darwin" ]; then
        printf '\n  %s\n\n' "$1"
    else
        osascript -e 'activate' -e "display dialog \"$1\" buttons {\"확인\"} default button 1 with icon caution" >/dev/null 2>&1
    fi
}
port_up() { curl -sf --noproxy '*' -o /dev/null -m 2 "http://127.0.0.1:$PORT/api/status" 2>/dev/null; }
show() {       # 이미 켜져 있을 때: 인터넷 창만 엶. 맥이 아니면(시험용) 실패로 돌려 파이썬이 열게 함
    [ "$(uname -s)" = "Darwin" ] && open "$URL" >/dev/null 2>&1
}

if [ -z "$APP" ] || [ ! -f "$APP/price_server.py" ]; then
    note "프로그램 파일을 찾지 못했어요. 다시 설치해 주세요."
    exit 1
fi
PY="$APP/runtime/python/bin/python3"
[ -x "$PY" ] || PY="$APP/runtime/venv/bin/python3"
if [ ! -x "$PY" ]; then
    note "아직 설치가 끝나지 않았어요. 설치 폴더의 '다시 설치하기'를 먼저 실행해 주세요."
    exit 1
fi

export PYTHONUTF8=1                                   # 아이콘으로 켜면 언어 설정이 비어 있어, 한글 출력이 깨지지 않게
export PYTHONNOUSERSITE=1                             # 이 컴퓨터에 따로 깔린 파이썬 부품과 섞이지 않게
unset PYTHONHOME PYTHONPATH
# 휴대용 파이썬은 맥의 인증서 묶음을 모를 수 있어, 함께 깔린 인증서 묶음을 알려 줌
if [ -z "${SSL_CERT_FILE:-}" ]; then
    CERT="$("$PY" -c 'import certifi; print(certifi.where())' 2>/dev/null)"
    if [ -n "$CERT" ] && [ -f "$CERT" ]; then export SSL_CERT_FILE="$CERT"; fi
fi

cd "$APP" || exit 1

if [ "${1:-}" = "--debug" ]; then
    if port_up; then
        printf '\n  앱이 이미 켜져 있어요. 원인을 보려면 앱 왼쪽 아래 [종료]를 누른 뒤 이 파일을 다시 눌러 주세요.\n\n'
        show
        exit 0
    fi
    "$PY" "$APP/price_server.py" --open
    printf '\n  앱이 꺼졌어요. 도움이 필요하면 위 내용을 사진으로 찍어 배포한 분께 보내 주세요.\n\n'
    exit 0
fi

tell() { if [ -t 1 ]; then printf '  %s\n' "$1"; fi; }  # 터미널로 켰을 때만 한 줄 안내 (아이콘으로 켜면 보이는 창이 없음)
if port_up && show; then                              # 이미 켜져 있으면 창만 열고 끝 (기록 파일도 건드리지 않음)
    tell ""; tell "앱이 이미 켜져 있어서 인터넷 창만 열었어요. 이 창은 닫으셔도 돼요."; tell ""
    exit 0
fi
tell ""; tell "앱을 켜는 중… (처음에는 10초쯤 걸려요)"

LOG="$APP/runtime/last_run.log"
if [ -f "$LOG" ] && [ "$(wc -c <"$LOG" | tr -d ' ')" -gt 200000 ]; then : >"$LOG"; fi   # 기록이 너무 커지면 비움
# 아이콘(작은 앱)이 먼저 끝나거나 터미널 창을 닫아도 앱이 같이 꺼지지 않게, 따로 떨어진 묶음(세션)으로 켬
(
    trap '' HUP
    exec "$PY" -c 'import os, sys
try:
    os.setsid()
except Exception:
    pass
os.execv(sys.argv[1], sys.argv[1:])' "$PY" "$APP/price_server.py" --open
) >>"$LOG" 2>&1 </dev/null &

i=0
while [ "$i" -lt 160 ]; do                            # 40초 안에 켜지는지 확인 (오래된 맥은 처음에 느릴 수 있음)
    if port_up; then tell "켜졌어요. 인터넷 창이 열려요. 이 창은 닫으셔도 돼요."; tell ""; exit 0; fi
    sleep 0.25
    i=$((i + 1))
done
note "앱이 켜지지 않았어요. 설치 폴더의 '문제 해결용 실행'을 눌러 나오는 내용을 사진으로 찍어 보내 주세요."
exit 1
