﻿# ==========================================================================
#  내 자산 비서 — 삭제 스크립트 ("삭제하기.bat" 이 실행)
#  바탕화면·시작 메뉴 아이콘과 휴대용 파이썬(runtime 폴더)을 지웁니다.
#  자산 데이터(userdata 폴더)는 물어본 뒤에만 지웁니다.
# ==========================================================================
$ErrorActionPreference = 'Continue'
$App = Split-Path -Parent $PSScriptRoot
$AppName = '내 자산 비서'

Write-Host ''
Write-Host '  ================================================' -ForegroundColor Blue
Write-Host '        내 자산 비서  -  삭제' -ForegroundColor Blue
Write-Host '  ================================================' -ForegroundColor Blue
Write-Host ''

# 켜져 있으면 끄기
try { Invoke-WebRequest -Uri 'http://127.0.0.1:8000/shutdown' -UseBasicParsing -TimeoutSec 3 | Out-Null; Start-Sleep -Seconds 1 } catch {}

foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    $lnk = Join-Path $dir ($AppName + '.lnk')
    if (Test-Path -LiteralPath $lnk) { Remove-Item -LiteralPath $lnk -Force; Write-Host ('  [OK] 아이콘 삭제: ' + $lnk) -ForegroundColor Green }
}
$rt = Join-Path $App 'runtime'
if (Test-Path -LiteralPath $rt) { Remove-Item -LiteralPath $rt -Recurse -Force; Write-Host '  [OK] 휴대용 파이썬 삭제' -ForegroundColor Green }

$ud = Join-Path $App 'userdata'
if (Test-Path -LiteralPath $ud) {
    Write-Host ''
    Write-Host '  자산 데이터(가족·계좌·기록)와 AI 키가 userdata 폴더에 남아 있어요.' -ForegroundColor Yellow
    $ans = Read-Host '  이것도 지울까요? 지우면 되돌릴 수 없어요. (지우려면 y 입력 후 Enter)'
    if ($ans -match '^\s*[yYㅛ]') { Remove-Item -LiteralPath $ud -Recurse -Force; Write-Host '  [OK] 자산 데이터 삭제' -ForegroundColor Green }
    else { Write-Host '  자산 데이터는 남겨 두었어요. 다시 설치하면 그대로 이어서 쓸 수 있어요.' -ForegroundColor Gray }
}
Write-Host ''
Write-Host '  삭제가 끝났어요. 앱 폴더는 직접 지우셔도 됩니다.' -ForegroundColor White
Write-Host ''
