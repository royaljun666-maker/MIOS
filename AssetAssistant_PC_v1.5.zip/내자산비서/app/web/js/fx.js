/* ==========================================================================
   fx.js — 화면 연출 (v1.5)
     · 숫자 올라가기(카운트업) · 값이 바뀌면 반짝임
     · 보유 종목 히트맵(크기=비중, 색=등락)
     · 시세 전광판(흐르는 띠) + 홈에 있는 동안 시장 자동 갱신
     · 버튼 물결 · 자산 최고 기록 축하(꽃가루)
   움직임 줄이기(접근성) 설정이 켜져 있으면 애니메이션 없이 바로 보여 줍니다.
   ========================================================================== */
'use strict';

const FX_REDUCED = (() => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } })();

/* ── 숫자 카운트업 ─────────────────────────────────────────────────────── */
const _fxLast = {};
function fxCountUp(el, to, o) {
  if (!el) return;
  o = o || {};
  const fmt = o.fmt || (v => nf(Math.round(v), 0));
  const key = o.key || el.id;
  const seen = key in _fxLast;
  const from = seen ? _fxLast[key] : (o.from != null ? o.from : 0);
  _fxLast[key] = to;
  if (FX_REDUCED || from === to || !isFinite(from) || !isFinite(to)) { el.textContent = fmt(to); return; }
  if (seen && o.flash !== false) fxFlash(el, to - from);
  const ms = o.ms || (from === 0 ? 1300 : 900), t0 = performance.now();
  const ease = t => t >= 1 ? 1 : 1 - Math.pow(2, -10 * t);   // easeOutExpo
  el.textContent = fmt(from);
  (function step(now) {
    const t = Math.min(1, (now - t0) / ms);
    el.textContent = fmt(from + (to - from) * ease(t));
    if (t < 1 && el.isConnected) requestAnimationFrame(step);
  })(t0);
}

/* 값이 오르면 빨강, 내리면 파랑으로 잠깐 반짝 (한국식 색) */
function fxFlash(el, diff) {
  if (!el || !diff || FX_REDUCED) return;
  el.classList.remove('fx-flash-up', 'fx-flash-down');
  void el.offsetWidth;                                   // 애니메이션 다시 시작
  el.classList.add(diff > 0 ? 'fx-flash-up' : 'fx-flash-down');
}

/* ── 보유 종목 히트맵 ───────────────────────────────────────────────────── */
function fxHeatItems() {
  const map = new Map();
  allHoldings().forEach(({ a, h }) => {
    const v = hv(h); if (!(v.valK > 0)) return;
    const k = String(h.ticker || dispName(h)).toUpperCase() + '|' + v.ccy;
    let m = map.get(k);
    if (!m) { m = { name: dispName(h), val: 0, cost: 0, chg: v.chg, a, h, big: 0 }; map.set(k, m); }
    m.val += v.valK; m.cost += v.costK;
    if (v.valK > m.big) { m.big = v.valK; m.a = a; m.h = h; }
    if (m.chg == null && v.chg != null) m.chg = v.chg;
  });
  return [...map.values()].map(m => ({ ...m, ret: m.cost > 0 ? (m.val - m.cost) / m.cost * 100 : 0 }))
    .sort((p, q) => q.val - p.val);
}

function fxHeatmapCard() {
  const items = fxHeatItems();
  if (items.length < 2) return '';
  const mode = UI.heatMode === 'ret' ? 'ret' : 'day';
  const cap = mode === 'ret' ? 30 : 3;
  return '<div class="card span-12 fx-heat-card">' +
    '<div class="card-head"><h3>' + icon('layers', 'ic-sm') + '보유 종목 지도 <span class="muted" style="font-weight:600;font-size:.8rem">크기 = 비중 · 색 = ' + (mode === 'ret' ? '총 수익률' : '오늘 등락') + '</span></h3>' +
      '<div class="seg" id="heatSeg"><button data-v="day" class="' + (mode === 'day' ? 'on' : '') + '">오늘 등락</button><button data-v="ret" class="' + (mode === 'ret' ? 'on' : '') + '">총 수익률</button></div></div>' +
    '<div class="fx-heat" id="homeHeat"></div>' +
    '<div class="fx-heat-legend"><span>-' + cap + '%</span><i></i><span>+' + cap + '%</span></div></div>';
}

/* squarified treemap — 정사각형에 가깝게 나눠서 이름이 잘 보이게 */
function fxSquarify(vals, x, y, w, h) {
  const out = [], total = vals.reduce((s, v) => s + v, 0);
  if (!(total > 0)) return out;
  const area = vals.map(v => v / total * w * h);
  let i = 0;
  while (i < area.length) {
    const side = Math.min(w, h);
    let row = [area[i]], j = i + 1;
    const worst = r => { const s = r.reduce((a, b) => a + b, 0), mx = Math.max(...r), mn = Math.min(...r); return Math.max(side * side * mx / (s * s), s * s / (side * side * mn)); };
    while (j < area.length && worst(row.concat(area[j])) <= worst(row)) { row.push(area[j]); j++; }
    const s = row.reduce((a, b) => a + b, 0);
    if (w >= h) {                                       // 왼쪽 세로줄로 채움
      const cw = s / h; let cy = y;
      row.forEach(r => { const ch = r / cw; out.push([x, cy, cw, ch]); cy += ch; });
      x += cw; w -= cw;
    } else {                                            // 위쪽 가로줄로 채움
      const rh = s / w; let cx = x;
      row.forEach(r => { const cw = r / rh; out.push([cx, y, cw, rh]); cx += cw; });
      y += rh; h -= rh;
    }
    i = j;
  }
  return out;
}

function fxHeatColor(v, cap) {
  if (v == null || !isFinite(v)) return 'rgb(58,63,71)';
  const t = Math.pow(Math.min(1, Math.abs(v) / cap), 0.65);
  const base = [58, 63, 71], hi = v >= 0 ? [240, 68, 82] : [49, 130, 246];
  return 'rgb(' + base.map((b, k) => Math.round(b + (hi[k] - b) * t)).join(',') + ')';
}

function fxRenderHeatmap(animate) {
  const box = document.getElementById('homeHeat'); if (!box) return;
  const items = fxHeatItems().slice(0, 40);
  const mode = UI.heatMode === 'ret' ? 'ret' : 'day', cap = mode === 'ret' ? 30 : 3;
  const W = box.clientWidth || 600, H = W < 520 ? 300 : 340;
  box.style.height = H + 'px';
  const rects = fxSquarify(items.map(x => x.val), 0, 0, W, H);
  box.innerHTML = items.map((x, i) => {
    const [l, t, w, hh] = rects[i] || [0, 0, 0, 0];
    const v = mode === 'ret' ? x.ret : x.chg;
    const big = w > 120 && hh > 70, tiny = w < 54 || hh < 34;
    return '<div class="fx-tile' + (animate && !FX_REDUCED ? ' fx-pop' : '') + '" data-act="open-h" data-a="' + x.a.id + '" data-h="' + x.h.id + '" ' +
      'style="left:' + l.toFixed(1) + 'px;top:' + t.toFixed(1) + 'px;width:' + Math.max(0, w - 3).toFixed(1) + 'px;height:' + Math.max(0, hh - 3).toFixed(1) + 'px;' +
      'background:' + fxHeatColor(v, cap) + ';animation-delay:' + Math.min(i * 35, 700) + 'ms" title="' + esc(x.name) + '">' +
      (tiny ? '' : '<b style="font-size:' + (big ? '1.05rem' : '.8rem') + '">' + esc(x.name) + '</b>' +
        '<span style="font-size:' + (big ? '.95rem' : '.75rem') + '">' + (v == null ? '-' : pct(v)) + '</span>' +
        (big ? '<em>' + compactKRW(x.val) + '원</em>' : '')) + '</div>';
  }).join('');
  const seg = document.getElementById('heatSeg');
  if (seg && !seg._wired) {
    seg._wired = true;
    seg.addEventListener('click', e => {
      const b = e.target.closest('button[data-v]'); if (!b) return;
      UI.heatMode = b.dataset.v; saveUI();
      seg.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b));
      const card = seg.closest('.fx-heat-card');
      const cap2 = UI.heatMode === 'ret' ? 30 : 3;
      card.querySelector('.card-head .muted').textContent = '크기 = 비중 · 색 = ' + (UI.heatMode === 'ret' ? '총 수익률' : '오늘 등락');
      const lg = card.querySelectorAll('.fx-heat-legend span'); lg[0].textContent = '-' + cap2 + '%'; lg[1].textContent = '+' + cap2 + '%';
      fxRenderHeatmap(true);
    });
  }
}
let _fxHeatRz;
window.addEventListener('resize', () => { clearTimeout(_fxHeatRz); _fxHeatRz = setTimeout(() => fxRenderHeatmap(false), 200); });

/* ── 시세 전광판(흐르는 띠) ────────────────────────────────────────────── */
function fxMarqueeHtml() {
  return '<div class="fx-marquee" id="homeMarquee" aria-label="실시간 시장 지표"><div class="fx-mq-track">' + fxMarqueeItems() + '</div></div>';
}
function fxMarqueeItems() {
  const items = MK.data && MK.data.items ? MK.data.items.filter(x => x.price != null) : [];
  if (!items.length) return '<span class="fx-mq-item muted">시장 지표를 불러오는 중…</span>';
  const one = items.map(x => '<span class="fx-mq-item" data-mk="' + esc(x.id) + '"><b>' + esc(x.name) + '</b><span class="px">' + mkPrice(x) + '</span>' +
    '<span class="' + cls(x.change_pct) + '">' + (x.change_pct != null ? arrow(x.change_pct) + ' ' + pct(x.change_pct) : '') + '</span></span>').join('');
  return one + one;                                     // 두 번 이어 붙여서 끊김 없이 돌게
}
function fxMarqueeSpeed() {
  const tr = document.querySelector('#homeMarquee .fx-mq-track'); if (!tr) return;
  const n = MK.data && MK.data.items ? MK.data.items.length : 6;
  tr.style.animationDuration = Math.max(25, n * 4.5) + 's';
}

/* 홈에 있는 동안 시장 지표 자동 갱신 → 바뀐 값만 반짝 */
let _fxMkTimer = null;
function fxStartLiveMarket() {
  if (_fxMkTimer) return;
  _fxMkTimer = setInterval(() => {
    if (document.hidden || route.page !== 'home') return;
    const before = {}; (MK.data && MK.data.items || []).forEach(x => { before[x.id] = x.price; });
    loadMarket(true).then(() => {
      if (route.page !== 'home') return;
      const strip = document.getElementById('homeTicker');
      if (strip) {
        strip.innerHTML = tickerStripHtml();
        strip.querySelectorAll('.tick').forEach((t, i) => {
          const id = ['kospi', 'kosdaq', 'sp500', 'nasdaq', 'usdkrw', 'krw-btc'][i], x = mkItem(id);
          if (x && before[id] != null && x.price !== before[id]) fxFlash(t.querySelector('.px'), x.price - before[id]);
        });
      }
      document.querySelectorAll('#homeMarquee [data-mk]').forEach(s => {
        const x = mkItem(s.dataset.mk); if (!x) return;
        const px = s.querySelector('.px'), ch = s.querySelector('.px + span');
        if (px) px.innerHTML = mkPrice(x);
        if (ch) { ch.className = cls(x.change_pct); ch.textContent = x.change_pct != null ? arrow(x.change_pct) + ' ' + pct(x.change_pct) : ''; }
        if (before[x.id] != null && x.price !== before[x.id]) fxFlash(s, x.price - before[x.id]);
      });
    });
  }, 90 * 1000);
}

/* ── 버튼 물결 ──────────────────────────────────────────────────────────── */
document.addEventListener('pointerdown', e => {
  if (FX_REDUCED) return;
  const b = e.target.closest('.btn, .chip, .seg button'); if (!b || b.disabled) return;
  const r = b.getBoundingClientRect(), d = Math.max(r.width, r.height) * 2;
  const s = document.createElement('span'); s.className = 'fx-ripple';
  s.style.cssText = 'width:' + d + 'px;height:' + d + 'px;left:' + (e.clientX - r.left - d / 2) + 'px;top:' + (e.clientY - r.top - d / 2) + 'px';
  b.appendChild(s); setTimeout(() => s.remove(), 650);
}, { passive: true });

/* ── 꽃가루 ─────────────────────────────────────────────────────────────── */
function fxConfetti(ms) {
  if (FX_REDUCED) return;
  ms = ms || 2800;
  const c = document.createElement('canvas'); c.className = 'fx-confetti';
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  c.width = innerWidth * dpr; c.height = innerHeight * dpr; document.body.appendChild(c);
  const g = c.getContext('2d'); g.scale(dpr, dpr);
  const COL = ['#3182F6', '#F04452', '#FFC233', '#1BAF7A', '#8B5CF6', '#FF8A3D', '#ffffff'];
  const P = Array.from({ length: 170 }, (_, i) => ({
    x: innerWidth / 2 + (Math.random() - .5) * 120, y: innerHeight * .35,
    vx: (Math.random() - .5) * 14, vy: -Math.random() * 13 - 4, s: 5 + Math.random() * 6,
    r: Math.random() * 6.28, vr: (Math.random() - .5) * .3, c: COL[i % COL.length], w: Math.random() < .5,
  }));
  const t0 = performance.now();
  (function frame(now) {
    const t = now - t0; g.clearRect(0, 0, innerWidth, innerHeight);
    g.globalAlpha = t > ms - 600 ? Math.max(0, (ms - t) / 600) : 1;
    P.forEach(p => {
      p.vy += .32; p.vx *= .99; p.x += p.vx; p.y += p.vy; p.r += p.vr;
      g.save(); g.translate(p.x, p.y); g.rotate(p.r); g.fillStyle = p.c;
      if (p.w) g.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2); else { g.beginPath(); g.arc(0, 0, p.s / 2.4, 0, 6.28); g.fill(); }
      g.restore();
    });
    if (t < ms) requestAnimationFrame(frame); else c.remove();
  })(t0);
}

/* 자산 최고 기록이면 하루 한 번 축하 */
function fxRecordCheck(asset, hist) {
  const today = todayKey();
  const prev = hist.filter(s => s.date !== today).map(s => num(s.totalAsset)).filter(v => v > 0);
  if (prev.length < 3 || !(asset > Math.max(...prev)) || UI.fxRecord === today) return;
  if (!UI.lastRefresh || todayKey(new Date(UI.lastRefresh)) !== today) return;   // 오늘 시세로 계산된 값일 때만
  UI.fxRecord = today; saveUI();
  setTimeout(() => { fxConfetti(); toast('🎉 자산 최고 기록을 새로 썼어요! ' + korUnit(asset), 4200); }, 900);
}
