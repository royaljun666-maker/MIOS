"""
무료 시장 데이터 (market_data.py)
=================================

키 없이 무료로 받을 수 있는 정보만 모아 화면에 전달합니다.
  - 지수·환율·금리·원자재 : 야후 파이낸스 차트 API
  - 코인(원화)            : 업비트 공개 API
  - 공포·탐욕 지수         : CNN(주식) · alternative.me(코인)
  - 시장 뉴스              : 구글 뉴스 RSS
  - 종목 검색(한글 OK)     : 네이버 증권 자동완성 → 야후 검색(백업)
  - 종목 차트              : 야후 파이낸스 차트 API
모두 '비공식/공개' 경로라 가끔 실패할 수 있으며, 실패해도 앱은 멈추지 않습니다.
"""

import re
import time
from concurrent.futures import ThreadPoolExecutor
from email.utils import parsedate_to_datetime
from xml.etree import ElementTree as ET

import requests
from flask import Blueprint, jsonify, request

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0 Safari/537.36")
H = {"User-Agent": UA, "Accept": "application/json,text/plain,*/*"}
TIMEOUT = 7

bp = Blueprint("market", __name__)

_C = {}


def _cget(k, ttl):
    v = _C.get(k)
    if v and time.time() - v[0] < ttl:
        return v[1]
    return None


def _cset(k, v):
    _C[k] = (time.time(), v)
    return v


# ---------------------------------------------------------------------------
# 야후 차트
# ---------------------------------------------------------------------------
def yahoo_chart(symbol, rng="1mo", interval="1d"):
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"
    r = requests.get(url, params={"range": rng, "interval": interval, "includePrePost": "false"},
                     headers=H, timeout=TIMEOUT)
    r.raise_for_status()
    res = r.json()["chart"]["result"][0]
    meta = res.get("meta") or {}
    ts = res.get("timestamp") or []
    closes = ((res.get("indicators") or {}).get("quote") or [{}])[0].get("close") or []
    pts = [[t, round(c, 4)] for t, c in zip(ts, closes) if c is not None]
    return meta, pts


MARKET_ITEMS = [
    # id, 이름, 그룹, 야후 심볼, 배수(엔화는 100엔 기준), 단위
    ("kospi", "코스피", "국내", "^KS11", 1, ""),
    ("kosdaq", "코스닥", "국내", "^KQ11", 1, ""),
    ("kospi200", "코스피 200", "국내", "^KS200", 1, ""),
    ("usdkrw", "원/달러 환율", "국내", "KRW=X", 1, "원"),
    ("sp500", "S&P 500", "미국", "^GSPC", 1, ""),
    ("nasdaq", "나스닥", "미국", "^IXIC", 1, ""),
    ("dow", "다우존스", "미국", "^DJI", 1, ""),
    ("sox", "필라델피아 반도체", "미국", "^SOX", 1, ""),
    ("nikkei", "일본 닛케이 225", "아시아", "^N225", 1, ""),
    ("shanghai", "중국 상하이종합", "아시아", "000001.SS", 1, ""),
    ("hangseng", "홍콩 항셍", "아시아", "^HSI", 1, ""),
    ("taiex", "대만 가권", "아시아", "^TWII", 1, ""),
    ("us10y", "미국 10년 국채금리", "금리·달러·심리", "^TNX", 1, "%"),
    ("dxy", "달러 인덱스", "금리·달러·심리", "DX-Y.NYB", 1, ""),
    ("vix", "VIX 변동성(공포)지수", "금리·달러·심리", "^VIX", 1, ""),
    ("jpykrw", "원/100엔 환율", "금리·달러·심리", "JPYKRW=X", 100, "원"),
    ("gold", "금 (온스)", "원자재", "GC=F", 1, "$"),
    ("wti", "WTI 원유 (배럴)", "원자재", "CL=F", 1, "$"),
    ("silver", "은 (온스)", "원자재", "SI=F", 1, "$"),
    ("copper", "구리 (파운드)", "원자재", "HG=F", 1, "$"),
]


def _one_market(item):
    iid, name, group, sym, mult, unit = item
    try:
        meta, pts = yahoo_chart(sym, "1mo", "1d")
        price = meta.get("regularMarketPrice")
        prev = None
        if len(pts) >= 2:
            # 마지막 점이 오늘이면 그 전날 종가가 '전일'
            prev = pts[-2][1]
        if price is None and pts:
            price = pts[-1][1]
        if price is None:
            return None
        price *= mult
        prev = prev * mult if prev else None
        chg = (price - prev) if prev else None
        return {"id": iid, "name": name, "group": group, "unit": unit, "price": round(price, 2),
                "change": round(chg, 2) if chg is not None else None,
                "change_pct": round(chg / prev * 100, 2) if prev else None,
                "spark": [round(p[1] * mult, 2) for p in pts][-22:]}
    except Exception:
        return None


def _upbit():
    out = []
    try:
        r = requests.get("https://api.upbit.com/v1/ticker", params={"markets": "KRW-BTC,KRW-ETH,KRW-XRP,KRW-SOL"},
                         headers=H, timeout=TIMEOUT)
        r.raise_for_status()
        names = {"KRW-BTC": "비트코인", "KRW-ETH": "이더리움", "KRW-XRP": "리플", "KRW-SOL": "솔라나"}
        for x in r.json():
            spark = []
            try:
                c = requests.get("https://api.upbit.com/v1/candles/days",
                                 params={"market": x["market"], "count": 22}, headers=H, timeout=TIMEOUT).json()
                spark = [k["trade_price"] for k in reversed(c)]
            except Exception:
                pass
            out.append({"id": x["market"].lower(), "name": names.get(x["market"], x["market"]),
                        "group": "코인", "unit": "원", "price": x["trade_price"],
                        "change": x.get("signed_change_price"),
                        "change_pct": round((x.get("signed_change_rate") or 0) * 100, 2), "spark": spark})
    except Exception:
        pass
    return out


@bp.get("/api/market")
def api_market():
    c = _cget("market", 90)
    if c:
        return jsonify(c)
    with ThreadPoolExecutor(max_workers=10) as ex:
        items = [x for x in ex.map(_one_market, MARKET_ITEMS) if x]
        up = ex.submit(_upbit).result()
    data = {"items": items + up, "updated": time.strftime("%Y-%m-%d %H:%M")}
    if items:
        _cset("market", data)
    return jsonify(data)


@bp.get("/api/sentiment")
def api_sentiment():
    c = _cget("sent", 1800)
    if c:
        return jsonify(c)
    out = {"stock": None, "crypto": None}
    try:
        r = requests.get("https://production.dataviz.cnn.io/index/fearandgreed/graphdata",
                         headers={"User-Agent": UA, "Referer": "https://edition.cnn.com/"}, timeout=TIMEOUT)
        fg = r.json()["fear_and_greed"]
        out["stock"] = {"score": round(fg["score"]), "rating": fg.get("rating"),
                        "prev": round(fg.get("previous_close") or 0),
                        "week": round(fg.get("previous_1_week") or 0),
                        "month": round(fg.get("previous_1_month") or 0)}
    except Exception:
        pass
    try:
        r = requests.get("https://api.alternative.me/fng/", params={"limit": 2}, headers=H, timeout=TIMEOUT)
        d = r.json()["data"]
        out["crypto"] = {"score": int(d[0]["value"]), "rating": d[0]["value_classification"],
                         "prev": int(d[1]["value"]) if len(d) > 1 else None}
    except Exception:
        pass
    return jsonify(_cset("sent", out) if (out["stock"] or out["crypto"]) else out)


# ---------------------------------------------------------------------------
# 시장 뉴스 (구글 뉴스 경제 섹션)
# ---------------------------------------------------------------------------
def _rss(url, limit=20):
    r = requests.get(url, headers={"User-Agent": UA}, timeout=TIMEOUT)
    r.raise_for_status()
    root = ET.fromstring(r.content)
    out = []
    for it in root.iter("item"):
        title = (it.findtext("title") or "").strip()
        src = (it.findtext("source") or "").strip()
        if src and title.endswith(" - " + src):
            title = title[: -len(" - " + src)]
        ts = None
        try:
            ts = int(parsedate_to_datetime(it.findtext("pubDate")).timestamp())
        except Exception:
            pass
        if title:
            out.append({"title": title, "url": (it.findtext("link") or "").strip(), "source": src, "ts": ts})
        if len(out) >= limit:
            break
    return out


@bp.get("/api/market/news")
def api_market_news():
    lang = request.args.get("lang", "kr")
    ck = "mnews:" + lang
    c = _cget(ck, 600)
    if c:
        return jsonify(c)
    if lang == "us":
        url = "https://news.google.com/rss/headlines/section/topic/BUSINESS?hl=en-US&gl=US&ceid=US:en"
    else:
        url = "https://news.google.com/rss/headlines/section/topic/BUSINESS?hl=ko&gl=KR&ceid=KR:ko"
    try:
        items = _rss(url, 24)
    except Exception:
        items = []
    items.sort(key=lambda x: x.get("ts") or 0, reverse=True)
    return jsonify(_cset(ck, items) if items else items)


# ---------------------------------------------------------------------------
# 종목 검색 — '삼성전자', '애플', 'TSLA', '005930' 모두 OK
# ---------------------------------------------------------------------------
@bp.get("/api/search")
def api_search():
    q = (request.args.get("q") or "").strip()
    if not q:
        return jsonify([])
    ck = "search:" + q.lower()
    c = _cget(ck, 3600)
    if c is not None:
        return jsonify(c)
    out, seen = [], set()
    try:
        r = requests.get("https://ac.stock.naver.com/ac", params={"q": q, "target": "stock,etf"},
                         headers=H, timeout=TIMEOUT)
        d = r.json()
        for it in d.get("items") or []:
            nat = it.get("nationCode")
            if nat not in ("KOR", "USA"):
                continue
            code = (it.get("code") or "").strip()
            if not code or code in seen:
                continue
            seen.add(code)
            kr = nat == "KOR"
            out.append({"ticker": code, "name": it.get("name") or code,
                        "market": "kr" if kr else "us", "ccy": "KRW" if kr else "USD",
                        "exchange": it.get("typeName") or it.get("typeCode") or ""})
    except Exception:
        pass
    if len(out) < 3 and re.fullmatch(r"[A-Za-z.\-^ ]{1,20}", q):
        try:
            r = requests.get("https://query2.finance.yahoo.com/v1/finance/search",
                             params={"q": q, "quotesCount": 8, "newsCount": 0}, headers=H, timeout=TIMEOUT)
            for it in r.json().get("quotes") or []:
                sym = it.get("symbol") or ""
                if it.get("quoteType") not in ("EQUITY", "ETF") or "." in sym or "=" in sym or sym in seen:
                    continue
                seen.add(sym)
                out.append({"ticker": sym, "name": it.get("shortname") or it.get("longname") or sym,
                            "market": "us", "ccy": "USD", "exchange": it.get("exchDisp") or ""})
        except Exception:
            pass
    out = out[:10]
    return jsonify(_cset(ck, out))


# ---------------------------------------------------------------------------
# 종목 차트
# ---------------------------------------------------------------------------
RANGES = {"1d": ("1d", "5m"), "1w": ("5d", "30m"), "1m": ("1mo", "1d"), "3m": ("3mo", "1d"),
          "1y": ("1y", "1d"), "5y": ("5y", "1wk")}


@bp.get("/api/chart")
def api_chart():
    t = (request.args.get("ticker") or "").strip().upper()
    market = (request.args.get("market") or "").lower()
    rng = request.args.get("range", "3m")
    if not t:
        return jsonify({"ok": False}), 400
    yr, iv = RANGES.get(rng, RANGES["3m"])
    ck = f"chart:{t}:{market}:{rng}"
    c = _cget(ck, 300 if rng in ("1d", "1w") else 1800)
    if c:
        return jsonify(c)
    if market == "kr" or re.fullmatch(r"\d[0-9A-Z]{5}", t):
        syms = [t + ".KS", t + ".KQ"]
    else:
        syms = [t]
    for sym in syms:
        try:
            meta, pts = yahoo_chart(sym, yr, iv)
            if len(pts) >= 2:
                data = {"ok": True, "symbol": sym, "points": pts,
                        "prev_close": meta.get("chartPreviousClose"),
                        "currency": meta.get("currency"),
                        "high52": meta.get("fiftyTwoWeekHigh"), "low52": meta.get("fiftyTwoWeekLow")}
                return jsonify(_cset(ck, data))
        except Exception:
            continue
    return jsonify({"ok": False, "points": []})
