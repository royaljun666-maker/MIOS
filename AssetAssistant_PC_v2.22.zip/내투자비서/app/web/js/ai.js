/* ==========================================================================
   ai.js — AI 인사이트 · 계좌 평가 · 브리핑 · 톱다운 · AI 상담(채팅)
   ========================================================================== */
'use strict';

let AI_STATUS = null;

async function loadAIStatus() {
  try { const d = await api('/api/status', { timeout: 6000 }); AI_STATUS = d.ai || { on: false }; SERVER_OK = true; }
  catch (e) { AI_STATUS = AI_STATUS || { on: false }; SERVER_OK = false; }
  const pill = document.getElementById('aiPill'), txt = document.getElementById('aiPillTxt');
  pill.classList.toggle('on', !!AI_STATUS.on); pill.classList.toggle('off', !AI_STATUS.on);
  txt.textContent = !SERVER_OK ? '서버 연결 안 됨' : AI_STATUS.on ? 'AI 연결됨 · ' + AI_STATUS.provider : 'AI 연결하기 (무료)';
  return AI_STATUS;
}
let SERVER_OK = true;

/* ---------------- 쉬운 용어 풀이 (밑줄 → 누르면 뜻) ---------------- */
const GLOSSARY = {
  'PER': '주가가 1년 이익의 몇 배인지. 낮을수록 싸다고 봐요 (보통 10~20배)',
  'PBR': '주가가 회사 순재산의 몇 배인지. 1보다 낮으면 재산보다 싸게 거래되는 셈',
  'ROE': '회사가 주주 돈으로 1년에 몇 % 이익을 냈나. 15% 넘으면 잘 버는 편',
  'PEG': 'PER을 이익 성장률로 나눈 값. 1보다 낮으면 성장에 비해 싸다고 봐요',
  'EPS': '1주당 이익 (회사 이익 ÷ 주식 수)',
  'ETF': '여러 종목을 한 바구니에 담아 주식처럼 사고파는 상품',
  '영업이익률': '100원어치 팔아서 본업으로 남기는 돈. 높을수록 장사를 잘하는 것',
  '영업이익': '본업으로 번 돈 (매출 − 원가 − 판매·관리비)',
  '순이익': '모든 비용과 세금을 빼고 최종적으로 남은 이익',
  '시가총액': '회사 전체의 몸값 = 주가 × 주식 수',
  '밸류에이션': '회사 가치에 비해 주가가 싼지 비싼지 따져 보는 것',
  '컨센서스': '증권사 전문가들의 평균 예상치',
  '목표주가': '증권사가 예상한 적정 주가 (틀릴 수 있어요)',
  '변동성': '가격이 오르내리는 폭. 클수록 위험도 커요',
  '리밸런싱': '정해 둔 비중에 맞게 다시 맞추는 것',
  '분산투자': '여러 곳에 나눠 투자해 위험을 줄이는 것',
  '분할 매수': '한 번에 다 사지 않고 여러 번 나눠 사는 것',
  '비중 축소': '가진 양을 일부 팔아 비율을 줄이는 것',
  '방어자산': '하락장에서 덜 떨어지는 자산 (현금·채권·배당주·금 등)',
  '배당': '회사가 번 돈의 일부를 주주에게 나눠 주는 돈',
  '시클리컬': '경기에 따라 이익이 크게 오르내리는 업종 (반도체·철강·화학 등)',
  '경기민감': '경기에 따라 이익이 크게 오르내리는 업종',
  '공시': '회사가 투자자에게 의무로 알리는 공식 발표',
  '실적': '회사가 일정 기간 벌어들인 매출과 이익 성적표',
  '금리': '돈을 빌리는 값(이자율). 오르면 보통 주식에 부담',
  '인플레이션': '물가가 계속 오르는 현상',
  '포트폴리오': '내가 가진 자산들의 모음',
};
const _GLOSS_RE = new RegExp('(' + Object.keys(GLOSSARY).sort((x, y) => y.length - x.length).map(k => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')', 'g');
// HTML 글자 부분에서만, 용어마다 처음 한 번만 밑줄
function glossify(html, seen) {
  if (!seen) return html;
  return html.split(/(<[^>]+>)/).map(part => part.charAt(0) === '<' ? part : part.replace(_GLOSS_RE, w => {
    if (seen.has(w)) return w;
    seen.add(w);
    return '<span class="term" tabindex="0" data-tip="' + esc(w + ': ' + GLOSSARY[w]) + '">' + w + '</span>';
  })).join('');
}
// 휴대폰은 마우스를 올릴 수 없으니 누르면 뜻을 보여 줌
function hideTermTip() { if (window._termT) { clearTimeout(window._termT); window._termT = 0; hideTip(); } }
document.addEventListener('click', e => {
  const t = e.target.closest && e.target.closest('.term, .fund-cell');
  if (!t) { hideTermTip(); return; }                 // 다른 곳을 누르면 닫힘
  const r = t.getBoundingClientRect();
  const tip = t.getAttribute('data-tip') || '';
  clearTimeout(window._termT); window._termT = setTimeout(hideTip, Math.min(9000, 3500 + tip.length * 45));   // 긴 설명은 더 오래
  showTip(tipText(tip), r.left + r.width / 2, r.top);
});
window.addEventListener('scroll', hideTermTip, { capture: true, passive: true });   // 스크롤하면 닫힘 (용어에서 떨어져 떠 있지 않게)

/* ---------------- 마크다운 → 화면 ---------------- */
function mdInline(s, seen) {
  s = esc(s);
  s = s.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
  s = s.replace(/(^|[^*\w])\*(?!\s)([^*\n]+?)\*(?!\*)/g, '$1<i>$2</i>');
  s = s.replace(/`([^`]+)`/g, '<code>$1</code>');
  s = s.replace(/(→)/g, '<span class="ai-arrow">$1</span>');
  s = s.replace(/(자료로는 알 수 없어요|제공된 (?:정보|수치|데이터)로는 알 수 없습니다)/g, '<span class="ai-hold">$1</span>');
  return glossify(s, seen);
}
function secMeta(label) {
  if (/3초 요약/.test(label)) return ['s-act', 'zap'];
  if (/전략|참고선/.test(label)) return ['s-act', 'target'];
  if (/시장 흐름/.test(label)) return ['s-check', 'globe'];
  if (/성향|장기|스윙|단타|스캘핑/.test(label)) return ['s-style', 'compass'];
  if (/좋은 점|잘 되어|몰리는|좋아져/.test(label)) return ['s-good', 'check'];
  if (/조심|위험|고치면|힘이 빠지|리스크|주의/.test(label)) return ['s-risk', 'alert'];
  if (/무슨 일|뉴스|최근/.test(label)) return ['s-news', 'news'];
  if (/숫자/.test(label)) return ['s-num', 'target'];
  if (/내 상황|내 종목|내 계좌/.test(label)) return ['s-act', 'user'];
  if (/바뀌는|확인|눈여겨|이렇게/.test(label)) return ['s-check', 'compass'];
  return ['', 'sparkles'];
}
// 의견 → 초보도 바로 알아듣는 한마디 [아이콘, 큰 글씨, 색]
function opPlain(op) {
  op = String(op || '');
  if (/적극\s*매수/.test(op)) return ['🟢', '지금 사도 좋아요', 'up'];
  if (/분할\s*매수/.test(op)) return ['🟢', '나눠서 조금씩 사세요', 'up'];
  if (/매수/.test(op)) return ['🟢', '사도 좋아요', 'up'];
  if (/축소/.test(op)) return ['🟠', '일부 파세요', 'down'];
  if (/매도/.test(op)) return ['🔴', '파는 게 좋아요', 'down'];
  if (/보유|관망/.test(op)) return ['🟡', '그대로 두세요 (새로 사지는 마세요)', 'flat'];
  return null;
}
// 의견 카드: "방향: 상승 70%" / "계산: …" / "의견: 매수" / "할 일: …" / "이유: …"
function opinionCard(lines, market) {
  const txt = lines.map(l => l.s.replace(/\*\*/g, '')).join('\n');
  const m = txt.match(/(상승|하락|오를|내릴)[^\d\n]{0,14}(\d{1,3})\s*%/);
  if (!m) return null;
  const p = Math.max(10, Math.min(90, +m[2]));            // 확률은 10~90 으로 고정
  const up = /상승|오를/.test(m[1]) ? p : 100 - p;
  const hz = (txt.match(/%\s*\(([^)·\n]+)/) || [])[1];      // "(앞으로 1주일 · 단타 기준)
  const op = ((txt.match(/의견\s*[:：]\s*([^\n]+)/) || [])[1] || '').trim();
  const why = ((txt.match(/(?:이유|한마디)\s*[:：]\s*([^\n]+)/) || [])[1] || '').trim();
  const todo = ((txt.match(/할\s*일\s*[:：]\s*([^\n]+)/) || [])[1] || '').trim();
  const calc = ((txt.match(/계산\s*[:：]\s*([^\n]+)/) || [])[1] || '').replace(/←.*$/, '').trim();
  const pl = market ? null : opPlain(op);
  const isUp = up >= 50, big = isUp ? up : 100 - up;
  const opCls = /매수/.test(op) ? 'up' : /매도|축소/.test(op) ? 'down' : 'flat';
  return '<div class="op-card">' +
    (pl ? '<div class="op-verdict ' + pl[2] + '"><span class="ov-ic">' + pl[0] + '</span><div><div class="ov-t">' + esc(pl[1]) + '</div>' +
      (todo ? '<div class="ov-todo">' + mdInline(todo) + '</div>' : '') + '</div></div>' : '') +
    '<div class="op-top"><div class="op-dir ' + (isUp ? 'up' : 'down') + '">' + (isUp ? '📈 ' : '📉 ') + (market ? '앞으로 1개월 시장이 ' : esc((hz || TRADE_STYLES[tradeStyle()].hz).trim()) + ' ') +
      (isUp ? '오를' : '내릴') + ' 확률 <b>' + big + '%</b></div>' + (op ? '<span class="op-chip ' + opCls + '">의견: ' + esc(op) + '</span>' : '') + '</div>' +
    '<div class="op-bar" role="img" aria-label="오를 확률 ' + up + '%, 내릴 확률 ' + (100 - up) + '%"><i class="u" style="width:' + up + '%"></i><i class="d" style="width:' + (100 - up) + '%"></i></div>' +
    '<div class="op-legend"><span>오를 확률 ' + up + '%</span><span>내릴 확률 ' + (100 - up) + '%</span></div>' +
    (calc ? '<div class="op-calc"><b>확률 계산</b> ' + esc(calc) + '</div>' : '') +
    (why ? '<div class="op-why">' + mdInline(why) + '</div>' : '') +
    '<div class="op-note">' + (market ? '' : esc(TRADE_STYLES[tradeStyle()].label) + ' 기준 · ') + 'AI가 뉴스와 숫자를 보고 낸 추정이에요. 실제 결과와 다를 수 있어요.</div></div>';
}
// 📌 앱이 일봉으로 계산한 참고 가격 (AI가 지어낸 숫자 아님 · 같은 날·같은 성향이면 늘 같은 값)
function levelsCard(lv) {
  if (!lv) return '';
  const P = v => priceTxt(v, lv.ccy), r = (ic, t, v, p, w, c) => '<div class="lv-row ' + c + '"><span>' + ic + ' ' + t + '</span><b>' + esc(P(v)) + '</b><em>' + (p >= 0 ? '+' : '') + p.toFixed(1) + '%</em><small>' + esc(w) + '</small></div>';
  return '<div class="lv-card"><h4>📌 참고 가격 <span>' + esc(lv.style) + ' 기준 · 앱이 실제 일봉으로 계산</span></h4>' +
    '<div class="lv-now">기준 현재가 <b>' + esc(P(lv.last)) + '</b></div>' +
    r('🎯', '매수', lv.buy, lv.buy_pct, lv.why[0], 'b') + r('🛑', '손절', lv.stop, lv.stop_pct, lv.why[1], 's') + r('🏁', '목표', lv.target, lv.target_pct, lv.why[2], 't') +
    '<p class="op-note">성향을 바꾸면 보는 기간이 달라서 가격도 달라져요(단타는 하루 변동폭, 스윙은 20일선, 장기는 60·200일선 기준). 같은 날·같은 성향이면 늘 같은 값이에요.</p></div>';
}
// 전문가 6인 투표 카드: "- 가치투자자(…): 매수 · 확신 72 — 이유"
function voteCard(lines) {
  const rows = lines.map(l => {
    const t = l.s.replace(/\*\*/g, '');
    const m = t.match(/^(.+?)(?:\(([^)]*)\))?\s*[:：]\s*(적극\s*매수|매수|보유|관망|매도|비중\s*축소)\s*[·,]?\s*(?:확신\s*(\d{1,3}))?\s*(?:[—–-]+\s*(.*))?$/);
    if (!m) return null;
    const v = /매수/.test(m[3]) ? 'up' : /매도|축소/.test(m[3]) ? 'down' : 'flat';
    return { who: m[1].trim(), sub: (m[2] || '').trim(), v, word: m[3].replace(/\s+/g, ' '), conf: Math.max(0, Math.min(100, +(m[4] || 50))), why: (m[5] || '').trim() };
  }).filter(Boolean);
  if (rows.length < 3) return null;
  const n = k => rows.filter(r => r.v === k).length;
  const word = { up: '사자', flat: '지켜보자', down: '팔자' };
  return '<div class="vote-card"><h4>' + icon('users', 'ic-sm') + '전문가 ' + rows.length + '인 투표</h4>' +
    '<div class="vote-sum"><span class="up">🟢 사자 <b>' + n('up') + '</b></span><span class="flat">🟡 지켜보자 <b>' + n('flat') + '</b></span><span class="down">🔴 팔자 <b>' + n('down') + '</b></span></div>' +
    rows.map(r => '<div class="vote-row"><div class="vr-top"><b>' + esc(r.who) + '</b><span class="vr-chip ' + r.v + '">' + word[r.v] + '</span></div>' +
      (r.sub ? '<div class="vr-sub">' + esc(r.sub) + '</div>' : '') +
      '<div class="vr-conf"><i class="' + r.v + '" style="width:' + r.conf + '%"></i></div><div class="vr-why">확신 ' + r.conf + ' · ' + mdInline(r.why) + '</div></div>').join('') +
    '<p class="op-note">각자 다른 기준으로 본 AI의 관점이에요. 의견이 갈리면 그만큼 불확실하다는 뜻이에요.</p></div>';
}
// 계좌 점수 카드: "점수: 72" / "한마디: …"
function scoreCard(lines) {
  const txt = lines.map(l => l.s.replace(/\*\*/g, '')).join('\n');
  const m = txt.match(/점수\s*[:：]?\s*(\d{1,3})/);
  if (!m) return null;
  const sc = Math.max(0, Math.min(100, +m[1]));
  const one = ((txt.match(/한마디\s*[:：]\s*([^\n]+)/) || [])[1] || '').trim();
  const st = sc >= 80 ? ['good', '양호', 'green'] : sc >= 60 ? ['warn', '보통', 'orange'] : ['bad', '주의', 'red'];
  const R = 34, C = 2 * Math.PI * R;
  return '<div class="score-card"><div class="score-ring"><svg viewBox="0 0 80 80" width="80" height="80"><circle cx="40" cy="40" r="' + R + '" fill="none" stroke="var(--surface-3)" stroke-width="8"/>' +
    '<circle cx="40" cy="40" r="' + R + '" fill="none" stroke="var(--' + st[0] + ')" stroke-width="8" stroke-linecap="round" stroke-dasharray="' + (C * sc / 100).toFixed(1) + ' ' + C.toFixed(1) + '" transform="rotate(-90 40 40)"/></svg><b>' + sc + '</b></div>' +
    '<div><div class="score-lab"><span class="badge ' + st[2] + '">' + st[1] + '</span> 계좌 점수 ' + sc + '점 / 100점</div>' +
    (one ? '<div class="score-one">' + mdInline(one) + '</div>' : '') + '</div></div>';
}
function renderAiText(text) {
  const lines = String(text || '').split(/\r?\n/);
  const secs = []; let cur = null;
  const push = l => { if (!cur) { cur = { label: '', lines: [] }; secs.push(cur); } cur.lines.push(l); };
  lines.forEach(raw => {
    const t = raw.replace(/\s+$/, ''); if (!t.trim()) return;
    const m = t.match(/^\s*#{1,6}\s+(.+)$/) || t.match(/^\s*\*{0,2}\[([^\]]{2,40})\]\*{0,2}\s*$/) || t.match(/^\s*\*\*([^*]{2,50})\*\*\s*:?\s*$/);
    if (m) { cur = { label: m[1].replace(/[*#]/g, '').replace(/[:：]\s*$/, '').trim(), lines: [] }; secs.push(cur); return; }
    const b = t.match(/^(\s*)(?:[-*•·]|\d+[.)])\s+(.*)$/);
    if (b) push({ lvl: b[1].length >= 2 ? 2 : 1, s: b[2] }); else push({ lvl: 0, s: t.trim() });
  });
  const seen = new Set();
  if (!secs.length) return '<div class="ai-sec"><div class="ln">' + mdInline(text, seen) + '</div></div>';
  return secs.map(sc => {
    if (/AI 의견|시장 분위기/.test(sc.label)) { const c = opinionCard(sc.lines, /시장/.test(sc.label)); if (c) return c; }
    if (/투표/.test(sc.label)) { const c = voteCard(sc.lines); if (c) return c; }
    if (/계좌 점수/.test(sc.label)) { const c = scoreCard(sc.lines); if (c) return c; }
    if (/한 줄 요약/.test(sc.label)) return '<div class="ai-summary">' + icon('sparkles', 'ic-sm') + '<div>' + sc.lines.map(l => mdInline(l.s, seen)).join('<br>') + '</div></div>';
    const mt = secMeta(sc.label);
    return '<div class="ai-sec ' + mt[0] + '">' + (sc.label ? '<h4>' + icon(mt[1], 'ic-sm') + mdInline(sc.label) + '</h4>' : '') +
      sc.lines.map(l => '<div class="ln' + (l.lvl === 2 ? ' sub2' : l.lvl === 0 ? ' plain' : '') + '">' + mdInline(l.s, seen) + '</div>').join('') + '</div>';
  }).join('') + (seen.size ? '<p class="note" style="margin:6px 2px 0">밑줄 친 말을 누르면 쉬운 뜻이 나와요.</p>' : '');
}
// 채팅용(가볍게)
function renderChatMd(text) {
  const out = [], seen = new Set(); let list = null, tbl = null;
  const flush = () => { list = null; tbl = null; };
  String(text || '').split(/\r?\n/).forEach(raw => {
    const t = raw.trim();
    if (/^\|.*\|$/.test(t)) {                                   // 표
      if (/^\|[\s:|-]+\|$/.test(t)) return;                       // 구분 줄
      const cells = t.slice(1, -1).split('|').map(c => c.trim());
      if (!tbl) { tbl = { head: cells, rows: [] }; out.push(tbl); list = null; } else tbl.rows.push(cells);
      return;
    }
    const b = t.match(/^([-*•·]|\d+[.)])\s+(.*)$/);
    if (b) {
      const ord = /\d/.test(b[1]);
      if (!list || list.ord !== ord) { list = { ord, items: [] }; out.push(list); tbl = null; }
      list.items.push(b[2]); return;
    }
    flush();
    if (!t) return;
    if (/^(-{3,}|\*{3,}|_{3,})$/.test(t)) { out.push('<hr>'); return; }
    const h = t.match(/^(#{1,6})\s+(.+)$/);
    out.push(h ? '<h4 class="cm-h' + (h[1].length <= 2 ? ' big' : '') + '">' + mdInline(h[2].replace(/\*\*/g, ''), seen) + '</h4>' : '<p>' + mdInline(t, seen) + '</p>');
  });
  return out.map(x => {
    if (typeof x === 'string') return x;
    if (x.head) return '<div class="cm-tbl"><table><tr>' + x.head.map(c => '<th>' + mdInline(c, seen) + '</th>').join('') + '</tr>' +
      x.rows.map(r => '<tr>' + r.map(c => '<td>' + mdInline(c, seen) + '</td>').join('') + '</tr>').join('') + '</table></div>';
    const tag = x.ord ? 'ol' : 'ul';
    return '<' + tag + '>' + x.items.map(i => '<li>' + mdInline(i, seen) + '</li>').join('') + '</' + tag + '>';
  }).join('');
}

/* ---------------- AI 결과 팝업 ---------------- */
function noKeyHtml() {
  return '<div class="empty"><div class="ill">' + icon('key') + '</div><b>AI가 아직 연결되지 않았어요</b><p>구글 계정만 있으면 무료예요. 키를 한 번 붙여넣으면 끝나요.</p>' +
    '<button class="btn btn-primary btn-lg" data-goai>' + icon('key') + '무료 AI 연결하기</button></div>';
}
function aiLoading(msg) {
  return '<div class="ai-loading"><div class="ai-think"><i class="orb"></i><i class="ring"></i><i class="ring r2"></i>' + icon('sparkles') + '</div>' +
    '<div><b>' + (msg || 'AI가 정리하는 중이에요…') + '</b>' +
    '<div class="ai-steps"><span>📰 뉴스 읽는 중</span><span>🌏 시장 흐름과 맞춰 보는 중</span><span>📊 확률 계산하는 중</span><span>✍️ ' + AI_DEPTHS[aiDepth()].label + ' 정리하는 중</span></div>' +
    '<span style="font-size:.8rem">보통 10~60초 걸려요</span></div>' +
    '<div class="ai-skel"><i></i><i></i><i></i></div></div>';
}
function openAiModal(title, disc, loadingMsg) {
  const m = openModal({ title, size: 'wide', body: (disc ? '<div class="ai-disc">' + disc + '</div>' : '') + aiLoading(loadingMsg) });
  m.disc = disc;
  m.body.addEventListener('click', e => { if (e.target.closest('[data-goai]')) { closeAllModals(); go('settings', { sec: 'ai' }); } });
  return m;
}
function aiFill(m, d, renderFn, extra) {
  if (m.closed) return;
  const disc = m.disc ? '<div class="ai-disc">' + m.disc + '</div>' : '';
  if (d && d.status === 'no_key') { m.setBody(noKeyHtml()); return; }
  if (!d || (d.status !== 'ok' && d.status !== 'ok_text')) {
    m.setBody(disc + '<div class="callout warn">' + icon('alert', 'ic-sm') + '<div><b>AI 답을 받지 못했어요</b><br>' + esc((d && d.text) || '잠시 후 다시 시도해 주세요.') + '</div></div>' +
      '<p class="note" style="margin-top:12px">무료 한도를 다 썼다면 설정 → AI 연결에서 <b>다른 무료 AI(Groq 등)</b>를 하나 더 연결해 두면 자동으로 바꿔 써요.</p>');
    return;
  }
  const meta = '<div class="ai-meta">' + icon('sparkles', 'ic-sm') + esc(d.provider || '') + (d.model ? ' · ' + esc(d.model) : '') + (extra ? ' · ' + extra : '') + '</div>';
  m.setBody(disc + meta + renderFn(d) + disclaimerHtml());
}

/* 📊 AI 예측 성적표 — 분석할 때의 확률·의견·가격을 기기에 저장하고, 1주·1달 뒤 실제 가격과 비교 */
const TRACK_KEY = 'ai_track_v1', DAY = 86400000;
function aiTrack() { try { const v = JSON.parse(localStorage.getItem(TRACK_KEY) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
function aiTrackSave(v) { try { localStorage.setItem(TRACK_KEY, JSON.stringify(v.slice(-200))); } catch (e) {} }
function trackNow(t) {                               // 지금 앱이 아는 현재가 (내 종목·관심종목)
  const T = String(t || '').toUpperCase(); if (!T) return null;
  const x = allHoldings().find(o => String(o.h.ticker || '').toUpperCase() === T), w = watchlist().find(o => String(o.ticker || '').toUpperCase() === T);
  const p = num((x && x.h.cur) || (w && w.cur) || 0);
  return p > 0 ? p : null;
}
function aiTrackLog(item, text) {
  const txt = String(text || '').replace(/\*\*/g, '');
  const m = txt.match(/(상승|하락|오를|내릴)[^\d\n]{0,14}(\d{1,3})\s*%/), price = num(item.price) || trackNow(item.ticker);
  if (!m || !(price > 0) || !item.ticker) return;
  const p = Math.max(10, Math.min(90, +m[2])), up = /상승|오를/.test(m[1]) ? p : 100 - p;
  const op = ((txt.match(/의견\s*[:：]\s*([^\n]+)/) || [])[1] || '').trim().slice(0, 12);
  const day = new Date().toISOString().slice(0, 10), v = aiTrack().filter(r => !(r.t === item.ticker && r.d === day));
  v.push({ t: item.ticker, n: item.name || item.ticker, at: Date.now(), d: day, p: price, up, op, st: tradeStyle() });
  aiTrackSave(v);
}
function aiTrackGrade() {                              // 1주·1달이 지난 기록에 그때 가격을 적어 둠
  const v = aiTrack(); let ch = false;
  v.forEach(r => {
    const age = Date.now() - r.at, now = trackNow(r.t); if (!now) return;
    if (age >= 7 * DAY && r.p7 == null) { r.p7 = now; ch = true; }
    if (age >= 30 * DAY && r.p30 == null) { r.p30 = now; ch = true; }
  });
  if (ch) aiTrackSave(v);
  return v;
}
function trackRes(r, k) {                              // {ret, hit} · hit: true 맞음 / false 틀림 / null 거의 안 움직임
  if (r[k] == null) return null;
  const ret = (r[k] / r.p - 1) * 100;
  return { ret, hit: Math.abs(ret) < 0.5 ? null : (r.up >= 50) === (ret > 0) };
}
function trackStat(v, k) {
  const g = v.map(r => trackRes(r, k)).filter(x => x && x.hit != null);
  return { n: g.length, hit: g.filter(x => x.hit).length };
}
function trackPast(ticker) {                           // 다음 분석 때 AI에게 주는 '지난 판단 → 결과'
  return aiTrack().filter(r => r.t === ticker && (r.p7 != null || r.p30 != null)).slice(-3).map(r => {
    const a = trackRes(r, 'p7'), b = trackRes(r, 'p30');
    const f = (x, l) => x ? l + ' ' + (x.ret >= 0 ? '+' : '') + x.ret.toFixed(1) + '%' + (x.hit == null ? '' : x.hit ? '(맞음)' : '(틀림)') : '';
    return r.d + ' 오를 확률 ' + r.up + '%' + (r.op ? '·' + r.op : '') + ' → ' + [f(a, '1주 뒤'), f(b, '1달 뒤')].filter(Boolean).join(', ');
  }).join('\n');
}
function aiTrackCard() {
  const v = aiTrackGrade();
  if (!v.length) return '<div class="card"><div class="card-head"><h3>' + icon('target', 'ic-sm') + 'AI 예측 성적표</h3></div><p class="note" style="margin:0">종목 AI 분석을 받으면 그때의 확률과 가격을 기억했다가, <b>1주·1달 뒤 실제로 맞았는지</b> 채점해 보여 줘요. 다음 분석 때 AI에게도 지난 결과를 알려 줘서 같은 실수를 줄여요.</p></div>';
  const s7 = trackStat(v, 'p7'), s30 = trackStat(v, 'p30');
  const pct = s => s.n ? '<b>' + Math.round(s.hit / s.n * 100) + '%</b><span>' + s.hit + '/' + s.n + '건 맞음</span>' : '<b>-</b><span>채점 대기</span>';
  const rows = v.slice(-6).reverse().map(r => {
    const a = trackRes(r, 'p30') || trackRes(r, 'p7'), left = Math.ceil((r.at + 7 * DAY - Date.now()) / DAY);
    const res = a ? '<span class="' + (a.ret >= 0 ? 'up' : 'down') + '">' + (a.ret >= 0 ? '+' : '') + a.ret.toFixed(1) + '%</span> ' + (a.hit == null ? '➖' : a.hit ? '✅' : '❌')
      : '<span class="muted">' + (left > 0 ? left + '일 뒤 채점' : '가격 확인 대기') + '</span>';
    return '<div class="trk-row"><div><b>' + esc(r.n) + '</b><span>' + esc(r.d.slice(5).replace('-', '/')) + ' · ' + (r.up >= 50 ? '오를 ' + r.up : '내릴 ' + (100 - r.up)) + '%' + (r.op ? ' · ' + esc(r.op) : '') + '</span></div><div class="trk-res">' + res + '</div></div>';
  }).join('');
  return '<div class="card"><div class="card-head"><h3>' + icon('target', 'ic-sm') + 'AI 예측 성적표</h3><span class="muted" style="font-size:.78rem">이 기기 기준</span></div>' +
    '<div class="trk-sum"><div><small>1주 뒤</small>' + pct(s7) + '</div><div><small>1달 뒤</small>' + pct(s30) + '</div></div>' + rows +
    '<p class="note" style="margin:8px 0 0">오를 확률이 50% 넘었는데 실제로 올랐으면 ✅. 0.5% 안쪽으로 움직였으면 ➖(채점 제외). 내 종목·관심종목의 가격으로 채점해요.</p></div>';
}

/* ---------------- 종목 인사이트 ---------------- */
function openInsight(accId, hId, fresh) {
  const a = findAcc(accId), h = a && a.holdings.find(x => x.id === hId); if (!h) return;
  const m = openAiModal('AI 분석 — ' + esc(dispName(h)), 'AI가 최근 뉴스와 숫자를 보고 <b>오를 확률과 의견</b>을 정리했어요. 확률은 AI의 추정이라 틀릴 수 있으니, 최종 결정은 직접 하세요.', '최근 뉴스와 실적을 모으고 있어요…');
  const q = { ticker: h.ticker || '', market: mkt(h), name: h.name || '', price: h.cur || '', per: h.per || '', pbr: h.pbr || '', forward_per: h.fper || '', asof: h.asof || '',
    peg: h.peg || '', roe: h.roe || '', op_income: h.opIncome || '', op_margin: h.opMargin || '', market_cap: h.marketCap || '', eps: h.eps || '', mcap_ccy: h.mcapCcy || '', rule: h.rule || '', style: tradeStyle() };
  const T = accT(a), v = hv(h);
  if (T.asset > 0) q.weight = (v.valK / T.asset * 100).toFixed(1);
  if (v.cost > 0) { q.ret = v.ret.toFixed(1); q.avg = priceTxt(v.avg, v.ccy); }
  if (fresh) q.fresh = '1';
  const past = trackPast(h.ticker || ''); if (past) q.past = past;
  const qs = Object.keys(q).map(k => k + '=' + encodeURIComponent(q[k])).join('&');
  api('/insight?' + qs, { timeout: 150000 }).then(d => {
    if (d && (d.status === 'ok' || d.status === 'ok_text')) aiTrackLog({ ticker: h.ticker, name: dispName(h), price: h.cur }, d.text);
    aiFill(m, d, x => levelsCard(x.levels) + renderAiText(x.text) + '<button class="btn btn-outline btn-block" style="margin-top:8px" data-again>' + icon('refresh', 'ic-sm') + '다시 분석</button>', d && d.headline_count != null ? '뉴스 ' + d.headline_count + '건 반영' : '');
    const ag = m.body.querySelector('[data-again]'); if (ag) ag.onclick = () => { m.close(); openInsight(accId, hId, true); };
  }).catch(() => aiFill(m, { status: 'fail', text: SERVER_DOWN }));
}

/* ---------------- 계좌 평가 ---------------- */
function openAccReview(accId) {
  const a = findAcc(accId); if (!a) return;
  const T = accT(a), c = accCheck(a, T), p = pol();
  const m = openAiModal('AI 계좌 점수 — ' + esc(a.name), '내 계좌를 <b>' + p.label + '</b> 기준으로 점수 매기고, 어디를 고치면 좋은지 쉽게 알려 드려요.');
  const facts = [
    '- 최고 비중: ' + c.topName + ' ' + c.topW.toFixed(0) + '% (' + p.label + ' 상한 ' + p.single + '%)',
    '- 상위3 합산: ' + c.top3W.toFixed(0) + '% (상한 ' + p.top3 + '%)',
    '- 방어자산 비중: ' + c.defW.toFixed(0) + '% (최소 ' + p.defMin + '%)',
    '- 현금 비중: ' + c.cashW.toFixed(0) + '% (최소 ' + p.cashMin + '%)',
    '- 고밸류(PER≥' + p.highPER + '): ' + c.highCount + '종목',
    '- 저밸류(PER≤' + LOW_PER + '): ' + c.lowCount + '종목',
    '- 보유 종목 수: ' + c.total + '개 (PER 확인 ' + c.perKnown + '개)',
    '- 계좌 수익률: ' + pct(T.ret) + ' (평가손익 ' + wonS(T.pl) + ')',
  ].join('\n');
  api('/review?policy=' + encodeURIComponent(p.label) + '&name=' + encodeURIComponent(a.name) + '&facts=' + encodeURIComponent(facts), { timeout: 150000 })
    .then(d => aiFill(m, d, x => renderAiText(x.text)))
    .catch(() => aiFill(m, { status: 'fail', text: SERVER_DOWN }));
}

/* ---------------- 브리핑 ---------------- */
function itemsOf(holdings) {
  const seen = {}, out = [];
  holdings.forEach(h => {
    if (!(h.ticker || h.name)) return;
    const k = (h.ticker || h.name).toUpperCase(); if (seen[k]) return; seen[k] = 1;
    out.push({ ticker: h.ticker || '', name: h.name || '', market: mkt(h), rule: h.rule || '' });
  });
  return out;
}
const BRIEF_PERIODS = [
  { h: 12, label: '12시간', desc: '오늘 아침·밤사이 새 소식만 빠르게' },
  { h: 72, label: '3일', desc: '이번 주 흐름 잡기' },
  { h: 168, label: '7일', desc: '한 주 전체를 꼼꼼하게' },
];
function watchItems() {
  return watchlist().filter(w => w.ticker || w.name).map(w => ({ ticker: w.ticker || '', name: w.name || '', market: w.market || 'kr', rule: '', watch: true }));
}
/* 브리핑 전에 기간(12시간/3일/7일)·관심종목 포함 여부를 고름 */
function briefChooser(title, baseItems, opts) {
  opts = opts || {};
  const wl = watchItems();
  let hours = UI.briefHours || 72, withWatch = opts.watchOnly ? true : (UI.briefWatch !== false);
  const st = TRADE_STYLES[tradeStyle()];
  const m = openModal({ title: title, body:
    '<div class="bc-sec"><b>뉴스 기간</b><div class="bc-opts">' + BRIEF_PERIODS.map(p =>
      '<button class="bc-opt' + (p.h === hours ? ' on' : '') + '" data-h="' + p.h + '"><b>' + p.label + '</b><span>' + p.desc + '</span></button>').join('') + '</div></div>' +
    (!opts.watchOnly && wl.length ? '<label class="bc-chk"><input type="checkbox" id="bcWatch"' + (withWatch ? ' checked' : '') + '> ⭐ 관심종목 ' + wl.length + '개도 같이 보기</label>' : '') +
    '<div class="bc-style">' + st.emoji + ' 내 성향 <b>' + st.label + '</b> 기준(' + st.hz + ')으로 판단해요 · <a data-nav="settings" data-sec="policy">바꾸기</a></div>',
    foot: '<button class="btn btn-primary btn-lg btn-block" id="bcGo">' + icon('sparkles') + '브리핑 받기</button>' });
  m.body.querySelectorAll('.bc-opt').forEach(b => b.onclick = () => { hours = +b.dataset.h; m.body.querySelectorAll('.bc-opt').forEach(x => x.classList.toggle('on', x === b)); });
  const chk = m.body.querySelector('#bcWatch'); if (chk) chk.onchange = () => { withWatch = chk.checked; };
  m.foot.querySelector('#bcGo').onclick = () => {
    UI.briefHours = hours; if (!opts.watchOnly) UI.briefWatch = withWatch; saveUI(); m.close();
    let items = baseItems.slice();
    if (withWatch) { const have = new Set(items.map(x => (x.ticker || x.name).toUpperCase())); wl.forEach(w => { if (!have.has((w.ticker || w.name).toUpperCase())) items.push(w); }); }
    if (!items.length) { toast('브리핑할 종목이 없어요'); return; }
    runBriefing(items.slice(0, 25), title, 'rich', hours);
  };
}
function openBriefAll() {
  const items = itemsOf(allHoldings().map(x => x.h));
  if (!items.length && !watchItems().length) { toast('먼저 종목이나 관심종목을 넣어 주세요'); return; }
  briefChooser('전체 브리핑 — 내 모든 종목', items);
}
function openBriefAcc(accId) {
  const a = findAcc(accId); if (!a) return;
  const items = itemsOf(a.holdings);
  if (!items.length) { toast('이 계좌에 종목이 없어요'); return; }
  briefChooser('계좌 브리핑 — ' + esc(a.name), items);
}
function openBriefWatch() {
  if (!watchItems().length) { toast('관심종목을 먼저 담아 주세요'); return; }
  briefChooser('관심종목 뉴스 브리핑', [], { watchOnly: true });
}
function runBriefing(items, title, mode, hours) {
  const per = (BRIEF_PERIODS.find(p => p.h === hours) || { label: Math.round(hours / 24) + '일' }).label;
  const st = TRADE_STYLES[tradeStyle()];
  const m = openAiModal(title, '최근 <b>' + per + ' 뉴스</b>로 종목마다 <b>주가에 줄 영향, 오를 확률, 지금 할 일</b>을 정리했어요. ' + st.emoji + ' <b>' + st.label + '</b> 기준(' + st.hz + ')이에요.', '종목 ' + items.length + '개의 ' + per + ' 뉴스를 모으는 중…');
  api('/briefing', { method: 'POST', body: { items, mode, hours, style: tradeStyle() }, timeout: 240000 }).then(d => {
    if (d && d.status === 'ok' && d.items && d.mode === 'rich' && hours >= 72) saveBriefingSnapshot(d.items.filter(x => !x.watch));
    aiFill(m, d, x => (x.note ? '<div class="callout warn" style="margin-bottom:12px">' + icon('alert', 'ic-sm') + esc(x.note) + '</div>' : '') +
      (x.items ? renderBriefItems(x.items) : renderAiText(x.text)), d && d.items ? '종목 ' + d.items.length + '개' : '');
  }).catch(() => aiFill(m, { status: 'fail', text: SERVER_DOWN }));
}
function renderBriefItems(items) {
  const flagOf = it => it.flag === 'red' || it.flag === 'green' ? it.flag : 'gray';
  const reds = items.filter(x => flagOf(x) === 'red');
  let html = reds.length ? '<div class="brief-top warn">' + icon('alert') + '<div>오늘 눈여겨볼 종목: <b>' + reds.map(x => esc(x.name || x.ticker)).join(', ') + '</b></div></div>'
    : '<div class="brief-top ok">' + icon('check') + '<div>오늘 특별히 주의할 종목은 없어요</div></div>';
  const groups = {}, order = [];
  items.forEach(it => { const s = (it.sector && String(it.sector).trim()) || '기타'; if (!groups[s]) { groups[s] = []; order.push(s); } groups[s].push(it); });
  order.sort((a, b) => (groups[a].some(x => flagOf(x) === 'red') ? 0 : 1) - (groups[b].some(x => flagOf(x) === 'red') ? 0 : 1));
  const lab = { red: ['red', '😟 나쁜 소식'], green: ['green', '😊 좋은 소식'], gray: ['gray', '😐 큰 영향 없음'] };
  const seen = new Set();
  order.forEach(s => {
    html += '<div class="sector-h">' + icon('layers', 'ic-sm') + esc(s) + ' <span class="muted">' + groups[s].length + '종목</span></div>';
    html += groups[s].map(it => {
      const f = flagOf(it), up0 = parseInt(it.up, 10), up = isFinite(up0) ? Math.max(10, Math.min(90, up0)) : NaN, op = String(it.opinion || '').trim();
      const opCls = /매수/.test(op) ? 'up' : /매도|축소/.test(op) ? 'down' : 'flat';
      const prob = isFinite(up) ? (up >= 50 ? '📈 오를 확률 ' + up + '%' : '📉 내릴 확률 ' + (100 - up) + '%') : '';
      return '<div class="bcard ' + f + '"><div class="t">' + esc(it.name || it.ticker || '') + (it.ticker ? ' <span class="muted" style="font-size:.8rem">' + esc(it.ticker) + '</span>' : '') +
        (it.watch ? '<span class="badge orange">⭐ 관심</span>' : '') + '<span class="badge ' + lab[f][0] + '">' + lab[f][1] + '</span></div>' +
        (prob || op ? '<div class="b-op">' + (prob ? '<span class="' + (up >= 50 ? 'up' : 'down') + '">' + prob + '</span>' : '') + (op ? '<span class="op-chip ' + opCls + '">' + (opPlain(op) ? opPlain(op)[0] + ' ' + esc(opPlain(op)[1]) : '의견: ' + esc(op)) + '</span>' : '') + '</div>' : '') +
        (it.headline ? '<div class="h">' + icon('news', 'ic-sm') + ' ' + esc(it.headline) + '</div>' : '') +
        (it.impact ? '<div class="b-row imp"><b>주가 영향</b><span>' + mdInline(it.impact, seen) + '</span></div>' : '') +
        (it.macro ? '<div class="b-row mac"><b>시장 흐름</b><span>' + mdInline(it.macro, seen) + '</span></div>' : '') +
        (it.action ? '<div class="b-row act"><b>지금 할 일</b><span>' + mdInline(it.action, seen) + '</span></div>' : '') +
        (it.insight ? '<div class="i">' + mdInline(it.insight, seen) + '</div>' : '') +
        (it.reason ? '<div class="i">' + mdInline(it.reason) + '</div>' : '') +
        (it.short ? '<div class="i"><b>단기</b> ' + mdInline(it.short) + '</div>' : '') +
        (it.long ? '<div class="i"><b>중장기</b> ' + mdInline(it.long) + '</div>' : '') +
        (it.rule ? '<div class="rule">▸ 나의 규칙: ' + esc(it.rule) + '</div>' : '') + '</div>';
    }).join('');
  });
  return html + '<p class="note" style="margin-top:14px">확률·의견·참고 가격은 AI가 최근 뉴스 제목과 시장 지표를 보고 낸 추정이에요. 중요한 건 기사 원문도 확인하세요. 밑줄 친 말을 누르면 뜻이 나와요.</p>';
}
function tdKey() { return 'td_snapshots_v1:' + (S.curPerson || 'default'); }
function saveBriefingSnapshot(items) {
  try {
    const snap = { date: todayKey(), sectors: {}, strong: [] };
    items.forEach(it => {
      const s = (it.sector && String(it.sector).trim()) || '기타';
      if (!snap.sectors[s]) snap.sectors[s] = { green: 0, red: 0, gray: 0 };
      const f = it.flag === 'green' || it.flag === 'red' ? it.flag : 'gray';
      snap.sectors[s][f]++;
      const upP = parseInt(it.up, 10);
      const c = parseInt(it.confidence, 10) || (isFinite(upP) ? Math.max(upP, 100 - upP) : 0);
      if (f !== 'gray' && c >= 60) snap.strong.push({ n: it.name || it.ticker, f, c, s });
    });
    let arr = []; try { arr = JSON.parse(localStorage.getItem(tdKey()) || '[]'); } catch (e) {}
    arr = arr.filter(x => x.date !== snap.date); arr.push(snap); if (arr.length > 60) arr = arr.slice(-60);
    localStorage.setItem(tdKey(), JSON.stringify(arr));
  } catch (e) {}
}
function buildPortSummary() {
  let arr = []; try { arr = JSON.parse(localStorage.getItem(tdKey()) || '[]'); } catch (e) {}
  if (!arr.length) return '';
  const recent = arr.slice(-14), agg = {};
  recent.forEach(sn => Object.keys(sn.sectors || {}).forEach(s => { if (!agg[s]) agg[s] = { green: 0, red: 0, gray: 0 }; ['green', 'red', 'gray'].forEach(k => agg[s][k] += sn.sectors[s][k]); }));
  const lines = ['누적 스냅샷 ' + recent.length + '개(최근일 ' + recent[recent.length - 1].date + '):'];
  Object.keys(agg).sort((a, b) => (agg[b].green + agg[b].red) - (agg[a].green + agg[a].red)).forEach(s => lines.push('- ' + s + ': 긍정 ' + agg[s].green + ' / 부정 ' + agg[s].red + ' / 소음 ' + agg[s].gray));
  const strong = (recent[recent.length - 1].strong || []).slice(0, 12).map(z => z.n + '(' + z.f + z.c + '·' + z.s + ')');
  if (strong.length) lines.push('최근 강한 신호: ' + strong.join(', '));
  return lines.join('\n');
}
function openTopdown() {
  const ps = buildPortSummary();
  const m = openAiModal('시장 큰 흐름', '요즘 시장 뉴스를 모아 <b>시장이 오를 확률</b>과 <b>돈이 몰리는 분야</b>를 쉽게 정리했어요.' +
    (ps ? '' : '<br><span style="color:var(--warn)">※ 전체 브리핑을 며칠 받으면 내 포트 신호가 쌓여 더 정확해져요.</span>'), '시장 헤드라인을 모으는 중…');
  api('/topdown', { method: 'POST', body: { port_summary: ps }, timeout: 180000 })
    .then(d => aiFill(m, d, x => renderAiText(x.text), d && d.market_count ? '시장 헤드라인 ' + d.market_count + '건' : ''))
    .catch(() => aiFill(m, { status: 'fail', text: SERVER_DOWN }));
}

/* ---------------- 고르기 팝업 ---------------- */
function pickAccount(then) {
  const accs = accounts();
  if (!accs.length) { toast('먼저 계좌를 만들어 주세요'); return; }
  if (accs.length === 1) { then(accs[0].id); return; }
  const m = openModal({ title: '어느 계좌를 볼까요?', body: '<div class="list">' + accs.map(a => { const t = accT(a); return '<div class="li" data-a="' + a.id + '"><div class="logo" style="background:' + aColor(a) + '">' + esc(a.name.slice(0, 1)) + '</div><div class="mid"><b>' + esc(a.name) + '</b><span>종목 ' + a.holdings.length + '개</span></div><div class="end"><b>' + won(t.asset) + '</b><span class="' + cls(t.ret) + '">' + pct(t.ret) + '</span></div></div>'; }).join('') + '</div>' });
  m.body.addEventListener('click', e => { const r = e.target.closest('[data-a]'); if (r) { m.close(); then(r.dataset.a); } });
}
function pickHolding(then) {
  const all = allHoldings();
  if (!all.length) { toast('먼저 종목을 넣어 주세요'); return; }
  const m = openModal({ title: '어느 종목을 분석할까요?', body: '<div class="list">' + all.map(x => holdRowHtml(x.a, x.h).replace('data-act="open-h"', 'data-pick="1"')).join('') + '</div>' });
  m.body.addEventListener('click', e => { const r = e.target.closest('[data-h]'); if (r) { m.close(); then(r.dataset.a, r.dataset.h); } });
}

/* ---------------- AI 화면 + 상담 ---------------- */
const CHAT_KEY = 'chat_v1';
function chatLog() { try { const all = JSON.parse(localStorage.getItem(CHAT_KEY) || '{}'); return all[S.curPerson] || []; } catch (e) { return []; } }
function saveChat(log) { try { const all = JSON.parse(localStorage.getItem(CHAT_KEY) || '{}'); all[S.curPerson] = log.slice(-40); localStorage.setItem(CHAT_KEY, JSON.stringify(all)); } catch (e) {} }
const SUGGEST = ['내 종목 중 앞으로 오를 확률이 가장 높은 건?', '지금 내 계좌에서 가장 위험한 점은?', '내가 가진 종목, 지금 더 사도 될까?', 'PER이 뭐야? 아주 쉽게 알려줘', '환율이 오르면 내 자산은 어떻게 돼?', '분산투자 잘 되어 있는지 점수로 알려줘'];

/* 내가 아는 종목 (보유·관심) — AI 대화에서 질문에 나온 종목의 실제 시세를 서버가 찾을 때 씀 */
function knownStocks() {
  const out = [], seen = new Set();
  const add = (name, ticker, market) => { if (!ticker || seen.has(ticker)) return; seen.add(ticker); out.push({ name: name || '', ticker, market: market || '' }); };
  allHoldings().forEach(x => add(dispName(x.h), x.h.ticker, mkt(x.h)));
  watchlist().forEach(w => add(dispName(w), w.ticker, w.market || (w.ccy === 'USD' ? 'us' : 'kr')));
  return out.slice(0, 80);
}
function portfolioContext() {
  const G = grand(), p = pol();
  const L = [];
  L.push('이름: ' + P().name + ' · 기준일 ' + todayKey() + ' · 환율 1달러=' + nf(fx(), 1) + '원');
  L.push('아래 종목 현재가는 앱이 마지막으로 시세를 받은 값 — ' + (UI.lastRefresh ? new Date(UI.lastRefresh).toLocaleString('ko-KR') + ' 기준 (' + ago(UI.lastRefresh) + ')' : '⚠ 아직 시세를 받은 적 없음(입력한 값)') +
    '. 오래됐으면 그 점을 밝히고, 실시간 값이 [방금 앱이 확인한 실제 시세]에 있으면 그걸 우선');
  L.push('투자 성향: ' + p.label + ' (한 종목 ' + p.single + '% 이하, 상위3 ' + p.top3 + '% 이하, 방어자산 ' + p.defMin + '% 이상, 현금 ' + p.cashMin + '% 이상 권장)');
  L.push('총자산 ' + won(G.asset) + ' (주식 ' + won(G.stock) + ' / 현금 ' + won(G.cash) + ') · 평가손익 ' + wonS(G.pl) + ' (' + pct(G.ret) + ') · 국내주식 ' + won(G.kr) + ' / 해외주식 ' + won(G.us));
  accounts().forEach(a => {
    const t = accT(a);
    L.push('[계좌] ' + a.name + ': 자산 ' + won(t.asset) + ', 현금 ' + won(t.cash) + ', 수익률 ' + pct(t.ret));
    a.holdings.slice().sort((x, y) => hv(y).valK - hv(x).valK).forEach(h => {
      const v = hv(h);
      L.push('  - ' + dispName(h) + '(' + (h.ticker || '코드없음') + ', ' + (v.ccy === 'USD' ? '미국' : '국내') + '): ' + nf(v.qty, 4) + '주, 평단 ' + priceTxt(v.avg, v.ccy) + ', 현재가 ' + priceTxt(v.cur, v.ccy) +
        ', 수익률 ' + pct(v.ret) + ', 평가 ' + won(v.valK) + ', 계좌 내 비중 ' + (t.asset > 0 ? (v.valK / t.asset * 100).toFixed(1) : 0) + '%' +
        (h.per ? ', PER ' + num(h.per).toFixed(1) : '') + (hasT(h) ? ', 목표비중 ' + num(h.target) + '%' : '') + (h.defensive ? ', 방어자산' : '') + (h.rule ? ', 나의 규칙: ' + h.rule : ''));
    });
  });
  return L.join('\n').slice(0, 6000);
}

PAGES.ai = function () {
  const el = pageEl('ai');
  const on = AI_STATUS && AI_STATUS.on;
  const hero = '<div class="ai-hero">' +
    '<svg class="deco" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.2"><path d="M12 3l1.9 5.6 5.6 1.9-5.6 1.9L12 18l-1.9-5.6-5.6-1.9 5.6-1.9z"/></svg>' +
    '<div class="status ' + (on ? '' : 'off') + '"><span class="dot"></span>' + (on ? esc(AI_STATUS.provider) + ' · ' + esc(AI_STATUS.model) + (AI_STATUS.count > 1 ? ' · 예비 ' + (AI_STATUS.count - 1) + '개' : '') : 'AI 연결 전') + '</div>' +
    '<h2>' + (on ? '무엇을 도와드릴까요?' : '무료 AI 비서를 연결해 보세요') + '</h2>' +
    '<p>' + (on ? '내 종목 뉴스를 정리하고, 계좌를 점검하고, 궁금한 걸 쉬운 말로 설명해 드려요. AI는 <b>판단을 돕는 비서</b>일 뿐, 사고파는 결정은 직접 하세요.'
      : '구글 Gemini·Groq 등 <b>무료</b> AI를 쓸 수 있어요. 안내대로 키 하나만 붙여넣으면 3분이면 끝나요.') + '</p>' +
    '<div class="row-btns">' + (on ? '<button class="btn btn-lg btn-white" data-act="ai-brief-all">' + icon('clipboard') + '오늘의 전체 브리핑</button><button class="btn btn-lg btn-glass" data-act="ai-topdown">' + icon('compass') + '시장 큰 흐름 보기</button>'
      : '<button class="btn btn-lg btn-white" data-nav="settings" data-sec="ai">' + icon('key') + '무료로 연결하기</button>') + '</div></div>';
  const act = (ic, bg, fg, t, d, a) => '<button class="card click ai-act" data-act="' + a + '"><div class="ico" style="background:' + bg + ';color:' + fg + '">' + icon(ic) + '</div><b>' + t + '</b><span>' + d + '</span></button>';
  const acts = '<div class="ai-acts" style="margin:18px 0">' +
    act('clipboard', 'var(--brand-soft)', 'var(--brand)', '전체 브리핑', '12시간·3일·7일 뉴스로 내 종목·관심종목의 주가 영향 정리', 'ai-brief-all') +
    act('compass', 'var(--good-soft)', 'var(--good)', '시장 큰 흐름', '시장이 오를 확률과 요즘 돈이 몰리는 분야', 'ai-topdown') +
    act('shield', 'var(--warn-soft)', 'var(--warn)', '계좌 점수', '내 계좌를 100점 만점으로 평가하고 고칠 점 안내', 'ai-review-pick') +
    act('sparkles', 'var(--up-soft)', 'var(--up)', '종목 분석', '뉴스 영향·오를 확률·매매 참고선', 'ai-insight-pick') +
    act('activity', 'var(--up-soft)', '#FF8A3D', '차트 분석', '추세·지지/저항·매수/손절/목표 참고선', 'ai-chart-pick') + '</div>' +
    '<div class="ai-mine">' + TRADE_STYLES[tradeStyle()].emoji + ' 성향 <b>' + TRADE_STYLES[tradeStyle()].label + '</b> · ' + AI_DEPTHS[aiDepth()].emoji + ' 설명 <b>' + AI_DEPTHS[aiDepth()].label + '</b> 기준으로 답해요' +
      '<button class="btn btn-ghost btn-sm" data-act="ai-setup">' + icon('pencil', 'ic-sm') + '바꾸기</button></div>' +
    (!feat('dna') ? '' : '<button class="dna-strip" data-act="dna"><span>' + esc(dnaSummary()) + '</span><b>투자 DNA 조절 ›</b></button>');
  const log = chatLog();
  const chat = '<div class="card span-8 ask-card"><div class="card-head"><h3>' + icon('message', 'ic-sm') + 'AI에게 물어보기</h3>' +
      (log.length ? '<span class="muted" style="font-size:.8rem">지난 대화 ' + log.length + '개</span>' : '') + '</div>' +
    '<button class="ask-bar" data-act="ai-chat">' + icon('sparkles', 'ic-sm') + '<span>' + (on ? (log.length ? '이어서 물어보기…' : '무엇이든 물어보세요…') : '먼저 AI를 연결해 주세요') + '</span>' + icon('send', 'ic-sm') + '</button>' +
    '<div class="suggest">' + SUGGEST.slice(0, 4).map(q => '<button data-act="ai-chat" data-q="' + esc(q) + '">' + esc(q) + '</button>').join('') + '</div>' +
    '<p class="note" style="margin:6px 2px 0">' + AI_DEPTHS[aiDepth()].emoji + ' ' + AI_DEPTHS[aiDepth()].label + ' 설명 · ' + TRADE_STYLES[tradeStyle()].emoji + ' ' + TRADE_STYLES[tradeStyle()].label +
      (sectors().length ? ' · 🎯 ' + esc(sectorText(2)) : '') + ' 기준으로, 큰 화면에서 자유롭게 대화해요.</p></div>';
  const side = '<div class="stack span-4">' + aiTrackCard() +
    '<div class="card"><div class="card-head"><h3>' + icon('info', 'ic-sm') + 'AI 똑똑하게 쓰는 법</h3></div><div class="stack" style="gap:10px">' +
      '<div class="callout gray">' + icon('check', 'ic-sm') + '<div><b>예비 AI를 하나 더</b> 연결해 두면, 무료 한도가 끝나도 자동으로 바꿔 답해요.</div></div>' +
      '<div class="callout gray">' + icon('check', 'ic-sm') + '<div>종목마다 <b>나의 규칙</b>을 적어 두면 AI가 분석할 때 함께 보여줘요.</div></div>' +
      '<div class="callout gray">' + icon('check', 'ic-sm') + '<div>AI도 틀릴 수 있어요. 중요한 숫자는 <b>원문 기사·공시</b>로 꼭 확인하세요.</div></div>' +
    '</div></div>' +
    '<div class="card"><div class="card-head"><h3>' + icon('lock', 'ic-sm') + '내 정보는 안전한가요?</h3></div><p class="note" style="margin:0">AI 키는 <b>이 기기(폰·PC)</b>에만 저장돼요. 질문할 때 계좌 요약(종목·수량·수익률)이 선택한 AI 회사로 전송되지만, 이름 외 개인정보(계좌번호 등)는 보내지 않아요.</p></div></div>';
  el.innerHTML = '<div class="page-head"><div><h1>AI 비서</h1><div class="desc">뉴스 정리 · 계좌 점검 · 무엇이든 질문</div></div>' +
    (on ? '<div class="actions"><button class="btn btn-outline" data-nav="settings" data-sec="ai">' + icon('settings') + 'AI 바꾸기</button></div>' : '') + '</div>' +
    hero + sessionBriefCard() + acts + '<div class="grid g-12">' + chat + side + '</div>';
  hydrateIcons(el);
};

/* 🗓 장 시작 전·마감 브리핑 (v2.21) — 한국장·미국장 */
const SB = [['kr_pre', '🇰🇷 한국장 시작 전', '밤사이 미국장·환율 → 오늘 예상'], ['kr_post', '🇰🇷 한국장 마감', '오늘 정리 → 내일 예상'],
  ['us_pre', '🇺🇸 미국장 시작 전', '선물·지표 → 오늘 밤 예상'], ['us_post', '🇺🇸 미국장 마감', '결과 → 오늘 한국장 영향']];
function sbNow() {                                       // 지금 시간(한국)에 맞는 브리핑
  const k = new Date(Date.now() + (new Date().getTimezoneOffset() + 540) * 60000), m = k.getHours() * 60 + k.getMinutes();
  return m < 7 * 60 ? 'us_post' : m < 9 * 60 ? 'kr_pre' : m < 15 * 60 + 30 ? 'kr_pre' : m < 21 * 60 ? 'kr_post' : 'us_pre';
}
function sessionBriefCard() {
  if (!feat('brief')) return '';
  const now = sbNow();
  return '<div class="card sb-card"><div class="card-head"><h3>🗓 장 브리핑</h3><span class="muted" style="font-size:.78rem">지금은 <b>' + esc(SB.find(x => x[0] === now)[1]) + '</b> 추천</span></div>' +
    '<div class="sb-grid">' + SB.map(([k, t, d]) => '<button class="sb-btn' + (k === now ? ' now' : '') + '" data-act="sbrief" data-k="' + k + '"><b>' + t + '</b><span>' + d + '</span></button>').join('') + '</div></div>';
}
function openSessionBrief(kind) {
  if (!(AI_STATUS && AI_STATUS.on)) { needAI(() => openSessionBrief(kind)); return; }
  const t = SB.find(x => x[0] === kind) || SB[0];
  const m = openAiModal(t[1] + ' 브리핑', '최근 하루 뉴스와 지수·환율·금리를 모아 <b>' + esc(t[2]) + '</b>을 정리해요. 예상은 확률이에요 — 틀릴 수 있어요.', '시장 뉴스와 지표를 모으는 중이에요…');
  const mine = [...new Set(allHoldings().map(x => dispName(x.h)).concat(watchlist().map(w => dispName(w))).filter(Boolean))].slice(0, 20);
  api('/api/session-brief', { method: 'POST', body: { kind, mine }, timeout: 150000 })
    .then(d => aiFill(m, d, x => renderAiText(x.text), d && d.news ? '뉴스 ' + d.news + '건' : ''))
    .catch(() => aiFill(m, { status: 'fail', text: SERVER_DOWN }));
}

/* 💬 AI에게 물어보기 — 화면을 꽉 채우는 대화창 (자유 대화 · 내 설정 반영) */
function chatSetHtml() {
  return '<span>' + AI_DEPTHS[aiDepth()].emoji + ' ' + AI_DEPTHS[aiDepth()].label + '</span><span>' + TRADE_STYLES[tradeStyle()].emoji + ' ' + TRADE_STYLES[tradeStyle()].label + '</span>' +
    '<span>🎯 ' + esc(sectors().length ? sectorText(2) : '섹터 골고루') + '</span>' + (feat('dna') && dnaCount() ? '<span>🧬 DNA ' + dnaCount() + '</span>' : '');
}
function refreshChatSet() { const e = document.getElementById('cmSet'); if (e) e.innerHTML = chatSetHtml(); }
function openChat(q) {
  if (!(AI_STATUS && AI_STATUS.on)) { needAI(() => openChat(q)); return; }
  if (document.getElementById('cmIn')) { if (q) sendChat(q); return; }   // 이미 열려 있음
  const log = chatLog();
  const m = openModal({ title: '💬 AI에게 물어보기', size: 'cm', body:
    '<div class="cm-bar"><div class="cm-set" id="cmSet">' + chatSetHtml() + '</div>' +
      '<button class="btn btn-ghost btn-sm" data-cm="setup">' + icon('pencil', 'ic-sm') + '설정</button>' +
      '<button class="btn btn-ghost btn-sm" data-cm="new">' + icon('plus', 'ic-sm') + '새 대화</button></div>' +
    '<div class="chat-log" id="chatLog">' + (log.length ? log.map(msgHtml).join('') : chatEmptyHtml()) + '</div>',
    foot: '<div class="cm-foot"><div class="chat-input"><textarea class="input" id="cmIn" rows="1" placeholder="무엇이든 물어보세요 (예: 요즘 반도체 어때? / 내 계좌 괜찮아?)"></textarea>' +
      '<button class="btn btn-primary" id="cmSend" aria-label="보내기">' + icon('send') + '</button></div>' +
      '<div class="cm-legal">AI 답변은 참고용이에요. 투자 판단과 결과의 책임은 본인에게 있어요.</div></div>' });
  const box = m.body.querySelector('#chatLog'), inp = m.foot.querySelector('#cmIn');
  box.scrollTop = box.scrollHeight;
  const send = () => { const v = inp.value.trim(); if (!v || _chatBusy) return; inp.value = ''; inp.style.height = ''; sendChat(v); };
  m.foot.querySelector('#cmSend').onclick = send;
  inp.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && !IS_APP) { e.preventDefault(); send(); } });
  inp.addEventListener('input', () => { inp.style.height = 'auto'; inp.style.height = Math.min(150, inp.scrollHeight) + 'px'; });
  m.body.addEventListener('click', async e => {
    const sq = e.target.closest('[data-q]'); if (sq) { sendChat(sq.dataset.q); return; }
    const b = e.target.closest('[data-cm]'); if (!b) return;
    if (b.dataset.cm === 'setup') openAiSetup(true);
    if (b.dataset.cm === 'new' && chatLog().length && await confirmBox({ title: '새 대화', msg: '지금까지 나눈 대화를 지우고 새로 시작할까요?', ok: '새로 시작', danger: true })) {
      saveChat([]); box.innerHTML = chatEmptyHtml();
    }
  });
  if (q) sendChat(q); else if (!IS_APP) setTimeout(() => inp.focus(), 300);
}
function chatEmptyHtml() {
  return '<div class="cm-empty"><div class="ill">' + icon('bot') + '</div><b>무엇이든 편하게 물어보세요</b>' +
    '<p>내 계좌·종목과 요즘 시장 상황을 알고 있는 AI예요. 주식 공부, 종목 고민, 경제 뉴스, 일상 질문까지 자연스럽게 대화하세요.</p>' +
    '<div class="suggest">' + SUGGEST.map(x => '<button data-q="' + esc(x) + '">' + esc(x) + '</button>').join('') + '</div></div>';
}
function msgHtml(x) {
  if (x.role === 'user') return '<div class="msg me">' + esc(x.content) + '</div>';
  return '<div class="msg ai">' + renderChatMd(x.content) + (x.meta ? '<div class="who">' + esc(x.meta) + '</div>' : '') + '</div>';
}
let _chatBusy = false;
async function sendChat(q) {
  if (_chatBusy) return;
  _chatBusy = true;
  const log = chatLog(); log.push({ role: 'user', content: q }); saveChat(log);
  const box = document.getElementById('chatLog');
  if (!box) { _chatBusy = false; return; }
  const em = box.querySelector('.cm-empty, .empty'); if (em) em.remove();
  box.insertAdjacentHTML('beforeend', msgHtml({ role: 'user', content: q }) + '<div class="msg ai" id="typing"><span class="typing"><i></i><i></i><i></i></span></div>');
  box.scrollTop = box.scrollHeight;
  let reply;
  try {
    const d = await api('/api/ai/chat', { method: 'POST', body: { messages: log.slice(-16).map(x => ({ role: x.role, content: x.content })), context: portfolioContext(), style: tradeStyle(), known: knownStocks() }, timeout: 150000 });
    reply = d.status === 'ok' ? { role: 'assistant', content: d.text, meta: d.provider + ' · ' + d.model } : { role: 'assistant', content: '⚠️ ' + (d.text || '답을 받지 못했어요.') };
  } catch (e) { reply = { role: 'assistant', content: '⚠️ ' + SERVER_DOWN }; }
  const t = document.getElementById('typing'); if (t) t.remove();
  if (!reply.content.startsWith('⚠️')) log.push(reply); else log.pop();   // 실패한 질문은 기록에서 뺌 (다음 질문이 꼬이지 않게)
  saveChat(log);
  const b2 = document.getElementById('chatLog');
  if (b2) {
    b2.insertAdjacentHTML('beforeend', msgHtml(reply));
    const last = b2.lastElementChild;   // 긴 답은 처음부터 읽게
    b2.scrollTop = last && last.offsetHeight > b2.clientHeight * .7 ? last.offsetTop - b2.offsetTop - 8 : b2.scrollHeight;
  }
  _chatBusy = false;
}

/* ---------------- AI 맞춤 설정 (설치·업데이트 후 첫 실행에 한 번) ---------------- */
const AI_SETUP_VER = 18;   // 18: 투자자 설문(나이·직업·목적…) 추가 · 한 화면에 한 질문씩
/* AI 맞춤 설정 — 한 화면에 한 질문 (누르면 다음으로). 설문 6개 → 투자 성향 → 설명 방식 → 관심 섹터 */
function openAiSetup(force) {
  if (!force && UI.aiSetupVer >= AI_SETUP_VER) return;
  const ans = Object.assign({}, profile()), sel = sectors().slice();
  let st = tradeStyle(), tn = aiDepth(), step = 0;
  const steps = PROFILE_Q.map(x => ({ t: x.q, k: x.k, o: x.o.map(([v, l]) => ({ v, l })) }))
    .concat([{ t: '나의 매매 스타일은?', k: '_st', o: Object.values(TRADE_STYLES).map(x => ({ v: x.key, l: x.emoji + ' ' + x.label, d: x.desc })) },
             { t: 'AI가 어떻게 설명해 주면 좋을까요?', k: '_tn', o: Object.values(AI_DEPTHS).map(x => ({ v: x.key, l: x.emoji + ' ' + x.label, d: x.desc })) },
             { t: '관심 있는 섹터를 골라 주세요', k: '_sec', multi: true }]);
  const cur = k => k === '_st' ? st : k === '_tn' ? tn : ans[k];
  const m = openModal({ title: '✨ 나에게 맞춘 AI 만들기', sticky: true, body: '<div id="wz"></div>', foot: '<div class="wz-foot" id="wzFoot"></div>' });
  const draw = () => {
    const S_ = steps[step], N = steps.length;
    m.body.querySelector('#wz').innerHTML =
      '<div class="wz-prog"><i style="width:' + ((step + 1) / N * 100) + '%"></i></div><div class="wz-n">' + (step + 1) + ' / ' + N + (step < PROFILE_Q.length ? ' · 투자자 설문' : '') + '</div>' +
      '<h3 class="wz-q">' + S_.t + '</h3>' +
      (step === 0 ? '<p class="note" style="margin:-4px 0 12px">답한 내용은 <b>이 기기에만</b> 저장되고, AI가 나에게 맞는 답을 하는 데만 써요.</p>' : '') +
      (S_.multi ? '<p class="note" style="margin:-4px 0 12px">여러 개 골라도 돼요. AI 종목 추천이 이 섹터를 중점으로 찾아요.</p>' + sectorChipsHtml(sel) + '<div class="sec-cnt" id="wzCnt"></div>'
        : '<div class="wz-opts">' + S_.o.map(o => '<button class="wz-o' + (cur(S_.k) === o.v ? ' on' : '') + '" data-v="' + o.v + '"><b>' + o.l + '</b>' + (o.d ? '<span>' + o.d + '</span>' : '') + '</button>').join('') + '</div>');
    m.foot.querySelector('#wzFoot').innerHTML =
      (step ? '<button class="btn btn-gray shrink" data-wz="prev">' + icon('chevron-left', 'ic-sm') + '이전</button>' : '') +
      (S_.multi ? '<button class="btn btn-primary" data-wz="done">' + icon('check') + '완료</button>'
        : '<button class="btn btn-ghost" data-wz="skip">' + (cur(S_.k) ? '다음' : '건너뛰기') + '</button>');
    hydrateIcons(m.foot);
    if (S_.multi) { const c = () => { m.body.querySelector('#wzCnt').textContent = sel.length ? sel.length + '개 골랐어요' : '안 고르면 골고루 추천해요'; }; wireSectorChips(m.body, sel, c); c(); }
    m.body.scrollTop = 0;
  };
  const finish = () => {
    UI.profile = ans; UI.tradeStyle = st; UI.aiDepth = tn; UI.sectors = sel.slice(); UI.aiSetupVer = AI_SETUP_VER; UI.sectorAsked = true; saveUI(); m.close();
    toast('✨ 나에게 맞춘 AI로 설정했어요' + (profileText() ? ' (' + profileText().split(' · ').slice(0, 2).join(' · ') + ' …)' : ''), 3200);
    if (['settings', 'watch', 'ai', 'home'].includes(route.page)) rerender();
    refreshChatSet();
  };
  m.body.addEventListener('click', e => {
    const b = e.target.closest('.wz-o'); if (!b) return;
    const k = steps[step].k;
    if (k === '_st') st = b.dataset.v; else if (k === '_tn') tn = b.dataset.v; else ans[k] = b.dataset.v;
    m.body.querySelectorAll('.wz-o').forEach(x => x.classList.toggle('on', x === b));
    setTimeout(() => { if (step < steps.length - 1) { step++; draw(); } }, 220);   // 누르면 다음 질문으로
  });
  m.foot.addEventListener('click', e => {
    const b = e.target.closest('[data-wz]'); if (!b) return;
    if (b.dataset.wz === 'prev' && step) { step--; draw(); }
    if (b.dataset.wz === 'skip' && step < steps.length - 1) { step++; draw(); }
    if (b.dataset.wz === 'done') finish();
  });
  draw();
}
/* 시작 애니메이션·첫 안내 창이 끝난 뒤에 띄움 */
function askAiSetupWhenFree() {
  const needSetup = !(UI.aiSetupVer >= AI_SETUP_VER), needSector = !needSetup && !sectors().length && !UI.sectorAsked;
  if (!needSetup && !needSector) return;
  let n = 0;
  const t = setInterval(() => {
    if (document.getElementById('licLock')) return;   // 쿠폰 잠금이 풀린 뒤에
    if (++n > 120) { clearInterval(t); return; }
    if (document.querySelector('.intro') || _modals.length) return;
    clearInterval(t); if (needSetup) openAiSetup(); else openSectorPicker(null, true);
  }, 700);
}

/* ---------------- AI 차트 분석 (v1.6) ----------------
   서버가 1년 일봉으로 이동평균·RSI·MACD·거래량·지지/저항을 계산 → AI가 성향 기준으로 해석.
   화면: 가격·20/60일선 + 지지/저항 + AI 참고선(매수·손절·목표)을 그린 차트 + 해설 */
function openChartAI(ticker, market, name) {
  if (!ticker) { toast('종목 코드가 있어야 차트를 분석할 수 있어요'); return; }
  if (!(AI_STATUS && AI_STATUS.on)) { needAI(() => openChartAI(ticker, market, name)); return; }
  const st = TRADE_STYLES[tradeStyle()];
  const m = openAiModal('AI 차트 분석 — ' + esc(name || ticker),
    '최근 1년 차트로 <b>추세·지지/저항·매수세</b>를 계산하고, ' + st.emoji + ' <b>' + st.label + '</b> 기준(' + st.hz + ')으로 <b>매매 참고선</b>을 잡았어요.',
    '1년 차트와 지표를 계산하는 중…');
  api('/api/ai/chart?ticker=' + encodeURIComponent(ticker) + '&market=' + encodeURIComponent(market || '') + '&name=' + encodeURIComponent(name || '') + '&style=' + tradeStyle(), { timeout: 150000 })
    .then(d => aiFill(m, d, x => techChartHtml(x) + levelsCard(x.levels) + renderAiText(x.text), d && d.chart ? 'RSI ' + d.chart.rsi : ''))
    .catch(() => aiFill(m, { status: 'fail', text: SERVER_DOWN }));
}
function parseLevels(text, ccy) {
  const line = (String(text || '').replace(/\*\*/g, '').match(/참고선\s*[:：]([^\n]+)/) || [])[1] || '';
  const val = k => { const mm = line.match(new RegExp(k + '\\s*\\$?\\s*([\\d,]+(?:\\.\\d+)?)')); return mm ? parseFloat(mm[1].replace(/,/g, '')) : null; };
  return { buy: val('매수'), stop: val('손절'), target: val('목표') };
}
function techChartHtml(d) {
  const c = d.chart; if (!c || !c.points || c.points.length < 10) return '';
  const lv = parseLevels(d.text, d.ccy);
  const W = 420, H = 230, pl = 4, pr = 96, pt = 12, pb = 10;
  const vals = c.points.map(p => p[1]).concat((c.ma20 || []).map(p => p[1]), (c.ma60 || []).map(p => p[1]), [c.sup, c.res, lv.buy, lv.stop, lv.target].filter(v => v > 0));
  let lo = Math.min(...vals), hi = Math.max(...vals); const pad = (hi - lo) * 0.06; lo -= pad; hi += pad;
  const t0 = c.points[0][0], t1 = c.points[c.points.length - 1][0];
  const X = t => pl + (W - pl - pr) * (t - t0) / Math.max(1, t1 - t0), Y = v => pt + (H - pt - pb) * (1 - (v - lo) / (hi - lo));
  const path = arr => arr.map((p, i) => (i ? 'L' : 'M') + X(p[0]).toFixed(1) + ',' + Y(p[1]).toFixed(1)).join('');
  const fmt = v => d.ccy === 'USD' ? '$' + nf(v, 2) : nf(Math.round(v), 0);
  const hl = (v, col, lab, dash) => v > 0 && v >= lo && v <= hi ? '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + Y(v).toFixed(1) + '" y2="' + Y(v).toFixed(1) + '" stroke="' + col + '" stroke-width="1.6" stroke-dasharray="' + (dash || '6 5') + '"/>' +
    '<rect x="' + (W - pr + 4) + '" y="' + (Y(v) - 10).toFixed(1) + '" width="' + (pr - 4) + '" height="20" rx="6" fill="' + col + '"/>' +
    '<text x="' + (W - pr / 2 + 2) + '" y="' + (Y(v) + 4.5).toFixed(1) + '" text-anchor="middle" fill="#fff" style="font-size:11.5px;font-weight:800;letter-spacing:-.02em">' + lab + ' ' + esc(fmt(v)) + '</text>' : '';
  const area = path(c.points) + 'L' + X(t1).toFixed(1) + ',' + (H - pb) + 'L' + X(t0).toFixed(1) + ',' + (H - pb) + 'Z';
  return '<div class="tc-wrap"><svg class="tc" viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="AI 차트 분석 그래프">' +
    '<defs><linearGradient id="tcg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3182F6" stop-opacity=".28"/><stop offset="1" stop-color="#3182F6" stop-opacity="0"/></linearGradient></defs>' +
    '<path d="' + area + '" fill="url(#tcg)"/>' +
    (c.ma60 && c.ma60.length ? '<path class="tc-ma" d="' + path(c.ma60) + '" stroke="#8B5CF6"/>' : '') +
    (c.ma20 && c.ma20.length ? '<path class="tc-ma" d="' + path(c.ma20) + '" stroke="#FF8A3D"/>' : '') +
    '<path class="tc-px" pathLength="1" d="' + path(c.points) + '"/>' +
    hl(c.res, '#F04452', '저항', '2 4') + hl(c.sup, '#3182F6', '지지', '2 4') +
    hl(lv.target, '#E0A100', '목표') + hl(lv.buy, '#1BAF7A', '매수') + hl(lv.stop, '#6B7684', '손절') +
    '<circle cx="' + X(t1).toFixed(1) + '" cy="' + Y(c.last).toFixed(1) + '" r="4.5" fill="#3182F6" stroke="#fff" stroke-width="2"/></svg>' +
    '<div class="tc-legend"><span><i style="background:#3182F6"></i>주가</span><span><i style="background:#FF8A3D"></i>20일선</span><span><i style="background:#8B5CF6"></i>60일선</span>' +
    '<span class="tc-rsi ' + (c.rsi >= 70 ? 'hot' : c.rsi <= 30 ? 'cold' : '') + '">RSI ' + c.rsi + (c.rsi >= 70 ? ' 과열' : c.rsi <= 30 ? ' 침체' : '') + '</span></div></div>';
}
