@echo off
rem ============================================================
rem  Asset Assistant - one-click installer
rem  Double-click this file. It downloads a portable Python into
rem  the "app" folder, installs the app parts, and creates a
rem  desktop icon. Run it again any time to repair.
rem ============================================================
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\tools\install.ps1"
if errorlevel 1 pause
