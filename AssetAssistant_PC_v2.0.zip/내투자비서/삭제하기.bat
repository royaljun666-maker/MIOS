@echo off
rem ============================================================
rem  Asset Assistant - remove icons and the portable Python.
rem  Your asset data (app\userdata) is kept unless you choose.
rem ============================================================
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\tools\uninstall.ps1"
pause
