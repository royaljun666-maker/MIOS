@echo off
rem ============================================================
rem  Troubleshooting start: shows the server window and errors.
rem  Use this only when the normal icon does not work.
rem ============================================================
cd /d "%~dp0app"
set "PY=%~dp0app\runtime\python\python.exe"
if not exist "%PY%" set "PY=%~dp0app\runtime\venv\Scripts\python.exe"
if not exist "%PY%" goto NOTINSTALLED
"%PY%" "%~dp0app\price_server.py" --open
echo.
echo  The server stopped. Take a photo of the messages above if you need help.
pause
exit /b 0

:NOTINSTALLED
echo.
echo  Not installed yet. Please double-click the installer first.
echo.
pause
exit /b 1
