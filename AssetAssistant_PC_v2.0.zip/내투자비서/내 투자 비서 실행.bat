@echo off
rem ============================================================
rem  Asset Assistant - start (same as the desktop icon)
rem ============================================================
cd /d "%~dp0app"
if exist "%~dp0app\runtime\python\pythonw.exe" goto EMBED
if exist "%~dp0app\runtime\venv\Scripts\pythonw.exe" goto VENV
echo.
echo  Not installed yet. Starting the installer...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\tools\install.ps1"
exit /b 0

:EMBED
start "" "%~dp0app\runtime\python\pythonw.exe" "%~dp0app\price_server.py" --open
exit /b 0

:VENV
start "" "%~dp0app\runtime\venv\Scripts\pythonw.exe" "%~dp0app\price_server.py" --open
exit /b 0
