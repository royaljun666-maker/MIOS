/* ==========================================================================
   game.js — 🚀 크래시 게임 (재미용 포인트 · 현금/상품 교환 없음)
   · 하루 1회 접속 보너스 100,000P · 한 판 10,000~100,000P · 하루 30판
   · 1.01배(+1%)부터 주가 차트처럼 출렁이며 지수함수로 상승, 최대 10배(+1000%) 도달 시 자동 수령
   · 폭발 지점: x배 이상 갈 확률 = EDGE_K ÷ x^EDGE_P (높은 배율일수록 급격히 어려움 — 화면에 실제 확률 그대로 표시)
   · 폭발·수령은 화면에 보이는(출렁이는) 배율이 그 값에 처음 닿는 순간 기준
   ========================================================================== */
'use strict';

const GAME = { MIN: 10000, MAX: 100000, STEP: 10000, DAILY: 100000, PLAYS: 30, CAP: 10, START: 1.01, RATE: Math.log(10 / 1.01) / 30, WIN_LIMIT: 100000000,
  EDGE_K: 0.97, EDGE_P: 1.0 };   // 10배까지 약 30초. 난이도: EDGE_P 를 키우면 더 잘 잃음 (1.0 = 일반 크래시, 환수율 97%)
const reachProb = x => Math.min(1, GAME.EDGE_K / Math.pow(x, GAME.EDGE_P));   // x배 이상 갈 확률
const ret = x => '+' + Math.floor((x - 1) * 100 + 1e-9) + '%';                 // 배율 → 수익률 표시 (2.87 → +187%)

function G() {
  const s = S.settings;
  if (!s.game || typeof s.game !== 'object') s.game = { pts: 0, day: '', plays: 0, bonusDay: '', hist: [], best: 0, todayNet: 0, bet: 20000, auto: 0 };
  return s.game;
}
function gameDayRoll() {
  const g = G(), t = todayKey();
  if (g.day !== t) { g.day = t; g.plays = 0; g.todayNet = 0; }
}
/* 접속 보너스 — 앱을 켜면 하루 한 번 */
function grantDailyBonus() {
  const g = G(); gameDayRoll();
  if (g.bonusDay === todayKey()) return;
  g.bonusDay = todayKey(); g.pts += GAME.DAILY; save();
  setTimeout(() => toast('🎁 출석 보너스 +' + nf(GAME.DAILY, 0) + 'P! 🚀 게임 탭에서 크래시에 도전해 보세요', 4500), 1500);
}
/* 폭발 배율: 0.99 / (1 - U), 소수 둘째 자리 내림, 1.00 미만은 1.00(즉시 폭발), 최대 1000 */
function crashPoint() {
  const a = new Uint32Array(1); crypto.getRandomValues(a);
  const u = a[0] / 4294967296;
  const raw = Math.pow(GAME.EDGE_K / (1 - u), 1 / GAME.EDGE_P);
  if (raw < 1) return 1;                                     // (1 - EDGE_K) 확률로 즉시 폭발
  return Math.min(Math.max(1.03, Math.floor(raw * 100) / 100), GAME.CAP);   // 시작(1.01)보다 조금 위부터 → 즉시 폭발은 1%만
}
const baseAt = t => GAME.START * Math.exp(GAME.RATE * t);  // 출렁임 없는 기본 곡선
/* 이번 판의 출렁임 (주가처럼 여러 주기의 물결을 겹침) */
function makeWaves() {
  const r = () => { const a = new Uint32Array(1); crypto.getRandomValues(a); return a[0] / 4294967296; };
  return [[0.9, .024], [2.1, .018], [3.9, .011], [7.1, .006]].map(([f, a]) => ({ f: f * (.8 + r() * .4), a: a * (.7 + r() * .6), p: r() * 6.283 }));
}
function multAt(t, R) {
  R = R || RUN; const base = baseAt(t);
  if (!R || !R.waves) return base;
  let n = 0; for (const w of R.waves) n += w.a * (Math.sin(w.f * t + w.p) - Math.sin(w.p));
  return Math.max(1, base * Math.exp(n * Math.min(1, t / 2.5)));
}

/* 효과음 (배경음이 켜져 있을 때만) */
const GSFX = (function () {
  let ctx = null;
  const ok = () => { if (soundModeSafe() === 'off') return false; try { ctx = ctx || new (window.AudioContext || window.webkitAudioContext)(); if (ctx.state === 'suspended') ctx.resume(); return true; } catch (e) { return false; } };
  function tone(f, d, type, vol, slide) {
    const o = ctx.createOscillator(), g = ctx.createGain(), t = ctx.currentTime;
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t); if (slide) o.frequency.exponentialRampToValueAtTime(slide, t + d);
    g.gain.setValueAtTime(vol || .15, t); g.gain.exponentialRampToValueAtTime(.0001, t + d);
    o.connect(g); g.connect(ctx.destination); o.start(t); o.stop(t + d + .02);
  }
  function noise(d, vol, freq) {
    const b = ctx.createBuffer(1, ctx.sampleRate * d, ctx.sampleRate), x = b.getChannelData(0);
    for (let i = 0; i < x.length; i++) x[i] = (Math.random() * 2 - 1) * (1 - i / x.length);
    const s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    s.buffer = b; f.type = 'lowpass'; f.frequency.value = freq || 900; g.gain.value = vol || .5;
    s.connect(f); f.connect(g); g.connect(ctx.destination); s.start();
  }
  return {
    launch() { if (ok()) { noise(1.2, .25, 500); tone(120, 1.2, 'sawtooth', .05, 420); } },
    tick() { if (ok()) tone(880, .06, 'square', .03); },
    cash() { if (ok()) { tone(880, .12, 'sine', .18); setTimeout(() => tone(1320, .25, 'sine', .18), 110); } },
    boom() { if (ok()) { noise(1.1, .9, 700); tone(90, .8, 'sine', .4, 30); } },
  };
})();
function soundModeSafe() { try { return soundMode(); } catch (e) { return 'off'; } }

/* ── 한 판 진행 (화면을 떠나도 계속 돌아감) ─────────────────────────── */
let RUN = null;          // { phase: 'count'|'fly'|'end', bet, auto, crash, t0, cashedAt, win, startAt }
let _gTimer = null;

function gameStart() {
  const g = G(); gameDayRoll();
  if (RUN && RUN.phase !== 'end') return;
  const bet = Math.min(GAME.MAX, Math.max(GAME.MIN, Math.round((g.bet || GAME.MIN) / GAME.STEP) * GAME.STEP));
  if (g.plays >= GAME.PLAYS) { toast('오늘 ' + GAME.PLAYS + '판을 다 했어요. 내일 다시 도전해요!'); return; }
  if (g.pts < bet) { toast('포인트가 모자라요. 금액을 줄이거나 내일 출석 보너스를 받으세요'); return; }
  g.pts -= bet; g.plays += 1; g.todayNet -= bet;
  RUN = { phase: 'count', bet, auto: +g.auto || 0, crash: crashPoint(), t0: performance.now() + 3000, cashedAt: 0, cashT: 0, endT: 0, win: 0, startAt: Date.now(), waves: makeWaves() };
  g.live = { bet, auto: RUN.auto, crash: RUN.crash, at: Date.now() };   // 앱이 꺼져도 정산할 수 있게
  save({ noSync: true });
  GSFX.launch();
  clearInterval(_gTimer); _gTimer = setInterval(gameStep, 40);
  gameRenderControls();
}
function gameStep() {
  if (!RUN) return;
  const now = performance.now();
  if (RUN.phase === 'count') { if (now >= RUN.t0) { RUN.phase = 'fly'; } else return; }
  if (RUN.phase !== 'fly') return;
  const t = (now - RUN.t0) / 1000, m = multAt(t);
  if (!RUN.cashedAt && RUN.auto >= 1.01 && m >= RUN.auto && RUN.auto < RUN.crash) gameCash(RUN.auto, t);
  if (m >= RUN.crash) {
    if (RUN.crash >= GAME.CAP && !RUN.cashedAt) gameCash(GAME.CAP, t);        // 10배 도달 → 자동 수령
    RUN.endT = t;
    gameEnd();
  }
}
function gameCash(at, tt) {
  if (!RUN || RUN.phase !== 'fly' || RUN.cashedAt) return;
  const t = tt != null ? tt : (performance.now() - RUN.t0) / 1000, cur = Math.floor(multAt(t) * 100) / 100;
  at = Math.min(at || cur, RUN.crash, GAME.CAP);
  const g = G();
  RUN.cashedAt = at; RUN.cashT = t; RUN.win = Math.min(Math.floor(RUN.bet * at), GAME.WIN_LIMIT);
  g.pts += RUN.win; g.todayNet += RUN.win; if (at > (g.best || 0)) g.best = at;
  delete g.live; save({ noSync: true });
  GSFX.cash();
  gameBurst('cash');
  gameRenderControls();
}
function gameEnd() {
  if (!RUN || RUN.phase === 'end') return;                   // 한 판은 한 번만 정산
  const g = G();
  RUN.phase = 'end'; clearInterval(_gTimer);
  g.hist = [RUN.crash].concat(g.hist || []).slice(0, 20);
  delete g.live; save();
  if (!RUN.cashedAt) GSFX.boom();
  gameBurst('boom');
  gameRenderControls(); gameRenderSide();
}
/* 앱이 꺼진 사이 끝난 판 정산: 자동 수령이 폭발보다 낮았으면 수령, 아니면 잃음 */
function gameSettleLive() {
  if (RUN && RUN.phase !== 'end') return;                    // 지금 날고 있는 판은 건드리지 않음
  const g = G(); if (!g.live) return;
  const L = g.live;
  if (L.auto >= 1.01 && L.auto <= L.crash) { const w = Math.min(Math.floor(L.bet * L.auto), GAME.WIN_LIMIT); g.pts += w; g.todayNet += w; if (L.auto > (g.best || 0)) g.best = L.auto; }
  g.hist = [L.crash].concat(g.hist || []).slice(0, 20);
  delete g.live; save();
}

/* ── 화면 ─────────────────────────────────────────────────────────── */
PAGES.game = function (params, re) {
  const el = pageEl('game'), g = G(); gameDayRoll(); gameSettleLive();
  if (re && document.getElementById('gmCanvas')) { gameRenderControls(); gameRenderSide(); return; }   // 다시 그리기: 진행 화면 유지
  const autos = [[0, '끄기'], [1.2, '+20%'], [1.5, '+50%'], [2, '+100%'], [3, '+200%'], [5, '+400%']];
  el.innerHTML =
    '<div class="page-head"><div><h1>🚀 크래시</h1><div class="desc">폭발하기 전에 수령하세요! 하루 30판 · 재미용 포인트</div></div></div>' +
    '<div class="gm-wrap">' +
      '<div class="card gm-main">' +
        '<div class="gm-stage" id="gmStage"><canvas id="gmCanvas"></canvas>' +
          '<div class="gm-mult" id="gmMult">+1%</div><div class="gm-pct" id="gmPct">1.01배</div><div class="gm-msg" id="gmMsg">금액을 정하고 출발을 눌러요</div>' +
          '<div class="gm-pts-mini" id="gmPtsMini"></div><div class="gm-flash" id="gmFlash"></div>' +
          '<button class="btn btn-lg btn-block gm-go" id="gmGo"></button></div>' +
        '<div class="gm-hist" id="gmHist"></div>' +
        '<div class="gm-ctrl">' +
          '<div class="gm-row"><b>참여 금액</b><div class="gm-bets" id="gmBets">' +
            Array.from({ length: 10 }, (_, i) => (i + 1) * GAME.STEP).map(v => '<button data-bet="' + v + '">' + (v / 10000) + '만</button>').join('') + '</div></div>' +
          '<div class="gm-row"><b>자동 수령</b><div class="seg gm-auto" id="gmAuto">' + autos.map(a => '<button data-auto="' + a[0] + '">' + a[1] + '</button>').join('') + '</div></div>' +
        '</div>' +
      '</div>' +
      '<div class="stack gm-side" id="gmSide"></div>' +
    '</div>';
  el.querySelector('#gmBets').onclick = e => { const b = e.target.closest('[data-bet]'); if (!b || (RUN && RUN.phase !== 'end')) return; G().bet = +b.dataset.bet; save({ noSync: true }); gameRenderControls(); };
  el.querySelector('#gmAuto').onclick = e => { const b = e.target.closest('[data-auto]'); if (!b || (RUN && RUN.phase !== 'end')) return; G().auto = +b.dataset.auto; save({ noSync: true }); gameRenderControls(); };
  el.querySelector('#gmGo').onclick = () => { if (RUN && RUN.phase === 'fly' && !RUN.cashedAt) gameCash(); else if (!RUN || RUN.phase === 'end') gameStart(); };
  gameRenderControls(); gameRenderSide(); gameCanvasLoop();
};
function gameRenderSide() {
  const box = document.getElementById('gmSide'); if (!box) return;
  const g = G(), left = Math.max(0, GAME.PLAYS - g.plays);
  box.innerHTML =
    '<div class="card gm-stats">' +
      '<div class="gm-pts"><span>내 포인트</span><b id="gmPts">' + nf(g.pts, 0) + 'P</b></div>' +
      '<div class="gm-grid"><div><span>오늘 남은 판</span><b>' + left + ' / ' + GAME.PLAYS + '</b></div>' +
      '<div><span>오늘 손익</span><b class="' + cls(g.todayNet) + '">' + (g.todayNet > 0 ? '+' : '') + nf(g.todayNet, 0) + 'P</b></div>' +
      '<div><span>최고 수령</span><b>' + (g.best ? ret(g.best) : '-') + '</b></div>' +
      '<div><span>출석 보너스</span><b>' + (g.bonusDay === todayKey() ? '오늘 받음 ✅' : '앱 켜면 지급') + '</b></div></div>' +
      '<div class="gm-dots">' + Array.from({ length: GAME.PLAYS }, (_, i) => '<i class="' + (i < g.plays ? 'used' : '') + '"></i>').join('') + '</div></div>' +
    '<div class="card"><div class="card-head"><h3>' + icon('info', 'ic-sm') + '게임 방법</h3></div>' +
      '<ol class="gm-rules"><li><b>금액</b>(1만~10만P)을 정하고 <b>출발</b>을 눌러요.</li>' +
      '<li>로켓이 오르는 동안 배율이 <b>점점 빨라지며</b> 올라가요. <b>폭발 전에 수령</b>을 누르세요.</li>' +
      '<li><b>자동 수령</b>을 정해 두면 그 배율에서 알아서 받아요. 먼저 폭발하면 참여 포인트를 잃어요.</li>' +
      '<li><b>+1%</b>에서 출발해 주가처럼 <b>출렁이며</b> 올라가요. 최대 <b>+900%</b>(10배)에 닿으면 자동 수령.</li>' +
      '<li>받는 포인트 = 참여 금액 × (1 + 수익률). 예) 1만P를 +150%에 수령 → 2만 5천P(순수익 +1만 5천P)</li></ol>' +
      '<div class="gm-odds"><b>실제 확률</b> (그 수익률 이상 날아갈 확률)<br>' + [1.2, 1.5, 2, 3, 5, 10].map(x => ret(x) + ' ' + (reachProb(x) * 100).toFixed(1) + '%').join(' · ') +
        '<br>한 판에 평균 ' + Math.round((1 - GAME.EDGE_K) * 100) + '% 정도씩 줄어드는 게임이에요. 길게 하면 포인트는 줄어요.</div>' +
      '<p class="note" style="margin:10px 0 0">포인트는 이 앱 안에서만 쓰는 <b>재미용</b>이에요. 현금·상품으로 바꿀 수 없고, 사고팔 수 없어요.</p></div>';
}
function gameRenderControls() {
  const el = pageEl('game'); if (!el || !document.getElementById('gmGo')) return;
  const g = G(), go = document.getElementById('gmGo');
  el.querySelectorAll('[data-bet]').forEach(b => b.classList.toggle('on', +b.dataset.bet === g.bet));
  el.querySelectorAll('[data-auto]').forEach(b => b.classList.toggle('on', +b.dataset.auto === (+g.auto || 0)));
  const busy = RUN && RUN.phase !== 'end';
  el.querySelector('.gm-ctrl').classList.toggle('gm-busy', !!busy);
  go.className = 'btn btn-lg btn-block gm-go';
  if (!busy) {
    const done = g.plays >= GAME.PLAYS, poor = g.pts < g.bet;
    go.disabled = done || poor;
    go.innerHTML = done ? '오늘 ' + GAME.PLAYS + '판 끝! 내일 또 만나요' : poor ? '포인트가 모자라요' : '🚀 출발 (' + nf(g.bet, 0) + 'P)';
  } else if (RUN.phase === 'count') { go.disabled = true; go.innerHTML = '곧 출발해요…'; }
  else if (RUN.cashedAt) { go.disabled = true; go.classList.add('cashed'); go.innerHTML = '✅ ' + ret(RUN.cashedAt) + ' 수령 · +' + nf(RUN.win, 0) + 'P'; }
  else { go.disabled = false; go.classList.add('cash'); go.innerHTML = '💰 수령'; }
  const pts = document.getElementById('gmPts'); if (pts) pts.textContent = nf(g.pts, 0) + 'P';
  const pm = document.getElementById('gmPtsMini'); if (pm) pm.innerHTML = '💎 ' + nf(g.pts, 0) + 'P · 남은 판 ' + Math.max(0, GAME.PLAYS - g.plays);
  const h = document.getElementById('gmHist');
  if (h) h.innerHTML = (g.hist || []).slice(0, 12).map(x => '<span class="' + (x < 2 ? 'lo' : x < 5 ? 'mid' : 'hi') + '">' + ret(x) + '</span>').join('') || '<span class="none">최근 결과(폭발 지점)가 여기 쌓여요</span>';
}

/* ── 캔버스: 우주·곡선·로켓·폭발 ──────────────────────────────────── */
let _gRaf = 0, _gStars = null, _gParts = [], _gShake = 0;
function gameBurst(kind) {
  const n = kind === 'boom' ? 70 : 34;
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2, sp = (kind === 'boom' ? 3 : 2) + Math.random() * (kind === 'boom' ? 7 : 4);
    _gParts.push({ kind, x: null, y: null, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - (kind === 'cash' ? 2 : 0), life: 1,
      c: kind === 'boom' ? ['#FFB020', '#FF5A36', '#FFE08A', '#ffffff'][i % 4] : ['#FFD54A', '#FFE9A3', '#1BAF7A'][i % 3], s: 2 + Math.random() * 4 });
  }
  if (kind === 'boom') _gShake = 14;
}
function gameCanvasLoop() {
  cancelAnimationFrame(_gRaf);
  const cv = document.getElementById('gmCanvas'); if (!cv) return;
  const stage = cv.parentElement, dpr = Math.min(2, window.devicePixelRatio || 1);
  let W = 0, H = 0;
  const fit = () => { W = stage.clientWidth; H = stage.clientHeight; cv.width = W * dpr; cv.height = H * dpr; cv.style.width = W + 'px'; cv.style.height = H + 'px'; };
  fit();
  if (!_gStars) _gStars = Array.from({ length: 70 }, () => ({ x: Math.random(), y: Math.random(), z: .3 + Math.random() * .7 }));
  const ctx = cv.getContext('2d');
  const multEl = document.getElementById('gmMult'), msgEl = document.getElementById('gmMsg');
  let lastTick = 0;
  (function frame() {
    if (!document.getElementById('gmCanvas')) return;
    if (stage.clientWidth !== W || stage.clientHeight !== H) fit();
    const now = performance.now();
    let m = 1, t = 0, phase = RUN ? RUN.phase : 'idle';
    if (RUN && phase !== 'count') { t = phase === 'end' ? RUN.endT : Math.max(0, (now - RUN.t0) / 1000); m = phase === 'end' ? RUN.crash : multAt(t); }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const sx = _gShake > 0 ? (Math.random() - .5) * _gShake : 0, sy = _gShake > 0 ? (Math.random() - .5) * _gShake : 0; _gShake *= .9; if (_gShake < .3) _gShake = 0;
    ctx.translate(sx, sy);
    // 하늘 → 우주 (배율이 클수록 깊은 우주색)
    const k = Math.min(1, Math.log10(Math.max(1, m)) / 2);
    const grd = ctx.createLinearGradient(0, 0, 0, H);
    grd.addColorStop(0, 'hsl(' + (230 + 40 * k) + ',55%,' + (16 - 9 * k) + '%)'); grd.addColorStop(1, 'hsl(' + (220 + 50 * k) + ',60%,' + (30 - 20 * k) + '%)');
    ctx.fillStyle = grd; ctx.fillRect(-20, -20, W + 40, H + 40);
    // 별 (속도 = 상승 속도)
    const spd = phase === 'fly' ? .0006 + .002 * Math.min(1, (m - 1) / 20) : .00015;
    _gStars.forEach(s => { s.x -= spd * s.z * 16; s.y += spd * s.z * 10; if (s.x < 0) s.x += 1; if (s.y > 1) s.y -= 1;
      ctx.globalAlpha = .35 + .65 * s.z; ctx.fillStyle = '#fff'; ctx.fillRect(s.x * W, s.y * H, s.z * 2, s.z * 2); });
    ctx.globalAlpha = 1;
    // 곡선 (시간축은 넉넉히, 배율축은 자동 확대)
    const pad = 28, tMax = Math.max(6, t * 1.12), mMax = Math.max(1.6, m * 1.22);
    const X = tt => pad + (W - pad * 2) * (tt / tMax), Y = mm => H - pad - (H - pad * 2) * ((mm - 1) / (mMax - 1));
    ctx.strokeStyle = 'rgba(255,255,255,.08)'; ctx.lineWidth = 1; ctx.font = '600 11px Pretendard, sans-serif'; ctx.fillStyle = 'rgba(255,255,255,.45)';
    [1.5, 2, 3, 5, 10].filter(v => v <= mMax).slice(-3).forEach(v => { ctx.beginPath(); ctx.moveTo(pad, Y(v)); ctx.lineTo(W - pad, Y(v)); ctx.stroke(); ctx.fillText(ret(v), 4, Y(v) - 3); });
    let hx = X(0), hy = Y(1);
    if (RUN && phase !== 'count') {
      const g2 = ctx.createLinearGradient(0, H, W, 0); g2.addColorStop(0, '#22B8CF'); g2.addColorStop(1, phase === 'end' && !RUN.cashedAt ? '#F04452' : '#7C5CFF');
      ctx.beginPath(); const N = Math.max(40, Math.min(240, Math.round(t * 16)));
      for (let i = 0; i <= N; i++) { const tt = t * i / N, x = X(tt), y = Y(multAt(tt)); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
      ctx.lineWidth = 4; ctx.strokeStyle = g2; ctx.shadowColor = '#7C9CFF'; ctx.shadowBlur = 12; ctx.stroke(); ctx.shadowBlur = 0;
      ctx.lineTo(X(t), H - pad); ctx.lineTo(X(0), H - pad); ctx.closePath();
      const fill = ctx.createLinearGradient(0, 0, 0, H); fill.addColorStop(0, 'rgba(124,92,255,.28)'); fill.addColorStop(1, 'rgba(34,184,207,0)'); ctx.fillStyle = fill; ctx.fill();
      hx = X(t); hy = Y(m);
      if (RUN.cashedAt) { const cx = X(RUN.cashT), cy = Y(RUN.cashedAt); ctx.fillStyle = '#1BAF7A'; ctx.beginPath(); ctx.arc(cx, cy, 6, 0, 7); ctx.fill(); ctx.fillStyle = '#fff'; ctx.font = '800 12px Pretendard, sans-serif'; ctx.fillText('수령 ' + ret(RUN.cashedAt), cx + 8, cy + 4); }
    }
    // 로켓 (폭발 전) / 폭발
    if (phase !== 'end') {
      // 로켓: 기본 곡선 방향 + 흔들림 + 둥실 + 깜빡이는 불꽃 + 연기 꼬리
      const dt = .25, slope = RUN && phase === 'fly' ? Math.atan2(Y(baseAt(t)) - Y(baseAt(Math.max(0, t - dt))), X(t) - X(Math.max(0, t - dt))) : -Math.PI / 4;
      const wob = Math.sin(now / 110) * .13 + Math.sin(now / 47) * .05, bob = Math.sin(now / 90) * 3;
      if (phase === 'fly' && Math.random() < .8) _gParts.push({ kind: 'smoke', x: hx - 10, y: hy + 10, vx: -1 - Math.random(), vy: .6 + Math.random() * .6, life: .8, c: 'rgba(200,210,255,.5)', s: 3 + Math.random() * 3 });
      ctx.save(); ctx.translate(hx, hy + bob - (phase === 'count' ? 4 + Math.sin(now / 40) * 2 : 0)); ctx.rotate(slope + Math.PI / 4 + wob);
      const fl = 14 + Math.random() * 12;
      const fg = ctx.createRadialGradient(-12, 12, 1, -12, 12, fl);
      fg.addColorStop(0, 'rgba(255,255,255,.95)'); fg.addColorStop(.35, 'rgba(255,200,60,.9)'); fg.addColorStop(1, 'rgba(255,70,40,0)');
      ctx.fillStyle = fg; ctx.beginPath(); ctx.ellipse(-12 - fl * .35, 12 + fl * .35, fl * .55, fl * .3, -Math.PI / 4, 0, 7); ctx.fill();
      ctx.shadowColor = 'rgba(160,190,255,.9)'; ctx.shadowBlur = 16;
      ctx.font = '38px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('🚀', 0, 0); ctx.shadowBlur = 0; ctx.restore();
      if (phase === 'fly') { ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = 1.5;          // 속도선
        for (let i = 0; i < 4; i++) { const yy = (now / 3 + i * 80) % H; ctx.beginPath(); ctx.moveTo(W - ((now / 2 + i * 137) % W), yy); ctx.lineTo(W - ((now / 2 + i * 137) % W) + 30, yy - 18); ctx.stroke(); } }
    } else if (phase === 'end') {
      ctx.font = '54px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('💥', hx, hy); ctx.textAlign = 'start'; ctx.textBaseline = 'alphabetic';
    }
    // 파편·코인
    _gParts = _gParts.filter(p => p.life > 0);
    _gParts.forEach(p => { if (p.x == null) { p.x = hx; p.y = hy; } p.x += p.vx; p.y += p.vy;
      if (p.kind === 'smoke') { p.s += .35; p.life -= .03; } else { p.vy += .15; p.life -= .018; }
      ctx.globalAlpha = Math.max(0, p.life); ctx.fillStyle = p.c; ctx.beginPath(); ctx.arc(p.x, p.y, p.s, 0, 7); ctx.fill(); });
    ctx.globalAlpha = 1;
    // 숫자·안내
    const pctEl = document.getElementById('gmPct');
    if (pctEl) { const mm = phase === 'idle' || phase === 'count' ? GAME.START : m; const up = mm >= (pctEl._last || 0); pctEl._last = mm;
      pctEl.textContent = (Math.floor(mm * 100) / 100).toFixed(2) + '배'; pctEl.className = 'gm-pct' + (phase === 'fly' ? (up ? ' up' : ' dn') : ''); }
    if (multEl) {
      if (phase === 'count') { const c = Math.ceil((RUN.t0 - now) / 1000); multEl.textContent = c > 0 ? c : '🚀'; multEl.className = 'gm-mult count'; msgEl.textContent = '발사 준비…'; }
      else if (phase === 'fly') { multEl.textContent = ret(m); multEl.className = 'gm-mult fly' + (m >= 5 ? ' hot' : m >= 2 ? ' warm' : '');
        msgEl.textContent = RUN.cashedAt ? '수령 완료! 로켓은 계속 날아가요…' : '지금 수령하면 +' + nf(Math.min(Math.floor(RUN.bet * m), GAME.WIN_LIMIT), 0) + 'P';
        if (now - lastTick > 1000 / Math.min(8, 1 + m)) { lastTick = now; if (m > 1.5 && !RUN.cashedAt) GSFX.tick(); }
        const ms = [2, 3, 5, 7].find(x => m >= x && !(RUN.miles || (RUN.miles = {}))[x]);
        if (ms) { RUN.miles[ms] = 1; const f = document.getElementById('gmFlash'); if (f) { f.textContent = '🔥 ' + ret(ms) + ' 돌파!'; f.classList.remove('on'); void f.offsetWidth; f.classList.add('on'); } GSFX.cash(); } }
      else if (phase === 'end') { multEl.textContent = RUN.cashedAt ? ret(RUN.cashedAt) : '💥 ' + ret(RUN.crash); multEl.className = 'gm-mult end' + (RUN.cashedAt ? ' won' : ' lost');
        msgEl.textContent = RUN.cashedAt ? '🎉 수령 성공 · +' + nf(RUN.win, 0) + 'P (순수익 ' + (RUN.win - RUN.bet >= 0 ? '+' : '') + nf(RUN.win - RUN.bet, 0) + 'P) · 로켓은 ' + ret(RUN.crash) + '에서 폭발' : ret(RUN.crash) + '에서 폭발 · -' + nf(RUN.bet, 0) + 'P'; }
      else { multEl.textContent = '+1%'; multEl.className = 'gm-mult'; msgEl.textContent = '금액을 정하고 출발을 눌러요'; }
    }
    _gRaf = requestAnimationFrame(frame);
  })();
}
