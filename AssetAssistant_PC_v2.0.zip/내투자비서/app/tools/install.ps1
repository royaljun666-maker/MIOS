﻿# ==========================================================================
#  내 투자 비서 — 설치 스크립트
#  "설치하기.bat" 을 두 번 누르면 이 파일이 실행됩니다.
#
#  하는 일
#    1) 앱 폴더 안(runtime\python)에 '휴대용 파이썬'을 내려받습니다.
#       → 컴퓨터에 따로 설치하지 않으므로 관리자 권한·환경변수 설정이 필요 없어요.
#    2) 앱에 필요한 부품(flask 등)을 설치합니다.
#    3) 바탕화면과 시작 메뉴에 "내 투자 비서" 아이콘을 만듭니다.
#    4) 앱을 실행합니다.
#  인터넷이 필요합니다(약 30MB). 다시 실행해도 안전합니다(이미 된 단계는 건너뜀).
# ==========================================================================
param([switch]$NoShortcut, [switch]$NoLaunch, [switch]$NoPause)   # 시험용 옵션(평소엔 쓰지 않음)

# 외부 프로그램(파이썬·pip)의 경고 출력 때문에 설치가 멈추지 않도록 Continue. 실패는 종료코드로 직접 확인.
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'   # PowerShell 5 의 진행 표시가 다운로드를 매우 느리게 만들어서 끔
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}

$App      = Split-Path -Parent $PSScriptRoot
$Runtime  = Join-Path $App 'runtime'
$PyDir    = Join-Path $Runtime 'python'
$VenvDir  = Join-Path $Runtime 'venv'
$PyVer    = '3.12.10'
$Arch     = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64') { 'arm64' } else { 'amd64' }
$AppName  = '내 투자 비서'
$Total    = 4

function Say($msg, $color = 'Gray') { Write-Host $msg -ForegroundColor $color }
function Step($n, $msg) { Write-Host ''; Write-Host ("[{0}/{1}] {2}" -f $n, $Total, $msg) -ForegroundColor Cyan }
function Done($msg) { Write-Host ("      [OK] " + $msg) -ForegroundColor Green }
function Fail($msg) {
    Write-Host ''
    Write-Host '  ================================================' -ForegroundColor Red
    Write-Host ("  설치하지 못했어요: " + $msg) -ForegroundColor Red
    Write-Host '  ================================================' -ForegroundColor Red
    Write-Host ''
    Write-Host '  • 인터넷이 연결되어 있는지 확인한 뒤 "설치하기.bat" 을 다시 실행해 주세요.' -ForegroundColor Yellow
    Write-Host '  • 회사·학교 PC는 보안 프로그램이 다운로드를 막을 수 있어요.' -ForegroundColor Yellow
    Write-Host '  • 계속 안 되면 이 창의 내용을 사진으로 찍어 배포한 분께 보내 주세요.' -ForegroundColor Yellow
    Write-Host ''
    if (-not $NoPause) { Read-Host '  Enter 키를 누르면 창이 닫혀요' }
    exit 1
}
function Get-File($url, $out) {
    for ($i = 1; $i -le 3; $i++) {
        try {
            Invoke-WebRequest -Uri $url -OutFile $out -UseBasicParsing -TimeoutSec 300
            if ((Test-Path $out) -and ((Get-Item $out).Length -gt 1000)) { return $true }
        } catch {
            Say ("      다운로드 재시도 {0}/3 …" -f $i) 'DarkYellow'
            Start-Sleep -Seconds (3 * $i)
        }
    }
    return $false
}
function Test-Py($exe) {
    if (-not (Test-Path $exe)) { return $false }
    try { & $exe -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" 2>&1 | Out-Null; return ($LASTEXITCODE -eq 0) } catch { return $false }
}
function Find-SystemPython {
    $cands = @()
    try { $p = & py -3 -c "import sys; print(sys.executable)" 2>$null; if ($LASTEXITCODE -eq 0 -and $p) { $cands += $p.Trim() } } catch {}
    try { $p = & python -c "import sys; print(sys.executable)" 2>$null; if ($LASTEXITCODE -eq 0 -and $p) { $cands += $p.Trim() } } catch {}
    foreach ($c in $cands) { if ($c -notmatch 'WindowsApps' -and (Test-Py $c)) { return $c } }
    return $null
}

Clear-Host
Say ''
Say '  ================================================' 'Blue'
Say '        내 투자 비서  -  설치를 시작합니다' 'Blue'
Say '  ================================================' 'Blue'
Say ''
Say '  창을 닫지 말고 잠시 기다려 주세요. (보통 1~3분)'
Say ("  설치 위치: " + $App) 'DarkGray'

# 인터넷에서 받은 압축파일이면 Windows가 파일마다 '차단' 표시를 붙여 경고창이 뜰 수 있어 미리 풀어 둠
try { Get-ChildItem -LiteralPath $App -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue } catch {}
# 배포 패키지 구조(겉 폴더에 .bat, 프로그램은 app 폴더)면 겉 폴더의 .bat 파일도 함께 풀어 둠
$Top = Split-Path -Parent $App
if ((Split-Path -Leaf $App) -eq 'app' -and (Test-Path -LiteralPath (Join-Path $Top '설치하기.bat'))) {
    try { Get-ChildItem -LiteralPath $Top -File -Filter '*.bat' -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue } catch {}
}

# ---------------------------------------------------------------- 1. 파이썬
Step 1 '휴대용 파이썬 준비'
$Py = $null; $PyW = $null
if (Test-Py (Join-Path $PyDir 'python.exe')) {
    $Py = Join-Path $PyDir 'python.exe'; $PyW = Join-Path $PyDir 'pythonw.exe'
    Done '이미 준비되어 있어요'
} elseif (Test-Py (Join-Path $VenvDir 'Scripts\python.exe')) {
    $Py = Join-Path $VenvDir 'Scripts\python.exe'; $PyW = Join-Path $VenvDir 'Scripts\pythonw.exe'
    Done '이미 준비되어 있어요'
} else {
    New-Item -ItemType Directory -Force -Path $Runtime | Out-Null
    $zip = Join-Path $Runtime 'python.zip'
    Say ("      Python {0} ({1}) 내려받는 중… (약 11MB)" -f $PyVer, $Arch)
    $ok = Get-File ("https://www.python.org/ftp/python/{0}/python-{0}-embed-{1}.zip" -f $PyVer, $Arch) $zip
    if ($ok) {
        if (Test-Path $PyDir) { Remove-Item -LiteralPath $PyDir -Recurse -Force }
        try { Expand-Archive -LiteralPath $zip -DestinationPath $PyDir -Force -ErrorAction Stop } catch { Fail '내려받은 파이썬 압축을 풀지 못했어요.' }
        Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue
        # 휴대용 파이썬 설정: 부품(site-packages) 사용 + 앱 폴더를 모듈 경로에 추가
        $pth = Get-ChildItem -LiteralPath $PyDir -Filter 'python*._pth' | Select-Object -First 1
        if ($pth) {
            $lines = Get-Content -LiteralPath $pth.FullName | ForEach-Object { if ($_ -match '^\s*#\s*import site') { 'import site' } else { $_ } }
            if (-not ($lines -contains '..\..')) { $lines += '..\..' }
            Set-Content -LiteralPath $pth.FullName -Value $lines -Encoding ASCII
        }
        $Py = Join-Path $PyDir 'python.exe'; $PyW = Join-Path $PyDir 'pythonw.exe'
        if (-not (Test-Py $Py)) { Fail '내려받은 파이썬이 실행되지 않아요.' }
        Done '휴대용 파이썬 준비 완료'
    } else {
        Say '      내려받기가 안 돼서, 이 컴퓨터에 이미 있는 파이썬을 찾아볼게요…' 'DarkYellow'
        $sys = Find-SystemPython
        if (-not $sys) { Fail '파이썬을 내려받지 못했고, 컴퓨터에 설치된 파이썬(3.9 이상)도 없어요.' }
        & $sys -m venv $VenvDir
        $Py = Join-Path $VenvDir 'Scripts\python.exe'; $PyW = Join-Path $VenvDir 'Scripts\pythonw.exe'
        if (-not (Test-Py $Py)) { Fail '파이썬 가상환경을 만들지 못했어요.' }
        Done ("컴퓨터의 파이썬 사용: " + $sys)
    }
}

# ---------------------------------------------------------------- 2. pip
Step 2 '부품 설치 도구(pip) 준비'
& $Py -m pip --version 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) {
    $gp = Join-Path $Runtime 'get-pip.py'
    if (-not (Get-File 'https://bootstrap.pypa.io/get-pip.py' $gp)) { Fail 'pip 설치 파일을 내려받지 못했어요.' }
    & $Py $gp --no-warn-script-location --disable-pip-version-check -q
    Remove-Item -LiteralPath $gp -Force -ErrorAction SilentlyContinue
    & $Py -m pip --version 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { Fail 'pip를 설치하지 못했어요.' }
}
Done 'pip 준비 완료'

# ---------------------------------------------------------------- 3. 부품
Step 3 '앱 부품 설치 (flask · requests · beautifulsoup4)'
& $Py -m pip install -r (Join-Path $App 'requirements.txt') --no-warn-script-location --disable-pip-version-check -q
if ($LASTEXITCODE -ne 0) {
    Say '      한 번 더 시도할게요…' 'DarkYellow'
    & $Py -m pip install -r (Join-Path $App 'requirements.txt') --no-warn-script-location --disable-pip-version-check
    if ($LASTEXITCODE -ne 0) { Fail '앱 부품을 설치하지 못했어요.' }
}
& $Py -c "import flask, flask_cors, requests, bs4" 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) { Fail '설치한 부품을 불러오지 못했어요.' }
Done '부품 설치 완료'

# ---------------------------------------------------------------- 4. 아이콘
Step 4 '바탕화면·시작 메뉴에 아이콘 만들기'
$icon   = Join-Path $App 'assets\app.ico'
$script = Join-Path $App 'price_server.py'
function New-Shortcut($lnk) {
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut($lnk)
    $sc.TargetPath = $PyW
    $sc.Arguments = ('"{0}" --open' -f $script)
    $sc.WorkingDirectory = $App
    if (Test-Path $icon) { $sc.IconLocation = "$icon,0" }
    $sc.Description = '내 투자 비서 — 쉽고 똑똑한 투자관리'
    $sc.Save()
}
if (-not $NoShortcut) {
foreach ($old in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    $o = Join-Path $old ('내 자산 비서' + '.lnk'); if (Test-Path -LiteralPath $o) { Remove-Item -LiteralPath $o -Force }   # 예전 이름 아이콘 정리
}
try {
    $desk = [Environment]::GetFolderPath('Desktop')
    New-Shortcut (Join-Path $desk ($AppName + '.lnk'))
    Done '바탕화면 아이콘 완료'
} catch { Say '      바탕화면 아이콘을 만들지 못했어요. 설치 폴더의 "내 투자 비서 실행.bat" 을 쓰세요.' 'DarkYellow' }
try {
    $progs = [Environment]::GetFolderPath('Programs')
    New-Shortcut (Join-Path $progs ($AppName + '.lnk'))
    Done '시작 메뉴 등록 완료'
} catch {}
} else { Done '(시험 모드: 아이콘 만들기 건너뜀)' }

# ---------------------------------------------------------------- 끝
Say ''
Say '  ================================================' 'Green'
Say '              설치가 끝났어요!' 'Green'
Say '  ================================================' 'Green'
Say ''
Say '  ▶ 다음부터는 바탕화면의 "내 투자 비서" 아이콘을 두 번 누르면 돼요.' 'White'
Say '  ▶ 앱을 끌 때는 앱 왼쪽 아래 [종료] 버튼을 누르세요.' 'White'
Say ''
if (-not $NoLaunch) {
    Say '  지금 앱을 엽니다… (인터넷 창이 열려요)'
    Start-Process -FilePath $PyW -ArgumentList ('"{0}" --open' -f $script) -WorkingDirectory $App
    Start-Sleep -Seconds 4
}
