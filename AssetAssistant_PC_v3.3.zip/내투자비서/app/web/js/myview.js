/* ==========================================================================
   myview.js — 📝 내 판단 기록 (v3.3)
   결정의 주인은 사용자. 종목 화면에서 '내 생각'(긍정·중립·부정 + 메모)을 남기면
   그때 가격을 기억했다가 1주·1달 뒤 실제 가격과 비교해 보여 줌. 매매 기록이 아님.
   ========================================================================== */
'use strict';

const MV_KEY = 'my_views_v1';
const MV_LAB = { pos: ['📈 긍정', 'up'], neu: ['➖ 중립', 'flat'], neg: ['📉 부정', 'down'] };
function myViews() { try { const v = JSON.parse(localStorage.getItem(MV_KEY) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
function myViewsSave(v) { try { localStorage.setItem(MV_KEY, JSON.stringify(v.slice(-300))); } catch (e) {} }
function myViewGrade() {                                // 1주·1달 지난 기록에 그때 가격 적기 (AI 기록과 같은 방식)
  const v = myViews(); let ch = false;
  v.forEach(r => {
    const age = Date.now() - r.at, now = trackNow(r.t); if (!now) return;
    if (age >= 7 * DAY && r.p7 == null) { r.p7 = now; ch = true; }
    if (age >= 30 * DAY && r.p30 == null) { r.p30 = now; ch = true; }
  });
  if (ch) myViewsSave(v);
  return v;
}
function myViewRes(r, k) {                              // 긍정이면 올랐을 때, 부정이면 내렸을 때, 중립이면 ±3% 안일 때 '내 생각대로'
  if (r[k] == null) return null;
  const ret = (r[k] / r.p - 1) * 100;
  return { ret, hit: r.v === 'neu' ? Math.abs(ret) <= 3 : r.v === 'pos' ? ret > 0.5 : ret < -0.5 };
}
function openMyView(it) {
  const t = String(it.ticker || '').toUpperCase(), p = num(it.cur) || trackNow(t);
  if (!t) { toast('종목 코드가 있어야 기록할 수 있어요'); return; }
  let pick = '';
  const past = myViewGrade().filter(r => r.t === t).slice(-5).reverse();
  const m = openModal({ title: '📝 내 생각 남기기 · ' + esc(it.name || t), body:
    '<p class="note" style="margin:0 0 10px">결정은 내가 해요. 지금 이 종목을 <b>어떻게 보는지</b> 남겨 두면, 1주·1달 뒤 실제 가격과 비교해 보여 줘요. (매매 기록이 아니에요)</p>' +
    '<div class="seg mv-seg" id="mvS">' + Object.entries(MV_LAB).map(([k, l]) => '<button data-v="' + k + '">' + l[0] + '</button>').join('') + '</div>' +
    '<div class="field" style="margin-top:10px"><label>메모 (왜 그렇게 보는지)</label><textarea class="input" id="mvM" rows="3" maxlength="200" placeholder="예: 실적은 좋은데 많이 올라서 부담"></textarea></div>' +
    '<p class="note">기준 가격: <b>' + (p > 0 ? esc(priceTxt(p, it.ccy || (/^[A-Za-z]/.test(t) ? 'USD' : 'KRW'))) : '시세를 아직 모름') + '</b></p>' +
    (past.length ? '<div class="ah-sub">이 종목에 남긴 내 생각</div>' + past.map(r => {
      const a = myViewRes(r, 'p30') || myViewRes(r, 'p7');
      return '<div class="trk-row"><div><b>' + MV_LAB[r.v][0] + '</b><span>' + esc(r.d.slice(5).replace('-', '/')) + (r.memo ? ' · ' + esc(r.memo) : '') + '</span></div><div class="trk-res">' +
        (a ? '<span class="' + (a.ret >= 0 ? 'up' : 'down') + '">' + (a.ret >= 0 ? '+' : '') + a.ret.toFixed(1) + '%</span> ' + (a.hit ? '✅' : '❌') : '<span class="muted">채점 대기</span>') + '</div></div>';
    }).join('') : ''),
    foot: '<button class="btn btn-gray" data-x>닫기</button><button class="btn btn-primary" data-ok disabled>기록하기</button>' });
  const ok = m.foot.querySelector('[data-ok]');
  m.body.querySelector('#mvS').onclick = e => { const b = e.target.closest('[data-v]'); if (!b) return; pick = b.dataset.v; m.body.querySelectorAll('#mvS button').forEach(x => x.classList.toggle('on', x === b)); ok.disabled = !(p > 0); };
  m.foot.querySelector('[data-x]').onclick = () => m.close();
  ok.onclick = () => {
    if (!pick || !(p > 0)) return;
    const v = myViews(); v.push({ t, n: it.name || t, at: Date.now(), d: todayKey(), p, v: pick, memo: m.body.querySelector('#mvM').value.trim().slice(0, 200) });
    myViewsSave(v); m.close(); toast('📝 기록했어요 — 1주 뒤부터 결과를 보여 줘요');
  };
}
function myViewCard() {
  const v = myViewGrade();
  const st = k => { const g = v.map(r => myViewRes(r, k)).filter(Boolean); return { n: g.length, hit: g.filter(x => x.hit).length }; };
  const s7 = st('p7'), s30 = st('p30');
  const pct = s => s.n ? '<b>' + Math.round(s.hit / s.n * 100) + '%</b><span>' + s.hit + '/' + s.n + '건 생각대로</span>' : '<b>-</b><span>채점 대기</span>';
  return '<div class="card"><div class="card-head"><h3>📝 내 판단 기록</h3><span class="muted" style="font-size:.78rem">' + v.length + '건 · 이 기기</span></div>' +
    (v.length ? '<div class="trk-sum"><div><small>1주 뒤</small>' + pct(s7) + '</div><div><small>1달 뒤</small>' + pct(s30) + '</div></div>' +
      v.slice(-5).reverse().map(r => { const a = myViewRes(r, 'p30') || myViewRes(r, 'p7');
        return '<div class="trk-row"><div><b>' + esc(r.n) + ' · ' + MV_LAB[r.v][0] + '</b><span>' + esc(r.d.slice(5).replace('-', '/')) + (r.memo ? ' · ' + esc(r.memo.slice(0, 30)) : '') + '</span></div><div class="trk-res">' +
          (a ? '<span class="' + (a.ret >= 0 ? 'up' : 'down') + '">' + (a.ret >= 0 ? '+' : '') + a.ret.toFixed(1) + '%</span> ' + (a.hit ? '✅' : '❌') : '<span class="muted">채점 대기</span>') + '</div></div>'; }).join('')
      : '<p class="note" style="margin:0">종목 화면의 <b>📝 내 생각 남기기</b>로 긍정·중립·부정을 기록해 보세요. 내 판단이 얼마나 맞는지 AI 추정과 나란히 볼 수 있어요.</p>') + '</div>';
}
