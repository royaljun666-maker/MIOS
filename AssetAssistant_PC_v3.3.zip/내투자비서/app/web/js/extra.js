/* ==========================================================================
   extra.js — 관심종목(즐겨찾기) · 뉴스·테마로 종목 찾기
   ========================================================================== */
'use strict';

/* 관심종목에 담긴 코드로 시세를 받아 가격·등락을 채움 */
let _watchBusy = false;
async function refreshWatchPrices(force) {
  const list = watchlist().filter(w => w.ticker);
  if (!list.length || _watchBusy) return;
  if (!force && list.every(w => w.cur && Date.now() - (w.at || 0) < 120000)) return;
  _watchBusy = true;
  try {
    const items = [...new Set(list.map(w => w.ticker + ':' + (w.market || 'kr')))].join(',');
    const data = await api('/prices?items=' + encodeURIComponent(items), { timeout: 60000 });
    list.forEach(w => {
      const d = data[w.ticker + ':' + (w.market || 'kr')];
      if (d && d.price > 0) {
        w.cur = d.price; w.at = Date.now();
        if (d.name && String(d.name).trim()) w.name = String(d.name).trim();
        if (d.change_pct != null && isFinite(d.change_pct)) w.chg = d.change_pct;
        storeFund(w, d);
      }
    });
    save({ noSync: true });
  } catch (e) { /* 서버 꺼짐 등 */ } finally { _watchBusy = false; }
}

function watchColor(w) { const n = dispName(w); return /^[A-Za-z]/.test(n) || w.market === 'us' ? 'var(--c2)' : 'var(--c1)'; }

PAGES.watch = function (params, isRe) {
  const el = pageEl('watch');
  const list = watchlist();
  // 다시 그릴 때 AI 발굴 결과·관심 뉴스는 그대로 둠 (시세 갱신·관심 담기 때 사라지지 않게)
  const keep = isRe ? ['watchNews'].map(id => document.getElementById(id)).filter(b => b && b.childNodes.length) : [];
  const st = TRADE_STYLES[tradeStyle()];
  const styleChips = '<div class="chips" style="margin-bottom:4px">' + Object.values(TRADE_STYLES).map(s =>
    '<button class="chip ' + (s.key === tradeStyle() ? 'on' : '') + '" data-act="set-style" data-v="' + s.key + '">' + s.emoji + ' ' + s.label + '</button>').join('') + '</div>';

  const cards = list.length ? list.map(w => {
    const chg = (w.chg != null && w.chgAt !== undefined) || w.chg != null ? w.chg : null;
    const per = (w.per != null && w.per !== '') ? 'PER ' + num(w.per).toFixed(1) : '';
    return '<div class="wl-card" data-act="watch-insight" data-t="' + esc(w.ticker) + '">' +
      '<div class="logo" style="background:' + watchColor(w) + '">' + esc(logoTxt(w)) + '</div>' +
      '<div class="mid"><b>' + esc(dispName(w)) + '</b><span>' + esc(w.ticker || '') + (w.market === 'us' ? ' · 미국' : '') + (per ? ' · ' + per : '') + '</span>' + paperBadge(w.ticker) + '</div>' +
      '<div class="end">' + (w.cur ? '<b>' + priceTxt(w.cur, w.ccy) + '</b>' : '<b class="muted">–</b>') +
        (chg != null ? '<span class="' + cls(chg) + '">' + pct(chg) + '</span>' : '<span class="muted">시세 갱신</span>') + '</div>' +
      '<button class="wl-x" data-act="watch-del" data-t="' + esc(w.ticker) + '" title="관심 삭제">' + icon('x', 'ic-sm') + '</button></div>';
  }).join('') : '';

  const aiOn = AI_STATUS && AI_STATUS.on;
  el.innerHTML =
    '<div class="page-head"><div><h1>관심종목</h1><div class="desc">안 가진 종목도 담아 두고 지켜보고, 포인트로 모의투자해요</div></div>' +
      '<div class="actions"><button class="btn btn-primary" data-act="watch-add">' + icon('plus') + '관심종목 추가</button></div></div>' +


    '<div class="card"><div class="card-head"><h3>' + icon('star', 'ic-sm') + '관심종목 <span class="muted" style="font-weight:600">' + list.length + '</span></h3>' +
      (list.length ? '<button class="btn btn-outline btn-sm" data-act="watch-refresh" data-refresh-btn>' + icon('refresh', 'ic-sm') + '시세 갱신</button>' : '') + '</div>' +
      (list.length ? '<div class="wl-list">' + cards + '</div>' +
        '<p class="note" style="margin:12px 2px 0">카드를 누르면 AI 정리(오를 이유·내릴 이유·지표 가격대)가 나와요.</p>' +
        '<div class="wl-acts"><button class="btn btn-soft" data-act="brief-watch">' + icon('clipboard') + '관심종목 AI 뉴스 브리핑</button>' +
        '<button class="btn btn-gray" data-act="watch-news">' + icon('news') + '관심종목 최신 뉴스</button></div>' +
        '<div id="watchNews"></div>'
      : '<div class="empty"><div class="ill">' + icon('star') + '</div><b>관심종목이 없어요</b><p>사고 싶은데 아직 안 산 종목, 지켜보는 종목을 담아 두세요. 위 <b>관심종목 추가</b>로 이름 검색해서 넣으면 돼요.</p>' +
        '<button class="btn btn-primary btn-lg" data-act="watch-add">' + icon('plus') + '관심종목 추가</button></div>') + '</div>' +
    (feat('paper') ? paperCardHtml() : '<div class="card pp-soon" style="margin-bottom:16px"><b>🎮 모의투자를 준비 중입니다</b><div class="pp-mypts">내 포인트 <b>💎 ' + nf(G().pts, 0) + 'P</b></div><p>곧 게임·출석으로 모은 <b>포인트로 관심종목을 사고파는 모의투자</b>가 열려요. 지금부터 포인트를 모아 두세요!</p>' + checkinBtnHtml('btn-sm') + ' <button class="btn btn-soft btn-sm" data-nav="game">💎 게임으로 모으기</button></div>');

  keep.forEach(old => { const nb = document.getElementById(old.id); if (nb) nb.replaceWith(old); });
  hydrateIcons(el); bindTips(el);
  if (!isRe && list.length) refreshWatchPrices(false).then(() => { if (route.page === 'watch') PAGES.watch({}, true); });
};

/* 🤖 AI 아이디어 발굴 카드 (v2.23 — AI 탭으로 옮김) */
function discoverCardHtml() {
  const aiOn = AI_STATUS && AI_STATUS.on;
  const styleChips = '<div class="chips" style="margin-bottom:4px">' + Object.values(TRADE_STYLES).map(s =>
    '<button class="chip ' + (s.key === tradeStyle() ? 'on' : '') + '" data-act="set-style" data-v="' + s.key + '">' + s.emoji + ' ' + s.label + '</button>').join('') + '</div>';
  return '<div class="card" style="margin-bottom:16px"><div class="card-head"><h3>' + icon('radar', 'ic-sm') + '뉴스·테마로 종목 찾기</h3>' +
      '<span class="badge ' + (aiOn ? 'green' : 'orange') + '">' + (aiOn ? 'AI 연결됨' : 'AI 연결 전') + '</span></div>' +
      '<p class="note" style="margin:0 0 12px">🤖 <b>뉴스·테마·관심 섹터</b>로 아직 몰랐던 종목 아이디어를 찾아요. 대형주 목록 밖 중소형주도 나와요. ' +
        '받은 아이디어는 <b>[📐 숫자로 검증]</b>으로 차트 조건까지 확인할 수 있어요. <b>참고용</b>이에요 — 사는 건 직접 판단하세요.' +
        '<br><span class="muted">내가 정한 숫자 조건으로 거르고 싶으면 → <a class="lnk" data-nav="quant">퀀트의 조건 검색기</a></span></p>' +
      '<div style="font-size:.84rem;color:var(--text-3);font-weight:650;margin-bottom:6px">내 투자 성향 (분석에 반영돼요)</div>' + styleChips +
      '<div class="sec-line"><div><span>🎯 관심 섹터 <em>(이 섹터 중점으로 찾기)</em></span><b>' + esc(sectorText(4)) + '</b></div>' +
        '<button class="btn btn-ghost btn-sm" data-act="pick-sectors">' + icon('pencil', 'ic-sm') + '바꾸기</button></div>' +
      '<button class="btn btn-soft btn-block" style="margin-top:12px" data-act="discover">' + icon('sparkles') + (aiOn ? 'AI로 뉴스·테마 종목 찾기' : '먼저 AI를 연결해 주세요') + '</button>' +
      '<div id="discoverBox"></div></div>';
}

/* 관심종목 추가 — 이름으로 검색 */
function openAddWatch() {
  const m = openModal({ title: '관심종목 추가', size: 'wide',
    body: '<div class="input-wrap"><span class="prefix-ic">' + icon('search') + '</span><input class="input lg" id="wq" placeholder="종목 이름이나 코드 (예: 삼성전자, 엔비디아)" autocomplete="off"></div>' +
      '<div class="chips" style="margin-top:12px" id="wqp">' + ['삼성전자', 'SK하이닉스', '엔비디아', '테슬라', '애플', 'TIGER 미국S&P500'].map(q => '<button class="chip" data-q="' + esc(q) + '">' + esc(q) + '</button>').join('') + '</div>' +
      '<div class="sr" id="wsr"><div class="sr-empty">한글로 검색해도 돼요. 미국 주식도 “엔비디아”처럼 찾을 수 있어요.</div></div>' });
  const q = m.body.querySelector('#wq'), sr = m.body.querySelector('#wsr');
  let seq = 0;
  const run = debounce(async () => {
    const my = ++seq, v = q.value.trim();
    if (!v) { sr.innerHTML = '<div class="sr-empty">종목 이름을 입력하세요.</div>'; return; }
    sr.innerHTML = '<div class="sr-empty">찾는 중…</div>';
    try {
      const r = await api('/api/search?q=' + encodeURIComponent(v), { timeout: 12000 });
      if (my !== seq) return;
      if (!r || !r.length) { sr.innerHTML = '<div class="sr-empty">결과가 없어요. 이름을 바꿔 보세요.</div>'; return; }
      sr.innerHTML = r.map(x => {
        const has = inWatch(x.ticker, x.ccy);
        return '<button data-add="' + esc(JSON.stringify(x)) + '" ' + (has ? 'disabled' : '') + '><div class="logo" style="background:' + (x.market === 'us' ? 'var(--c2)' : 'var(--c1)') + '">' + esc(x.market === 'us' ? x.ticker.slice(0, 2) : x.name.slice(0, 1)) + '</div>' +
          '<div class="mid"><b>' + esc(x.name) + '</b><span>' + esc(x.ticker) + ' · ' + esc(x.exchange || '') + '</span></div>' +
          (has ? '<span class="badge gray">담김</span>' : '<span class="badge blue">＋ 담기</span>') + '</button>';
      }).join('');
    } catch (e) { if (my === seq) sr.innerHTML = '<div class="sr-empty">' + SERVER_DOWN + '</div>'; }
  }, 260);
  q.addEventListener('input', run);
  m.body.querySelector('#wqp').addEventListener('click', e => { const b = e.target.closest('[data-q]'); if (b) { q.value = b.dataset.q; run(); q.focus(); } });
  sr.addEventListener('click', e => {
    const b = e.target.closest('[data-add]'); if (!b) return;
    const x = JSON.parse(b.dataset.add);
    addToWatch(x);
    b.disabled = true; b.querySelector('.badge').outerHTML = '<span class="badge green">' + icon('check', 'ic-sm') + '담김</span>'; hydrateIcons(b);
    toast('“' + x.name + '”을(를) 관심종목에 담았어요');
  });
  setTimeout(() => q.focus(), 250);
}
function addToWatch(x) {
  if (inWatch(x.ticker, x.ccy)) return;
  watchlist().push({ ticker: x.ticker, name: x.name, market: x.market, ccy: x.ccy || (x.market === 'us' ? 'USD' : 'KRW'), exch: x.exchange || '', at: 0 });
  save();
  if (route.page === 'watch') { refreshWatchPrices(true).then(() => { if (route.page === 'watch') PAGES.watch({}, true); }); PAGES.watch({}, true); }
}
function delWatch(ticker) {
  const p = P(); p.watch = watchlist().filter(w => (w.ticker || '').toUpperCase() !== String(ticker).toUpperCase());
  save(); PAGES.watch({}, true);
}

/* 관심종목 AI 분석 — openInsight 와 같은 화면, 계좌 없이 */
function watchInsight(ticker) {
  const w = watchlist().find(x => (x.ticker || '').toUpperCase() === String(ticker).toUpperCase()); if (!w) return;
  if (!(AI_STATUS && AI_STATUS.on)) { needAI(() => watchInsight(ticker)); return; }
  const m = openAiModal('AI 분석 — ' + esc(dispName(w)), 'AI가 최근 뉴스와 숫자로 <b>오를 수 있는 이유와 내릴 수 있는 이유</b>를 정리했어요. 확률은 추정이에요.', '최근 뉴스와 실적을 모으고 있어요…');
  const q = { ticker: w.ticker || '', market: w.market || 'kr', name: w.name || '', price: w.cur || '', per: w.per || '', pbr: w.pbr || '',
    forward_per: w.fper || '', asof: w.asof || '', peg: w.peg || '', roe: w.roe || '', op_income: w.opIncome || '', op_margin: w.opMargin || '',
    market_cap: w.marketCap || '', eps: w.eps || '', mcap_ccy: w.mcapCcy || '', style: tradeStyle() };
  const past = trackPast(w.ticker || ''); if (past) q.past = past;
  const qs = Object.keys(q).map(k => k + '=' + encodeURIComponent(q[k])).join('&');
  api('/insight?' + qs, { timeout: 150000 })
    .then(d => { if (d && (d.status === 'ok' || d.status === 'ok_text')) aiTrackLog({ ticker: w.ticker, name: dispName(w), price: w.cur }, d.text); return d; })
    .then(d => aiFill(m, d, x => renderAiText(x.text, levelsCard(x.levels)) + '<button class="btn btn-outline btn-block" style="margin-top:8px" data-act="my-view" data-p="' + esc(JSON.stringify({ ticker: w.ticker, name: dispName(w), cur: w.cur, ccy: w.ccy })) + '">📝 이 종목에 대한 내 생각 남기기</button>', d && d.headline_count != null ? '뉴스 ' + d.headline_count + '건' : ''))
    .catch(() => aiFill(m, { status: 'fail', text: SERVER_DOWN }));
}

/* AI 종목 발굴 */
function openDiscover() {
  if (!(AI_STATUS && AI_STATUS.on)) { needAI(openDiscover); return; }
  const box = document.getElementById('discoverBox');
  if (box) box.innerHTML = '<div class="ai-loading" style="padding:30px 10px"><div class="orb"></div><div>요즘 시장을 살펴 새 종목을 찾는 중이에요…<br><span style="font-size:.8rem">20~40초 걸려요</span></div></div>';
  const have = [];
  allHoldings().forEach(x => { const n = dispName(x.h); if (n) have.push(n + (x.h.ticker ? '(' + x.h.ticker + ')' : '')); });
  watchlist().forEach(w => { const n = dispName(w); if (n) have.push(n + (w.ticker ? '(' + w.ticker + ')' : '')); });
  // 다른 성향에서 이미 나온 종목은 빼 달라고 함 → 성향끼리 겹치지 않게
  let hist = {}; try { hist = JSON.parse(localStorage.getItem('disc_hist_v1') || '{}'); } catch (e) {}
  const avoid = [...new Set(Object.keys(hist).filter(k => k !== tradeStyle()).flatMap(k => hist[k] || []))];
  api('/discover', { method: 'POST', body: { have: have.join(', '), style: tradeStyle(), avoid, sectors: sectors() }, timeout: 180000 })
    .then(d => {
      if (d && d.items && d.items.length) {
        hist[tradeStyle()] = d.items.map(x => (x.name || '') + (x.ticker ? '(' + x.ticker + ')' : '')).slice(0, 8);
        try { localStorage.setItem('disc_hist_v1', JSON.stringify(hist)); } catch (e) {}
      }
      if (!box) return;
      if (d && d.status === 'no_key') { box.innerHTML = '<div class="callout warn" style="margin-top:12px">' + icon('key', 'ic-sm') + 'AI를 먼저 연결해 주세요.</div>'; return; }
      if (!d || (d.status !== 'ok' && d.status !== 'ok_text') || (!d.items && !d.text)) {
        box.innerHTML = '<div class="callout warn" style="margin-top:12px">' + icon('alert', 'ic-sm') + '결과를 받지 못했어요. 잠시 후 다시 해 주세요.</div>'; return;
      }
      if (!d.items) { box.innerHTML = '<div class="ai-sec" style="margin-top:12px"><div class="ln plain">' + mdInline(d.text) + '</div></div>'; return; }
      window._lastDisc = d;
      box.innerHTML = renderDiscover(d);
      hydrateIcons(box); bindTips(box);
      wireDiscVerify(box, d.items);
    })
    .catch(() => { if (box) box.innerHTML = '<div class="callout warn" style="margin-top:12px">' + icon('alert', 'ic-sm') + SERVER_DOWN + '</div>'; });
}
function renderDiscover(d) {
  const st = TRADE_STYLES[tradeStyle()];
  let html = '<div class="disc-meta">' + icon('sparkles', 'ic-sm') + esc(d.provider || '') + (d.model ? ' · ' + esc(d.model) : '') + ' · ' + st.emoji + st.label + ' 기준' + (sectors().length ? ' · 🎯 ' + esc(sectors().map(k => SECTOR_MAP[k].label).join('·')) + ' 중점' : '') + '</div>';
  html += d.items.map(it => {
    const up = Math.max(10, Math.min(90, parseInt(it.up, 10) || 55));
    const row = (k, lab, v) => v ? '<div class="disc-row ' + k + '"><b>' + lab + '</b><span>' + mdInline(v) + '</span></div>' : '';
    const mk = (it.market === 'us' || /^[A-Za-z]/.test(it.ticker || '')) ? 'us' : 'kr';
    const has = inWatch(it.ticker, mk === 'us' ? 'USD' : 'KRW');
    const payload = esc(JSON.stringify({ ticker: it.ticker, name: it.name, market: mk, ccy: mk === 'us' ? 'USD' : 'KRW' }));
    return '<div class="disc-card" data-tk="' + esc(String(it.ticker || '').toUpperCase()) + '">' +
      '<div class="disc-top"><div class="logo" style="background:' + (mk === 'us' ? 'var(--c2)' : 'var(--c1)') + '">' + esc((mk === 'us' ? (it.ticker || it.name).slice(0, 2) : (it.name || '').slice(0, 1))) + '</div>' +
        '<div style="flex:1;min-width:0"><b>' + esc(it.name || '') + '</b><span class="disc-tk">' + esc(it.ticker || '') + (it.theme ? ' · <span class="disc-theme">#' + esc(it.theme) + '</span>' : '') + '</span></div>' +
        '<div class="disc-up ' + (up >= 50 ? 'up' : 'down') + '" title="상승 가능성 추정">추정 ' + up + '%</div></div>' +
      (it.price_now ? '<div class="disc-price">✅ 실제 현재가 <b>' + esc(priceTxt(it.price_now, it.price_ccy === 'USD' ? 'USD' : 'KRW')) + '</b>' +
          (it.price_chg != null ? ' <span class="' + cls(it.price_chg) + '">' + pct(it.price_chg) + '</span>' : '') + ' <em>· ' + esc(String(it.price_at || '').slice(5, 16)) + ' 확인</em></div>'
        : (it.price_now === null ? '<div class="disc-price warn">⚠ 앱에서 시세를 확인하지 못했어요 — 종목 이름·코드가 맞는지 꼭 확인하세요</div>' : '')) +
      (it.why ? '<div class="disc-why">' + mdInline(it.why) + '</div>' : '') +
      row('fit', st.emoji + ' ' + st.label + '에 맞는 이유', it.fit) + row('cat', '재료', it.catalyst) + row('ent', '함께 볼 것', it.entry) + row('rsk', '위험', it.risk) +
      '<div class="disc-acts">' +
        '<button class="btn btn-soft btn-sm" data-act="disc-insight" data-p="' + payload + '">' + icon('sparkles', 'ic-sm') + '자세히 보기</button>' +
        '<button class="btn btn-outline btn-sm" data-act="disc-watch" data-p="' + payload + '" ' + (has ? 'disabled' : '') + '>' + icon(has ? 'check' : 'star', 'ic-sm') + (has ? '관심 담김' : '관심 담기') + '</button>' +
        '</div></div>';
  }).join('');
  html += '<button class="btn btn-outline btn-block" style="margin-top:12px" data-verify>📐 숫자로 검증 — 이 아이디어들, 차트 조건도 맞을까?</button>';
  html += '<p class="note" style="margin:12px 2px 0">뉴스·테마에 자주 나온 종목을 AI가 정리한 <b>검색 결과</b>예요. 투자 권유·종목 추천이 아니에요 — 직접 확인하고 판단하세요.</p>';
  return html;
}
/* AI 아이디어 → 퀀트 엔진으로 숫자 검증 (같은 일봉 규칙으로 판정, AI 안 씀) */
function wireDiscVerify(box, items) {
  const b = box.querySelector('[data-verify]'); if (!b) return;
  b.onclick = () => {
    b.disabled = true; b.textContent = '📐 일봉 데이터로 계산하는 중…';
    const list = items.filter(it => it.ticker).map(it => ({ ticker: String(it.ticker).toUpperCase(), name: it.name, market: (it.market === 'us' || /^[A-Za-z]/.test(it.ticker)) ? 'us' : 'kr' }));
    api('/api/quant/signals', { method: 'POST', body: { items: list, style: tradeStyle() }, timeout: 120000 }).then(d => {
      if (!box.isConnected) return;
      let good = 0;
      (d.items || []).forEach(g => {
        const card = box.querySelector('.disc-card[data-tk="' + String(g.ticker).toUpperCase().replace(/"/g, '') + '"]'); if (!card) return;
        const tone = /^상승 조건 (모두 )?충족/.test(g.verdict) ? 'up' : /하락|과열/.test(g.verdict) ? 'down' : 'flat';
        if (tone === 'up') good++;
        const el = document.createElement('div'); el.className = 'disc-qv ' + tone;
        el.innerHTML = '<b>📐 전략 규칙으로 보면: ' + esc(g.verdict) + '</b>' +
          (g.conds ? '<div class="qc-hits">' + g.conds.map(c => '<span class="' + (c.ok ? 'ok' : 'no') + '">' + (c.ok ? '✓ ' : '✗ ') + esc(c.t) + '</span>').join('') + '</div>' : g.why ? '<span>' + esc(g.why.join(' · ')) + '</span>' : '') +
          (g.basis ? '<em>' + esc(g.basis) + ' · AI 정리와 다를 수 있어요</em>' : '');
        const old = card.querySelector('.disc-qv'); if (old) old.remove();
        card.querySelector('.disc-top').after(el);
      });
      b.textContent = '📐 검증 완료 — ' + list.length + '개 중 ' + good + '개가 차트 조건까지 충족';
    }).catch(() => { b.disabled = false; b.textContent = '📐 숫자로 검증 (다시 시도)'; toast(SERVER_DOWN); });
  };
}
/* 발굴 결과의 종목을 임시로 관심에 담아 AI 분석 */
function discInsight(p) {
  const x = JSON.parse(p);
  if (!inWatch(x.ticker, x.ccy)) { watchlist().push(Object.assign({ at: 0, _tmp: true }, x)); }
  watchInsight(x.ticker);
  // 임시로 담은 건 분석만 하고 목록엔 남기지 않음 (사용자가 '관심 담기'를 눌러야 저장)
  const p2 = P(); p2.watch = watchlist().filter(w => !w._tmp);
}

/* ==========================================================================
   배경음 — 코드로 만드는 아주 잔잔한 패드(음악 파일 없음). 기본 꺼짐.
   브라우저 규칙상 사용자가 화면을 한 번 누른 뒤에만 소리가 납니다.
   ========================================================================== */
const Ambient = (function () {
  let ctx = null, master = null, timer = null, on = false;
  const NOTES = [196.00, 246.94, 293.66, 392.00, 440.00];  // 잔잔한 5음 (G, B, D, G, A)
  function ensure() {
    if (ctx) return true;
    try {
      const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return false;
      ctx = new AC();
      master = ctx.createGain(); master.gain.value = 0.05; master.connect(ctx.destination);  // 아주 작게
      return true;
    } catch (e) { return false; }
  }
  function voice() {
    if (!ctx || ctx.state !== 'running') return;
    const now = ctx.currentTime;
    const f = NOTES[Math.floor(Math.random() * NOTES.length)] * (Math.random() < 0.3 ? 2 : 1);
    const osc = ctx.createOscillator(), g = ctx.createGain();
    osc.type = 'sine'; osc.frequency.value = f;
    const dur = 4 + Math.random() * 4;
    g.gain.setValueAtTime(0, now);
    g.gain.linearRampToValueAtTime(0.5, now + dur * 0.4);
    g.gain.linearRampToValueAtTime(0, now + dur);
    osc.connect(g); g.connect(master);
    osc.start(now); osc.stop(now + dur + 0.1);
  }
  function loop() { if (on) { voice(); timer = setTimeout(loop, 2600 + Math.random() * 2600); } }
  return {
    start() {
      if (on || !ensure()) return;
      if (ctx.state === 'suspended') ctx.resume();
      on = true; loop();
    },
    stop() { on = false; clearTimeout(timer); if (master && ctx) { try { master.gain.setTargetAtTime(0, ctx.currentTime, 0.3); } catch (e) {} setTimeout(() => { if (!on && master) master.gain.value = 0.05; }, 600); } },
    get on() { return on; },
  };
})();
window.Ambient = Ambient;

/* 경쾌한 배경음 — 118 BPM, C–G–Am–F 진행. 킥·하이햇·베이스·화음·아르페지오 멜로디 (파일 없이 코드로 연주) */
const Upbeat = (function () {
  let ctx = null, master = null, on = false, timer = null, next = 0, step = 0, noise = null;
  const BPM = 118, S16 = 60 / BPM / 4;
  const CH = [[261.63, 329.63, 392.00], [196.00, 246.94, 293.66], [220.00, 261.63, 329.63], [174.61, 220.00, 261.63]]; // C G Am F
  const BASS = [65.41, 49.00, 55.00, 43.65];
  const ARP = [0, 1, 2, 1, 0, 2, 1, 2];
  function ensure() {
    if (ctx) return true;
    try {
      const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return false;
      ctx = new AC();
      master = ctx.createGain(); master.gain.value = 0.07; master.connect(ctx.destination);
      noise = ctx.createBuffer(1, ctx.sampleRate * 0.2, ctx.sampleRate);
      const d = noise.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      return true;
    } catch (e) { return false; }
  }
  function env(g, t, a, peak, dur) { g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(peak, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + dur); }
  function tone(type, f, t, dur, peak, a) {
    const o = ctx.createOscillator(), g = ctx.createGain(); o.type = type; o.frequency.value = f;
    env(g, t, a || 0.005, peak, dur); o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + 0.05);
  }
  function kick(t) {
    const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine';
    o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(45, t + 0.12);
    env(g, t, 0.003, 0.9, 0.22); o.connect(g); g.connect(master); o.start(t); o.stop(t + 0.25);
  }
  function hat(t, peak) {
    const src = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    src.buffer = noise; f.type = 'highpass'; f.frequency.value = 7000;
    env(g, t, 0.002, peak, 0.05); src.connect(f); f.connect(g); g.connect(master); src.start(t); src.stop(t + 0.06);
  }
  function play(i, t) {
    const bar = Math.floor(i / 16) % 4, s = i % 16, ch = CH[bar];
    if (s % 4 === 0) kick(t);
    if (s % 4 === 2) hat(t, 0.18); else if (s % 2 === 1) hat(t, 0.06);
    if (s === 0 || s === 6 || s === 8 || s === 14) tone('triangle', BASS[bar] * (s === 14 ? 2 : 1), t, S16 * 1.8, 0.5);
    if (s === 0 || s === 8) ch.forEach(f => tone('sine', f, t, S16 * 7, 0.08, 0.04));
    if (s % 2 === 0) tone('square', ch[ARP[(s / 2) % 8]] * 2, t, S16 * 0.9, 0.05);           // 통통 튀는 아르페지오
    if (bar === 3 && s >= 12 && s % 1 === 0) tone('triangle', ch[(s - 12) % 3] * 4, t, S16 * 0.8, 0.04);  // 마디 끝 꾸밈음
  }
  function sched() {
    if (!on) return;
    while (next < ctx.currentTime + 0.15) { play(step++, next); next += S16; }
    timer = setTimeout(sched, 30);
  }
  return {
    start() {
      if (on || !ensure()) return;
      if (ctx.state === 'suspended') ctx.resume();
      master.gain.cancelScheduledValues(ctx.currentTime); master.gain.setValueAtTime(0.07, ctx.currentTime);
      on = true; step = 0; next = ctx.currentTime + 0.05; sched();
    },
    stop() { on = false; clearTimeout(timer); if (master && ctx) { try { master.gain.setTargetAtTime(0.0001, ctx.currentTime, 0.2); } catch (e) {} } },
    get on() { return on; },
  };
})();
window.Upbeat = Upbeat;

/* 배경음 고르기: off(끄기) · calm(잔잔하게) · upbeat(경쾌하게). 예전 설정(켜짐)은 '잔잔하게' */
function soundMode() { return UI.soundMode || (UI.sound ? 'calm' : 'off'); }
function setSound(mode) {
  UI.soundMode = mode; UI.sound = mode !== 'off'; saveUI();
  Ambient.stop(); Upbeat.stop();
  if (mode === 'calm') Ambient.start(); else if (mode === 'upbeat') Upbeat.start();
}

// 사용자가 처음 화면을 누르면, 켜 둔 경우 배경음 시작
document.addEventListener('pointerdown', function _once() {
  const m = soundMode();
  if (m === 'calm') Ambient.start(); else if (m === 'upbeat') Upbeat.start();
  document.removeEventListener('pointerdown', _once);
}, { once: true });

/* 관심종목 최신 뉴스 — 종목마다 최근 뉴스 몇 개씩 */
async function loadWatchNews() {
  const box = document.getElementById('watchNews'); if (!box) return;
  const list = watchlist().filter(w => w.ticker || w.name).slice(0, 12);
  box.innerHTML = '<div class="wn-loading">' + icon('news') + ' 관심종목 ' + list.length + '개의 뉴스를 모으는 중…</div>';
  hydrateIcons(box);
  const res = await Promise.all(list.map(w => api('/news?ticker=' + encodeURIComponent(w.ticker || '') + '&market=' + (w.market || 'kr') + '&name=' + encodeURIComponent(w.name || ''), { timeout: 25000 })
    .then(arr => ({ w, arr: Array.isArray(arr) ? arr.slice(0, 4) : [] })).catch(() => ({ w, arr: [] }))));
  if (!document.getElementById('watchNews')) return;
  box.innerHTML = res.map(({ w, arr }) =>
    '<div class="wn-group"><div class="wn-h"><b>' + esc(dispName(w)) + '</b>' + (w.chg != null ? '<span class="' + cls(w.chg) + '">' + pct(w.chg) + '</span>' : '') +
      '<button class="btn btn-soft btn-sm" data-act="watch-insight" data-t="' + esc(w.ticker) + '">' + icon('sparkles', 'ic-sm') + 'AI 영향 분석</button>' +
      (w.ticker ? '<button class="btn btn-gray btn-sm" data-act="ai-chart" data-t="' + esc(w.ticker) + '" data-m="' + (w.market || 'kr') + '" data-n="' + esc(dispName(w)) + '">' + icon('activity', 'ic-sm') + '차트</button>' : '') + '</div>' +
    (arr.length ? '<div class="headlines">' + newsListHtml(arr) + '</div>' : '<p class="note" style="margin:6px 2px">최근 7일 뉴스가 없어요.</p>') + '</div>').join('') +
    '<p class="note" style="margin-top:10px">뉴스가 주가에 어떤 영향을 줄지는 <b>AI 영향 분석</b>이나 <b>관심종목 AI 뉴스 브리핑</b>에서 볼 수 있어요.</p>';
  hydrateIcons(box);
}

/* ── ☕ 개발자 후원하기 — 토스 송금 링크로 연결. 후원해도 앱 기능·포인트는 똑같음(대가 없음) ── */
// tossId: toss.me/○○○ 의 ○○○ — 관리 파일(update.json)의 "support": {"toss": "○○○"} 로 원격 설정
const SUPPORT = { tossId: (() => { try { return localStorage.getItem('support_toss') || ''; } catch (e) { return ''; } })(), amounts: [1000, 2000, 5000] };
function setSupportId(id) { id = String(id || '').trim().replace(/^https?:\/\/toss\.me\//, '').replace(/\/.*$/, ''); SUPPORT.tossId = id; try { localStorage.setItem('support_toss', id); } catch (e) {} }
function supportUrl(amount) { return 'https://toss.me/' + encodeURIComponent(SUPPORT.tossId) + (amount ? '/' + Math.round(amount) : ''); }
function openSupport() {
  const toss = !!SUPPORT.tossId, kakao = !!REMOTE.kakao;
  let amt = SUPPORT.amounts[0];
  const m = openModal({ title: '☕ 개발자 후원하기', body:
    '<p style="margin:0 0 6px;line-height:1.65;color:var(--text-2)">이 앱이 도움이 됐다면 커피 한 잔 값으로 응원해 주세요. 더 좋은 기능을 만드는 데 큰 힘이 돼요 🙏</p>' +
    '<div class="sp-hint">💡 예시 금액: <b>1천원 · 2천원 · 5천원</b> (원하는 만큼 자유롭게)</div>' +
    (toss ? '<div class="as-h" style="margin-top:14px">토스 후원 금액</div><div class="sp-amts">' + SUPPORT.amounts.map((a, i) => '<button class="sp-amt' + (i ? '' : ' on') + '" data-amt="' + a + '">' + (a / 1000) + '천원</button>').join('') +
      '<button class="sp-amt" data-amt="etc">직접 입력</button></div>' +
      '<div class="sp-etc" id="spEtc" hidden><div class="input-wrap"><input class="input tnum" id="spInput" inputmode="numeric" placeholder="금액"><span class="suffix">원</span></div></div>' : '') +
    '<div class="callout gray" style="margin-top:14px">' + icon('info', 'ic-sm') + '<div>후원은 <b>자유</b>예요. 후원해도 <b>앱 기능·포인트·게임에는 아무 차이가 없어요</b>. 송금한 뒤에는 환불이 어려워요.</div></div>',
    foot: '<div class="sp-foot">' +
      '<div class="sp-way">' + (kakao ? '<button class="btn btn-lg btn-block sp-kakao" id="spKakao">💛 카카오페이로 후원하기</button><small>카카오페이 송금 화면이 열려요 → 금액을 넣고 보내면 끝!</small>'
        : '<button class="btn btn-gray btn-lg btn-block" disabled>💛 카카오페이로 후원하기 · 준비 중</button>') + '</div>' +
      '<div class="sp-way">' + (toss ? '<button class="btn btn-lg btn-block sp-toss" id="spGo">💙 토스로 후원하기</button><small>위에서 고른 금액으로 토스 송금 화면이 열려요</small>'
        : '<button class="btn btn-gray btn-lg btn-block" disabled>💙 토스로 후원하기 · 준비 중</button>') + '</div></div>' });
  const etc = m.body.querySelector('#spEtc'), inp = m.body.querySelector('#spInput');
  m.body.querySelectorAll('.sp-amt').forEach(b => b.onclick = () => {
    m.body.querySelectorAll('.sp-amt').forEach(x => x.classList.toggle('on', x === b));
    if (b.dataset.amt === 'etc') { amt = 0; etc.hidden = false; inp.focus(); } else { amt = +b.dataset.amt; etc.hidden = true; }
  });
  const kk = m.foot.querySelector('#spKakao'); if (kk) kk.onclick = () => { openExt(REMOTE.kakao); m.close(); setTimeout(() => toast('고마워요! 💛', 2500), 600); };
  const go = m.foot.querySelector('#spGo'); if (go) go.onclick = () => {
    const v = amt || Math.round(num(inp.value));
    if (!(v >= 100)) { toast('100원 이상으로 입력해 주세요'); return; }
    openExt(supportUrl(v));
    m.close(); setTimeout(() => toast('고마워요! 💙', 2500), 600);
  };
}
