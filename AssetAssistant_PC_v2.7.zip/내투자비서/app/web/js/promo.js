/* ==========================================================================
   promo.js — 💰 수익 장치 (전부 관리 파일 update.json 으로 원격 설정 → 앱을 다시 만들 필요 없음)
   · 광고·제휴 자리  "promo": [{ "id": "p1", "title": "…", "desc": "…", "url": "https://…", "cta": "자세히",
                               "where": ["home", "more"], "emoji": "📚", "from": "2026-10-20", "until": "2026-12-31", "label": "광고" }]
     - 화면에 '광고'(또는 label) 표시가 꼭 붙어요 (표시광고법). 닫으면 그 광고는 7일 동안 안 보임
   · 후원  "support": { "toss": "토스아이디", "kakao": "https://qr.kakaopay.com/…" }   (extra.js 의 SUPPORT)
   · 친구에게 추천  "share": { "url": "…", "text": "…" }  (없으면 배포 페이지)
   · 후원·추천 안내: 앱을 5일 넘게 쓴 사람에게 2주에 한 번, 홈 화면에서만 조용히 (다시 보지 않기 가능)
   ========================================================================== */
'use strict';

const REMOTE = (() => { try { return JSON.parse(localStorage.getItem('remote_cfg') || '{}') || {}; } catch (e) { return {}; } })();
const SHARE_DEFAULT = { url: 'https://github.com/royaljun666-maker/MIOS',
  text: '내 주식 계좌를 한눈에 보고, 무료 AI가 내 종목 뉴스 영향까지 정리해 주는 앱 「내 투자 비서」 써 보세요!' };

function _httpsUrl(u) { u = String(u || '').trim(); return /^https?:\/\/[^\s"'<>]+$/i.test(u) ? u : ''; }
function okPromo(p) {
  if (!p || typeof p !== 'object' || !p.id || !p.title || !_httpsUrl(p.url)) return false;
  const t = todayKey();
  return !(p.from && String(p.from) > t) && !(p.until && String(p.until) < t);
}
/* 관리 파일 내용 반영 (update.js 의 checkUpdate 에서 부름) */
function setRemote(d) {
  if (!d || d.status !== 'ok') return;
  REMOTE.promo = Array.isArray(d.promo) ? d.promo.filter(p => p && typeof p === 'object').slice(0, 6) : [];
  REMOTE.share = d.share && typeof d.share === 'object' ? { url: _httpsUrl(d.share.url), text: String(d.share.text || '').slice(0, 300) } : {};
  REMOTE.kakao = _httpsUrl(d.support && d.support.kakao);
  try { localStorage.setItem('remote_cfg', JSON.stringify(REMOTE)); } catch (e) {}
  if (route && (route.page === 'home')) { const box = document.getElementById('promo-home'); if (box) box.outerHTML = promoSlot('home'); }
}
function _promoHidden() { try { return JSON.parse(localStorage.getItem('promo_hide') || '{}'); } catch (e) { return {}; } }
function activePromo(where) {
  const hide = _promoHidden(), now = Date.now();
  return (REMOTE.promo || []).filter(okPromo).find(p => (!Array.isArray(p.where) || p.where.includes(where)) && !(hide[p.id] && hide[p.id] > now)) || null;
}
/* 광고·제휴 카드 (없으면 빈 자리) */
function promoSlot(where) {
  const p = activePromo(where);
  if (!p) return '<div id="promo-' + where + '" hidden></div>';
  return '<div class="card span-12 promo" id="promo-' + where + '">' +
    '<span class="pr-badge">' + esc(String(p.label || '광고').slice(0, 6)) + '</span>' +
    (p.emoji ? '<span class="pr-emoji">' + esc(String(p.emoji).slice(0, 4)) + '</span>' : '') +
    '<div class="pr-body"><b>' + esc(String(p.title).slice(0, 60)) + '</b>' + (p.desc ? '<span>' + esc(String(p.desc).slice(0, 120)) + '</span>' : '') + '</div>' +
    '<button class="btn btn-soft btn-sm" data-act="promo-open" data-id="' + esc(p.id) + '">' + esc(String(p.cta || '보기').slice(0, 10)) + '</button>' +
    '<button class="pr-x" data-act="promo-x" data-id="' + esc(p.id) + '" aria-label="광고 닫기">✕</button></div>';
}
function promoOpen(id) {
  const p = (REMOTE.promo || []).find(x => x && x.id === id); if (!p) return;
  openExt(_httpsUrl(p.url));
}
function promoHide(id) {
  const h = _promoHidden(); h[id] = Date.now() + 7 * 864e5;
  try { localStorage.setItem('promo_hide', JSON.stringify(h)); } catch (e) {}
  document.querySelectorAll('.promo').forEach(el => { if (el.querySelector('[data-id="' + CSS.escape(id) + '"]')) el.outerHTML = '<div id="' + el.id + '" hidden></div>'; });
  toast('이 광고는 7일 동안 안 보여요');
}

/* 바깥 링크 열기 (폰 앱은 기본 브라우저로) */
function openExt(url) {
  if (!url) return;
  try { if (IS_APP) location.href = url; else window.open(url, '_blank', 'noopener'); } catch (e) { location.href = url; }
}
/* 복사 (폰 웹뷰에서 clipboard 가 막힐 때도 되게) */
function copyText(t) {
  const legacy = () => {
    const ta = document.createElement('textarea'); ta.value = t; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:-9999px;top:0';
    document.body.appendChild(ta); ta.select(); let ok = false; try { ok = document.execCommand('copy'); } catch (e) {} ta.remove(); return ok;
  };
  if (navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(t).then(() => true, () => legacy());
  return Promise.resolve(legacy());
}

/* 📣 친구에게 추천 */
function shareApp() {
  const s = { url: (REMOTE.share && REMOTE.share.url) || SHARE_DEFAULT.url, text: (REMOTE.share && REMOTE.share.text) || SHARE_DEFAULT.text };
  const full = s.text + '\n👉 ' + s.url;
  if (navigator.share && !IS_APP) { navigator.share({ title: '내 투자 비서', text: s.text, url: s.url }).catch(() => {}); return; }
  const m = openModal({ title: '📣 친구에게 추천하기', body:
    '<p style="margin:0 0 12px;color:var(--text-2);line-height:1.6">아래 글을 복사해서 <b>카카오톡·문자</b>에 붙여넣어 보내 주세요. 쓰는 사람이 많아질수록 앱이 더 좋아져요 🙏</p>' +
    '<div class="sh-box">' + esc(full).replace(/\n/g, '<br>') + '</div>',
    foot: '<button class="btn btn-primary btn-lg btn-block" id="shCopy">' + icon('copy') + '글 복사하기</button>' });
  m.foot.querySelector('#shCopy').onclick = () => copyText(full).then(ok => { toast(ok ? '복사했어요! 카카오톡에 붙여넣어 보내 주세요' : '길게 눌러 직접 복사해 주세요', 3000); if (ok) m.close(); });
}

/* 사용한 날 세기 + 가끔 조용한 후원·추천 안내 */
function usageTick() {
  const t = todayKey();
  if (UI.useDay !== t) { UI.useDay = t; UI.useDays = (UI.useDays || 0) + 1; saveUI(); }
}
function maybeNudge() {
  if (UI.nudgeOff || (UI.useDays || 0) < 5) return;
  if (UI.nudgeAt && Date.now() - UI.nudgeAt < 14 * 864e5) return;
  if (!route || route.page !== 'home' || (typeof _modals !== 'undefined' && _modals.length) || document.querySelector('.nudge')) return;
  UI.nudgeAt = Date.now(); saveUI();
  const canPay = !!(SUPPORT.tossId || REMOTE.kakao);
  const n = document.createElement('div'); n.className = 'nudge';
  n.innerHTML = '<button class="ng-x" aria-label="닫기">✕</button><b>내 투자 비서, 도움이 되고 있나요? 🙌</b>' +
    '<span>' + (UI.useDays || 0) + '일째 함께하고 있어요. ' + (canPay ? '커피 한 잔으로 응원하거나 ' : '') + '친구에게 알려 주시면 큰 힘이 돼요.</span>' +
    '<div class="ng-btns">' + (canPay ? '<button class="btn btn-primary btn-sm" data-ng="pay">☕ 후원하기</button>' : '') +
    '<button class="btn btn-soft btn-sm" data-ng="share">📣 친구에게 추천</button></div>' +
    '<button class="ng-off" data-ng="off">다시 보지 않기</button>';
  document.body.appendChild(n); requestAnimationFrame(() => n.classList.add('on'));
  const close = () => { n.classList.remove('on'); setTimeout(() => n.remove(), 300); };
  n.addEventListener('click', e => {
    if (e.target.closest('.ng-x')) return close();
    const b = e.target.closest('[data-ng]'); if (!b) return;
    if (b.dataset.ng === 'pay') openSupport();
    if (b.dataset.ng === 'share') shareApp();
    if (b.dataset.ng === 'off') { UI.nudgeOff = true; saveUI(); toast('다시 안 보여 드릴게요'); }
    close();
  });
  setTimeout(close, 20000);
}
