/* ==========================================================================
   core.js — 데이터 · 계산 · 서버 통신 · 공통 UI(팝업/알림/아이콘)
   ========================================================================== */
'use strict';

const KEY = 'portfolio_state_v5';       // 예전 앱과 같은 저장소(데이터 그대로 이어짐)
const UI_KEY = 'asset_ui_v1';
const MAXH = 50;                         // 계좌당 최대 종목 수
const LOW_PER = 10;
const POLICY = {
  conservative: { label: '안정형', desc: '잃지 않는 게 먼저', single: 15, top3: 40, defMin: 40, cashMin: 10, highPER: 25 },
  moderate:     { label: '균형형', desc: '수익과 안정의 균형', single: 20, top3: 50, defMin: 25, cashMin: 7,  highPER: 28 },
  aggressive:   { label: '성장형', desc: '높은 수익을 노림',   single: 25, top3: 60, defMin: 15, cashMin: 5,  highPER: 30 },
};
const CAT = ['--c1', '--c2', '--c3', '--c4', '--c5', '--c6', '--c7'];  // 차트 범주색(고정 순서)

/* ---------------- 상태 ---------------- */
let S = loadState();
let UI = loadUI();

function uid(p) { return p + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36); }

function loadState() {
  let s = null;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const o = JSON.parse(raw);
      if (o && o.people && o.people.length) s = { people: o.people, curPerson: o.curPerson, settings: o.settings || {}, savedAt: o.savedAt || 0 };
    }
    if (!s) {
      const v4 = localStorage.getItem('portfolio_state_v4');
      if (v4) {
        const q = JSON.parse(v4);
        s = { people: [{ id: uid('p'), name: q.owner || '나', accounts: q.accounts || [], history: q.history || [] }], settings: q.settings || {} };
      }
    }
    if (!s) {
      const v3 = localStorage.getItem('portfolio_state_v3');
      if (v3) {
        const p = JSON.parse(v3);
        const acc = { id: uid('a'), name: '내 계좌', cash: p.cash || '0', holdings: p.holdings || [] };
        const hist = (p.history || []).map(x => ({ date: x.date, totalAsset: x.totalAsset, totalCost: x.totalCost, totalPL: x.totalPL, totalRet: x.totalRet,
          accounts: [{ name: '내 계좌', val: x.totalAsset, weight: 100, pl: x.totalPL, ret: x.totalRet }] }));
        s = { people: [{ id: uid('p'), name: '나', accounts: [acc], history: hist }], settings: {} };
      }
    }
  } catch (e) { /* 깨진 데이터는 무시하고 새로 시작 */ }
  if (!s) s = { people: [{ id: uid('p'), name: '나', accounts: [], history: [] }], settings: {}, savedAt: 0, fresh: true };
  return normalizeState(s);
}

function normalizeState(s) {
  s.settings = s.settings || {};
  const d = { feeRate: '0.015', taxRate: '0.20', fxRate: '1400', policy: 'conservative', autoSnap: true, autoRefresh: true };
  for (const k in d) if (s.settings[k] == null) s.settings[k] = d[k];
  if (!s.people || !s.people.length) s.people = [{ id: uid('p'), name: '나', accounts: [], history: [] }];
  s.people.forEach(p => {
    p.accounts = p.accounts || []; p.history = p.history || [];
    p.accounts.forEach((a, i) => {
      a.holdings = a.holdings || []; if (a.cash == null) a.cash = '0';
      if (a.ci == null) a.ci = i;
      const used = new Set(a.holdings.filter(h => h.ci != null).map(h => h.ci));
      a.holdings.forEach(h => { if (h.ci == null) { h.ci = nextFree(used); used.add(h.ci); } });
    });
  });
  if (!s.curPerson || !s.people.some(p => p.id === s.curPerson)) s.curPerson = s.people[0].id;
  return s;
}
function nextFree(used) { for (let i = 0; i < CAT.length; i++) if (!used.has(i)) return i; return -1; }

let _syncTimer = null, _forceNext = false;
function save(opts) {
  S.savedAt = Date.now();
  delete S.fresh;
  if (opts && opts.force) _forceNext = true;   // '모두 지우기'처럼 일부러 비울 때만
  // 자동 기록이 켜져 있고 오늘 기록이 이미 있으면, 사고팔고 고친 내용을 오늘 기록에도 반영
  if (S.settings.autoSnap && typeof snapObj === 'function') {
    const h = P().history, i = h.findIndex(x => x.date === todayKey());
    if (i >= 0) { const o = snapObj(); if (o) h[i] = o; }
  }
  try { localStorage.setItem(KEY, JSON.stringify(serial())); } catch (e) { toast('브라우저 저장 공간이 가득 찼어요. 설정 → 데이터에서 백업해 주세요.'); }
  if (!(opts && opts.noSync)) { clearTimeout(_syncTimer); _syncTimer = setTimeout(pushServer, 1200); }
}
function serial() { return { people: S.people, curPerson: S.curPerson, settings: S.settings, savedAt: S.savedAt }; }

// 서버(이 PC의 userdata 폴더)에 자동 백업 — 브라우저 기록을 지워도 자산 데이터가 남도록
async function pushServer() {
  const force = _forceNext;
  try { await api('/api/data', { method: 'PUT', body: { state: serial(), force }, timeout: 8000 }); if (force) _forceNext = false; }
  catch (e) { /* 서버 꺼짐 등 — 다음 저장 때 재시도 */ }
}
async function pullServer() {
  try {
    const d = await api('/api/data', { timeout: 6000 });
    const sv = d && d.state;
    const hasServer = !!(sv && sv.people && sv.people.some(p => (p.accounts || []).length || (p.history || []).length));
    // 일부러 다 지운 경우(저장 시각 있음)는 '빈 데이터'로 보지 않음 → 지운 계좌가 서버 사본에서 되살아나지 않게
    const localEmpty = S.fresh || (!S.savedAt && !S.people.some(p => p.accounts.length || p.history.length));
    // 예전 앱에서 넘어온 데이터는 저장 시각(savedAt)이 없음 → 절대 서버 것으로 덮어쓰지 않고 이 데이터를 기준으로 삼음
    const legacyLocal = !localEmpty && !S.savedAt;
    const pull = hasServer && (localEmpty || (!legacyLocal && (sv.savedAt || 0) > (S.savedAt || 0)));
    if (pull) {
      // 덮어쓰기 전에 지금 브라우저 데이터를 따로 보관(혹시 모를 실수 대비)
      if (!localEmpty) { try { localStorage.setItem(KEY + '_before_sync', JSON.stringify(Object.assign({ keptAt: new Date().toISOString() }, serial()))); } catch (e) {} }
      S = normalizeState({ people: sv.people, curPerson: sv.curPerson, settings: sv.settings || {}, savedAt: sv.savedAt || 0 });
      try { localStorage.setItem(KEY, JSON.stringify(serial())); } catch (e) {}
      return 'pulled';
    }
    if (!localEmpty && (legacyLocal || !hasServer || (S.savedAt || 0) > (sv.savedAt || 0))) {
      if (legacyLocal) save({ noSync: true });   // 저장 시각을 붙여 이후부터 정상 동기화
      pushServer();
    }
  } catch (e) { /* 서버 없이 파일로 연 경우 등 */ }
  return 'kept';
}

function loadUI() {
  let u = {};
  try { u = JSON.parse(localStorage.getItem(UI_KEY) || '{}') || {}; } catch (e) {}
  return Object.assign({ theme: 'auto', fontScale: 'normal', onboarded: false, histRange: 'day', homeAlloc: 'type', lastRefresh: 0, tradeStyle: 'long', sound: false }, u);
}
// 🔑 새 기능 원격 스위치 — 관리 파일(update.json)의 features 에 이름이 있어야 보임 (하루 하나씩 공개)
let FEATURES = (() => { try { return new Set(JSON.parse(localStorage.getItem('features_v1') || '[]')); } catch (e) { return new Set(); } })();
function feat(k) { return FEATURES.has(k); }
function setFeatures(list) {
  if (!Array.isArray(list)) return;
  const was = [...FEATURES].join(','); FEATURES = new Set(list);
  try { localStorage.setItem('features_v1', JSON.stringify(list)); } catch (e) {}
  if (was !== list.join(',') && route && route.page && PAGES[route.page]) go(route.page, route.params, true);
}
function saveUI() { try { localStorage.setItem(UI_KEY, JSON.stringify(UI)); } catch (e) {} }

/* 투자 성향(매매 스타일) — 장기·스윙·단타. AI 조언을 이 성향에 맞춤 */
const TRADE_STYLES = {
  long:  { key: 'long',  label: '장기투자', emoji: '📈', hz: '앞으로 1년',     desc: '1년 이상 · 꾸준히 버는 회사와 싼 가격을 봄' },
  swing: { key: 'swing', label: '스윙매매', emoji: '🔁', hz: '앞으로 1~3개월', desc: '몇 주~3개월 · 실적 흐름·추세·거래량을 봄' },
  day:   { key: 'day',   label: '단타',     emoji: '⚡', hz: '앞으로 1주일',   desc: '하루~1주 · 뉴스 재료·수급·변동폭 중심' },
  scalp: { key: 'scalp', label: '스캘핑',   emoji: '⏱️', hz: '오늘~내일',      desc: '몇 분~하루 · 장중 재료 (시세 15~20분 지연, 분위기 참고용)' },
};
// 모든 AI 화면 맨 아래에 붙는 면책 문구
const DISCLAIMER = '⚠️ 이 앱은 투자 정보를 모아 정리·계산하는 도구이며, 투자자문·종목 추천·매매 권유를 하지 않습니다. 확률은 추정이라 틀릴 수 있고, 지표 가격은 과거 관측값이에요. 투자 판단과 그 결과(손실 포함)의 책임은 투자자 본인에게 있습니다.';
function disclaimerHtml() { return '<div class="ai-legal">' + DISCLAIMER + '</div>'; }
function tradeStyle() { return TRADE_STYLES[UI.tradeStyle] ? UI.tradeStyle : 'long'; }
// AI 설명 방식 — 내 주식 실력에 맞춰 답변의 길이·깊이·내용이 달라짐 (설치·업데이트 후 첫 실행 때 물어봄)
const AI_DEPTHS = {
  brief:   { key: 'brief',   label: '간략하게',     emoji: '⚡', desc: '바쁜 사람 · 핵심·확률·근거만 핵심 위주로' },
  easy:    { key: 'easy',    label: '쉽게',         emoji: '🙂', desc: '주식 초보 · 용어 풀이와 비유로 충분히 자세히' },
  serious: { key: 'serious', label: '진중하게',     emoji: '🧐', desc: '신중한 투자자 · 근거·반대 근거·시나리오·위험까지 깊게' },
  expert:  { key: 'expert',  label: '전문가처럼',   emoji: '📊', desc: '경험 많은 투자자 · 밸류에이션·수급·기술적 수치를 리포트처럼' },
  teacher: { key: 'teacher', label: '선생님처럼',   emoji: '👩‍🏫', desc: '배우고 싶은 사람 · 원리를 차근차근 + 오늘의 투자 공부' },
};
function aiDepth() { return AI_DEPTHS[UI.aiDepth] ? UI.aiDepth : 'easy'; }

/* 투자자 설문 — 나이·직업·목적·경험·위험 감내·투자 비중. AI 모든 답변의 맥락이 됨.
   키(영문)만 서버로 보냄 → 서버 ai_engine.PROFILE_TEXT 와 키가 같아야 함 */
const PROFILE_Q = [
  { k: 'age', q: '나이대가 어떻게 되세요?', o: [['20', '20대 이하'], ['30', '30대'], ['40', '40대'], ['50', '50대'], ['60', '60대 이상']] },
  { k: 'job', q: '하시는 일은요?', o: [['office', '💼 회사원'], ['biz', '🏪 자영업·사업'], ['pro', '⚖️ 전문직'], ['public', '🏛️ 공무원·교사'], ['free', '💻 프리랜서'], ['student', '🎓 학생'], ['home', '🏠 주부'], ['retired', '🌿 은퇴'], ['etc', '🙂 기타']] },
  { k: 'goal', q: '투자로 가장 이루고 싶은 건?', o: [['grow', '🚀 목돈을 크게 불리기'], ['retire', '🌅 노후·은퇴 준비'], ['house', '🏡 내 집 마련'], ['income', '💵 꾸준한 배당·용돈'], ['edu', '🎒 자녀 교육·결혼 자금'], ['keep', '🛡️ 물가 이기며 지키기'], ['short', '⚡ 짧게 빠른 수익']] },
  { k: 'exp', q: '주식 투자 경험은 얼마나 되세요?', o: [['0', '🌱 처음이에요'], ['1', '1년 미만'], ['3', '1~3년'], ['5', '3~10년'], ['10', '10년 넘게']] },
  { k: 'risk', q: '투자한 돈이 한 달 만에 -20%가 되면?', o: [['low', '😰 무서워서 팔 것 같아요'], ['mid', '🤔 지켜보며 기다려요'], ['high', '😎 오히려 더 사요']] },
  { k: 'share', q: '투자금은 내 전체 자산에서 어느 정도예요?', o: [['s', '10% 미만 (여윳돈)'], ['m', '10~30%'], ['l', '30~50%'], ['xl', '50% 넘게']] },
  // v4.16 — 더 다양하게 (이 답들로 AI가 '나만의 맥락'을 만들어요)
  { k: 'src', q: '투자하는 돈은 어떤 돈이에요?', o: [['pay', '💼 매달 월급에서 조금씩'], ['lump', '💰 모아 둔 목돈'], ['sev', '🎁 퇴직금·보상금'], ['loan', '🏦 빌린 돈·신용'], ['gift', '👨‍👩‍👧 상속·증여']] },
  { k: 'info', q: '투자 정보는 주로 어디서 얻으세요?', o: [['news', '📰 뉴스·신문'], ['yt', '📺 유튜브·방송'], ['chart', '📈 차트·HTS 직접'], ['ppl', '💬 주변 사람·단톡방'], ['rep', '📄 증권사 리포트·공시'], ['none', '🙈 거의 안 봐요']] },
  { k: 'dec', q: '살지 말지는 보통 어떻게 정하세요?', o: [['num', '🔢 숫자·근거를 따져서'], ['gut', '💡 느낌·직감으로'], ['follow', '👥 남들 따라서'], ['slow', '🤔 오래 고민해요']] },
  { k: 'time', q: '장중(9시~3시 반)에 시세를 볼 수 있나요?', o: [['no', '🙅 거의 못 봐요'], ['some', '🕐 하루 한두 번'], ['live', '👀 계속 볼 수 있어요']] },
  { k: 'target', q: '1년에 이 정도면 만족한다 하는 수익은?', o: [['bank', '🏦 은행 이자보다 조금 더'], ['10', '📈 10% 정도'], ['20', '🚀 20% 이상'], ['x2', '💥 두 배 이상']] },
  { k: 'asset', q: '주로 어디에 투자하세요?', o: [['kr', '🇰🇷 국내 주식'], ['us', '🇺🇸 미국 주식'], ['etf', '🧺 ETF 위주'], ['mix', '🪙 주식+코인'], ['re', '🏠 부동산이 더 커요']] },
  { k: 'learn', q: 'AI 설명은 어느 정도까지?', o: [['just', '✂️ 결론만 간단히'], ['why', '🧩 이유까지'], ['deep', '📚 공부하듯 깊게']] },
  { k: 'fam', q: '가족 상황은요?', o: [['solo', '🧍 혼자'], ['couple', '👫 부부'], ['kids', '👶 어린 자녀'], ['grown', '🎓 자녀 독립'], ['parent', '👵 부모님 부양']] },
  { k: 'worry', q: '투자하면서 가장 걱정되는 건?', o: [['loss', '📉 원금 손실'], ['miss', '🏃 기회를 놓치는 것'], ['time', '⏰ 볼 시간이 없는 것'], ['know', '❓ 모르고 하는 것'], ['tax', '🧾 세금·제도']] },
];
function profile() { return (UI.profile && typeof UI.profile === 'object') ? UI.profile : {}; }
function profileHeader() { const p = profile(); return PROFILE_Q.filter(x => p[x.k]).map(x => x.k + '=' + p[x.k]).join(';'); }
function profileText() {
  const p = profile(), out = [];
  PROFILE_Q.forEach(x => { const o = x.o.find(y => y[0] === p[x.k]); if (o) out.push(o[1].replace(/^[^0-9A-Za-z가-힣]+/, '').trim()); });
  return out.join(' · ');
}

/* 관심 섹터 (여러 개) — AI 종목 발굴·시장 흐름·대화가 이 섹터를 중점으로 봄.
   키(영문)만 서버로 보냄(머리글엔 한글 불가) → 서버 price_server.py SECTOR_INFO 와 키가 같아야 함 */
const SECTORS = [
  ['semi', '💾', '반도체'], ['battery', '🔋', '2차전지·배터리'], ['ai', '🤖', 'AI·소프트웨어'], ['platform', '🌐', '인터넷·플랫폼'],
  ['bigtech', '🍎', '미국 빅테크'], ['display', '📺', '디스플레이·전자부품'], ['robot', '🦾', '로봇·자동화'], ['space', '🛰️', '우주항공'],
  ['bio', '🧬', '바이오·제약'], ['health', '🩺', '의료기기·헬스케어'], ['auto', '🚗', '자동차·부품'], ['ship', '🚢', '조선·해운'],
  ['defense', '🛡️', '방산'], ['nuclear', '⚛️', '원전·전력기기'], ['green', '☀️', '신재생·수소'], ['chem', '🧪', '정유·화학'],
  ['steel', '🔩', '철강·소재'], ['build', '🏗️', '건설·인프라'], ['bank', '🏦', '은행·금융지주'], ['broker', '📈', '증권·보험'],
  ['beauty', '💄', '화장품·뷰티'], ['food', '🍜', '음식료·유통'], ['travel', '✈️', '여행·항공·레저'], ['content', '🎬', '엔터·K콘텐츠'],
  ['game', '🎮', '게임'], ['telecom', '📡', '통신'], ['crypto', '🪙', '가상자산 관련'], ['dividend', '💰', '고배당·리츠'], ['etf', '📊', 'ETF·지수'],
];
const SECTOR_MAP = Object.fromEntries(SECTORS.map(([k, e, l]) => [k, { key: k, emoji: e, label: l }]));
function sectors() { return (Array.isArray(UI.sectors) ? UI.sectors : []).filter(k => SECTOR_MAP[k]); }
function sectorText(max) {
  const s = sectors(); if (!s.length) return '골고루 (선택 안 함)';
  const t = s.slice(0, max || 99).map(k => SECTOR_MAP[k].emoji + ' ' + SECTOR_MAP[k].label).join(' · ');
  return s.length > (max || 99) ? t + ' 외 ' + (s.length - max) + '개' : t;
}
/* 섹터 고르기 칩 (여러 개) — box 안의 [data-sector] 를 눌러 켜고 끔 */
function sectorChipsHtml(sel) {
  return '<div class="sec-chips">' + SECTORS.map(([k, e, l]) => '<button type="button" class="sec-chip' + (sel.includes(k) ? ' on' : '') + '" data-sector="' + k + '">' + e + ' ' + l + '</button>').join('') + '</div>';
}
function wireSectorChips(box, sel, onChange) {
  box.querySelectorAll('[data-sector]').forEach(b => b.onclick = () => {
    const k = b.dataset.sector, i = sel.indexOf(k);
    if (i >= 0) sel.splice(i, 1); else sel.push(k);
    b.classList.toggle('on', i < 0);
    if (onChange) onChange(sel);
  });
}
/* 섹터 고르기 창 (설정·관심 화면에서) */
function openSectorPicker(after, first) {
  const sel = sectors().slice();
  UI.sectorAsked = true; saveUI();
  const m = openModal({ title: first ? '🎯 새 기능: 관심 섹터' : '🎯 관심 섹터 고르기', sticky: !!first, body:
    (first ? '<div class="callout info" style="margin-bottom:12px">' + icon('sparkles', 'ic-sm') + '<div>관심 있는 분야를 고르면 <b>AI 종목 정리·시장 분석·대화</b>가 그 섹터를 중점으로 봐 줘요. 사람마다 다르게!</div></div>' : '') +
    '<p class="note" style="margin:0 0 12px">관심 있는 분야를 <b>여러 개</b> 골라 주세요. 하나도 안 고르면 골고루 찾아요. 나중에 설정 → 관심 섹터에서 바꿀 수 있어요.</p>' +
    sectorChipsHtml(sel) + '<div class="sec-cnt" id="secCnt"></div>',
    foot: (first ? '<button class="btn btn-gray shrink" id="secLater">나중에</button>' : '<button class="btn btn-gray shrink" id="secClear">모두 해제</button>') +
      '<button class="btn btn-primary" id="secOk">' + icon('check') + '저장하기</button>' });
  const later = m.foot.querySelector('#secLater'); if (later) later.onclick = () => m.close();
  const cnt = () => { m.body.querySelector('#secCnt').textContent = sel.length ? sel.length + '개 골랐어요' : '아무것도 안 고르면 골고루 봐요'; };
  wireSectorChips(m.body, sel, cnt); cnt();
  const clr = m.foot.querySelector('#secClear'); if (clr) clr.onclick = () => { sel.length = 0; m.body.querySelectorAll('[data-sector]').forEach(b => b.classList.remove('on')); cnt(); };
  m.foot.querySelector('#secOk').onclick = () => {
    UI.sectors = sel.slice(); saveUI(); m.close();
    toast(sel.length ? '관심 섹터 ' + sel.length + '개로 맞췄어요' : '섹터 상관없이 골고루 봐요', 2600);
    if (after) after(); else if (['home', 'watch', 'settings', 'ai'].includes(route.page)) rerender();
    if (typeof refreshChatSet === 'function') refreshChatSet();
  };
}

/* 현재 사람·계좌 */
function P() { return S.people.find(p => p.id === S.curPerson) || S.people[0]; }
function accounts() { return P().accounts; }
/* 관심종목(즐겨찾기) — 안 가진 종목도 담아 두고 지켜봄 */
function watchlist() { const p = P(); if (!Array.isArray(p.watch)) p.watch = []; return p.watch; }
function inWatch(ticker, ccy) { return watchlist().some(w => (w.ticker || '').toUpperCase() === String(ticker || '').toUpperCase() && (w.ccy || 'KRW') === (ccy || 'KRW')); }
function findAcc(id) { return accounts().find(a => a.id === id); }
function allHoldings() { const out = []; accounts().forEach(a => a.holdings.forEach(h => out.push({ a, h }))); return out; }
function pol() { return POLICY[S.settings.policy] || POLICY.conservative; }

/* ---------------- 숫자 ---------------- */
function num(v) { const n = parseFloat(String(v == null ? '' : v).replace(/[,\s원$₩%]/g, '')); return isFinite(n) ? n : 0; }
function nf(n, d) { if (!isFinite(n)) n = 0; return n.toLocaleString('ko-KR', { maximumFractionDigits: d == null ? 2 : d, minimumFractionDigits: 0 }); }
function won(n) { return nf(Math.round(n), 0) + '원'; }
function wonS(n) { const r = Math.round(n); return (r > 0 ? '+' : r < 0 ? '-' : '') + nf(Math.abs(r), 0) + '원'; }
/* +158만원 — 좁은 칸용 (1만원 미만은 그대로) */
function wonSC(n) { const r = Math.round(n); return Math.abs(r) < 10000 ? wonS(r) : (r > 0 ? '+' : '') + compactKRW(r) + '원'; }
function money(n, ccy) { return ccy === 'USD' ? '$' + nf(n, 2) : won(n); }
function moneyS(n, ccy) { if (ccy === 'USD') return (n > 0 ? '+' : n < 0 ? '-' : '') + '$' + nf(Math.abs(n), 2); return wonS(n); }
function pct(n, d) { if (!isFinite(n)) n = 0; return (n > 0 ? '+' : '') + n.toFixed(d == null ? 2 : d) + '%'; }
function cls(n) { return n > 0.0000001 ? 'up' : n < -0.0000001 ? 'down' : 'flat'; }
function arrow(n) { return n > 0 ? '▲' : n < 0 ? '▼' : ''; }
/* 1억 2,345만원 — 어르신도 한눈에 */
function korUnit(n) {
  const neg = n < 0; let a = Math.round(Math.abs(n));
  if (a < 10000) return (neg ? '-' : '') + nf(a, 0) + '원';
  const jo = Math.floor(a / 1e12); a -= jo * 1e12;
  const eok = Math.floor(a / 1e8); a -= eok * 1e8;
  const man = Math.floor(a / 1e4);
  const parts = [];
  if (jo) parts.push(nf(jo, 0) + '조');
  if (eok) parts.push(nf(eok, 0) + '억');
  if (man) parts.push(nf(man, 0) + '만');
  return (neg ? '-' : '') + parts.join(' ') + '원';
}
function compactKRW(n) {
  const a = Math.abs(n), s = n < 0 ? '-' : '';
  if (a >= 1e12) return s + (a / 1e12).toFixed(a >= 1e13 ? 0 : 1) + '조';
  if (a >= 1e8) return s + (a / 1e8).toFixed(a >= 1e10 ? 0 : 1).replace(/\.0$/, '') + '억';
  if (a >= 1e4) return s + nf(Math.round(a / 1e4), 0) + '만';
  return s + nf(a, 0);
}
function bigMoney(v, ccy) {
  v = num(v); if (!v) return null; const a = Math.abs(v), s = v < 0 ? '-' : '';
  if ((ccy || 'USD').toUpperCase() === 'KRW') {
    if (a >= 1e12) return s + (a / 1e12).toFixed(1) + '조원';
    if (a >= 1e8) return s + nf(Math.round(a / 1e8), 0) + '억원';
    return s + nf(Math.round(a / 1e4), 0) + '만원';
  }
  if (a >= 1e12) return s + '$' + (a / 1e12).toFixed(2) + 'T';
  if (a >= 1e9) return s + '$' + (a / 1e9).toFixed(1) + 'B';
  if (a >= 1e6) return s + '$' + (a / 1e6).toFixed(1) + 'M';
  return s + '$' + nf(a, 0);
}
function priceTxt(v, ccy) { return ccy === 'USD' ? '$' + nf(v, 2) : nf(v, 0) + '원'; }

/* 날짜 */
function todayKey(d) { d = d || new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function dateLabel(k) { const p = k.split('-'); return p[0].slice(2) + '.' + p[1] + '.' + p[2]; }
function ago(ts) {
  if (!ts) return '';
  const s = Math.max(0, (Date.now() - ts) / 1000);
  if (s < 60) return '방금';
  if (s < 3600) return Math.floor(s / 60) + '분 전';
  if (s < 86400) return Math.floor(s / 3600) + '시간 전';
  if (s < 86400 * 7) return Math.floor(s / 86400) + '일 전';
  const d = new Date(ts); return (d.getMonth() + 1) + '월 ' + d.getDate() + '일';
}
function todayLong() {
  const d = new Date(); const w = '일월화수목금토'[d.getDay()];
  return d.getFullYear() + '년 ' + (d.getMonth() + 1) + '월 ' + d.getDate() + '일 (' + w + ')';
}

/* ---------------- 계산 ---------------- */
function fx() { const r = num(S.settings.fxRate); return r > 0 ? r : 1400; }
function ccyOf(h) { return h && h.ccy === 'USD' ? 'USD' : 'KRW'; }
function mult(h) { return ccyOf(h) === 'USD' ? fx() : 1; }
function mkt(h) { return ccyOf(h) === 'USD' ? 'us' : 'kr'; }
function hasT(h) { return h.target !== '' && h.target != null && num(h.target) > 0; }
function dispName(h) { return (h.name && String(h.name).trim()) ? h.name : (h.ticker || '(이름 없음)'); }
function chgFresh(h) { return h.chgAt === todayKey() && h.chg != null && isFinite(num(h.chg)); }

function hv(h) {
  const m = mult(h), qty = num(h.qty), avg = num(h.avg), cur = num(h.cur);
  const cost = avg * qty, val = cur * qty;
  const chg = chgFresh(h) ? num(h.chg) : null;
  const dayK = chg != null ? (val * m) * chg / (100 + chg) : 0;
  return { m, qty, avg, cur, cost, val, pl: val - cost, ret: cost > 0 ? (val - cost) / cost * 100 : 0,
    costK: cost * m, valK: val * m, plK: (val - cost) * m, ccy: ccyOf(h), chg, dayK };
}
function accT(a) {
  const cash = num(a.cash); let stock = 0, cost = 0, sumT = 0, day = 0, dayBase = 0;
  a.holdings.forEach(h => { const v = hv(h); stock += v.valK; cost += v.costK; if (hasT(h)) sumT += num(h.target); if (v.chg != null) { day += v.dayK; dayBase += v.valK - v.dayK; } });
  return { cash, stock, cost, sumT, asset: stock + cash, costBase: cost + cash, pl: stock - cost, ret: cost > 0 ? (stock - cost) / cost * 100 : 0, day, dayPct: dayBase > 0 ? day / dayBase * 100 : null };
}
function grand() {
  let asset = 0, stock = 0, cash = 0, cost = 0, day = 0, dayBase = 0, kr = 0, us = 0, any = false;
  accounts().forEach(a => {
    const t = accT(a); asset += t.asset; stock += t.stock; cash += t.cash; cost += t.cost;
    a.holdings.forEach(h => {
      const v = hv(h);
      if (v.ccy === 'USD') us += v.valK; else kr += v.valK;
      if (v.chg != null) { day += v.dayK; dayBase += v.valK - v.dayK; any = true; }
    });
  });
  return { asset, stock, cash, cost, pl: stock - cost, ret: cost > 0 ? (stock - cost) / cost * 100 : 0,
    day: any ? day : null, dayPct: any && dayBase > 0 ? day / dayBase * 100 : null, kr, us };
}

/* 색: 종목·계좌는 '고유색'을 계속 유지(순위가 바뀌어도 색이 안 바뀜) */
function catVar(i) { return (i != null && i >= 0 && i < CAT.length) ? 'var(' + CAT[i] + ')' : 'var(--c-other)'; }
function hColor(h) { return catVar(h.ci); }
function aColor(a) { return catVar(a.ci); }
function logoTxt(h) {
  const n = dispName(h).trim();
  if (/^[A-Za-z]/.test(n)) return (h.ticker || n).replace(/[^A-Za-z]/g, '').slice(0, 2).toUpperCase() || n[0];
  return n.slice(0, 1);
}

/* ---------------- 문자열 안전 ---------------- */
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function safeUrl(u) { u = String(u || ''); return /^https?:\/\//i.test(u) ? u : '#'; }

/* ---------------- 서버 ---------------- */
function base() { return location.protocol.indexOf('http') === 0 ? location.origin : (S.settings.serverUrl || 'http://localhost:8000'); }
async function api(path, o) {
  o = o || {};
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), o.timeout || 25000);
  try {
    const r = await fetch(base() + path, {
      method: o.method || 'GET',
      headers: Object.assign(o.body ? { 'Content-Type': 'application/json' } : {}, { 'X-AI-Depth': aiDepth(), 'X-AI-Style': tradeStyle(), 'X-AI-Sectors': sectors().join(','), 'X-AI-Profile': profileHeader(), 'X-AI-DNA': (typeof dnaHeader === 'function' && feat('dna') ? dnaHeader() : ''), 'X-AI-Persona': (typeof personaHeader === 'function' ? personaHeader() : '') }),
      body: o.body ? JSON.stringify(o.body) : undefined,
      signal: ctrl.signal, cache: 'no-store',
    });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await r.json();
  } finally { clearTimeout(t); }
}
// 안드로이드 앱 안에서 열렸는지 (앱이 화면에 이름표를 붙여 줌)
const IS_APP = /AssetAppAndroid/.test(navigator.userAgent);
const SERVER_DOWN = IS_APP ? '앱 내부 연결이 끊겼어요. 앱을 완전히 닫았다가 다시 열어 주세요.'
  : '시세 서버에 연결할 수 없어요. 바탕화면의 “내 투자 비서”로 앱을 다시 켜 주세요.';

/* ---------------- 아이콘 ---------------- */
const ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V9.5"/>',
  wallet: '<path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
  sparkles: '<path d="M12 3l1.9 5.6 5.6 1.9-5.6 1.9L12 18l-1.9-5.6-5.6-1.9 5.6-1.9z"/><path d="M19 15l.8 2.2 2.2.8-2.2.8L19 21l-.8-2.2-2.2-.8 2.2-.8z"/>',
  history: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
  rocket: '<path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/>',
  settings: '<path d="M21 4h-7M10 4H3M21 12h-9M8 12H3M21 20h-5M12 20H3M14 2v4M8 10v4M16 18v4"/>',
  refresh: '<path d="M21 12a9 9 0 0 1-15.5 6.3L3 16"/><path d="M3 21v-5h5"/><path d="M3 12a9 9 0 0 1 15.5-6.3L21 8"/><path d="M21 3v5h-5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', minus: '<path d="M5 12h14"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  'chevron-right': '<path d="m9 18 6-6-6-6"/>', 'chevron-down': '<path d="m6 9 6 6 6-6"/>', 'chevron-left': '<path d="m15 18-6-6 6-6"/>',
  'trending-up': '<path d="M22 7 13.5 15.5 8.5 10.5 2 17"/><path d="M16 7h6v6"/>',
  'trending-down': '<path d="M22 17 13.5 8.5 8.5 13.5 2 7"/><path d="M16 17h6v-6"/>',
  news: '<path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2"/><path d="M18 14h-8M15 18h-5M10 6h8v4h-8z"/>',
  external: '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
  pencil: '<path d="M17 3a2.85 2.85 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>',
  trash: '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
  power: '<path d="M12 2v10"/><path d="M18.4 6.6a9 9 0 1 1-12.77.04"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>',
  moon: '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5"/><path d="M12 3v12"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  alert: '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4M12 17h.01"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
  send: '<path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>',
  key: '<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6"/><path d="m15.5 7.5 3 3L22 7l-3-3"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
  'eye-off': '<path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.53 13.53 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><path d="m2 2 20 20"/>',
  bot: '<rect x="3" y="8" width="18" height="12" rx="3"/><path d="M12 8V4M9 4h6"/><path d="M9 14h.01M15 14h.01"/>',
  pie: '<path d="M21.2 15.9A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/>',
  card: '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/>',
  compass: '<circle cx="12" cy="12" r="10"/><path d="m16.24 7.76-2.12 6.36-6.36 2.12 2.12-6.36z"/>',
  clipboard: '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M9 12h6M9 16h4"/>',
  activity: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
  more: '<circle cx="12" cy="12" r="1.2"/><circle cx="19" cy="12" r="1.2"/><circle cx="5" cy="12" r="1.2"/>',
  calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
  message: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14a9 3 0 0 0 18 0V5"/><path d="M3 12a9 3 0 0 0 18 0"/>',
  type: '<path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
  bookmark: '<path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>',
  target: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
  gauge: '<path d="m12 14 4-4"/><path d="M3.34 19a10 10 0 1 1 17.32 0"/>',
  coins: '<circle cx="8" cy="8" r="6"/><path d="M18.09 10.37A6 6 0 1 1 10.34 18"/><path d="M7 6h1v4"/>',
  layers: '<path d="m12 2 10 5-10 5L2 7z"/><path d="m2 17 10 5 10-5"/><path d="m2 12 10 5 10-5"/>',
  wifi: '<path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><path d="M12 20h.01"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  paste: '<path d="M15 2H9a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1Z"/><path d="M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-2"/>',
  zap: '<path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/>',
  lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  heart: '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>',
  star: '<path d="M12 2l3 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.9 21l1.2-6.8-5-4.9 6.9-1z"/>',
  'star-fill': '<path d="M12 2l3 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.9 21l1.2-6.8-5-4.9 6.9-1z" fill="currentColor" stroke="none"/>',
  compass2: '<circle cx="12" cy="12" r="10"/><path d="m16 8-6 2-2 6 6-2z"/>',
  radar: '<path d="M19.07 4.93A10 10 0 1 0 22 12"/><path d="M12 12 19 5"/><circle cx="12" cy="12" r="1.5"/><path d="M12 12 8 8"/>',
};
/* 🌐 해외 뉴스 제목: 번역을 크게, 원문은 작게 (v3.7 · 설정에서 끌 수 있음)
   v3.8: 화면을 먼저 띄우고, 번역 안 된 제목은 뒤에서 받아 그 자리만 바꿈 (기다리지 않음) */
const TR_MEM = {};
function trOn() { return UI.trNews !== 'off'; }
function isForeignT(t) { t = String(t || ''); return !/[가-힣]/.test(t) && /[A-Za-z]{3,}/.test(t); }
function trOf(it) { if (!it) return ''; const t = String(it.title || '').trim(); return it.title_ko || TR_MEM[t] || ''; }
function newsT(it) { return (trOn() && trOf(it)) || (it && it.title) || ''; }
function trSpan(orig) {                                   // 번역 대기 중인 제목 — 받으면 이 자리만 바뀜
  return '<span data-tr="' + esc(orig) + '">' + esc(orig) + '</span>';
}
function newsTitleHtml(it, tag) {
  tag = tag || 'b';
  const t = (it && it.title) || '', k = trOn() ? trOf(it) : '';
  if (k) return '<' + tag + '>' + esc(k) + ' <i class="tr-badge">번역</i></' + tag + '><small class="tr-orig">' + esc(t) + '</small>';
  return '<' + tag + '>' + (trOn() && isForeignT(t) ? trSpan(t) : esc(t)) + '</' + tag + '>';
}
function trInline(it) {                                   // 카드 안 한 줄 (번역 + 원문 작게)
  const t = (it && it.title) || '', k = trOn() ? trOf(it) : '';
  if (k) return esc(k) + ' <i class="tr-badge">번역</i><small class="tr-orig">' + esc(t) + '</small>';
  return trOn() && isForeignT(t) ? trSpan(t) : esc(t);
}
let _trT = 0, _trBusy = false;
function trScan() {
  clearTimeout(_trT);
  _trT = setTimeout(() => {
    if (_trBusy || !trOn()) return;
    const els = [...document.querySelectorAll('[data-tr]:not([data-trd])')];
    els.forEach(e => { const k = TR_MEM[e.dataset.tr]; if (k) trPut(e, k); });
    const want = [...new Set(els.filter(e => !e.dataset.trd).map(e => e.dataset.tr))].slice(0, 60);
    if (!want.length) return;
    _trBusy = true;
    want.forEach(t => { TR_MEM[t] = TR_MEM[t] || ''; });
    api('/api/translate', { method: 'POST', body: { titles: want }, timeout: 30000 })
      .then(d => { Object.assign(TR_MEM, (d && d.tr) || {}); })
      .catch(() => {})
      .finally(() => {
        _trBusy = false;
        document.querySelectorAll('[data-tr]:not([data-trd])').forEach(e => { const k = TR_MEM[e.dataset.tr]; if (k) trPut(e, k); else if (want.includes(e.dataset.tr)) e.dataset.trd = 'x'; });
        trScan();                                         // 그 사이 새로 그려진 것
      });
  }, 250);
}
function trPut(e, k) {
  e.dataset.trd = '1';
  e.innerHTML = esc(k) + ' <i class="tr-badge">번역</i><small class="tr-orig">' + esc(e.dataset.tr) + '</small>';
}
try { new MutationObserver(ms => { if (ms.some(m => m.addedNodes.length)) trScan(); }).observe(document.documentElement, { childList: true, subtree: true }); } catch (e) {}
/* 긴 회사 이름 줄이기 (v4.5) — 'Taiwan Semiconductor Manufacturing Company Limited' → 'Taiwan Semiconductor Manufacturing' */
function shortNm(n, max) {
  n = String(n || '').replace(/,?\s*(Inc\.?|Incorporated|Corporation|Corp\.?|Company Limited|Co\.,?\s*Ltd\.?|Limited|Ltd\.?|Holdings?|PLC|N\.V\.|S\.A\.|AG|SE|Class [A-C]|\(The\))\s*$/i, '').trim();
  n = n.replace(/,?\s*(Inc\.?|Corporation|Corp\.?|Limited|Ltd\.?)\s*$/i, '').trim();
  max = max || 18;
  return n.length > max ? n.slice(0, max - 1) + '…' : n;
}
function icon(name, extra) { return '<span class="ic ' + (extra || '') + '"><svg viewBox="0 0 24 24">' + (ICONS[name] || '') + '</svg></span>'; }
function hydrateIcons(root) {
  (root || document).querySelectorAll('[data-icon]').forEach(el => {
    if (el.dataset.iconDone) return;
    el.innerHTML = '<svg viewBox="0 0 24 24">' + (ICONS[el.dataset.icon] || '') + '</svg>';
    el.dataset.iconDone = '1';
  });
}

/* ---------------- 알림 / 로딩 ---------------- */
let _toastT;
/* 알림 (v3.2) — 한 번에 하나씩 차례로, 같은 말은 10초 안에 다시 안 띄움, 누르면 바로 닫힘, 최대 3개까지 대기 */
const _toastQ = [], _toastSeen = {};
let _toastOn = false;
function toast(msg, ms) {
  msg = String(msg || ''); if (!msg) return;
  const now = Date.now();
  if (_toastSeen[msg] && now - _toastSeen[msg] < 10000) return;
  _toastSeen[msg] = now;
  if (_toastQ.length >= 3) _toastQ.shift();
  _toastQ.push([msg, Math.min(ms || 2400, 4000)]);
  if (!_toastOn) _toastNext();
}
function _toastNext() {
  const t = document.getElementById('toast'), it = _toastQ.shift();
  if (!it) { _toastOn = false; return; }
  _toastOn = true; t.textContent = it[0]; t.classList.add('on');
  clearTimeout(_toastT); _toastT = setTimeout(_toastHide, it[1]);
}
function _toastHide() {
  const t = document.getElementById('toast'); t.classList.remove('on');
  clearTimeout(_toastT); _toastT = setTimeout(_toastNext, 260);
}
document.addEventListener('click', e => { if (e.target.id === 'toast' && _toastOn) _toastHide(); });
function busy(msg) { document.getElementById('busyMsg').textContent = msg || '불러오는 중…'; document.getElementById('busy').classList.add('on'); }
function unbusy() { document.getElementById('busy').classList.remove('on'); }

/* ---------------- 팝업(모달 · 휴대폰에선 아래 시트) ---------------- */
const _modals = [];
function openModal(o) {
  const z = (o.top ? 460 : 100) + _modals.length * 3;   // o.top: 동의 화면 위에 띄울 창(약관 보기)
  const scrim = document.createElement('div'); scrim.className = 'scrim'; scrim.style.zIndex = z;
  const m = document.createElement('div');
  m.className = 'modal ' + (o.size || ''); m.style.zIndex = z + 1;
  m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true');
  m.innerHTML = '<div class="grip"></div><div class="modal-head">' +
    (o.back ? '<button class="icon-btn back" data-mclose-back>' + icon('chevron-left') + '</button>' : '') +
    '<h2></h2><button class="icon-btn" data-mclose aria-label="닫기">' + icon('x') + '</button></div>' +
    '<div class="modal-body"></div><div class="modal-foot"></div>';
  document.getElementById('modalRoot').append(scrim, m);
  const ctl = {
    el: m, body: m.querySelector('.modal-body'), foot: m.querySelector('.modal-foot'),
    setTitle(t) { m.querySelector('h2').innerHTML = t; },
    setBody(h) { ctl.body.innerHTML = h; hydrateIcons(ctl.body); ctl.body.scrollTop = 0; },
    setFoot(h) { ctl.foot.innerHTML = h || ''; ctl.foot.style.display = h ? '' : 'none'; hydrateIcons(ctl.foot); },
    close(v) {
      if (ctl.closed) return; ctl.closed = true;
      if (typeof hideTip === 'function') hideTip();   // 창을 닫으면 떠 있던 설명 풍선도 닫기
      const i = _modals.indexOf(ctl); if (i >= 0) _modals.splice(i, 1);
      scrim.classList.remove('on'); m.classList.remove('on');
      setTimeout(() => { scrim.remove(); m.remove(); }, 260);
      if (!_modals.length) document.body.style.overflow = '';
      if (o.onClose) o.onClose(v);
    },
    closed: false,
  };
  ctl.setTitle(o.title || '');
  ctl.setBody(o.body || '');
  ctl.setFoot(o.foot || '');
  scrim.addEventListener('click', () => { if (!o.sticky) ctl.close(); });
  m.querySelector('[data-mclose]').addEventListener('click', () => ctl.close());
  const bk = m.querySelector('[data-mclose-back]'); if (bk) bk.addEventListener('click', () => { ctl.close(); if (typeof o.back === 'function') o.back(); });
  _modals.push(ctl);
  document.body.style.overflow = 'hidden';
  requestAnimationFrame(() => { scrim.classList.add('on'); m.classList.add('on'); });
  return ctl;
}
function topModal() { return _modals[_modals.length - 1]; }
function closeAllModals() { _modals.slice().forEach(m => m.close()); }

function confirmBox(o) {
  return new Promise(res => {
    const m = openModal({
      title: o.title || '확인', size: '',
      body: '<p style="margin:0 0 6px;color:var(--text-2);line-height:1.65;font-size:.98rem">' + (o.msg || '') + '</p>',
      foot: '<button class="btn btn-gray" data-no>' + (o.cancel || '취소') + '</button><button class="btn ' + (o.danger ? 'btn-danger' : 'btn-primary') + '" data-yes>' + (o.ok || '확인') + '</button>',
      onClose: v => res(v === true),
    });
    m.foot.querySelector('[data-no]').onclick = () => m.close(false);
    m.foot.querySelector('[data-yes]').onclick = () => m.close(true);
  });
}

/* 작은 메뉴(사람 바꾸기 · 더보기) */
let _menu = null;
function openMenu(anchor, items) {
  closeMenu();
  const mn = document.createElement('div'); mn.className = 'menu';
  mn.innerHTML = items.map((it, i) => it === '-' ? '<hr>' :
    '<button data-i="' + i + '" class="' + (it.on ? 'on ' : '') + (it.danger ? 'danger' : '') + '">' + (it.icon ? icon(it.icon, 'ic-sm') : '') + '<span style="flex:1">' + esc(it.label) + '</span>' + (it.on ? icon('check', 'ic-sm') : '') + '</button>').join('');
  document.body.appendChild(mn);
  const r = anchor.getBoundingClientRect();
  const w = Math.max(mn.offsetWidth, r.width);
  mn.style.minWidth = w + 'px';
  let left = Math.min(r.left, window.innerWidth - w - 12);
  let top = r.bottom + 6;
  if (top + mn.offsetHeight > window.innerHeight - 12) top = Math.max(12, r.top - mn.offsetHeight - 6);
  mn.style.left = Math.max(12, left) + 'px'; mn.style.top = top + 'px';
  mn.addEventListener('click', e => { const b = e.target.closest('button[data-i]'); if (!b) return; const it = items[+b.dataset.i]; closeMenu(); it.act && it.act(); });
  setTimeout(() => document.addEventListener('click', closeMenu, { once: true }), 0);
  _menu = mn;
}
function closeMenu() { if (_menu) { _menu.remove(); _menu = null; } }

/* 숫자 칸 바로 고치기 */
function inlineEdit(el, value, onSave, suffix) {
  if (el.querySelector('input')) return;
  const old = el.innerHTML;
  el.innerHTML = '<input class="inline-edit tnum" inputmode="decimal" value="' + esc(value) + '">' + (suffix ? ' ' + suffix : '');
  const inp = el.querySelector('input'); inp.focus(); inp.select();
  let done = false;
  const fin = ok => { if (done) return; done = true; if (ok) onSave(num(inp.value)); else el.innerHTML = old; };
  inp.addEventListener('blur', () => fin(true));
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') inp.blur(); if (e.key === 'Escape') fin(false); });
  inp.addEventListener('click', e => e.stopPropagation());
}

/* 디바운스 */
function debounce(fn, ms) { let t; return function () { const a = arguments, th = this; clearTimeout(t); t = setTimeout(() => fn.apply(th, a), ms); }; }
