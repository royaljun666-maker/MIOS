"""
AI 엔진 (ai_engine.py)
======================

여러 AI 회사(LLM)를 한 가지 방식으로 부르는 심부름꾼입니다.
  - 키(API Key)는 앱 화면 ⚙️ 설정 → 'AI 연결'에서 넣습니다.
  - 넣은 키는 이 PC의  userdata/settings.json  에만 저장됩니다. (브라우저·인터넷 어디에도 안 올라감)
  - 예전 방식(환경변수 GEMINI_API_KEY 등)도 그대로 동작합니다.

지원 회사
  gemini      구글 Gemini            — 무료(추천)
  groq        Groq                   — 무료 · 매우 빠름
  openrouter  OpenRouter             — ':free' 모델 무료
  github      GitHub Models          — GPT-4.1 등 무료(깃허브 계정)
  mistral     Mistral                — 무료(Experiment 요금제)
  cerebras    Cerebras               — 무료 · 매우 빠름
  ollama      Ollama (내 PC)         — 완전 무료 · 인터넷 불필요
  openai      OpenAI (ChatGPT)       — 유료(선불 충전)
  anthropic   Anthropic (Claude)     — 유료(선불 충전)
"""

import json
import os
import random
import threading
import time

import requests
from flask import Blueprint, jsonify, request

HERE = os.path.dirname(os.path.abspath(__file__))
# 폰 앱에서는 앱 전용 저장 공간을 ASSET_DATA_DIR 로 넘겨받음
DATA_DIR = os.environ.get("ASSET_DATA_DIR") or os.path.join(HERE, "userdata")
SETTINGS_PATH = os.path.join(DATA_DIR, "settings.json")
AI_TIMEOUT = 60

# ---------------------------------------------------------------------------
# 제공사 목록 — 화면(설정)에 그대로 보여줍니다.
#   kind: gemini / anthropic / openai(=OpenAI 호환 API)
#   models: [모델ID, 짧은 설명]  ← 기본 추천 목록. 화면의 '목록 불러오기'로 최신 목록을 받을 수 있음
# ---------------------------------------------------------------------------
PROVIDERS = {
    "gemini": {
        "name": "Google Gemini", "kind": "gemini", "tier": "free",
        "badge": "무료 · 추천",
        "desc": "구글 계정만 있으면 무료. 한국어 실력이 좋고 가장 무난합니다.",
        "base": "https://generativelanguage.googleapis.com/v1beta",
        "key_url": "https://aistudio.google.com/app/apikey",
        "key_hint": "보통 AIza…로 시작",
        "steps": ["아래 '키 발급 페이지 열기'를 누릅니다.",
                  "구글 계정으로 로그인합니다.",
                  "'API 키 만들기(Create API key)'를 누릅니다.",
                  "만들어진 키(보통 AIza…로 시작)를 복사해서 아래 칸에 붙여넣습니다."],
        "models": [["gemini-3.1-flash-lite", "추천 · 무료 · 빠르고 많이 씀"],
                   ["gemini-2.5-flash", "똑똑하고 빠름"],
                   ["gemini-2.5-flash-lite", "무료 한도 넉넉"],
                   ["gemini-3-flash", "최신 · 균형"],
                   ["gemini-2.5-pro", "가장 깊은 분석 · 무료 한도 적음"]],
    },
    "groq": {
        "name": "Groq", "kind": "openai", "tier": "free",
        "badge": "무료 · 초고속",
        "desc": "카드 등록 없이 무료. 답이 매우 빠릅니다(Llama·GPT-OSS 등 공개 모델).",
        "base": "https://api.groq.com/openai/v1",
        "key_url": "https://console.groq.com/keys",
        "key_hint": "gsk_로 시작",
        "steps": ["'키 발급 페이지 열기'를 누릅니다.",
                  "구글 계정 등으로 가입/로그인합니다.",
                  "'Create API Key'를 누르고 이름은 아무거나 적습니다.",
                  "나온 키(gsk_…)를 복사해 붙여넣습니다. (창을 닫으면 다시 못 보니 바로 복사!)"],
        "models": [["openai/gpt-oss-120b", "추천 · OpenAI 공개모델"],
                   ["llama-3.3-70b-versatile", "메타 Llama 70B"],
                   ["qwen/qwen3-32b", "알리바바 Qwen3"],
                   ["llama-3.1-8b-instant", "가장 빠름 · 가벼움"]],
    },
    "openrouter": {
        "name": "OpenRouter", "kind": "openai", "tier": "free",
        "badge": "무료 모델 다수",
        "desc": "이름 끝이 ':free'인 모델은 무료. DeepSeek·Llama·Qwen 등 여러 회사 모델을 한 키로.",
        "base": "https://openrouter.ai/api/v1",
        "key_url": "https://openrouter.ai/settings/keys",
        "key_hint": "sk-or-로 시작",
        "steps": ["'키 발급 페이지 열기'를 누릅니다.",
                  "구글 계정 등으로 로그인합니다.",
                  "'Create Key'를 눌러 키(sk-or-…)를 만들고 복사합니다.",
                  "아래에 붙여넣고 '목록 불러오기'로 무료(:free) 모델을 고릅니다."],
        "models": [],  # 무료 모델은 자주 바뀌므로 '목록 불러오기'로 받는다(키 없이도 가능)
    },
    "github": {
        "name": "GitHub Models", "kind": "openai", "tier": "free",
        "badge": "GPT 무료",
        "desc": "깃허브 계정으로 GPT-4.1 등 OpenAI 모델을 무료로(하루 횟수 제한).",
        "base": "https://models.github.ai/inference",
        "key_url": "https://github.com/settings/personal-access-tokens/new",
        "key_hint": "github_pat_ 또는 ghp_로 시작",
        "steps": ["깃허브(github.com)에 가입/로그인합니다.",
                  "'키 발급 페이지 열기' → 이름 아무거나, 기간 선택.",
                  "아래쪽 권한(Permissions)에서 'Models'를 Read-only로 켭니다.",
                  "'Generate token'으로 만든 토큰을 복사해 붙여넣습니다."],
        "models": [["openai/gpt-4.1-mini", "추천 · GPT-4.1 mini"],
                   ["openai/gpt-4.1", "GPT-4.1 · 하루 횟수 적음"],
                   ["openai/gpt-4o-mini", "GPT-4o mini"],
                   ["deepseek/DeepSeek-V3-0324", "DeepSeek V3"]],
    },
    "mistral": {
        "name": "Mistral", "kind": "openai", "tier": "free",
        "badge": "무료",
        "desc": "프랑스 Mistral. 무료 'Experiment' 요금제로 사용(전화번호 인증 필요).",
        "base": "https://api.mistral.ai/v1",
        "key_url": "https://console.mistral.ai/api-keys",
        "key_hint": "32자리 문자",
        "steps": ["'키 발급 페이지 열기'로 가입/로그인합니다.",
                  "요금제는 무료 'Experiment'를 고릅니다(전화번호 인증).",
                  "'Create new key'로 키를 만들어 복사합니다.",
                  "아래 칸에 붙여넣습니다."],
        "models": [["mistral-small-latest", "추천 · 빠름"],
                   ["mistral-medium-latest", "균형"],
                   ["mistral-large-latest", "가장 똑똑함"]],
    },
    "cerebras": {
        "name": "Cerebras", "kind": "openai", "tier": "free",
        "badge": "무료 · 초고속",
        "desc": "카드 없이 무료. 응답 속도가 매우 빠릅니다.",
        "base": "https://api.cerebras.ai/v1",
        "key_url": "https://cloud.cerebras.ai/platform",
        "key_hint": "csk-로 시작",
        "steps": ["'키 발급 페이지 열기'로 가입/로그인합니다.",
                  "왼쪽 'API Keys' 메뉴로 갑니다.",
                  "키(csk-…)를 만들어 복사합니다.",
                  "아래 칸에 붙여넣습니다."],
        "models": [["gpt-oss-120b", "추천 · OpenAI 공개모델"],
                   ["llama-3.3-70b", "메타 Llama 70B"],
                   ["qwen-3-32b", "Qwen3 32B"]],
    },
    "ollama": {
        "name": "Ollama (내 PC)", "kind": "openai", "tier": "local",
        "badge": "완전 무료 · 오프라인",
        "desc": "AI를 내 컴퓨터에서 직접 돌립니다. 키·인터넷 불필요. 대신 PC 사양(메모리 16GB+)이 필요합니다.",
        "base": "http://localhost:11434",
        "key_url": "https://ollama.com/download",
        "key_hint": "키 필요 없음",
        "no_key": True,
        "steps": ["'설치 페이지 열기'에서 Ollama를 내려받아 설치합니다.",
                  "명령창(cmd)에서  ollama pull qwen3:8b  를 한 번 실행합니다.",
                  "아래 '목록 불러오기'로 설치된 모델을 고릅니다."],
        "models": [["qwen3:8b", "추천 · 한국어 무난"],
                   ["gemma3:12b", "구글 Gemma3"],
                   ["llama3.1:8b", "메타 Llama"]],
    },
    "openai": {
        "name": "OpenAI (ChatGPT)", "kind": "openai", "tier": "paid",
        "badge": "유료",
        "desc": "ChatGPT를 만든 회사. API는 무료가 없고 선불 충전($5~)이 필요합니다. ChatGPT Plus 구독과는 별개입니다.",
        "base": "https://api.openai.com/v1",
        "key_url": "https://platform.openai.com/api-keys",
        "key_hint": "sk-로 시작",
        "steps": ["'키 발급 페이지 열기'로 로그인합니다.",
                  "Billing에서 선불 금액을 충전합니다(무료 없음).",
                  "'Create new secret key'로 키(sk-…)를 만들어 복사합니다.",
                  "아래 칸에 붙여넣습니다."],
        "models": [["gpt-5-mini", "추천 · 가성비"],
                   ["gpt-5-nano", "가장 저렴"],
                   ["gpt-4.1-mini", "GPT-4.1 mini"]],
    },
    "anthropic": {
        "name": "Anthropic (Claude)", "kind": "anthropic", "tier": "paid",
        "badge": "유료",
        "desc": "Claude를 만든 회사. API는 선불 충전($5~)이 필요합니다. Claude 구독(Pro)과는 별개입니다.",
        "base": "https://api.anthropic.com/v1",
        "key_url": "https://console.anthropic.com/settings/keys",
        "key_hint": "sk-ant-로 시작",
        "steps": ["'키 발급 페이지 열기'로 로그인합니다.",
                  "Billing에서 선불 크레딧을 충전합니다.",
                  "'Create Key'로 키(sk-ant-…)를 만들어 복사합니다.",
                  "아래 칸에 붙여넣습니다."],
        "models": [["claude-haiku-4-5-20251001", "추천 · 빠르고 저렴"],
                   ["claude-sonnet-5-5", "균형 · 똑똑함"],
                   ["claude-opus-5-5", "가장 똑똑함 · 비쌈"]],
    },
}
ORDER = ["gemini", "groq", "openrouter", "github", "mistral", "cerebras", "ollama", "openai", "anthropic"]

# 구글 서버 혼잡(503) 때 자동으로 바꿔 시도할 Gemini 모델
# 기본 모델이 그 키에서 안 될 때(모델 이름 없음·과부하) 순서대로 대신 시도
GEM_FALLBACK = ["gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-3-flash"]


# ---------------------------------------------------------------------------
# 설정 파일 (userdata/settings.json)
# ---------------------------------------------------------------------------
_LOCK = threading.Lock()


def load_settings():
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            s = json.load(f)
            if isinstance(s, dict):
                return s
    except Exception:
        pass
    return {}


def save_settings(s):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = SETTINGS_PATH + ".tmp"
    with _LOCK:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False, indent=2)
        os.replace(tmp, SETTINGS_PATH)


def mask(key):
    key = (key or "").strip()
    if not key:
        return ""
    if len(key) <= 10:
        return key[:2] + "…"
    return key[:4] + "…" + key[-4:]


def _configured(pid, cfg):
    if not cfg:
        return False
    if PROVIDERS.get(pid, {}).get("no_key"):
        return bool(cfg.get("model"))
    return bool((cfg.get("key") or "").strip())


def default_model(pid):
    ms = PROVIDERS.get(pid, {}).get("models") or []
    return ms[0][0] if ms else ""


# ---------------------------------------------------------------------------
# 에러 → 쉬운 한국어
# ---------------------------------------------------------------------------
class AIError(Exception):
    def __init__(self, code, msg, detail=""):
        super().__init__(msg)
        self.code = code
        self.msg = msg
        self.detail = detail


def _extract_msg(body_text):
    """AI 회사가 보낸 오류 본문(JSON)에서 사람이 읽을 문장만 꺼냄."""
    try:
        j = json.loads(body_text)
        e = j.get("error", j) if isinstance(j, dict) else j
        if isinstance(e, dict):
            return str(e.get("message") or e.get("msg") or e)[:200]
        if isinstance(e, list) and e and isinstance(e[0], dict):
            return str((e[0].get("error") or {}).get("message") or e[0])[:200]
        return str(e)[:200]
    except Exception:
        return (body_text or "")[:200]


def _friendly(status, body_text, pid):
    t = _extract_msg(body_text)
    low = (body_text or "")[:600].lower()
    if "access_token_type_unsupported" in low or "expected oauth 2 access token" in low:
        return AIError("auth", "이 키는 지금 쓸 수 없는 형식이에요. 키 발급 페이지에서 'API 키 만들기'로 새 키(보통 AIza로 시작)를 만들어 붙여넣어 주세요.", t)
    if status in (401, 403) or "api key not valid" in low or "invalid api key" in low or "unauthorized" in low:
        return AIError("auth", "키가 올바르지 않아요. 키를 다시 복사해서 붙여넣어 주세요.", t)
    if status == 402 or "insufficient" in low or "credit" in low or "billing" in low:
        return AIError("billing", "충전된 금액(크레딧)이 없어요. 이 회사는 유료라 선불 충전이 필요합니다.", t)
    if status == 429 or "quota" in low or "rate limit" in low or "resource_exhausted" in low:
        return AIError("quota", "오늘(또는 1분) 무료 사용 한도를 다 썼어요. 잠시 후 다시 하거나 다른 AI를 추가해 두세요.", t)
    if status == 404 or "not found" in low or "does not exist" in low or "model_not_found" in low:
        return AIError("model", "이 모델 이름을 찾을 수 없어요. '목록 불러오기'로 모델을 다시 골라 주세요.", t)
    if status in (500, 502, 503, 504) or "overloaded" in low or "unavailable" in low:
        return AIError("busy", "AI 회사 서버가 지금 붐벼요. 잠시 후 다시 시도해 주세요.", t)
    return AIError("other", f"AI 호출 실패 (HTTP {status})", t)


def _post(url, headers, body, pid):
    """일시 장애(5xx)는 재시도, 429는 한 번만 짧게 재시도."""
    last_err = None
    for i in range(3):
        try:
            r = requests.post(url, headers=headers, json=body, timeout=AI_TIMEOUT)
        except requests.exceptions.ConnectionError:
            if pid == "ollama":
                raise AIError("network", "Ollama가 켜져 있지 않아요. Ollama 프로그램을 실행해 주세요.")
            last_err = AIError("network", "인터넷 연결을 확인해 주세요.")
            time.sleep(1.5 * (i + 1))
            continue
        except requests.exceptions.Timeout:
            last_err = AIError("busy", "AI 응답이 너무 늦어요(시간 초과). 잠시 후 다시 시도해 주세요.")
            continue
        if r.status_code < 400:
            return r
        err = _friendly(r.status_code, r.text, pid)
        if err.code == "busy" and i < 2:
            time.sleep((2 ** i) + random.uniform(0, 1))
            last_err = err
            continue
        if err.code == "quota" and i == 0 and "per minute" in r.text.lower():
            time.sleep(2.5)
            last_err = err
            continue
        raise err
    raise last_err or AIError("other", "AI 호출 실패")


# ---------------------------------------------------------------------------
# 호출
# ---------------------------------------------------------------------------
def call(pid, key, model, prompt=None, max_out=1200, base_url=None,
         system=None, messages=None, temperature=0.7):
    """한 번 호출. messages=[{"role":"user"|"assistant","content":"..."}] 를 주면 대화형."""
    p = PROVIDERS.get(pid)
    if not p:
        raise AIError("other", f"알 수 없는 AI 회사: {pid}")
    msgs = list(messages or [])
    if prompt:
        msgs.append({"role": "user", "content": prompt})
    if not msgs:
        raise AIError("other", "보낼 내용이 없어요.")
    kind = p["kind"]

    if kind == "gemini":
        url = f"{p['base']}/models/{model}:generateContent"
        headers = {"x-goog-api-key": key, "content-type": "application/json"}
        gen = {"temperature": temperature, "maxOutputTokens": max_out}
        # 2.5 flash 계열은 '생각'에 토큰을 써서 본문이 잘림 → 끔. (pro 는 끌 수 없음)
        if model.startswith("gemini-2.5-flash"):
            gen["thinkingConfig"] = {"thinkingBudget": 0}
        body = {"contents": [{"role": "model" if m["role"] == "assistant" else "user",
                              "parts": [{"text": m["content"]}]} for m in msgs],
                "generationConfig": gen}
        if system:
            body["systemInstruction"] = {"parts": [{"text": system}]}
        r = _post(url, headers, body, pid)
        j = r.json()
        cands = j.get("candidates") or []
        parts = (cands[0].get("content", {}).get("parts") if cands else []) or []
        text = "".join(x.get("text", "") for x in parts if not x.get("thought")).strip()
        if not text and cands and cands[0].get("finishReason") == "SAFETY":
            raise AIError("other", "AI가 안전 정책으로 답을 거절했어요. 질문을 바꿔 보세요.")
        return text

    if kind == "anthropic":
        url = f"{p['base']}/messages"
        headers = {"x-api-key": key, "anthropic-version": "2023-06-01",
                   "content-type": "application/json"}
        body = {"model": model, "max_tokens": max_out, "messages": msgs}
        if system:
            body["system"] = system
        r = _post(url, headers, body, pid)
        blocks = r.json().get("content", []) or []
        return "".join(b.get("text", "") for b in blocks if b.get("type") == "text").strip()

    # OpenAI 호환(OpenAI·Groq·OpenRouter·GitHub·Mistral·Cerebras·Ollama)
    base = (base_url or p["base"]).rstrip("/")
    if pid == "ollama" and not base.endswith("/v1"):
        base += "/v1"
    url = f"{base}/chat/completions"
    headers = {"content-type": "application/json"}
    if key:
        headers["authorization"] = f"Bearer {key}"
    if pid == "openrouter":
        headers["HTTP-Referer"] = "http://localhost"
        headers["X-Title"] = "My Asset App"
    full = ([{"role": "system", "content": system}] if system else []) + msgs
    body = {"model": model, "messages": full}
    if pid == "openai":
        # 최신 OpenAI 모델은 max_tokens 대신 max_completion_tokens, temperature 고정
        body["max_completion_tokens"] = max_out * (4 if model.startswith(("gpt-5", "o")) else 1)
        if not model.startswith(("gpt-5", "o")):
            body["temperature"] = temperature
    else:
        body["max_tokens"] = max_out
        body["temperature"] = temperature
    r = _post(url, headers, body, pid)
    j = r.json()
    ch = (j.get("choices") or [{}])[0]
    text = ((ch.get("message") or {}).get("content") or "").strip()
    # 일부 추론 모델은 <think>…</think> 를 본문에 섞어 보냄 → 제거
    if "<think>" in text and "</think>" in text:
        text = text.split("</think>", 1)[1].strip()
    return text


def list_models(pid, key="", base_url=None):
    """그 회사에서 지금 쓸 수 있는 모델 목록 [[id, 설명], ...]."""
    p = PROVIDERS[pid]
    kind = p["kind"]
    out = []
    if kind == "gemini":
        r = requests.get(f"{p['base']}/models?pageSize=200", headers={"x-goog-api-key": key}, timeout=15)
        if r.status_code >= 400:
            raise _friendly(r.status_code, r.text, pid)
        skip = ("embedding", "tts", "image", "vision", "live", "audio", "aqa", "learnlm", "thinking", "-exp")
        prev = []
        for m in r.json().get("models", []) or []:
            nm = (m.get("name") or "").replace("models/", "")
            if "generateContent" not in (m.get("supportedGenerationMethods") or []) or not nm.startswith("gemini"):
                continue
            if any(x in nm for x in skip):
                continue
            row = [nm, m.get("displayName") or ""]
            (prev if ("preview" in nm or "-pre" in nm) else out).append(row)
        # 정식 모델 먼저(최신순), 그다음 preview. 깔끔한 이름만 보이게.
        out.sort(key=lambda x: x[0], reverse=True)
        prev.sort(key=lambda x: x[0], reverse=True)
        res = out + prev
        return res if res else [[nm, dn] for nm, dn in ((m.get("name", "").replace("models/", ""), m.get("displayName", ""))
                                                        for m in r.json().get("models", []) or []) if nm.startswith("gemini")]
    if kind == "anthropic":
        r = requests.get(f"{p['base']}/models?limit=100",
                         headers={"x-api-key": key, "anthropic-version": "2023-06-01"}, timeout=15)
        if r.status_code >= 400:
            raise _friendly(r.status_code, r.text, pid)
        return [[m["id"], m.get("display_name", "")] for m in r.json().get("data", [])]
    if pid == "ollama":
        base = (base_url or p["base"]).rstrip("/")
        if base.endswith("/v1"):
            base = base[:-3]
        try:
            r = requests.get(f"{base}/api/tags", timeout=5)
        except requests.exceptions.ConnectionError:
            raise AIError("network", "Ollama가 켜져 있지 않아요. Ollama 프로그램을 실행해 주세요.")
        return [[m["name"], f"{round((m.get('size') or 0) / 1e9, 1)}GB"] for m in r.json().get("models", [])]
    if pid == "openrouter":
        r = requests.get(f"{p['base']}/models", timeout=15)
        r.raise_for_status()
        known = ("deepseek/", "meta-llama/", "google/", "qwen/", "mistralai/", "openai/", "moonshotai/", "z-ai/", "nvidia/")
        for m in r.json().get("data", []):
            if not m["id"].endswith(":free"):   # 가격 0이어도 ':free'가 아닌 미리보기 모델은 제외
                continue
            ctx = m.get("context_length") or 0
            out.append([m["id"], (m.get("name") or "") + (f" · {ctx // 1000}K" if ctx else "")])
        out.sort(key=lambda x: (0 if x[0].startswith(known) else 1, x[0]))
        return out
    if pid == "github":
        r = requests.get("https://models.github.ai/catalog/models",
                         headers={"authorization": f"Bearer {key}"} if key else {}, timeout=15)
        if r.status_code >= 400:
            raise _friendly(r.status_code, r.text, pid)
        for m in r.json():
            mods = m.get("supported_output_modalities") or ["text"]
            if "text" in mods and "embedding" not in (m.get("id") or ""):
                out.append([m["id"], m.get("name") or ""])
        return out
    r = requests.get(f"{p['base']}/models", headers={"authorization": f"Bearer {key}"}, timeout=15)
    if r.status_code >= 400:
        raise _friendly(r.status_code, r.text, pid)
    skip = ("embed", "whisper", "tts", "dall-e", "image", "audio", "moderation", "realtime",
            "transcribe", "guard", "search", "davinci", "babbage", "ocr")
    for m in r.json().get("data", []):
        mid = m.get("id") or ""
        if mid and not any(s in mid.lower() for s in skip):
            out.append([mid, ""])
    out.sort(key=lambda x: x[0])
    return out


# ---------------------------------------------------------------------------
# 후보 순서: 기본 AI → (자동 대체 켜짐) 다른 등록 AI들 → 예전 환경변수 키
# ---------------------------------------------------------------------------
def candidates():
    s = load_settings()
    provs = s.get("providers") or {}
    prim = s.get("primary")
    out, seen = [], set()

    def add(pid, key, model, base=None):
        k = (pid, key, model)
        if model and k not in seen:
            seen.add(k)
            out.append((pid, key, model, base))

    def add_cfg(pid):
        cfg = provs.get(pid) or {}
        if pid not in PROVIDERS or not _configured(pid, cfg):
            return
        model = cfg.get("model") or default_model(pid)
        add(pid, (cfg.get("key") or "").strip(), model, cfg.get("base_url"))
        if pid == "gemini":
            for m in GEM_FALLBACK:
                add(pid, cfg["key"].strip(), m)

    if prim:
        add_cfg(prim)
    if s.get("auto_fallback", True) or not prim:
        for pid in ORDER:
            if pid != prim:
                add_cfg(pid)

    # 예전 방식: 환경변수
    def env_keys(*names):
        ks = []
        for n in names:
            for part in (os.environ.get(n) or "").split(","):
                part = part.strip()
                if part and part not in ks:
                    ks.append(part)
        return ks
    env_model = os.environ.get("AI_MODEL")
    for k in env_keys("GEMINI_API_KEY", "GEMINI_API_KEY2", "GEMINI_API_KEY3", "GOOGLE_API_KEY"):
        for m in ([env_model] if env_model and env_model.startswith("gemini") else []) + GEM_FALLBACK:
            add("gemini", k, m)
    for k in env_keys("ANTHROPIC_API_KEY", "ANTHROPIC_API_KEY2"):
        add("anthropic", k, os.environ.get("AI_MODEL_ANTHROPIC") or default_model("anthropic"))
    for k in env_keys("OPENAI_API_KEY"):
        add("openai", k, os.environ.get("AI_MODEL_OPENAI") or default_model("openai"))
    for k in env_keys("GROQ_API_KEY"):
        add("groq", k, default_model("groq"))
    return out


def has_ai():
    return bool(candidates())


def complete(prompt=None, max_out=1200, system=None, messages=None, temperature=0.7):
    """후보를 차례로 시도. 반환 (text, provider_name, model, error_message)."""
    cands = candidates()
    if not cands:
        return (None, None, None, "NO_KEY")
    last = None
    bad_keys = set()
    for pid, key, model, base in cands:
        # 키가 틀렸거나 충전이 없으면 같은 키의 다른 모델은 건너뜀.
        # (한도 초과는 Gemini처럼 '모델별' 한도인 곳이 있어 다른 모델은 계속 시도)
        if (pid, key) in bad_keys:
            continue
        try:
            text = call(pid, key, model, prompt=prompt, max_out=max_out, base_url=base,
                        system=system, messages=messages, temperature=temperature)
            if text:
                return (text, PROVIDERS[pid]["name"], model, None)
            last = AIError("other", "AI가 빈 답을 보냈어요.")
        except AIError as e:
            last = e
            if e.code in ("auth", "billing"):
                bad_keys.add((pid, key))
        except Exception as e:  # 예상 못 한 오류도 다음 후보로
            last = AIError("other", f"{type(e).__name__}")
    msg = last.msg if isinstance(last, AIError) else str(last)
    for _, k, _, _ in cands:
        if k:
            msg = msg.replace(k, "***")
    return (None, None, None, msg)


def status_summary():
    s = load_settings()
    cands = candidates()
    if not cands:
        return {"on": False, "provider": None, "model": None, "count": 0}
    pid, _, model, _ = cands[0]
    n = len({(c[0], c[1]) for c in cands})
    return {"on": True, "provider": PROVIDERS[pid]["name"], "provider_id": pid,
            "model": model, "count": n, "auto_fallback": s.get("auto_fallback", True)}


# ---------------------------------------------------------------------------
# 화면(설정)용 API
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 관심 섹터 — 화면이 'X-AI-Sectors: semi,battery' 처럼 키만 보냄 (web/js/core.js SECTORS 와 키가 같아야 함)
# ---------------------------------------------------------------------------
SECTOR_INFO = {
    "semi": "반도체 (메모리·파운드리·장비·소재·AI칩 설계)",
    "battery": "2차전지·배터리 (셀·양극재·음극재·전해질·분리막·리튬)",
    "ai": "AI·소프트웨어 (AI 서비스·클라우드·데이터센터 소프트웨어·보안)",
    "platform": "인터넷·플랫폼 (검색·메신저·커머스·핀테크)",
    "bigtech": "미국 빅테크 (대형 기술주)",
    "display": "디스플레이·전자부품 (OLED·기판·카메라모듈·MLCC)",
    "robot": "로봇·자동화 (산업용·협동 로봇·감속기·스마트팩토리)",
    "space": "우주항공 (위성·발사체·항공기 부품)",
    "bio": "바이오·제약 (신약·바이오시밀러·CDMO·비만/항암 치료제)",
    "health": "의료기기·헬스케어 (미용의료·진단·임플란트·디지털 헬스)",
    "auto": "자동차·부품 (완성차·전장·타이어·전기차 부품)",
    "ship": "조선·해운 (LNG선·선박 엔진·기자재·해운사)",
    "defense": "방산 (무기 수출·K방산·탄약·레이더)",
    "nuclear": "원전·전력기기 (원전 설비·SMR·변압기·전선·전력망)",
    "green": "신재생·수소 (태양광·풍력·수소·연료전지)",
    "chem": "정유·화학 (정유·석유화학·특수화학)",
    "steel": "철강·소재 (철강·비철금속·희토류·소재)",
    "build": "건설·인프라 (건설·시멘트·해외 수주·인프라)",
    "bank": "은행·금융지주 (밸류업·배당·주주환원)",
    "broker": "증권·보험 (증권사·손해/생명보험)",
    "beauty": "화장품·뷰티 (K뷰티 수출·ODM·인디 브랜드)",
    "food": "음식료·유통 (K푸드 수출·라면·편의점·백화점)",
    "travel": "여행·항공·레저 (항공·여행사·카지노·호텔)",
    "content": "엔터·K콘텐츠 (K팝 기획사·드라마/영화 제작·웹툰)",
    "game": "게임 (모바일·PC·콘솔 게임사)",
    "telecom": "통신 (이동통신사·통신장비)",
    "crypto": "가상자산 관련 (거래소 지분·비트코인 보유 기업·블록체인)",
    "dividend": "고배당·리츠 (배당주·부동산 리츠)",
    "etf": "ETF·지수 (국내외 대표 지수·테마 ETF)",
}


def req_sectors(extra=None):
    """요청의 관심 섹터 키 목록 (머리글 + 본문). 모르는 키는 버림."""
    raw = []
    try:
        raw += [x.strip() for x in str(request.headers.get("X-AI-Sectors", "")).split(",")]
    except Exception:
        pass
    if isinstance(extra, list):
        raw += [str(x).strip() for x in extra]
    out = []
    for k in raw:
        if k in SECTOR_INFO and k not in out:
            out.append(k)
    return out[:15]


def sector_names(keys):
    return [SECTOR_INFO[k].split(" (")[0] for k in keys]


def sector_lines(keys):
    return "\n".join("- " + SECTOR_INFO[k] for k in keys)


bp = Blueprint("ai", __name__)


def _local_request():
    """설정 변경은 이 앱 화면(같은 주소)에서 온 요청만 허용 — 다른 웹사이트가 몰래 못 바꾸게."""
    origin = request.headers.get("Origin")
    if not origin or origin == "null":
        return True
    host = request.host_url.rstrip("/")
    return origin.rstrip("/") == host


ENV_NAMES = {"gemini": ("GEMINI_API_KEY", "GEMINI_API_KEY2", "GEMINI_API_KEY3", "GOOGLE_API_KEY"),
             "anthropic": ("ANTHROPIC_API_KEY", "ANTHROPIC_API_KEY2"),
             "openai": ("OPENAI_API_KEY",), "groq": ("GROQ_API_KEY",)}


@bp.get("/api/ai/providers")
def api_providers():
    s = load_settings()
    provs = s.get("providers") or {}
    out = []
    for pid in ORDER:
        p = PROVIDERS[pid]
        cfg = provs.get(pid) or {}
        env = next((n for n in ENV_NAMES.get(pid, ()) if (os.environ.get(n) or "").strip()), None)
        out.append({
            "env": env,
            "id": pid, "name": p["name"], "tier": p["tier"], "badge": p["badge"], "desc": p["desc"],
            "key_url": p["key_url"], "key_hint": p["key_hint"], "steps": p["steps"],
            "no_key": bool(p.get("no_key")), "models": p["models"],
            "default_base": p["base"] if pid == "ollama" else None,
            "configured": _configured(pid, cfg), "key_masked": mask(cfg.get("key")),
            "model": cfg.get("model") or default_model(pid), "base_url": cfg.get("base_url") or "",
        })
    return jsonify({"providers": out, "primary": s.get("primary"),
                    "auto_fallback": s.get("auto_fallback", True), "status": status_summary()})


@bp.post("/api/ai/settings")
def api_save_settings():
    if not _local_request():
        return jsonify({"ok": False, "error": "허용되지 않은 요청"}), 403
    d = request.get_json(force=True, silent=True) or {}
    s = load_settings()
    provs = s.setdefault("providers", {})
    pid = d.get("provider")
    if pid:
        if pid not in PROVIDERS:
            return jsonify({"ok": False, "error": "알 수 없는 AI"}), 400
        cfg = provs.setdefault(pid, {})
        if d.get("remove"):
            provs.pop(pid, None)
            if s.get("primary") == pid:
                s["primary"] = next((x for x in ORDER if _configured(x, provs.get(x))), None)
        else:
            if isinstance(d.get("key"), str) and d["key"].strip():
                cfg["key"] = d["key"].strip()
            if isinstance(d.get("model"), str) and d["model"].strip():
                cfg["model"] = d["model"].strip()
            if isinstance(d.get("base_url"), str):
                cfg["base_url"] = d["base_url"].strip()
            if d.get("make_primary") or not s.get("primary"):
                if _configured(pid, cfg):
                    s["primary"] = pid
    if "primary" in d and (d["primary"] in PROVIDERS or d["primary"] is None):
        s["primary"] = d["primary"]
    if "auto_fallback" in d:
        s["auto_fallback"] = bool(d["auto_fallback"])
    save_settings(s)
    return jsonify({"ok": True, "status": status_summary()})


@bp.post("/api/ai/test")
def api_test():
    if not _local_request():
        return jsonify({"ok": False, "error": "허용되지 않은 요청"}), 403
    d = request.get_json(force=True, silent=True) or {}
    pid = d.get("provider")
    if pid not in PROVIDERS:
        return jsonify({"ok": False, "error": "알 수 없는 AI"}), 400
    cfg = (load_settings().get("providers") or {}).get(pid) or {}
    key = (d.get("key") or "").strip() or (cfg.get("key") or "")
    model = (d.get("model") or "").strip() or cfg.get("model") or default_model(pid)
    base = (d.get("base_url") or "").strip() or cfg.get("base_url") or None
    if not key and not PROVIDERS[pid].get("no_key"):
        return jsonify({"ok": False, "error": "키를 먼저 붙여넣어 주세요."})
    t0 = time.time()
    try:
        text = call(pid, key, model, prompt="안녕하세요. 한 문장으로 짧게 인사해 주세요.",
                    max_out=80, base_url=base)
        return jsonify({"ok": True, "reply": (text or "")[:200], "model": model,
                        "ms": int((time.time() - t0) * 1000)})
    except AIError as e:
        return jsonify({"ok": False, "error": e.msg, "code": e.code, "detail": e.detail[:200]})
    except Exception as e:
        return jsonify({"ok": False, "error": f"연결 실패: {type(e).__name__}"})


@bp.post("/api/ai/models")
def api_models():
    if not _local_request():
        return jsonify({"ok": False, "error": "허용되지 않은 요청"}), 403
    d = request.get_json(force=True, silent=True) or {}
    pid = d.get("provider")
    if pid not in PROVIDERS:
        return jsonify({"ok": False, "error": "알 수 없는 AI"}), 400
    cfg = (load_settings().get("providers") or {}).get(pid) or {}
    key = (d.get("key") or "").strip() or (cfg.get("key") or "")
    base = (d.get("base_url") or "").strip() or cfg.get("base_url") or None
    if not key and not PROVIDERS[pid].get("no_key") and pid != "openrouter":
        return jsonify({"ok": False, "error": "키를 먼저 붙여넣어 주세요."})
    try:
        return jsonify({"ok": True, "models": list_models(pid, key, base)})
    except AIError as e:
        return jsonify({"ok": False, "error": e.msg})
    except Exception as e:
        return jsonify({"ok": False, "error": f"목록을 못 가져왔어요: {type(e).__name__}"})


@bp.post("/api/ai/chat")
def api_chat():
    """포트폴리오 상담 대화. context(내 포트 요약)를 시스템 지시로 붙여 보냄."""
    d = request.get_json(force=True, silent=True) or {}
    msgs = [m for m in (d.get("messages") or [])
            if isinstance(m, dict) and m.get("role") in ("user", "assistant") and m.get("content")][-12:]
    if not msgs or msgs[-1]["role"] != "user":
        return jsonify({"status": "fail", "text": "질문이 비어 있어요."})
    ctx = str(d.get("context") or "")[:6000]
    styles = {"long": ("장기투자", "앞으로 1년"), "swing": ("스윙매매", "앞으로 1~3개월"),
              "day": ("단타", "앞으로 1주일"), "scalp": ("스캘핑", "오늘~내일")}
    s_label, s_hz = styles.get(str(d.get("style") or ""), styles["long"])
    depths = {  # 설명 방식: (지시, 길이 배율)
        "brief": ("설명 방식: 간략하게 — 결론·확률·할 일 위주로 5~8줄.", 0.8),
        "easy": ("설명 방식: 쉽게(주식 초보) — 용어는 괄호로 풀고 생활 비유로, 15~25줄 충분히.", 1.4),
        "serious": ("설명 방식: 진중하게 — 근거와 반대 근거, 낙관/기본/비관 시나리오와 위험을 꼼꼼히, 20~30줄.", 1.7),
        "expert": ("설명 방식: 전문가처럼 — 밸류에이션·실적 추정·수급·기술적 수치·업종 비교·촉매를 전문 용어로 상세히, 20~35줄.", 1.9),
        "teacher": ("설명 방식: 선생님처럼 — '무엇→왜→예를 들면' 순서로 차근차근, 마지막에 '📚 오늘의 투자 공부:' 단락.", 1.7),
    }
    tone_line, d_mult = depths.get(request.headers.get("X-AI-Depth", ""), depths["easy"])
    system = (
        "당신은 바쁜 한국 개인투자자의 똑똑한 투자비서입니다. 한국어로 답하세요.\n"
        f"- {tone_line}\n"
        f"- 이 사용자의 투자 성향은 '{s_label}'입니다. 판단 기간은 기본 {s_hz}로 잡으세요.\n"
        + (f"- 이 사용자의 관심 섹터: {', '.join(sector_names(req_sectors()))}. 종목 추천·투자 아이디어를 물으면 이 섹터를 먼저 중점으로 보되, "
           "다른 섹터가 분명히 더 나으면 솔직히 그렇게 말하세요.\n" if req_sectors() else "") +
        "- 첫 줄에 결론부터 한 문장으로. '그래서 사? 말아? 지금? 언제?'에 바로 답이 되게. 빈말 금지.\n"
        "- 그다음 이유를 목록으로. 전체 길이와 깊이는 위 설명 방식을 따르세요.\n"
        "- 뉴스·이슈는 '주가에 오름/내림 · 강/중/약 · 얼마나 오래' 영향까지 말하고, 금리·환율·업종 분위기·외국인 수급 같은 시장 흐름과 연결하세요.\n"
        "- 쉬운 우리말로. 전문용어는 괄호로 뜻을 붙이세요.\n"
        f"- 오를지·내릴지, 사도 될지 같은 질문에는 '{s_hz} 오를 확률 65%'처럼 확률과 함께 "
        "'적극 매수 / 매수 / 분할 매수 / 보유 / 비중 축소 / 매도' 중 하나로 분명한 의견을 주세요. "
        "확률은 10~90 사이, 5% 단위, 50%는 피하세요. 가능하면 매수·손절 참고선을 현재가 대비 %로.\n"
        "- 자료에 없는 최신 시세·뉴스는 지어내지 말고 '시세 갱신 후 다시 물어봐 주세요'라고 하세요.\n"
        "- 아래 [내 포트폴리오]의 숫자는 앱이 계산한 사실입니다. 숫자를 바꾸거나 새로 지어내지 마세요.\n\n"
        "[내 포트폴리오]\n" + (ctx or "(정보 없음)"))
    text, prov, mdl, err = complete(messages=msgs, system=system, max_out=min(8192, int(2000 * d_mult)))
    if err == "NO_KEY":
        return jsonify({"status": "no_key", "text": "AI가 아직 연결되지 않았어요. 설정 → AI 연결에서 무료 키를 넣어 주세요."})
    if not text:
        return jsonify({"status": "fail", "text": err or "답을 받지 못했어요."})
    return jsonify({"status": "ok", "provider": prov, "model": mdl, "text": text})
